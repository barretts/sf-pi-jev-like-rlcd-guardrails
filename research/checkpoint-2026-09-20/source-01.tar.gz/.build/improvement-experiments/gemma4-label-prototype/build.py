"""Compile/link only, using existing libraries; never execute the native output."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = HERE / "main.cpp"
BINARY = HERE / "gemma4-label-prototype"
VENDOR = ROOT / ".vendor/llama.cpp"
LIBDIR = ROOT / ".build/llama"
LIBRARIES = [
    LIBDIR / "src/libllama.a",
    LIBDIR / "common/libllama-common.a",
    LIBDIR / "src/libllama.a",
    LIBDIR / "ggml/src/libggml.a",
    LIBDIR / "ggml/src/libggml-cpu.a",
    LIBDIR / "ggml/src/ggml-metal/libggml-metal.a",
    LIBDIR / "ggml/src/libggml-base.a",
    LIBDIR / "common/libllama-common-base.a",
    LIBDIR / "vendor/cpp-httplib/libcpp-httplib.a",
]
PROTECTED = [
    ROOT / name for name in (
        "native/main.cpp", "src/core.ts", "src/backend.ts", "src/models.ts",
        "dist/core.js", "dist/backend.js", "dist/models.js", "models/registry.json",
        "models/gemma-4-31B-it.chat_template.jinja",
    )
]

def digest(path):
    h = sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def identities(paths):
    return {str(p.relative_to(ROOT)): digest(p) for p in dict.fromkeys(paths) if p.is_file()}

source_sha = digest(SOURCE)
before = identities(PROTECTED)
argv = [
    "/usr/bin/c++", "-O2", "-DNDEBUG", "-std=gnu++17", "-arch", "arm64",
    "-fno-lto", "-Wno-deprecated-declarations", "-DGGML_USE_CPU", "-DGGML_USE_METAL",
    "-DLLAMA_SUBPROCESS", '-DGEMMA4_PROTOTYPE_SOURCE_SHA256="' + source_sha + '"',
    "-I" + str(VENDOR / "vendor"), "-I" + str(VENDOR / "include"),
    "-I" + str(VENDOR / "ggml/include"), "-I" + str(VENDOR / "common"),
    "-I" + str(VENDOR / "vendor/sheredom"),
    str(SOURCE), "-o", str(BINARY),
    str(LIBRARIES[0]), str(LIBRARIES[1]), str(LIBRARIES[2]), str(LIBRARIES[3]),
    str(LIBRARIES[4]), "-framework", "Accelerate", str(LIBRARIES[5]),
    str(LIBRARIES[6]), "-lm", "-framework", "Foundation", "-framework", "Metal",
    "-framework", "MetalKit", str(LIBRARIES[7]), str(LIBRARIES[8]),
]
record = {
    "stage": "compile_only", "started_at": datetime.now(timezone.utc).isoformat(),
    "cwd": str(HERE), "compiler_argv": argv, "cpu_compile_jobs": 1,
    "vendor_rebuilt": False, "native_output_executed": False,
    "model_weights_read_or_loaded": False, "native_tokenizer_executed": False,
    "gpu_operation_executed": False, "network_or_auth_used": False,
    "prototype_source_sha256": source_sha, "reused_library_sha256": identities(LIBRARIES),
    "binary_capability": "CPU and Metal through pre-existing static libraries",
    "protected_file_sha256_before": before,
}
with (HERE / "compile.log").open("wb") as log:
    result = subprocess.run(argv, cwd=HERE, stdout=log, stderr=subprocess.STDOUT, check=False)
record["compiler_exit_code"] = result.returncode
record["completed_at"] = datetime.now(timezone.utc).isoformat()
record["protected_file_sha256_after"] = identities(PROTECTED)
record["protected_files_unchanged"] = record["protected_file_sha256_after"] == before
record["compile_log_sha256"] = digest(HERE / "compile.log")
if result.returncode == 0:
    record["binary_sha256"] = digest(BINARY)
    record["binary_size"] = BINARY.stat().st_size
(HERE / "compile-evidence.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({k: record.get(k) for k in (
    "compiler_exit_code", "prototype_source_sha256", "binary_sha256", "binary_size",
    "protected_files_unchanged", "native_output_executed",
)}, indent=2))
if result.returncode:
    print((HERE / "compile.log").read_text(), file=sys.stderr)
sys.exit(result.returncode)
