"""Future ROOT-cleared native probe. DO NOT RUN while frozen R6 is active."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import resource
import select
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
EXPECTED_MODEL_SHA = "179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b"
PROFILE = "gemma4-direct-label-raw-q4-research-v0"
ROOT = HERE.parents[2]
MODEL = ROOT / "models/gemma-4-31B_q4_0-it.gguf"
TEMPLATE = ROOT / "models/gemma-4-31B-it.chat_template.jinja"
BINARY = HERE / "gemma4-label-prototype"
MAX_PACKET_BYTES = 256 * 1024

def file_sha(path):
    h = sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def owned_path(value):
    p = Path(value).resolve()
    if HERE not in p.parents:
        raise ValueError("All probe input/output paths must remain inside the owned prototype folder")
    return p

def encode_packet(request, deadline=None):
    if deadline is not None and time.monotonic() >= deadline:
        raise TimeoutError("RPC deadline expired before packet encoding")
    packet = json.dumps(request, allow_nan=False, separators=(",", ":")).encode("utf-8") + b"\n"
    if len(packet) > MAX_PACKET_BYTES:
        raise ValueError("Outgoing JSON packet exceeds 256 KiB including newline")
    if deadline is not None and time.monotonic() >= deadline:
        raise TimeoutError("RPC deadline expired during packet encoding")
    return packet

def send_packet(fd, packet, deadline):
    os.set_blocking(fd, False)
    offset = 0
    view = memoryview(packet)
    while offset < len(packet):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("RPC deadline expired while sending stdin packet")
        _, writable, _ = select.select([], [fd], [], remaining)
        if not writable:
            continue
        try:
            written = os.write(fd, view[offset:])
        except (BlockingIOError, InterruptedError):
            continue
        if written <= 0:
            raise RuntimeError("Native stdin closed during packet send")
        offset += written

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--root-clearance-after-r6", action="store_true")
parser.add_argument("--verified-model-sha256", required=True)
parser.add_argument("--mode", choices=("vocab", "cpu", "metal"), default="vocab")
parser.add_argument("--branches", required=True)
parser.add_argument("--proof-dir", required=True)
parser.add_argument("--timeout-seconds", type=float, default=300)
args = parser.parse_args()
if not args.root_clearance_after_r6 or args.verified_model_sha256 != EXPECTED_MODEL_SHA:
    parser.error("ROOT must clear this exact stage after R6 is terminal and verify the frozen model SHA first")
if not 0 < args.timeout_seconds <= 600:
    parser.error("Each RPC timeout must be within (0, 600] seconds")
input_path = owned_path(args.branches)
proof_dir = owned_path(args.proof_dir)
if proof_dir.exists():
    parser.error("Use a new proof directory; previous evidence must remain untouched")
input_bytes = input_path.read_bytes()
plan = json.loads(input_bytes)
input_sha256 = sha256(input_bytes).hexdigest()
branches = plan["branches"]
if not isinstance(branches, list) or not 1 <= len(branches) <= 3:
    parser.error("The initial synthetic probe supports only 1-3 branches")
init_request = {"v": 1, "id": "init", "op": "init", "research_profile": PROFILE,
                "model_file": str(MODEL), "chat_template_file": str(TEMPLATE),
                "vocab_only": args.mode == "vocab",
                "device": "metal" if args.mode == "metal" else "cpu",
                "max_model_len": 2048, "max_batch_size": 1, "max_batch_tokens": 2048}
compile_request = {"v": 1, "id": "compile", "op": "compile", "branches": branches}
# Both initial outgoing packets must fit before creating a proof or process.
try:
    preflight_packet_sizes = {"init": len(encode_packet(init_request)),
                              "compile": len(encode_packet(compile_request))}
except ValueError as error:
    parser.error(str(error))
evidence = json.loads((HERE / "compile-evidence.json").read_text())
if evidence["compiler_exit_code"] != 0 or file_sha(BINARY) != evidence["binary_sha256"]:
    parser.error("Native binary must match the reviewed compile evidence")
if file_sha(HERE / "main.cpp") != evidence["prototype_source_sha256"]:
    parser.error("Source must match the reviewed compile evidence")
proof_dir.mkdir()
started = time.monotonic()
record = {
    "stage": args.mode, "started_at": datetime.now(timezone.utc).isoformat(),
    "root_clearance_argument": True,
    "model_sha256_root_attestation": args.verified_model_sha256,
    "model_sha256_recomputed_by_probe": False,
    "input_sha256": input_sha256, "input_snapshot_bytes": len(input_bytes),
    "input_parse_and_sha_same_snapshot": True, "binary_sha256": file_sha(BINARY),
    "outgoing_packet_limit_bytes": MAX_PACKET_BYTES,
    "initial_packet_bytes_preflight": preflight_packet_sizes,
    "rpc_deadline_includes_encode_stdin_send_and_response": True,
    "prototype_source_sha256": evidence["prototype_source_sha256"],
    "uses_production_registry_or_rfdt": False,
    "probability_semantics": "selected label logits only; uncalibrated candidate-relative scores",
    "rpc": [],
}
process = None
pending = b""

def rpc(request):
    global pending
    sent = time.monotonic()
    deadline = sent + args.timeout_seconds
    attempt = {"request": request, "timeout_seconds": args.timeout_seconds}
    record["rpc"].append(attempt)
    try:
        packet = encode_packet(request, deadline)
        attempt["packet_bytes"] = len(packet)
        send_packet(process.stdin.fileno(), packet, deadline)
        while b"\n" not in pending:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("RPC " + request["op"] + " exceeded the cleared timeout")
            readable, _, _ = select.select([process.stdout], [], [], remaining)
            if not readable:
                continue
            chunk = os.read(process.stdout.fileno(), 65536)
            if not chunk:
                raise RuntimeError("Native process exited before a complete protocol response")
            pending += chunk
            if len(pending) > 64 * 1024 * 1024:
                raise RuntimeError("Native response exceeded 64 MiB")
        line, pending = pending.split(b"\n", 1)
        response = json.loads(line)
        if time.monotonic() >= deadline:
            raise TimeoutError("RPC deadline expired during response parsing")
        if response.get("v") != 1 or response.get("id") != request["id"]:
            raise RuntimeError("Native response envelope mismatch")
        attempt["response"] = response
        return response
    except Exception as error:
        attempt["error"] = str(error)
        raise
    finally:
        attempt["seconds"] = time.monotonic() - sent

try:
    with (proof_dir / "native-stderr.log").open("wb") as native_log:
        process = subprocess.Popen([str(BINARY)], cwd=HERE, stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=native_log, bufsize=0)
        record["native_pid"] = process.pid
        init = rpc(init_request)
        if "error" in init:
            raise RuntimeError("Native init failed: " + init["error"]["message"])
        provenance = init["result"]["provenance"]
        if provenance["prototype_source_sha256"] != evidence["prototype_source_sha256"]:
            raise RuntimeError("Executed source provenance mismatch")
        expected_mode = {"vocab": "cpu_vocabulary_only_no_context", "cpu": "quantized_cpu",
                         "metal": "quantized_metal"}[args.mode]
        if provenance["actual_mode"] != expected_mode:
            raise RuntimeError("Executed mode provenance mismatch")
        compiled = rpc(compile_request)
        if "error" in compiled:
            raise RuntimeError("Native compile failed: " + compiled["error"]["message"])
        evaluated = rpc({"v": 1, "id": "evaluate", "op": "evaluate",
                         "branches": compiled["result"], "full": True})
        if args.mode == "vocab":
            if provenance["weights_loaded"] or provenance["context_created"] or provenance["explicit_backend_init"]:
                raise RuntimeError("Vocabulary-only mode unexpectedly initialized weights/context/backend")
            if evaluated.get("error", {}).get("kind") != "invalid_request" or "vocabulary-only" not in evaluated["error"]["message"]:
                raise RuntimeError("Vocabulary-only evaluation was not explicitly rejected")
            record["vocabulary_only_evaluation_rejected"] = True
        elif "error" in evaluated:
            raise RuntimeError("Native evaluate failed: " + evaluated["error"]["message"])
        process.stdin.close()
        record["native_exit_code"] = process.wait(timeout=10)
        if record["native_exit_code"] != 0:
            raise RuntimeError("Native exit was not zero")
        record["probe_contracts_passed"] = True
except Exception as error:
    record["probe_contracts_passed"] = False
    record["error"] = str(error)
finally:
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        record["owned_native_terminated_after_error"] = True
    if process is not None:
        record.setdefault("native_exit_code", process.returncode)
    record["elapsed_seconds"] = time.monotonic() - started
    record["completed_at"] = datetime.now(timezone.utc).isoformat()
    record["child_resource_maxrss"] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    record["child_resource_maxrss_units"] = "bytes on Darwin; KiB on Linux"
    record["memory_limitations"] = "child peak RSS does not establish whole-host or owned-server residency, Metal allocations, or an admission budget"
    (proof_dir / "proof.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({k: record.get(k) for k in ("stage", "probe_contracts_passed", "native_exit_code", "elapsed_seconds", "error")}, indent=2))
sys.exit(0 if record.get("probe_contracts_passed") else 1)
