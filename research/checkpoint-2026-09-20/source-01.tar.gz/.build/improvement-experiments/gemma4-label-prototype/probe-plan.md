# Gemma4 direct label prototype: ROOT review before execution

This folder is a separate research experiment. Frozen R6, its compiler, RFDT,
TEST/VAL/gold, production model roles, and existing source/distributions/proofs
must stay untouched. The prototype and future driver have not been executed.
ROOT must explicitly clear each exact future native stage after R6 is terminal.
The driver's clearance flag is a recorded manual assertion, not an automatic
check of R6 or an authorization mechanism.

## Compiled artifact and scope

- `main.cpp` is copied from production `native/main.cpp`, whose SHA-256 at copy
  was `ac0b5b0f1b8832bbbbc563e219bcbc621553e2297f456004955553560cadbcce`.
- This research source supports only the explicit physical profile
  `gemma4-direct-label-raw-q4-research-v0` and architecture `gemma4`.
- `build.py` compiled one CPU job and linked the pre-existing static libraries.
  It did not rebuild vendor code, execute native output, or load/tokenize weights.
  `compile-evidence.json` contains the exact compiler argv, exit code, source,
  binary and library fingerprints, and protected-file before/after fingerprints.
- The reused libraries are **CPU and Metal capable**. CPU selection cannot prove
  that Metal is never registered internally. No CPU-only vendor build is claimed.
- Model input is bound to the exact literal local path
  `/Users/bsonntag/code/simple-jev-ts/models/gemma-4-31B_q4_0-it.gguf`, size
  `17651001568`, expected SHA-256
  `179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b`.
  Native init checks path/type/size, **does not recompute model SHA**, and reports
  this limitation. ROOT must verify the already-frozen full model identity first.
- Corrected Jinja is bound to the exact local template path, size `18683`,
  revision `842da3794eaa0b77d5f08bae87a17459d91ff475`, SHA-256
  `ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4`.
  Native init verifies its bytes/hash and supplies that exact source override.

## Physical compiler and modes

`vocab_only` defaults to `true`. Vocabulary-only CPU mode sets the native
vocabulary-only load flag, performs no explicit `llama_backend_init` or backend
enumeration, returns before context creation, and explicitly rejects `evaluate`.
The reused library may still perform internal backend registration. This mode
does load native tokenizer/model metadata and therefore still needs ROOT's
post-R6 clearance; it is not an authorized operation during source preparation.

Weight modes load the pinned **raw quantized GGUF directly**, with no F32 weight
expansion, weight conversion, temporary model copy, or production registry role
change. CPU mode sets GPU layers to `0`, `offload_kqv=false`, `op_offload=false`,
and disables extra weight buffer types. Separately cleared Metal mode requests
`99` GPU layers and enables those offload flags. Requested layers do not prove
actual layer offload; native provenance deliberately leaves actual offloaded
layers unknown. ROOT must inspect actual runtime/backend evidence for that claim.

Bounds: model prompt 2048 tokens; suffix batch token budget 2048; one suffix
branch at a time; 256-token decode chunks; microbatch 128; two CPU threads;
F32 K/V cache; Flash Attention disabled; at most two native sequences including
shared-prefix sequence; allocated context capacity is at most 4096 tokens.
The first probes request full prefill, avoiding shared-prefix reuse.

The wire remains JSON Lines `v:1`, with the existing branch messages,
`answer_prefix`, `output_labels`, compiled `tokens`/`token_ids`, and selected
`logits` outputs. The original single-distinct-token label check stays unchanged:
each label must preserve every prompt token and append exactly one distinct
token. BOS is resolved from the actual vocabulary and required exactly once.
The ordinary disabled-thinking generation boundary must be exactly:

```text
<|turn>model
<|channel>thought
<channel|>
```

The existing JSON answer prefix follows that boundary. Init, compiled branches,
and evaluation metrics report physical profile/hash, template identity, embedded
prototype source hash, effective bounds, BOS piece/ID, and actual mode. The
logical v2 instructions are supplied by the current logical compiler unchanged;
the new physical profile is separate and cannot silently redefine frozen v2.

The driver parses and hashes a single immutable input byte snapshot. It caps
every serialized outgoing JSON packet at 256 KiB including its newline and
preflights both initial packets before creating a proof directory or process.
Each RPC deadline starts before encoding and includes nonblocking stdin writes,
response reads, and parsing; send failures reach the existing owned-process
cleanup. Later evaluation packets are also capped before sending. This cap is
distinct from the native protocol's larger incoming-line ceiling.

The native physical compiler merges a final consecutive user message into the
preceding user turn, as inherited from production. The simple independent Jinja
reference below does not apply that merge and therefore proves only the current
three `state` branches, each containing one system and one user message. It is
not evidence for consecutive-user chat history. Any future history probe must
apply the identical merge to the reference messages and bind both original and
normalized histories; it needs a separate ROOT review and clearance.

## Exact future ROOT sequence

**Do not execute these commands until R6 is terminal and ROOT has reviewed this
folder and cleared the exact stage.** Use fresh proof directories. All new writes
below stay inside this folder. No TEST/VAL/gold or teacher responses are inputs.

1. ROOT verifies the frozen model SHA against the expected value above, using
   the existing attributable frozen proof or a fresh full-file checksum. A fresh
   checksum reads the entire 17.65 GB file and is deferred until post-R6:

   ```sh
   cd /Users/bsonntag/code/simple-jev-ts
   shasum -a 256 models/gemma-4-31B_q4_0-it.gguf
   ```

2. ROOT creates exactly three independent synthetic branch prompts using the
   current unchanged logical compiler. This does not use `Classifier`, model
   registry promotion, RFDT, a teacher, or a protected corpus:

   ```sh
   node --input-type=module <<'NODE'
   import { preparePrompt } from './dist/core.js';
   import { readFileSync, writeFileSync } from 'node:fs';
   import { createHash } from 'node:crypto';
   const request = {
     model: 'google/gemma-4-31B-it-qat-q4_0',
     state: 'Synthetic probe: build validation completed successfully. No deployment was performed.',
     questions: [
       { id: 'observed_action', type: 'choice', instructions: 'Which action completed?', criteria: [
         { id: 'validation', description: 'Build validation completed.' },
         { id: 'deployment', description: 'Deployment completed.' }
       ] },
       { id: 'delivery_level', type: 'score', instructions: 'Rate the observed delivery state.', criteria: [
         'No validation or deployment was completed.',
         'Validation completed, with no deployment performed.',
         'Deployment completed.'
       ] },
       { id: 'deployment_happened', type: 'noul', instructions: 'Was a deployment performed?' }
     ],
     options: { template_version: 'v2', raw_logits: true }
   };
   const plan = preparePrompt(request, 'v2');
   const digest = p => createHash('sha256').update(readFileSync(p)).digest('hex');
   writeFileSync('.build/improvement-experiments/gemma4-label-prototype/synthetic-plan.json', JSON.stringify({
     note: 'Independent synthetic contract probes; no frozen R6 or quality corpus use.',
     logical_template_version: plan.template_version,
     logical_source_sha256: digest('src/core.ts'),
     logical_distribution_sha256: digest('dist/core.js'),
     request, branches: plan.questions
   }, null, 2) + '\n', { flag: 'wx' });
   NODE
   ```

3. After explicit vocabulary-stage clearance, ROOT executes **vocabulary-only
   first**. The expected intentional evaluation rejection is recorded as a
   contract check. It is not model quality evidence:

   ```sh
   /usr/bin/python3 .build/improvement-experiments/gemma4-label-prototype/future-probe.py \
     --root-clearance-after-r6 \
     --verified-model-sha256 179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b \
     --mode vocab \
     --branches .build/improvement-experiments/gemma4-label-prototype/synthetic-plan.json \
     --proof-dir .build/improvement-experiments/gemma4-label-prototype/vocab-proof-root-1 \
     --timeout-seconds 120
   ```

4. ROOT checks exact rendering with independent Jinja2 using only those synthetic
   prompts and the actual BOS piece. If Jinja2 is unavailable, stop this evidence
   lane; do not install dependencies or access the network implicitly:

   ```sh
   /usr/bin/python3 <<'PY'
   import json
   from pathlib import Path
   from jinja2.sandbox import ImmutableSandboxedEnvironment
   folder = Path('.build/improvement-experiments/gemma4-label-prototype')
   proof = json.loads((folder / 'vocab-proof-root-1/proof.json').read_text())
   assert proof['probe_contracts_passed']
   init = proof['rpc'][0]['response']['result']
   compiled = proof['rpc'][1]['response']['result']
   branches = proof['rpc'][1]['request']['branches']
   env = ImmutableSandboxedEnvironment(trim_blocks=True, lstrip_blocks=True)
   def fail(message): raise ValueError(message)
   env.globals['raise_exception'] = fail
   template = env.from_string(Path('models/gemma-4-31B-it.chat_template.jinja').read_text())
   checks = []
   for branch, result in zip(branches, compiled):
       expected = template.render(messages=branch['messages'],
           bos_token=init['provenance']['bos_piece'], eos_token='',
           add_generation_prompt=True, enable_thinking=False) + branch['answer_prefix']
       assert expected == result['rendered'], branch['branch_id']
       checks.append({'branch_id': branch['branch_id'], 'exact_render_match': True,
                      'label_token_ids': result['token_ids'], 'prompt_tokens': len(result['tokens'])})
   (folder / 'vocab-proof-root-1/jinja-reference.json').write_text(json.dumps(checks, indent=2) + '\n')
   print(json.dumps(checks, indent=2))
   PY
   ```

5. Only after the vocabulary/render checks pass, ROOT may separately clear a
   bounded quantized CPU model probe and establish a resource budget. The driver
   uses one owned native process, sends each RPC sequentially, limits every RPC
   to 300 seconds, waits for owned cleanup, and records failures honestly:

   ```sh
   /usr/bin/python3 .build/improvement-experiments/gemma4-label-prototype/future-probe.py \
     --root-clearance-after-r6 \
     --verified-model-sha256 179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b \
     --mode cpu \
     --branches .build/improvement-experiments/gemma4-label-prototype/synthetic-plan.json \
     --proof-dir .build/improvement-experiments/gemma4-label-prototype/cpu-proof-root-1 \
     --timeout-seconds 300
   ```

   A Metal probe requires a separate ROOT clearance for this exact profile and
   host budget. Use the same command with `--mode metal` and a fresh
   `metal-proof-root-1` directory. Do not infer actual offload from requested mode.

## Interpretation and resource limits

Each full probe supplies three prompt branches and zero generated output tokens;
it reads next-token logits without sampling labels. Native metrics separate
executed prompt tokens, logical unique-prefix usage and scored positions. The
candidate-label-only softmax is an uncalibrated relative score. Noul's nine bins
and nonlinear response mapping are a rubric convention, without proving truth
probabilities. The native output does not expose excluded vocabulary mass.

The GGUF file is approximately 16.44 GiB. Current all-F32 expansion would require
approximately 115.5 GiB for a nominal 31B weights alone and is removed here.
Quantized file size is not a peak RSS guarantee. KV cache, scratch/work buffers,
Metal allocations, extra copies, file mappings, the OS and the current owned
server still need independent accounting on the same 96 GiB unified-memory host.
The driver's child peak RSS cannot establish whole-host or other-server residency
or Metal memory. This prototype does not implement a hard memory admission limit
or reliable low-memory behavior. ROOT must set the post-R6 co-residency budget;
do not interrupt R6 or silently stop the existing owned server to make room.

A successful synthetic probe would establish rendering/token boundaries and
selected-logit execution for this exact artifact/profile/backend. It would not
establish production fallback readiness, protected quality gates, calibration,
broad accuracy, latency advantage, shared-prefix parity, or model promotion.
