import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { preparePrompt } from '../../../../dist/core.js';
import { QUALITY_GATES, summarizeQuality } from '../../../../dist/evaluation.js';
import { readInputSets, HERE, EXPECTED, sha, wireBranch, prerequisiteProofs, diagnosisGrid } from './protocol.mjs';
import { responseFromSelectedLogits, evaluateValidation, attachValidationCoverage, verifyCompiledBranch, ResearchClassifier } from './quality.mjs';
import { checkRootClearance, nativeContractsPassed } from './runner.mjs';

const example = () => preparePrompt({ model: 'research-cpu-mock', state: 'Synthetic neutral host-construction input.',
  questions: [
    { id: 'pick', type: 'choice', instructions: 'Select a synthetic option.', criteria: [{ id: 'first', description: 'First.' }, { id: 'second', description: 'Second.' }] },
    { id: 'level', type: 'score', instructions: 'Select a synthetic level.', criteria: ['Low.', 'Middle.', 'High.'] },
    { id: 'truth', type: 'noul', instructions: 'Rate a synthetic proposition.' },
  ] }, 'v2');
const allZero = plan => Object.fromEntries(plan.questions.map(branch => [branch.branch_id, Object.fromEntries(branch.output_labels.map(label => [label, 0]))]));

test('unchanged production response maps selected logits to candidate IDs, expected score and NOUL, with zero generation', () => {
  const plan = example();
  const logits = { '0': { A: -1000, B: 0 }, '1': { '0': -1000, '1': 0, '2': -1000 },
    '2': Object.fromEntries(Array.from('123456789').map(label => [label, label === '5' ? 0 : -1000])) };
  const response = responseFromSelectedLogits(plan, logits, 321, { synthetic: true });
  assert.equal(response.answers.pick.choice, 'second');
  assert.deepEqual(response.answers.pick.logits, { first: -1000, second: 0 });
  assert.equal(response.answers.level.score, 1);
  assert.deepEqual(response.answers.level.logits, { '0': -1000, '1': 0, '2': -1000 });
  assert.equal(response.answers.truth.noul, 0.5);
  assert.equal(response.answers.truth.rating.expected_score, 5);
  assert.equal(response.usage.input_tokens, 321);
  assert.equal(response.usage.output_tokens, 0);
  assert.equal(response.metadata.template_version, 'v2');
  assert.equal(response.metadata.production_role_approval, false);
  assert.equal(response.answers.pick.calibrated, false);
});

test('missing, extra and nonfinite selected logits fail the production constructor', () => {
  const plan = example();
  const logits = allZero(plan);
  assert.throws(() => responseFromSelectedLogits(plan, { ...logits, extra: {} }, 0, {}), /branch logits/);
  assert.throws(() => responseFromSelectedLogits(plan, { ...logits, '0': { A: 0 } }, 0, {}), /label logits/);
  assert.throws(() => responseFromSelectedLogits(plan, { ...logits, '0': { A: 0, B: Infinity } }, 0, {}), /non-finite/);
  assert.throws(() => responseFromSelectedLogits(plan, logits, 0.2, {}), /token count/);
});

const setsPromise = readInputSets();
test('exact safe inputs retain all 194 validation IDs, 83 groups, and all 14 four-record diagnosis groups', async () => {
  const sets = await setsPromise;
  assert.deepEqual(sets.map(set => set.records.length), [60, 78, 56]);
  assert.deepEqual(sets.map(set => set.groups), [30, 39, 14]);
  assert.equal(new Set(sets.flatMap(set => set.expected_ids)).size, 194);
  assert.ok(sets.every(set => set.records.every(record => record.split === 'validation')));
  assert.equal(sets[2].records.filter(record => record.request.state != null).length, 28);
  assert.equal(sets[2].records.filter(record => record.request.messages != null).length, 28);
  assert.deepEqual(sets.flatMap(set => set.records).flatMap(record => record.request.questions).reduce((counts, question) => {
    counts[question.type]++; return counts;
  }, { choice: 0, noul: 0, score: 0 }), { choice: 102, noul: 46, score: 46 });
});

test('diagnosis coverage requires each order/representation cross cell, not only passing marginals', async () => {
  const row = (id, representation) => ({ id, group_id: 'cpu-mock-grid', request: representation === 'state' ? { state: 'neutral' } : { messages: [{ role: 'user', content: 'neutral' }] } });
  const malformed = [row('cpu-first-order1-state', 'state'), row('cpu-second-order1-state', 'state'),
    row('cpu-first-order2-chat', 'chat'), row('cpu-second-order2-chat', 'chat')];
  assert.deepEqual(diagnosisGrid(malformed).counts, { 'state/order1': 2, 'chat/order1': 0, 'state/order2': 0, 'chat/order2': 2 });
  assert.equal(diagnosisGrid(malformed).complete, false);
  const valid = [row('cpu-order1-state', 'state'), row('cpu-order1-chat', 'chat'), row('cpu-order2-state', 'state'), row('cpu-order2-chat', 'chat')];
  assert.equal(diagnosisGrid(valid).complete, true);
  assert.equal(diagnosisGrid([...valid.slice(0, 3), valid[0]]).complete, false);
  const sets = await setsPromise;
  const report = await evaluateValidation({ classify: async request => {
    const plan = preparePrompt(request, 'v2');
    return responseFromSelectedLogits(plan, allZero(plan), 0, {});
  } }, sets);
  const malformedSets = [...sets.slice(0, 2), { ...sets[2], records: [
    ...malformed.map((record, index) => {
      const base = sets[2].records[index];
      const request = { ...base.request }; delete request.state; delete request.messages;
      return { ...base, ...record, request: { ...request, ...record.request } };
    }), ...sets[2].records.slice(4)] }];
  const malformedReport = attachValidationCoverage(report, malformedSets);
  assert.equal(malformedReport.diagnosis.groups[0].complete, false);
  assert.equal(malformedReport.gates.additional.diagnosis_all_14_groups_56_representations, false);
});

test('full 194-row CPU mock uses host scoring and fixed uniform logits without putting any targets into classify requests', async () => {
  const sets = await setsPromise;
  let calls = 0;
  const report = await evaluateValidation({ classify: async request => {
    calls++;
    assert.equal(Object.hasOwn(request, 'targets'), false);
    assert.equal(Object.hasOwn(request, 'split'), false);
    assert.equal(Object.hasOwn(request, 'group_id'), false);
    const plan = preparePrompt(request, 'v2');
    assert.ok(plan.questions.every(branch => Object.keys(wireBranch(branch)).every(key => ['branch_id', 'messages', 'answer_prefix', 'output_labels'].includes(key))));
    return responseFromSelectedLogits(plan, allZero(plan), 1, { mock: true }, { independent_render_match: false, actual_mode: 'cpu_mock_no_model' });
  } }, sets);
  assert.equal(calls, 194);
  assert.equal(report.results.length, 194);
  assert.equal(report.coverage.exact_order, true);
  assert.equal(report.coverage.actual_question_count, 194);
  assert.equal(report.diagnosis.groups.length, 14);
  assert.ok(report.diagnosis.groups.every(group => group.complete && group.records.length === 4));
  assert.deepEqual(report.research_protocol.production_quality_gates, QUALITY_GATES);
  assert.equal(report.gates.additional.independent_render_all_records, false);
  assert.equal(report.gates.passed, false, 'CPU mock cannot satisfy native render/quality evidence');
  assert.ok(report.unknown_noul.expected_count > 0);
  assert.equal(report.unknown_noul.mae, 0);
});

test('one missing answer produces a retained failed row and closed coverage/gates; dropping any failed row remains visible', async () => {
  const sets = await setsPromise;
  let cursor = 0;
  const report = await evaluateValidation({ classify: async request => {
    const index = cursor++;
    const plan = preparePrompt(request, 'v2');
    const response = responseFromSelectedLogits(plan, allZero(plan), 1, { mock: true });
    if (index === 60) delete response.answers[plan.questions[0].question_id];
    return response;
  } }, sets);
  assert.equal(report.results.length, 194);
  assert.equal(report.summary.failures, 1);
  assert.match(report.results[60].error, /Missing answer/);
  assert.equal(report.gates.production.no_failures, false);
  assert.equal(report.gates.additional.complete_question_coverage, false);
  const omitted = attachValidationCoverage({ ...report, results: report.results.filter((_, index) => index !== 60) }, sets);
  assert.equal(omitted.coverage.exact_order, false);
  assert.deepEqual(omitted.coverage.missing, [sets[1].expected_ids[0]]);
  assert.equal(omitted.gates.passed, false);
});

test('terminal owned inference error still produces all 194 explicit failure records', async () => {
  const sets = await setsPromise;
  const report = await evaluateValidation({ classify: async () => { throw new Error('CPU mock owned transport terminated'); } }, sets);
  assert.equal(report.results.length, 194);
  assert.equal(report.summary.failures, 194);
  assert.equal(report.coverage.exact_order, true);
  assert.equal(report.coverage.actual_question_count, 0);
  assert.equal(report.gates.passed, false);
  assert.equal(report.diagnosis.summary.failures, 56);
});

test('combined 194 aggregate success cannot mask failed original legacy gates or per-set unknown MAE', async () => {
  const sets = await setsPromise;
  const report = await evaluateValidation({ classify: async request => {
    const plan = preparePrompt(request, 'v2');
    return responseFromSelectedLogits(plan, allZero(plan), 0, {}, { independent_render_match: true });
  } }, sets);
  // CPU scoring-result fixture only. No model prompt or mock inference receives targets.
  const results = structuredClone(report.results);
  for (const row of results) for (const answer of row.answers) {
    if (!answer.uncertain) answer.correct = true;
    if (answer.type === 'score' || answer.type === 'noul') answer.normalized_absolute_error = 0;
    if (answer.type === 'noul') answer.squared_error = 0;
  }
  const failedLegacyChoices = results.slice(0, 60).flatMap(row => row.answers).filter(answer => answer.type === 'choice').slice(0, 3);
  failedLegacyChoices.forEach(answer => { answer.correct = false; });
  const summary = summarizeQuality(results);
  assert.equal(summary.gates.passed, true, 'Combined choice accuracy remains above 0.9');
  const scoped = attachValidationCoverage({ ...report, results, summary }, sets);
  assert.equal(scoped.gates.production.choice_accuracy, true);
  assert.equal(scoped.gates.production_by_set['legacy-validation-60'].choice_accuracy, false);
  assert.equal(scoped.gates.production_by_set['developer-validation-78'].passed, true);
  assert.equal(scoped.gates.passed, false);
  failedLegacyChoices.forEach(answer => { answer.correct = true; });
  const legacyUnknown = results.slice(0, 60).flatMap(row => row.answers).filter(answer => answer.type === 'noul' && answer.target.answer === null);
  legacyUnknown.forEach(answer => { answer.normalized_absolute_error = 0.2; });
  const unknownScoped = attachValidationCoverage({ ...report, results, summary: summarizeQuality(results) }, sets);
  assert.ok(unknownScoped.unknown_noul.mae <= 0.1, 'Aggregate unknown MAE can pass');
  assert.equal(unknownScoped.coverage.sets[0].unknown_noul.passed, false);
  assert.equal(unknownScoped.gates.passed, false);
});

test('native acceptance refuses unknown close, transport failure, nonzero/signal exits, pending work, cleanup or audit errors', () => {
  const child = { state: 'closed', closedObserved: true, exitedObserved: true, exitCode: 0,
    signal: null, failureCode: null, pendingRequests: 0 };
  const stage = { error: null, actual_mode: 'quantized_metal', actual_native_process_launches: 1,
    owned_native: child, owned_native_close_result: child };
  assert.equal(nativeContractsPassed(stage), true);
  for (const change of [{ closedObserved: false }, { exitedObserved: false }, { exitCode: 1 }, { signal: 'SIGTERM' }, { failureCode: 'TOTAL_TIMEOUT' }, { pendingRequests: 1 }]) {
    assert.equal(nativeContractsPassed({ ...stage, owned_native: { ...child, ...change } }), false);
    assert.equal(nativeContractsPassed({ ...stage, owned_native_close_result: { ...child, ...change } }), false);
  }
  assert.equal(nativeContractsPassed({ ...stage, owned_native_close_result: null }), false);
  assert.equal(nativeContractsPassed({ ...stage, owned_native_close_result: { ...child, cleanupError: 'unobserved close' } }), false);
  assert.equal(nativeContractsPassed(stage, 'audit cap exceeded'), false);
});

test('ROOT clearance binds exact plan bytes and independently reviewed prerequisites', () => {
  const bytes = Buffer.from('synthetic cpu-only run plan bytes');
  const clearance = { kind: 'gemma4_validation_research_root_clearance', stage_cleared: true,
    clearance_scope: 'validation_194_one_owned_sequential_metal_process', run_plan_sha256: sha(bytes),
    successful_vocab_and_independent_jinja_reviewed: true, tiny_three_question_metal_proof_reviewed: true,
    exact_model_sha256_verified: EXPECTED.modelSha256, production_role_approval: false };
  assert.doesNotThrow(() => checkRootClearance(clearance, bytes));
  assert.throws(() => checkRootClearance({ ...clearance, stage_cleared: false }, bytes), /ROOT/);
  assert.throws(() => checkRootClearance(clearance, Buffer.from('changed')), /plan bytes/);
  assert.throws(() => checkRootClearance({ ...clearance, successful_vocab_and_independent_jinja_reviewed: false }, bytes), /Jinja/);
  assert.throws(() => checkRootClearance({ ...clearance, production_role_approval: true }, bytes), /role approval/);
});

test('frozen synthetic vocab/Jinja prerequisites retain independent source/identity binding without executing artifacts', async () => {
  const proofs = await prerequisiteProofs();
  assert.equal(proofs.vocab.sha256, EXPECTED.vocabProofSha256);
  assert.equal(proofs.jinja.sha256, EXPECTED.jinjaProofSha256);
  assert.equal(proofs.physical_profile.id, EXPECTED.profile);
  assert.equal(proofs.physical_profile.enable_thinking, false);
});

test('actual compile boundary, distinct labels, tokens, source and independent render checks reject malformed native evidence', async () => {
  const prerequisites = await prerequisiteProofs();
  const vocab = JSON.parse(await readFile(prerequisites.vocab.path, 'utf8'));
  const provenance = { ...vocab.rpc[0].response.result.provenance, actual_mode: 'quantized_metal',
    vocab_only: false, weights_loaded: true, context_created: true, explicit_backend_init: true,
    device: 'metal', gpu_layers_requested: 99, offload_kqv: true, op_offload: true, context_train_limit_checked: true };
  const plan = { ...prerequisites, sources: { prototype: { sha256: EXPECTED.sourceSha256 } }, artifacts: { binary: { sha256: EXPECTED.binarySha256 }, model: { sha256: EXPECTED.modelSha256, bytes: EXPECTED.modelBytes } } };
  const branch = example().questions[0];
  const rendered = '<bos>CPU synthetic render\n' + EXPECTED.generationBoundary + branch.answer_prefix;
  const compiled = { branch_id: branch.branch_id, tokens: [2, 100, 200], token_ids: { A: 300, B: 301 },
    rendered, rendered_generation_boundary: EXPECTED.generationBoundary + branch.answer_prefix, provenance };
  const reference = { rendered, rendered_sha256: sha(rendered), final_two_user_messages_merged: false };
  assert.equal(verifyCompiledBranch(branch, compiled, reference, plan).actual_prompt_tokens, 3);
  assert.throws(() => verifyCompiledBranch(branch, { ...compiled, tokens: [2, 100, 2] }, reference, plan), /BOS/);
  assert.throws(() => verifyCompiledBranch(branch, { ...compiled, token_ids: { A: 300, B: 300 } }, reference, plan), /label token/);
  assert.throws(() => verifyCompiledBranch(branch, compiled, { ...reference, rendered: 'changed' }, plan), /parity/);
  assert.throws(() => verifyCompiledBranch(branch, { ...compiled, provenance: { ...provenance, actual_mode: 'quantized_cpu' } }, reference, plan), /mode/);
  assert.throws(() => verifyCompiledBranch(branch, { ...compiled, provenance: { ...provenance, prototype_source_sha256: 'wrong' } }, reference, plan), /source/);
});

test('classifier CPU RPC mock compiles each actual logical question then evaluates full prefill with selected logits and zero generation', async () => {
  const prerequisites = await prerequisiteProofs();
  const vocab = JSON.parse(await readFile(prerequisites.vocab.path, 'utf8'));
  const provenance = { ...vocab.rpc[0].response.result.provenance, actual_mode: 'quantized_metal',
    vocab_only: false, weights_loaded: true, context_created: true, explicit_backend_init: true,
    device: 'metal', gpu_layers_requested: 99, offload_kqv: true, op_offload: true, context_train_limit_checked: true };
  const frozen = { ...prerequisites, sources: { prototype: { sha256: EXPECTED.sourceSha256 } },
    artifacts: { binary: { sha256: EXPECTED.binarySha256 }, model: { sha256: EXPECTED.modelSha256, bytes: EXPECTED.modelBytes } } };
  const prompt = example();
  const renders = prompt.questions.map(branch => ({ record_id: 'cpu-only-generic-record', branch_id: branch.branch_id,
    rendered: '<bos>CPU synthetic render\n' + EXPECTED.generationBoundary + branch.answer_prefix,
    rendered_sha256: sha('<bos>CPU synthetic render\n' + EXPECTED.generationBoundary + branch.answer_prefix),
    final_two_user_messages_merged: false }));
  const requests = [];
  const evidence = [];
  let compiled = null;
  const rpc = { snapshot: () => ({ state: 'running', failureCode: null, exitCode: null }), request: async request => {
    requests.push(request);
    if (request.op === 'compile') {
      assert.equal(request.branches.length, 1);
      assert.deepEqual(request.branches[0], wireBranch(prompt.questions[Number(request.branches[0].branch_id)]));
      const branch = request.branches[0];
      const reference = renders.find(row => row.branch_id === branch.branch_id);
      compiled = { branch_id: branch.branch_id, tokens: [2, 100, 200],
        token_ids: Object.fromEntries(branch.output_labels.map((label, index) => [label, 300 + index])),
        rendered: reference.rendered, rendered_generation_boundary: EXPECTED.generationBoundary + branch.answer_prefix,
        provenance };
      return { v: 1, id: request.id, result: [compiled] };
    }
    assert.equal(request.op, 'evaluate');
    assert.equal(request.full, true);
    assert.deepEqual(request.branches, [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }]);
    const metrics = { backend: 'llama.cpp', prefill_strategy: 'full', prefix_tokens: 0,
      branch_output_tokens: 0, scored_positions: 1, suffix_batch_sizes: [1], computed_prompt_tokens: 3,
      branch_prompt_tokens: 3, logical_prefill_tokens: 3, padded_suffix_tokens: 0, engine_forwards: 1, provenance };
    return { v: 1, id: request.id, result: { input_tokens: 3, metrics,
      logits: { [compiled.branch_id]: Object.fromEntries(Object.keys(compiled.token_ids).map(label => [label, 0])) } } };
  } };
  const classifier = new ResearchClassifier({ rpc, plan: frozen, orderedRecords: [{ id: 'cpu-only-generic-record' }],
    renderReference: { rows: renders }, evidenceSink: async entry => evidence.push(entry) });
  const response = await classifier.classify(prompt.request);
  assert.deepEqual(requests.map(request => request.op), ['compile', 'evaluate', 'compile', 'evaluate', 'compile', 'evaluate']);
  assert.equal(new Set(requests.map(request => request.id)).size, 6);
  assert.equal(response.usage.input_tokens, 9);
  assert.equal(response.usage.output_tokens, 0);
  assert.equal(response.answers.pick.choice, 'first');
  assert.equal(response.answers.level.score, 1);
  assert.equal(response.answers.truth.noul, 0.5);
  assert.equal(evidence.length, 1);
  assert.equal(evidence[0].questions.length, 3);
  assert.ok(evidence[0].questions.every(question => question.independent_render_match === true && question.generation_tokens === 0));
});
