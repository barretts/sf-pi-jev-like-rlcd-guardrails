/** Host-side proof only: Node CPU mocks, exact validation inputs, no native/model/template calls. */
import { mkdir, writeFile } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join } from 'node:path';
import { preparePrompt } from '../../../../dist/core.js';
import { HERE, EXPECTED, sha, jsonBytes, insist, readInputSets, ownedNewPath, fileIdentity } from './protocol.mjs';
import { sourceCpuPlan } from './runner.mjs';
import { responseFromSelectedLogits, evaluateValidation } from './quality.mjs';

async function main() {
  insist(process.argv.length === 4 && process.argv[2] === '--proof-dir', 'Usage: node cpu-proof.mjs --proof-dir fresh-owned-directory');
  const proofDirectory = await ownedNewPath(process.argv[3]);
  await mkdir(proofDirectory, { mode: 0o700 });
  const started = performance.now();
  let testExitCode = 0;
  let testOutput = '';
  try {
    const result = await promisify(execFile)(process.execPath, ['--test', join(HERE, 'quality.test.mjs'), join(HERE, 'rpc.test.mjs')],
      { cwd: HERE, timeout: 30000, maxBuffer: 1024 * 1024, encoding: 'utf8' });
    testOutput = result.stdout + result.stderr;
  } catch (error) {
    testExitCode = Number.isInteger(error.code) ? error.code : 1;
    testOutput = (error.stdout ?? '') + (error.stderr ?? '') + '\n' + String(error) + '\n';
  }
  await writeFile(join(proofDirectory, 'cpu-tests.log'), testOutput, { flag: 'wx', mode: 0o600 });
  const plan = await sourceCpuPlan();
  const planBytes = jsonBytes(plan);
  await writeFile(join(proofDirectory, 'source-cpu-plan.json'), planBytes, { flag: 'wx', mode: 0o600 });
  const sets = await readInputSets();
  const classifyEvidence = [];
  const report = await evaluateValidation({ classify: async request => {
    insist(!Object.hasOwn(request, 'targets'), 'Host scoring targets must not enter model/RPC requests');
    const prompt = preparePrompt(request, 'v2');
    const logits = Object.fromEntries(prompt.questions.map(branch => [branch.branch_id,
      Object.fromEntries(branch.output_labels.map(label => [label, 0]))]));
    classifyEvidence.push({ logical_prompt_sha256: sha(JSON.stringify(prompt.questions)),
      question_count: prompt.questions.length, targets_present_in_request: false,
      raw_selected_label_logits: logits, cpu_mock_rule: 'uniform zero logits, independent of targets; no tokenizer/model call' });
    return responseFromSelectedLogits(prompt, logits, 0, { cpu_mock: true },
      { actual_mode: 'cpu_mock_no_model', independent_render_match: false });
  } }, sets);
  report.cpu_mock_only = true;
  report.native_model_or_tokenizer_executed = false;
  report.limits = 'This uniform CPU mock intentionally fails model/native quality gates. It proves unchanged host response construction, host scoring, and exact retained 194-record coverage only.';
  const reportBytes = jsonBytes(report);
  const evidenceBytes = Buffer.from(classifyEvidence.map(row => JSON.stringify(row)).join('\n') + '\n');
  await writeFile(join(proofDirectory, 'cpu-mock-quality-report.json'), reportBytes, { flag: 'wx', mode: 0o600 });
  await writeFile(join(proofDirectory, 'cpu-classify-evidence.jsonl'), evidenceBytes, { flag: 'wx', mode: 0o600 });
  const cpuSources = await Promise.all(['protocol.mjs', 'quality.mjs', 'runner.mjs', 'render-reference.py',
    'rpc.mjs', 'quality.test.mjs', 'rpc.test.mjs', 'rpc-mock-child.mjs', 'cpu-proof.mjs'].map(name => fileIdentity(join(HERE, name))));
  const proof = { kind: 'gemma4_validation_source_cpu_mock_proof', created_at: new Date().toISOString(),
    source_run_plan_sha256: sha(planBytes), cpu_sources: cpuSources,
    production_sources: plan.sources.production, input_manifest: plan.input_manifest,
    test_command: [process.execPath, '--test', join(HERE, 'quality.test.mjs'), join(HERE, 'rpc.test.mjs')],
    tests_exit_code: testExitCode, test_log_sha256: sha(testOutput),
    cpu_quality_report_sha256: sha(reportBytes), cpu_classify_evidence_sha256: sha(evidenceBytes),
    actual_cpu_mock_records: report.results.length, actual_cpu_mock_questions: report.coverage.actual_question_count,
    exact_194_record_coverage: report.coverage.exact_order, diagnosis_groups: report.diagnosis.groups.length,
    diagnosis_representation_records: report.diagnosis.groups.reduce((sum, group) => sum + group.records.length, 0),
    cpu_classify_requests_without_targets: classifyEvidence.length === 194 && classifyEvidence.every(row => row.targets_present_in_request === false),
    mocked_quality_gates_passed: report.gates.passed,
    model_native_tokenizer_weights_gpu_network_auth_build_or_git_executed: false,
    model_or_native_binary_read: false, original_raw_template_read: false,
    synthetic_prerequisites_read_only: { vocab_sha256: EXPECTED.vocabProofSha256, jinja_sha256: EXPECTED.jinjaProofSha256 },
    runner_resource_usage: process.resourceUsage(), elapsed_ms: performance.now() - started,
    passed: testExitCode === 0 && report.results.length === 194 && report.coverage.exact_order && report.coverage.actual_question_count === 194 && report.gates.passed === false,
    limitation: 'Passing CPU proof proves host construction, bounded mock RPC/cleanup, validation roster and closed coverage gates. It does not prove model quality, native/runtime acceptance, GPU allocation, calibration, benchmark gain, production role suitability, or permission to run inference.' };
  await writeFile(join(proofDirectory, 'cpu-proof.json'), jsonBytes(proof), { flag: 'wx', mode: 0o600 });
  console.log(JSON.stringify({ proof_directory: proofDirectory, passed: proof.passed, tests_exit_code: testExitCode,
    source_run_plan_sha256: proof.source_run_plan_sha256, records: 194, cpu_mock_quality_gates_passed: false }));
  if (!proof.passed) process.exitCode = 1;
}

main().catch(error => { console.error(error instanceof Error ? error.stack : String(error)); process.exitCode = 1; });
