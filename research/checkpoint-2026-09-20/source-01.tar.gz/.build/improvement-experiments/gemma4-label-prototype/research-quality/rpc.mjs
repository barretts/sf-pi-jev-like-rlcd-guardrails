import { spawn } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import { TextDecoder } from 'node:util';

const DEFAULTS = Object.freeze({
  requestTimeoutMs: 30_000,
  maxPacketBytes: 1_048_576,
  maxResponseBytes: 1_048_576,
  maxStderrBytes: 16_384,
  exitTimeoutMs: 250,
  totalTimeoutMs: 120_000,
  maxRequests: 10_000,
});
const MAX_TIMER_MS = 2_147_483_647;
const MAX_JSON_DEPTH = 128;

export class RpcError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'RpcError';
    this.code = code;
    this.details = details;
  }
}

function deferred() {
  let resolve;
  const promise = new Promise((done) => { resolve = done; });
  return { promise, resolve };
}

function optionsFor(options) {
  if (options === null || typeof options !== 'object' || Array.isArray(options)) {
    throw new RpcError('INVALID_OPTIONS', 'RPC options must be an object.');
  }
  const limits = {};
  for (const [key, fallback] of Object.entries(DEFAULTS)) {
    const value = options[key] ?? fallback;
    const minimum = key === 'maxStderrBytes' ? 0 : 1;
    if (!Number.isSafeInteger(value) || value < minimum || value > MAX_TIMER_MS) {
      throw new RpcError('INVALID_OPTIONS', `${key} must be an integer from ${minimum} to ${MAX_TIMER_MS}.`);
    }
    limits[key] = value;
  }
  if (options.cwd !== undefined && (typeof options.cwd !== 'string' || options.cwd.length === 0)) {
    throw new RpcError('INVALID_OPTIONS', 'cwd must be a nonempty string.');
  }
  return Object.freeze(limits);
}

// Own data properties only: no getters, custom toJSON, implicit NaN conversion,
// cycles, sparse arrays, or objects that JSON.stringify silently changes.
// Byte checks happen while encoding, before a packet is sent or fully allocated.
function encodeFiniteJson(value, maxBytes, checkDeadline, code) {
  let buffer = Buffer.alloc(0);
  const active = new Set();
  let bytes = 0;
  let encodedId;
  let encodedVersion;
  const invalid = (message) => { throw new RpcError(code, message); };
  const emit = (part) => {
    checkDeadline();
    const nextBytes = bytes + Buffer.byteLength(part);
    if (nextBytes > maxBytes) throw new RpcError('PACKET_TOO_LARGE', `Outgoing packet exceeds ${maxBytes} bytes including its newline.`);
    if (nextBytes > buffer.length) {
      const next = Buffer.allocUnsafe(Math.min(maxBytes, Math.max(1_024, nextBytes, buffer.length * 2)));
      buffer.copy(next, 0, 0, bytes);
      buffer = next;
    }
    buffer.write(part, bytes);
    bytes = nextBytes;
  };
  const string = (part) => {
    checkDeadline();
    if (Buffer.byteLength(part) > maxBytes) throw new RpcError('PACKET_TOO_LARGE', `Outgoing packet exceeds ${maxBytes} bytes including its newline.`);
    emit(JSON.stringify(part));
  };
  const walk = (item, depth) => {
    checkDeadline();
    if (depth > MAX_JSON_DEPTH) invalid(`JSON nesting exceeds ${MAX_JSON_DEPTH} levels.`);
    if (item === null) return emit('null');
    if (typeof item === 'string') return string(item);
    if (typeof item === 'boolean') return emit(item ? 'true' : 'false');
    if (typeof item === 'number') {
      if (!Number.isFinite(item)) invalid('JSON numbers must be finite.');
      return emit(JSON.stringify(item));
    }
    if (typeof item !== 'object') invalid('Values must be finite JSON data.');
    if (active.has(item)) invalid('JSON data must not contain cycles.');
    const array = Array.isArray(item);
    const prototype = Object.getPrototypeOf(item);
    if (!array && prototype !== Object.prototype && prototype !== null) invalid('JSON objects must have a plain or null prototype.');
    active.add(item);
    const keys = Reflect.ownKeys(item);
    checkDeadline();
    if (keys.length > maxBytes) throw new RpcError('PACKET_TOO_LARGE', `Outgoing packet exceeds ${maxBytes} bytes including its newline.`);
    if (array) {
      if (item.length > maxBytes) throw new RpcError('PACKET_TOO_LARGE', `Outgoing packet exceeds ${maxBytes} bytes including its newline.`);
      if (keys.length !== item.length + 1) invalid('JSON arrays must be dense and have no additional properties.');
      emit('[');
      for (let index = 0; index < item.length; index++) {
        if (index) emit(',');
        const descriptor = Object.getOwnPropertyDescriptor(item, String(index));
        if (!descriptor || !descriptor.enumerable || !Object.hasOwn(descriptor, 'value')) invalid('JSON arrays must contain enumerable data properties.');
        walk(descriptor.value, depth + 1);
      }
      emit(']');
    } else {
      emit('{');
      let first = true;
      for (const key of keys) {
        if (typeof key !== 'string') invalid('JSON objects must not have symbol properties.');
        const descriptor = Object.getOwnPropertyDescriptor(item, key);
        if (!descriptor || !descriptor.enumerable || !Object.hasOwn(descriptor, 'value')) invalid('JSON objects must contain enumerable data properties.');
        if (depth === 0 && key === 'id') encodedId = descriptor.value;
        if (depth === 0 && key === 'v') encodedVersion = descriptor.value;
        if (!first) emit(',');
        first = false;
        string(key);
        emit(':');
        walk(descriptor.value, depth + 1);
      }
      emit('}');
    }
    active.delete(item);
  };
  walk(value, 0);
  emit('\n');
  checkDeadline();
  return { packet: Buffer.from(buffer.subarray(0, bytes)), encodedId, encodedVersion };
}

function assertFiniteJson(value, checkDeadline, depth = 0) {
  checkDeadline();
  if (depth > MAX_JSON_DEPTH) throw new RpcError('INVALID_RESPONSE', `JSON nesting exceeds ${MAX_JSON_DEPTH} levels.`);
  if (typeof value === 'number' && !Number.isFinite(value)) throw new RpcError('INVALID_RESPONSE', 'Response JSON numbers must be finite.');
  if (value !== null && typeof value === 'object') {
    for (const child of Object.values(value)) assertFiniteJson(child, checkDeadline, depth + 1);
  }
}

function boundedUtf8(buffer, limit) {
  let text = buffer.toString('utf8');
  // A cut multibyte sequence may expand into a replacement character. Keep the
  // diagnostic string bounded in bytes as well as the retained raw buffer.
  while (Buffer.byteLength(text) > limit) text = text.slice(text.codePointAt(0) > 0xffff ? 2 : 1);
  return text;
}

/**
 * Owns one directly spawned process; imports never launch a process.
 * Each request/response is a newline-terminated JSON object with v:1 and a
 * nonempty string id. Response envelopes, including error envelopes, are
 * returned intact. IDs can be used once per instance. Concurrent requests may
 * complete in any order; unsolicited or duplicate responses fail the session.
 *
 * Timers cover encode/write/read/parse and use monotonic elapsed time. The total
 * timeout bounds operational lifetime. Fatal cleanup has at most 3 additional
 * exitTimeoutMs waits; explicit graceful close has at most 4. These bounds are
 * cooperative with the Node event loop, not an OS CPU/RSS/process limit.
 */
export class OwnedRpc {
  static spawn(command, args = [], options = {}) {
    if (typeof command !== 'string' || command.length === 0 || !Array.isArray(args) || args.some((arg) => typeof arg !== 'string')) {
      throw new RpcError('INVALID_COMMAND', 'command must be a nonempty string and args an array of strings.');
    }
    const limits = optionsFor(options);
    return new OwnedRpc(command, args, options.cwd, limits);
  }

  constructor(command, args, cwd, limits) {
    this.limits = limits;
    this._startedAt = performance.now();
    this._totalDeadline = this._startedAt + limits.totalTimeoutMs;
    this._pending = new Map();
    this._seenIds = new Set();
    this._lineBuffer = Buffer.alloc(0);
    this._lineBytes = 0;
    this._stderr = Buffer.alloc(0);
    this._stderrBytesSeen = 0;
    this._stdoutBytesSeen = 0;
    this._writesCompleted = 0;
    this._failure = null;
    this._state = 'running';
    this._exitInfo = null;
    this._closedObserved = false;
    this._signals = [];
    this._closed = deferred();
    this._closing = null;
    this._decoder = new TextDecoder('utf-8', { fatal: true });
    this._child = spawn(command, args, { cwd, shell: false, detached: false, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    this._child.on('error', (error) => this._fail(new RpcError('SPAWN_ERROR', error.message)));
    this._child.stdin.on('error', (error) => {
      if (this._state === 'running') this._fail(new RpcError('WRITE_ERROR', error.message));
    });
    this._child.stdout.on('data', (chunk) => this._read(chunk));
    this._child.stdout.on('error', (error) => {
      if (this._state === 'running') this._fail(new RpcError('READ_ERROR', error.message));
    });
    this._child.stdout.on('end', () => {
      if (this._state === 'running' && this._lineBytes > 0) this._fail(new RpcError('UNTERMINATED_RESPONSE', 'Child stdout ended without a JSONL newline.'));
    });
    this._child.stderr.on('data', (chunk) => this._captureStderr(chunk));
    this._child.stderr.on('error', (error) => {
      if (this._state === 'running') this._fail(new RpcError('STDERR_ERROR', error.message));
    });
    this._child.on('exit', (exitCode, signal) => {
      this._exitInfo = { exitCode, signal };
    });
    this._child.on('close', (exitCode, signal) => {
      this._exitInfo ??= { exitCode, signal };
      this._closedObserved = true;
      this._state = 'closed';
      clearTimeout(this._totalTimer);
      this._closed.resolve(this.snapshot());
      if (this._pending.size) this._fail(new RpcError('CHILD_EXIT', `Owned child closed before a response (code ${exitCode}, signal ${signal ?? 'none'}).`));
    });
    this._totalTimer = setTimeout(() => this._fail(new RpcError('TOTAL_TIMEOUT', `RPC operational lifetime exceeded ${limits.totalTimeoutMs} ms.`)), limits.totalTimeoutMs);
  }

  get pid() { return this._child.pid ?? null; }

  snapshot() {
    return {
      pid: this.pid,
      state: this._state,
      elapsedMs: performance.now() - this._startedAt,
      exitCode: this._exitInfo?.exitCode ?? null,
      signal: this._exitInfo?.signal ?? null,
      exitedObserved: this._exitInfo !== null,
      closedObserved: this._closedObserved,
      stderr: boundedUtf8(this._stderr, this.limits.maxStderrBytes),
      stderrBytesRetained: this._stderr.length,
      stderrBytesSeen: this._stderrBytesSeen,
      stderrTruncated: this._stderrBytesSeen > this._stderr.length,
      stdoutBytesSeen: this._stdoutBytesSeen,
      writesCompleted: this._writesCompleted,
      responseBufferBytesAllocated: this._lineBuffer.length,
      submittedRequests: this._seenIds.size,
      pendingRequests: this._pending.size,
      failureCode: this._failure?.code ?? null,
      signalsSent: [...this._signals],
      limits: { ...this.limits },
      cleanupWaitBoundMs: (this._gracefulClose ? 4 : 3) * this.limits.exitTimeoutMs,
      resourceEnforcement: {
        cpu: 'unavailable',
        rss: 'unavailable',
        descendantProcessCount: 'unavailable',
        descendantTermination: 'unavailable',
        explanation: 'Node timers and byte caps only; no OS resource limit, RSS sampling, process-group kill, or descendant discovery. Only the directly owned child can receive signals. Timers cannot preempt a blocked Node event loop.',
      },
    };
  }

  async request(request, { signal } = {}) {
    const startedAt = performance.now();
    const deadline = Math.min(startedAt + this.limits.requestTimeoutMs, this._totalDeadline);
    const checkDeadline = () => this._checkDeadline(deadline);
    if (this._state !== 'running') throw this._failure ?? new RpcError('RPC_CLOSED', 'RPC is closed.', this.snapshot());
    if (signal !== undefined && (signal === null || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) {
      throw new RpcError('INVALID_REQUEST', 'signal must be an AbortSignal.');
    }
    if (signal?.aborted) {
      const error = new RpcError('ABORTED', 'Request was aborted.');
      await this._fail(error);
      throw error;
    }
    let packet;
    let id;
    try {
      checkDeadline();
      if (request === null || typeof request !== 'object' || Array.isArray(request)) throw new RpcError('INVALID_REQUEST', 'Request must be a JSON object.');
      // Read descriptors rather than invoking caller-provided accessors.
      const version = Object.getOwnPropertyDescriptor(request, 'v');
      const identifier = Object.getOwnPropertyDescriptor(request, 'id');
      if (!version || !Object.hasOwn(version, 'value') || version.value !== 1 || !identifier || !Object.hasOwn(identifier, 'value') || typeof identifier.value !== 'string' || !identifier.value.length) {
        throw new RpcError('INVALID_REQUEST', 'Request must contain data properties v:1 and a nonempty string id.');
      }
      id = identifier.value;
      if (this._seenIds.has(id)) throw new RpcError('DUPLICATE_ID', `Request ID ${JSON.stringify(id)} was already submitted.`);
      if (this._seenIds.size >= this.limits.maxRequests) throw new RpcError('REQUEST_LIMIT', `RPC accepts at most ${this.limits.maxRequests} requests.`);
      const encoded = encodeFiniteJson(request, this.limits.maxPacketBytes, checkDeadline, 'INVALID_REQUEST');
      if (encoded.encodedId !== id || encoded.encodedVersion !== 1) throw new RpcError('INVALID_REQUEST', 'Request envelope changed during encoding.');
      packet = encoded.packet;
      checkDeadline();
    } catch (error) {
      if (error.code === 'REQUEST_TIMEOUT' || error.code === 'TOTAL_TIMEOUT') await this._fail(error);
      throw error;
    }
    this._seenIds.add(id);
    return new Promise((resolve, reject) => {
      const entry = { id, deadline, resolve, reject, writeComplete: false, response: null, timer: null, signal, abort: null };
      this._pending.set(id, entry);
      entry.timer = setTimeout(() => {
        const code = performance.now() >= this._totalDeadline ? 'TOTAL_TIMEOUT' : 'REQUEST_TIMEOUT';
        this._fail(new RpcError(code, `Request ${JSON.stringify(id)} exceeded its encode/write/read deadline.`));
      }, Math.max(1, Math.ceil(deadline - performance.now())));
      if (signal) {
        entry.abort = () => this._fail(new RpcError('ABORTED', `Request ${JSON.stringify(id)} was aborted.`));
        signal.addEventListener('abort', entry.abort, { once: true });
        if (signal.aborted) { entry.abort(); return; }
      }
      try {
        checkDeadline();
        // The callback is part of completion. Backpressure never resets a timer.
        this._child.stdin.write(packet, (error) => {
          if (!this._pending.has(id)) return;
          if (error) { this._fail(new RpcError('WRITE_ERROR', error.message)); return; }
          try {
            checkDeadline();
            entry.writeComplete = true;
            this._writesCompleted++;
            this._complete(entry);
          } catch (failure) { this._fail(failure); }
        });
      } catch (error) { this._fail(error); }
    });
  }

  _checkDeadline(deadline = this._totalDeadline) {
    const now = performance.now();
    if (now >= this._totalDeadline) throw new RpcError('TOTAL_TIMEOUT', `RPC operational lifetime exceeded ${this.limits.totalTimeoutMs} ms.`);
    if (now >= deadline) throw new RpcError('REQUEST_TIMEOUT', 'Request exceeded its encode/write/read deadline.');
  }

  _captureStderr(chunk) {
    this._stderrBytesSeen += chunk.length;
    const cap = this.limits.maxStderrBytes;
    if (!cap) return;
    if (chunk.length >= cap) this._stderr = Buffer.from(chunk.subarray(chunk.length - cap));
    else {
      const keep = Math.min(this._stderr.length, cap - chunk.length);
      this._stderr = Buffer.concat([this._stderr.subarray(this._stderr.length - keep), chunk], keep + chunk.length);
    }
  }

  _read(chunk) {
    if (this._state !== 'running') return;
    this._stdoutBytesSeen += chunk.length;
    try {
      this._checkDeadline();
      let start = 0;
      while (start < chunk.length) {
        const newline = chunk.indexOf(10, start);
        const end = newline === -1 ? chunk.length : newline;
        const segment = chunk.subarray(start, end);
        const previousBytes = this._lineBytes;
        this._lineBytes += segment.length;
        // Account for the required LF even before it arrives. This also bounds
        // output from a child that emits an endless line without a newline.
        if (this._lineBytes + 1 > this.limits.maxResponseBytes) throw new RpcError('RESPONSE_TOO_LARGE', `Response line exceeds ${this.limits.maxResponseBytes} bytes including its newline.`);
        if (this._lineBytes > this._lineBuffer.length) {
          const next = Buffer.allocUnsafe(Math.min(this.limits.maxResponseBytes - 1, Math.max(1_024, this._lineBytes, this._lineBuffer.length * 2)));
          this._lineBuffer.copy(next, 0, 0, previousBytes);
          this._lineBuffer = next;
        }
        if (segment.length) segment.copy(this._lineBuffer, previousBytes);
        if (newline === -1) break;
        const bytes = this._lineBuffer.subarray(0, this._lineBytes);
        this._lineBytes = 0;
        this._response(bytes);
        if (this._state !== 'running') return;
        start = newline + 1;
      }
    } catch (error) { this._fail(error); }
  }

  _response(bytes) {
    this._checkDeadline();
    let response;
    try { response = JSON.parse(this._decoder.decode(bytes)); }
    catch (error) { throw new RpcError('MALFORMED_RESPONSE', `Response is not valid UTF-8 JSON: ${error.message}`); }
    this._checkDeadline();
    if (response === null || typeof response !== 'object' || Array.isArray(response) || response.v !== 1 || typeof response.id !== 'string' || !response.id.length) {
      throw new RpcError('INVALID_RESPONSE', 'Response must be a JSON object with v:1 and a nonempty string id.');
    }
    const entry = this._pending.get(response.id);
    if (!entry) throw new RpcError('UNEXPECTED_ID', `Response ID ${JSON.stringify(response.id)} has no pending request.`);
    this._checkDeadline(entry.deadline);
    assertFiniteJson(response, () => this._checkDeadline(entry.deadline));
    if (entry.response !== null) throw new RpcError('DUPLICATE_RESPONSE', `Response ID ${JSON.stringify(response.id)} was returned twice.`);
    entry.response = response;
    this._complete(entry);
  }

  _complete(entry) {
    if (!entry.writeComplete || entry.response === null || this._state !== 'running') return;
    this._checkDeadline(entry.deadline);
    this._pending.delete(entry.id);
    this._disposeEntry(entry);
    entry.resolve(entry.response);
  }

  _disposeEntry(entry) {
    clearTimeout(entry.timer);
    if (entry.abort) entry.signal.removeEventListener('abort', entry.abort);
  }

  _fail(error) {
    this._failure ??= error instanceof RpcError ? error : new RpcError('RPC_FAILURE', error.message ?? String(error));
    if (this._closing) return this._closing;
    const pending = [...this._pending.values()];
    this._pending.clear();
    for (const entry of pending) this._disposeEntry(entry);
    this._closing = this._shutdown(false).then((result) => {
      this._failure.details = { ...this.snapshot(), cleanupError: result.cleanupError ?? null };
      for (const entry of pending) entry.reject(this._failure);
      return result;
    });
    return this._closing;
  }

  _signal(signal) {
    if (this._exitInfo !== null || this._closedObserved || !this.pid) return;
    try {
      if (this._child.kill(signal)) this._signals.push(signal);
    } catch (error) {
      this._signalError = error.message;
    }
  }

  _destroyStreams() {
    this._child.stdin.destroy();
    this._child.stdout.destroy();
    this._child.stderr.destroy();
  }

  async _waitClosed(ms) {
    if (this._closedObserved) return true;
    let timer;
    const result = await Promise.race([
      this._closed.promise.then(() => true),
      new Promise((resolve) => { timer = setTimeout(() => resolve(false), ms); }),
    ]);
    clearTimeout(timer);
    return result;
  }

  async _shutdown(graceful) {
    clearTimeout(this._totalTimer);
    this._gracefulClose = graceful;
    if (this._closedObserved) return this.snapshot();
    this._state = 'closing';
    this._lineBuffer = Buffer.alloc(0);
    this._lineBytes = 0;
    this._child.stdin.end();
    const grace = this.limits.exitTimeoutMs;
    if (graceful && await this._waitClosed(grace)) return this.snapshot();
    this._signal('SIGTERM');
    if (await this._waitClosed(grace)) return this.snapshot();
    this._signal('SIGKILL');
    if (await this._waitClosed(grace)) return this.snapshot();
    // Closing our pipes never signals a descendant. It avoids an inherited
    // pipe keeping the Node close event open after the owned process exits.
    this._destroyStreams();
    if (await this._waitClosed(grace)) return this.snapshot();
    return { ...this.snapshot(), cleanupError: new RpcError('CLEANUP_TIMEOUT', 'Owned child close was not observed within the bounded cleanup waits.', { signalError: this._signalError ?? null }) };
  }

  async close() {
    if (this._closing) return this._closing;
    if (this._pending.size) return this._fail(new RpcError('RPC_CLOSED', 'RPC was closed with pending requests.'));
    this._closing = this._shutdown(true);
    return this._closing;
  }
}
