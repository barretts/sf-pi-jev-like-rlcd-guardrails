// CPU-only JSONL fixture. No native executable, model, network, or file effects.
import { createInterface } from 'node:readline';

const mode = process.argv[2] ?? 'echo';
const send = (value) => process.stdout.write(`${JSON.stringify(value)}\n`);
const lines = createInterface({ input: process.stdin, crlfDelay: Infinity });
let first;

if (mode === 'ignore-term') {
  process.on('SIGTERM', () => process.stderr.write('mock ignored SIGTERM\n'));
  setInterval(() => {}, 1_000);
}
if (mode === 'shutdown-stderr') {
  process.on('SIGTERM', () => process.stderr.write('q'.repeat(262_144) + 'FINAL SHUTDOWN STDERR', () => process.exit(0)));
  setInterval(() => {}, 1_000);
}
if (mode === 'no-read') {
  lines.close();
  process.stdin.pause();
  setInterval(() => {}, 1_000);
}

lines.on('line', (line) => {
  const request = JSON.parse(line);
  const response = { v: 1, id: request.id, result: request.payload ?? null };
  switch (mode) {
    case 'echo': send(response); break;
    case 'error': send({ v: 1, id: request.id, error: { code: 'MOCK_FAILURE', message: 'Fixture error envelope.' } }); break;
    case 'bad-id': send({ ...response, id: 'not-the-request-id' }); break;
    case 'bad-version': send({ ...response, v: 2 }); break;
    case 'malformed': process.stdout.write('{broken JSON}\n'); break;
    case 'nonfinite': process.stdout.write(`{"v":1,"id":${JSON.stringify(request.id)},"result":1e999}\n`); break;
    case 'invalid-utf8': process.stdout.write(Buffer.from([0xff, 10])); break;
    case 'oversize': send({ ...response, result: 'x'.repeat(4_096) }); break;
    case 'oversize-no-newline': process.stdout.write('x'.repeat(4_096)); break;
    case 'unterminated': process.stdout.write(JSON.stringify(response), () => process.exit(0)); break;
    case 'exit': process.stderr.write('mock exited deliberately\n', () => process.exit(7)); break;
    case 'ignore-term':
    case 'shutdown-stderr': break;
    case 'stderr-tail': process.stderr.write('x'.repeat(4_096) + 'FINAL STDERR MARKER', () => send(response)); break;
    case 'reverse':
      if (!first) first = response;
      else { send(response); send(first); first = undefined; }
      break;
    case 'duplicate-response': send(response); send(response); break;
    default: throw new Error(`Unknown CPU mock mode: ${mode}`);
  }
});
