import { mkdir, readFile, writeFile, appendFile, stat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { pathToFileURL } from 'node:url';
import { join, resolve } from 'node:path';
import { OwnedRpc } from './rpc.mjs';
import { HERE, ROOT, BINARY, TEMPLATE, EXPECTED, LIMITS, INPUTS, sha, jsonBytes, insist,
  initRequest, wireBranch, packetBytes, readInputSets, researchSourceIdentities,
  productionSourceIdentities, freezePlan, verifyFrozenIdentities, ownedNewPath,
  validateProvenance } from './protocol.mjs';
import { ResearchClassifier, evaluateValidation } from './quality.mjs';
import { preparePrompt } from '../../../../dist/core.js';

const executeFile = promisify(execFile);
const reportFilesLimitBytes = 128 * 1024 * 1024;

export function checkRootClearance(clearance, planBytes) {
  insist(clearance.kind === 'gemma4_validation_research_root_clearance' && clearance.stage_cleared === true,
    'Explicit ROOT validation research clearance required');
  insist(clearance.clearance_scope === 'validation_194_one_owned_sequential_metal_process', 'ROOT scope must equal exactly this validation stage');
  insist(clearance.run_plan_sha256 === sha(planBytes), 'ROOT clearance must bind exact frozen run-plan bytes');
  insist(clearance.successful_vocab_and_independent_jinja_reviewed === true,
    'ROOT must review successful vocab and independent original-template Jinja synthetic proof');
  insist(clearance.tiny_three_question_metal_proof_reviewed === true, 'ROOT must review the prior tiny three-question Metal proof');
  insist(clearance.exact_model_sha256_verified === EXPECTED.modelSha256, 'ROOT must attest exact raw GGUF SHA');
  insist(clearance.production_role_approval === false, 'Research clearance has no production role approval');
}

export function nativeContractsPassed(stage, auditFailure = null) {
  const child = stage.owned_native;
  const close = stage.owned_native_close_result;
  return !stage.error && !auditFailure && stage.actual_mode === 'quantized_metal' && stage.actual_native_process_launches === 1 &&
    !!close && !close.cleanupError && child?.state === 'closed' && child.closedObserved === true && child.exitedObserved === true &&
    child.exitCode === 0 && child.signal === null && child.failureCode === null && child.pendingRequests === 0 &&
    close.closedObserved === true && close.exitedObserved === true && close.exitCode === 0 && close.signal === null && close.failureCode === null && close.pendingRequests === 0;
}

function resourceSampler(pid) {
  const samples = [];
  let pending = null;
  let stopped = false;
  const started = performance.now();
  async function collect() {
    if (pending || stopped) return;
    pending = executeFile('/bin/ps', ['-p', String(pid), '-o', 'rss=', '-o', 'time=', '-o', '%cpu='],
      { timeout: 1000, maxBuffer: 4096, encoding: 'utf8' }).then(({ stdout }) => {
      const match = stdout.trim().match(/^(\d+)\s+(\S+)\s+([\d.]+)$/);
      if (match) samples.push({ elapsed_ms: performance.now() - started, rss_kib: Number(match[1]),
        cumulative_cpu_time_ps: match[2], cpu_percent_ps: Number(match[3]) });
    }).catch(() => {}).finally(() => { pending = null; });
    await pending;
  }
  const timer = setInterval(() => { void collect(); }, 1000);
  timer.unref();
  void collect();
  return async () => {
    stopped = true; clearInterval(timer); await pending;
    return { native_pid: pid, sample_interval_ms: 1000, samples,
      observed_peak_rss_kib: samples.length ? Math.max(...samples.map(sample => sample.rss_kib)) : null,
      memory_limitations: 'One-second ps RSS samples can miss the true peak. RSS is not total host residency, Metal allocation, GPU peak, or a proven memory admission limit.',
      cpu_limitations: 'ps CPU percent and cumulative time are observations, not a kernel-enforced CPU budget.',
      native_peak_rusage: 'unavailable in Node direct-child API; sampled RSS retained explicitly',
    };
  };
}

export async function sourceCpuPlan() {
  const sets = await readInputSets();
  return { kind: 'gemma4_validation_source_cpu_mock_plan', created_at: new Date().toISOString(),
    sources: { research: await researchSourceIdentities(), production: await productionSourceIdentities() },
    input_manifest: sets.map(({ records, ...set }) => ({ ...set, records: records.length })),
    execution_order: sets.flatMap(set => set.expected_ids), expected_records: 194,
    runtime_bounds: LIMITS, requested_future_native_stage: 'ROOT-cleared single sequential quantized Metal process',
    raw_model_or_binary_read_by_cpu_stage: false, model_tokenizer_native_gpu_or_network_executed: false,
    native_artifact_literals: EXPECTED,
    limitation: 'This source/CPU plan is not an inference clearance or a native frozen run plan. ROOT must freeze all native artifacts and approve that exact plan before run.',
  };
}

export async function runFutureNative({ planPath, clearancePath, proofPath }) {
  const planBytes = await readFile(planPath);
  const clearanceBytes = await readFile(clearancePath);
  const plan = JSON.parse(planBytes);
  const clearance = JSON.parse(clearanceBytes);
  checkRootClearance(clearance, planBytes);
  await verifyFrozenIdentities(plan); // Includes a full current raw-model SHA; no execution until this succeeds.
  const proofDirectory = await ownedNewPath(proofPath);
  await mkdir(proofDirectory, { mode: 0o700 });
  const snapshotDirectory = join(proofDirectory, 'inputs');
  await mkdir(snapshotDirectory, { mode: 0o700 });
  const sets = await readInputSets(snapshotDirectory);
  const order = sets.flatMap(set => set.expected_ids);
  insist(JSON.stringify(order) === JSON.stringify(plan.execution_order), 'Frozen record order changed');
  const manifests = sets.map(({ records, ...set }) => ({ ...set, records: records.length }));
  insist(JSON.stringify(manifests) === JSON.stringify(plan.inputs), 'Frozen input SHA, IDs or logical prompts changed');
  packetBytes(initRequest());
  await writeFile(join(proofDirectory, 'run-plan.json'), planBytes, { flag: 'wx', mode: 0o600 });
  await writeFile(join(proofDirectory, 'root-clearance.json'), clearanceBytes, { flag: 'wx', mode: 0o600 });
  const requests = sets.flatMap(set => set.records.flatMap(record => {
    const prompt = preparePrompt({ ...record.request, options: { ...record.request.options, template_version: 'v2' } }, 'v2');
    return prompt.questions.map(branch => ({ record_id: record.id, branch: wireBranch(branch) }));
  }));
  insist(requests.length === 194, 'Frozen stage requires exactly 194 single-question records');
  const renderRequestBytes = jsonBytes(requests);
  await writeFile(join(proofDirectory, 'render-requests.json'), renderRequestBytes, { flag: 'wx', mode: 0o600 });
  const stage = { kind: 'gemma4_validation_research_native_stage', started_at: new Date().toISOString(),
    run_plan_sha256: sha(planBytes), root_clearance_sha256: sha(clearanceBytes),
    root_clearance_scope: clearance.clearance_scope, all_194_inputs_frozen: true,
    input_snapshot_parse_sha_same_bytes: true, probabilities_calibrated: false,
    native_artifacts: plan.artifacts, prototype_source: plan.sources.prototype,
    physical_profile_sha256: plan.physical_profile_sha256,
    template_parser_sha256: EXPECTED.parserTemplateSha256,
    requested_native_process_count: 1, actual_native_process_launches: 0,
    production_registry_or_role_mutated: false, rfdt_gates_mutated: false,
    execution_order: order, runtime_bounds: LIMITS,
    resource_enforcement: 'Deadlines and protocol/data caps enforced; no kernel CPU/RSS/Metal allocation cap is promised.',
    init_cold_scope: plan.cold_scope, runner_resource_usage_before: process.resourceUsage() };
  const started = performance.now();
  let rpc = null; let samplerStop = null; let report = null;
  let stageError = null; let auditBytes = 0;
  const appendAudit = async (filename, value) => {
    const bytes = Buffer.from(JSON.stringify(value) + '\n');
    auditBytes += bytes.length;
    if (auditBytes > reportFilesLimitBytes) {
      auditFailure = 'Frozen 128 MiB combined RPC/question audit cap exceeded';
      throw new Error(auditFailure);
    }
    try { await appendFile(join(proofDirectory, filename), bytes, { mode: 0o600 }); }
    catch (error) { auditFailure = String(error); throw error; }
  };
  let auditFailure = null;
  const modelId = EXPECTED.profile;
  const orderedRecords = sets.flatMap(set => set.records);
  let classifier = { classify: async () => { throw new Error(stageError ?? 'Native initialization unavailable'); } };
  try {
    const renderStarted = performance.now();
    const renderer = await executeFile(plan.host_runtime.renderer.python_executable, [join(HERE, 'render-reference.py'),
      '--requests', join(proofDirectory, 'render-requests.json'), '--output', join(proofDirectory, 'independent-render.json'),
      '--template', TEMPLATE, '--expected-sha256', EXPECTED.templateSha256],
      { cwd: HERE, timeout: 60000, maxBuffer: 1024 * 1024, encoding: 'utf8' });
    stage.independent_renderer_ms = performance.now() - renderStarted;
    stage.independent_renderer_stdout = renderer.stdout;
    stage.independent_renderer_stderr = renderer.stderr;
    const referenceBytes = await readFile(join(proofDirectory, 'independent-render.json'));
    const reference = JSON.parse(referenceBytes);
    insist(reference.kind === 'gemma4_independent_full_validation_jinja_render' && reference.requests_sha256 === sha(renderRequestBytes) && reference.original_raw_template_sha256 === EXPECTED.templateSha256 && reference.original_raw_template_bytes === EXPECTED.templateBytes && reference.rows.length === 194 && reference.native_or_model_execution === false && JSON.stringify(reference.runtime_identity) === JSON.stringify(plan.host_runtime.renderer), 'Full independent Jinja manifest identity/coverage/runtime mismatch');
    stage.independent_render_sha256 = sha(referenceBytes);
    stage.independent_render_rows = reference.rows.length;
    stage.independent_render_final_pair_merges = reference.rows.filter(row => row.final_two_user_messages_merged).length;
    rpc = OwnedRpc.spawn(BINARY, [], { cwd: HERE, requestTimeoutMs: LIMITS.requestTimeoutMs,
      totalTimeoutMs: LIMITS.totalTimeoutMs, maxPacketBytes: LIMITS.maxPacketBytes,
      maxResponseBytes: LIMITS.maxResponseBytes, maxStderrBytes: LIMITS.maxStderrBytes,
      exitTimeoutMs: LIMITS.exitTimeoutMs });
    stage.actual_native_process_launches = 1;
    stage.native_pid = rpc.snapshot().pid;
    samplerStop = resourceSampler(stage.native_pid);
    const auditedRpc = {
      snapshot: () => ({ ...rpc.snapshot(), ...(auditFailure ? { failure: auditFailure } : {}) }),
      request: async (request, options) => {
        insist(!auditFailure, 'Native inference stopped after audit failure: ' + auditFailure);
        const sent = performance.now();
        const attempt = { id: request.id, op: request.op, request };
        try { attempt.response = await rpc.request(request, options); return attempt.response; }
        catch (error) { attempt.error = error instanceof Error ? error.message : String(error); throw error; }
        finally {
          attempt.elapsed_ms = performance.now() - sent;
          try { await appendAudit('native-rpc.jsonl', attempt); }
          catch (error) { auditFailure = String(error); throw error; }
        }
      },
    };
    const initStarted = performance.now();
    const init = await auditedRpc.request(initRequest());
    stage.init_ms = performance.now() - initStarted;
    if (init.error) throw new Error('Native init: ' + JSON.stringify(init.error));
    validateProvenance(init.result?.provenance, plan);
    insist(init.result.architecture === 'gemma4' && init.result.ready === true && init.result.device === 'metal', 'Init actual architecture/device/readiness mismatch');
    stage.init_provenance = init.result.provenance;
    stage.actual_mode = init.result.provenance.actual_mode;
    stage.actual_backend = 'llama.cpp';
    classifier = new ResearchClassifier({ rpc: auditedRpc, plan, orderedRecords, renderReference: reference,
      evidenceSink: entry => appendAudit('question-evidence.jsonl', entry) });
  } catch (error) { stageError = error instanceof Error ? error.message : String(error); }
  try {
    // Production evaluateRecords catches per-record failures, retaining all 194 rows even after init/transport failure.
    report = await evaluateValidation(classifier, sets.map(set => ({ ...set, records: set.records.map(record => ({
      ...record, request: { ...record.request, model: modelId } })) })));
  } catch (error) { stageError = stageError ?? String(error); }
  finally {
    if (rpc) {
      try {
        stage.owned_native_close_result = await rpc.close();
        if (stage.owned_native_close_result.cleanupError) stageError = stageError ?? 'Owned native cleanup incomplete: ' + String(stage.owned_native_close_result.cleanupError);
      } catch (error) { stageError = stageError ?? 'Owned native close: ' + String(error); }
      stage.owned_native = rpc.snapshot();
      await writeFile(join(proofDirectory, 'native-stderr.log'), stage.owned_native.stderr ?? '', { flag: 'wx', mode: 0o600 });
    }
    if (samplerStop) stage.native_resource_samples = await samplerStop();
    stage.elapsed_ms = performance.now() - started;
    stage.completed_at = new Date().toISOString();
    stage.runner_resource_usage_after = process.resourceUsage();
    stage.resource_usage_scope = 'runner_resource_usage measures Node host runner only. Native token counters and ps samples are separate. No GPU allocation or whole-host budget claim.';
    stage.audit_bytes = auditBytes;
    stage.audit_limit_bytes = reportFilesLimitBytes;
    stage.audit_failure = auditFailure;
    stage.error = stageError;
    stage.native_contracts_passed = nativeContractsPassed(stage, auditFailure);
    stage.quality_gates_passed = report?.gates.passed === true;
    stage.passed = stage.native_contracts_passed && stage.quality_gates_passed;
    if (report) {
      report.native_stage = { run_plan_sha256: stage.run_plan_sha256, native_contracts_passed: stage.native_contracts_passed,
        actual_mode: stage.actual_mode ?? null, native_exit_code: stage.owned_native?.exitCode ?? null,
        native_pid: stage.native_pid ?? null, root_clearance_sha256: stage.root_clearance_sha256 };
      report.gates.native_contracts = stage.native_contracts_passed;
      report.gates.passed = report.gates.passed && stage.native_contracts_passed;
      await writeFile(join(proofDirectory, 'quality-report.json'), jsonBytes(report), { flag: 'wx', mode: 0o600 });
    }
    await writeFile(join(proofDirectory, 'stage-proof.json'), jsonBytes(stage), { flag: 'wx', mode: 0o600 });
  }
  return stage;
}

function parseArguments(argv) {
  const [command, ...arguments_] = argv;
  const options = {};
  for (let index = 0; index < arguments_.length; index += 2) {
    const key = arguments_[index];
    insist(['--output', '--plan', '--root-clearance', '--proof-dir'].includes(key) && typeof arguments_[index + 1] === 'string' && !arguments_[index + 1].startsWith('--'), 'Invalid CLI argument');
    insist(!Object.hasOwn(options, key), 'Duplicate CLI argument');
    options[key] = arguments_[index + 1];
  }
  return { command, options };
}

async function main() {
  const { command, options } = parseArguments(process.argv.slice(2));
  if (command === 'cpu-plan' || command === 'freeze') {
    insist(Object.keys(options).length === 1 && options['--output'], 'cpu-plan/freeze require only --output');
    const output = await ownedNewPath(options['--output']);
    const plan = command === 'cpu-plan' ? await sourceCpuPlan() : await freezePlan();
    const bytes = jsonBytes(plan);
    await writeFile(output, bytes, { flag: 'wx', mode: 0o600 });
    console.log(JSON.stringify({ command, output, sha256: sha(bytes), expected_records: 194,
      native_execution: false, root_native_clearance: false }));
    return;
  }
  insist(command === 'run' && Object.keys(options).length === 3 && options['--plan'] && options['--root-clearance'] && options['--proof-dir'],
    'Usage: node runner.mjs cpu-plan|freeze --output owned.json; run --plan frozen.json --root-clearance root.json --proof-dir fresh-owned-directory');
  const result = await runFutureNative({ planPath: options['--plan'], clearancePath: options['--root-clearance'], proofPath: options['--proof-dir'] });
  console.log(JSON.stringify({ passed: result.passed, native_contracts_passed: result.native_contracts_passed,
    quality_gates_passed: result.quality_gates_passed, run_plan_sha256: result.run_plan_sha256, error: result.error }));
  if (!result.passed) process.exitCode = 1;
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main().catch(error => { console.error(error instanceof Error ? error.stack : String(error)); process.exitCode = 1; });
}
