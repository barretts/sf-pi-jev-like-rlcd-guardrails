import { buildResponse, preparePrompt } from '../../../../dist/core.js';
import { evaluateRecords, summarizeQuality, QUALITY_GATES } from '../../../../dist/evaluation.js';
import { EXPECTED, LIMITS, insist, sha, wireBranch, validateProvenance, diagnosisGrid } from './protocol.mjs';

/** Adapt native selected label logits using the actual unchanged production response constructor. */
export function responseFromSelectedLogits(plan, logits, inputTokens, metrics, metadata = {}) {
  insist(Number.isSafeInteger(inputTokens) && inputTokens >= 0, 'Invalid native input token count');
  const responsePlan = { ...plan, request: { ...plan.request, options: { ...plan.request.options, raw_logits: true } } };
  return buildResponse(responsePlan, logits, inputTokens, true, {
    metrics,
    metadata: { ...metadata, backend: 'llama.cpp', research_profile: EXPECTED.profile,
      calibration: 'not_calibrated', probability_semantics: 'softmax over selected labels only; uncalibrated candidate-relative scores',
      usage_accounting: 'actual full-prefill prompt tokens; zero generated output tokens',
      production_role_approval: false },
  });
}

export function verifyCompiledBranch(branch, compiled, reference, plan) {
  insist(compiled?.branch_id === branch.branch_id, 'Compiled branch ID mismatch');
  insist(Array.isArray(compiled.tokens) && compiled.tokens.length >= 1 && compiled.tokens.length <= LIMITS.max_model_len && compiled.tokens.every(token => Number.isSafeInteger(token) && token >= 0), 'Invalid actual compiled tokens');
  insist(compiled.tokens[0] === 2 && compiled.tokens.filter(token => token === 2).length === 1, 'Actual tokens must contain exactly one initial BOS');
  insist(compiled.token_ids && Object.keys(compiled.token_ids).length === branch.output_labels.length && branch.output_labels.every(label => Number.isSafeInteger(compiled.token_ids[label]) && compiled.token_ids[label] >= 0) && new Set(Object.values(compiled.token_ids)).size === branch.output_labels.length, 'Selected label token identity mismatch');
  insist(reference?.rendered === compiled.rendered && reference.rendered_sha256 === sha(compiled.rendered), 'Independent original-raw-template render parity failed');
  insist(compiled.rendered_generation_boundary === EXPECTED.generationBoundary + branch.answer_prefix && compiled.rendered.endsWith(compiled.rendered_generation_boundary), 'Actual disabled-thinking/JSON boundary mismatch');
  validateProvenance(compiled.provenance, plan);
  return { actual_prompt_tokens: compiled.tokens.length, rendered_sha256: sha(compiled.rendered),
    independent_render_match: true, final_two_user_messages_merged: reference.final_two_user_messages_merged,
    selected_label_token_ids: compiled.token_ids, labels: branch.output_labels,
    answer_labels: branch.answer_labels, BOS_exactly_once: true,
    one_distinct_token_label_rule: 'native compile verified tokenized rendered prefix + each entire label preserves prefix and adds exactly one distinct token' };
}

export class ResearchClassifier {
  constructor({ rpc, plan, orderedRecords, renderReference, evidenceSink }) {
    this.rpc = rpc; this.plan = plan; this.orderedRecords = orderedRecords;
    this.reference = new Map(renderReference.rows.map(row => [row.record_id + ':' + row.branch_id, row]));
    this.evidenceSink = evidenceSink; this.cursor = 0; this.terminalError = null;
  }
  async classify(request, signal) {
    const record = this.orderedRecords[this.cursor++];
    insist(record, 'Classifier called beyond frozen 194-record order');
    if (this.terminalError) throw new Error(this.terminalError);
    const plan = preparePrompt(request, 'v2');
    const evidence = { record_id: record.id, logical_prompt_sha256: sha(JSON.stringify(plan.questions)),
      questions: [], elapsed_ms: 0, actual_mode: 'quantized_metal' };
    const started = performance.now();
    let inputTokens = 0;
    const logits = Object.create(null);
    const metrics = [];
    try {
      for (let index = 0; index < plan.questions.length; index++) {
        const branch = plan.questions[index];
        const prefix = `r${String(this.cursor - 1).padStart(3, '0')}q${index}`;
        const compiledEnvelope = await this.rpc.request({ v: 1, id: prefix + '-compile', op: 'compile', branches: [wireBranch(branch)] }, { signal });
        if (compiledEnvelope.error) throw new Error('Native compile: ' + JSON.stringify(compiledEnvelope.error));
        insist(Array.isArray(compiledEnvelope.result) && compiledEnvelope.result.length === 1, 'Native compile returned unexpected branch count');
        const compiled = compiledEnvelope.result[0];
        const parity = verifyCompiledBranch(branch, compiled, this.reference.get(record.id + ':' + branch.branch_id), this.plan);
        const evaluationRequest = { v: 1, id: prefix + '-evaluate', op: 'evaluate', full: true,
          branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] };
        const evaluatedEnvelope = await this.rpc.request(evaluationRequest, { signal });
        if (evaluatedEnvelope.error) throw new Error('Native evaluate: ' + JSON.stringify(evaluatedEnvelope.error));
        const evaluated = evaluatedEnvelope.result;
        const nativeMetrics = evaluated?.metrics;
        insist(nativeMetrics?.backend === 'llama.cpp' && nativeMetrics.prefill_strategy === 'full' && nativeMetrics.prefix_tokens === 0 && nativeMetrics.branch_output_tokens === 0 && nativeMetrics.scored_positions === 1 && JSON.stringify(nativeMetrics.suffix_batch_sizes) === '[1]', 'Native did not execute one-question full prefill with zero generation');
        insist(nativeMetrics.computed_prompt_tokens === compiled.tokens.length && nativeMetrics.branch_prompt_tokens === compiled.tokens.length && nativeMetrics.logical_prefill_tokens === compiled.tokens.length && nativeMetrics.padded_suffix_tokens === 0 && nativeMetrics.engine_forwards === Math.ceil(compiled.tokens.length / 256), 'Native actual token/forward accounting mismatch');
        validateProvenance(nativeMetrics.provenance, this.plan);
        insist(evaluated.input_tokens === compiled.tokens.length, 'Single-question actual/unique input tokens mismatch');
        insist(Object.keys(evaluated.logits ?? {}).length === 1 && Object.hasOwn(evaluated.logits, branch.branch_id), 'Native selected logit branch mismatch');
        logits[branch.branch_id] = evaluated.logits[branch.branch_id];
        inputTokens += compiled.tokens.length;
        metrics.push(nativeMetrics);
        evidence.questions.push({ question_id: branch.question_id, branch_id: branch.branch_id,
          ...parity, raw_selected_label_logits: evaluated.logits[branch.branch_id], native_metrics: nativeMetrics,
          compiled_token_sha256: sha(JSON.stringify(compiled.tokens)), generation_tokens: 0 });
      }
      return responseFromSelectedLogits(plan, logits, inputTokens, { per_question_native: metrics }, {
        actual_mode: 'quantized_metal', physical_profile_sha256: this.plan.physical_profile_sha256,
        prototype_source_sha256: this.plan.sources.prototype.sha256,
        binary_sha256: this.plan.artifacts.binary.sha256, raw_model_sha256: this.plan.artifacts.model.sha256,
        raw_model_bytes: this.plan.artifacts.model.bytes,
        raw_template_sha256: EXPECTED.templateSha256, parser_template_sha256: EXPECTED.parserTemplateSha256,
        independent_render_match: true, actual_question_count: plan.questions.length,
      });
    } catch (error) {
      evidence.error = error instanceof Error ? error.message : String(error);
      // Broken transport terminates inference. Production evaluateRecords still records all remaining failures.
      if (this.rpc.snapshot().failure || this.rpc.snapshot().failureCode || this.rpc.snapshot().state !== 'running' || this.rpc.snapshot().exitCode != null)
        this.terminalError = 'Owned native transport terminal: ' + evidence.error;
      throw error;
    } finally {
      evidence.elapsed_ms = performance.now() - started;
      await this.evidenceSink(evidence);
    }
  }
}

export async function evaluateValidation(classifier, sets) {
  const orderedRecords = sets.flatMap(set => set.records);
  const report = await evaluateRecords(classifier, orderedRecords, 'v2');
  return attachValidationCoverage(report, sets);
}

export function attachValidationCoverage(report, sets) {
  const records = sets.flatMap(set => set.records);
  const expectedIds = records.map(record => record.id);
  const actualIds = report.results.map(result => result.id);
  const duplicates = actualIds.filter((id, index) => actualIds.indexOf(id) !== index);
  const missing = expectedIds.filter(id => !actualIds.includes(id));
  const unexpected = actualIds.filter(id => !expectedIds.includes(id));
  const exact = actualIds.length === 194 && duplicates.length === 0 && missing.length === 0 && unexpected.length === 0 && JSON.stringify(actualIds) === JSON.stringify(expectedIds);
  const diagnostics = sets[2].records;
  const diagnosticResults = report.results.filter(result => diagnostics.some(record => record.id === result.id));
  const diagSummary = summarizeQuality(diagnosticResults);
  const groups = [...new Set(diagnostics.map(record => record.group_id))].map(groupId => {
    const expectedRows = diagnostics.filter(record => record.group_id === groupId);
    const rows = expectedRows.map(record => {
      const result = diagnosticResults.find(item => item.id === record.id);
      return { id: record.id, representation: record.request.state != null ? 'state' : 'chat',
        candidate_order: record.id.includes('-order1-') ? 'order1' : 'order2',
        present: !!result, occurrence_count: diagnosticResults.filter(item => item.id === record.id).length,
        error: result?.error ?? null, correct: !!result && !result.error && result.answers.length === 1 && result.answers[0].correct === true };
    });
    const grid = diagnosisGrid(expectedRows);
    return { group_id: groupId, records: rows, cell_counts: grid.counts,
      complete: grid.complete && rows.every(row => row.present && row.occurrence_count === 1), all_correct: rows.every(row => row.correct) };
  });
  const unknownAnswers = report.results.flatMap(result => result.answers).filter(answer => answer.type === 'noul' && answer.target.answer === null);
  const expectedUnknown = records.flatMap(record => record.request.questions.map(question => ({ question, target: record.targets[question.id] }))).filter(({ question, target }) => question.type === 'noul' && target.answer === null).length;
  const unknownMae = unknownAnswers.length ? unknownAnswers.reduce((sum, answer) => sum + answer.normalized_absolute_error, 0) / unknownAnswers.length : null;
  const expectedQuestionCount = records.reduce((sum, record) => sum + record.request.questions.length, 0);
  const actualQuestionCount = report.results.reduce((sum, result) => sum + result.answers.length, 0);
  const setReports = sets.map(set => {
    const rows = report.results.filter(result => set.expected_ids.includes(result.id));
    const summary = summarizeQuality(rows);
    const unknown = rows.flatMap(result => result.answers).filter(answer => answer.type === 'noul' && answer.target.answer === null);
    const expected = set.records.flatMap(record => record.request.questions.map(question => ({ question, target: record.targets[question.id] })))
      .filter(({ question, target }) => question.type === 'noul' && target.answer === null).length;
    const mae = unknown.length ? unknown.reduce((sum, answer) => sum + answer.normalized_absolute_error, 0) / unknown.length : null;
    const expectedQuestions = set.records.reduce((sum, record) => sum + record.request.questions.length, 0);
    const unknownGate = expected > 0 && unknown.length === expected && mae <= 0.1;
    const complete = rows.length === set.records.length && rows.reduce((sum, row) => sum + row.answers.length, 0) === expectedQuestions;
    return { name: set.name, expected_records: set.records.length, expected_groups: set.groups, summary,
      unknown_noul: { expected_count: expected, scored_count: unknown.length, mae, threshold: 0.1, passed: unknownGate },
      complete_question_coverage: complete,
      production_gates_required: set.name !== 'diagnosis-validation-56',
      passed: set.name === 'diagnosis-validation-56' ? null : summary.gates.passed && unknownGate && complete };
  });
  const productionSetsPassed = setReports.slice(0, 2).every(set => set.passed === true);
  const additions = {
    exact_194_record_coverage: exact,
    complete_question_coverage: expectedQuestionCount === actualQuestionCount,
    unknown_noul_mae: expectedUnknown > 0 && unknownAnswers.length === expectedUnknown && unknownMae <= 0.1,
    diagnosis_choice_accuracy: diagnosticResults.length === 56 && diagSummary.failures === 0 && diagSummary.choice.count === 56 && diagSummary.choice.accuracy >= 0.95,
    diagnosis_all_14_groups_56_representations: groups.length === 14 && groups.every(group => group.complete) && diagnosticResults.length === 56,
    independent_render_all_records: report.results.every(result => !result.error && result.metadata?.independent_render_match === true),
    original_quality_gates_independently_on_legacy60_and_developer78: productionSetsPassed,
  };
  const productionGates = Object.fromEntries(Object.entries(report.summary.gates).filter(([name]) => name !== 'passed'));
  return { ...report, research_protocol: { validation_only: true, expected_records: 194, expected_questions: expectedQuestionCount,
      production_quality_gates: QUALITY_GATES, additional_thresholds: { unknown_noul_mae: 0.1, diagnosis_choice_accuracy: 0.95 },
      production_role_approval: false, probability_semantics: 'uncalibrated selected-label scores' },
    coverage: { expected_ids: expectedIds, actual_ids: actualIds, duplicates, missing, unexpected, exact_order: exact,
      expected_question_count: expectedQuestionCount, actual_question_count: actualQuestionCount,
      sets: setReports },
    unknown_noul: { expected_count: expectedUnknown, scored_count: unknownAnswers.length, mae: unknownMae, threshold: 0.1 },
    diagnosis: { summary: diagSummary, groups, expected_groups: 14, expected_records: 56,
      representations: ['state/order1', 'chat/order1', 'state/order2', 'chat/order2'] },
    gates: { production: productionGates, aggregate_production_usage: 'reporting only; legacy60 and developer78 must each independently pass original gates and unknown coverage/MAE',
      production_by_set: Object.fromEntries(setReports.slice(0, 2).map(set => [set.name, {
        ...set.summary.gates, complete_question_coverage: set.complete_question_coverage,
        unknown_noul_mae: set.unknown_noul.passed, passed: set.passed }])),
      additional: additions, passed: productionSetsPassed && Object.values(additions).every(Boolean) },
    limits: 'Validation research only; CPU mocks prove host construction/coverage, not model quality. A passing native report does not establish benchmark improvement or authorize a production role.',
  };
}
