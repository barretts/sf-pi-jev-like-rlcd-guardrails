import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { OwnedRpc, RpcError } from './rpc.mjs';

const fixture = fileURLToPath(new URL('./rpc-mock-child.mjs', import.meta.url));
function mock(t, mode = 'echo', options = {}) {
  const rpc = OwnedRpc.spawn(process.execPath, [fixture, mode], {
    requestTimeoutMs: 1_000,
    totalTimeoutMs: 3_000,
    exitTimeoutMs: 40,
    ...options,
  });
  t.after(async () => {
    const result = await rpc.close();
    assert.equal(result.cleanupError, undefined, 'owned process cleanup must complete');
    assert.equal(result.closedObserved, true, 'wait for the owned child close event');
  });
  return rpc;
}
const packet = (id, payload = { label: 'cpu mock' }) => ({ v: 1, id, payload });
function isCode(code) {
  return (error) => {
    assert.ok(error instanceof RpcError);
    assert.equal(error.code, code);
    return true;
  };
}

test('success preserves finite JSON values and close records the child exit code', async (t) => {
  const rpc = mock(t);
  const payload = { null: null, bool: true, number: 2.5, text: 'hello\n世界', list: [1, false, 'x'] };
  assert.deepEqual(await rpc.request(packet('a', payload)), { v: 1, id: 'a', result: payload });
  const closed = await rpc.close();
  assert.equal(closed.exitCode, 0);
  assert.equal(closed.signal, null);
  assert.equal(closed.exitedObserved, true);
  assert.equal(closed.closedObserved, true);
  assert.equal(closed.resourceEnforcement.rss, 'unavailable');
  assert.equal(closed.resourceEnforcement.cpu, 'unavailable');
});

test('concurrent replies bind to their exact request IDs even in reverse order', async (t) => {
  const rpc = mock(t, 'reverse');
  const [one, two] = await Promise.all([rpc.request(packet('one', 1)), rpc.request(packet('two', 2))]);
  assert.equal(one.result, 1);
  assert.equal(two.result, 2);
});

test('application error envelopes are returned unchanged', async (t) => {
  const rpc = mock(t, 'error');
  assert.deepEqual(await rpc.request(packet('error')), {
    v: 1, id: 'error', error: { code: 'MOCK_FAILURE', message: 'Fixture error envelope.' },
  });
});

test('duplicate submitted IDs are rejected after completion and while pending', async (t) => {
  const rpc = mock(t);
  await rpc.request(packet('used'));
  await assert.rejects(rpc.request(packet('used')), isCode('DUPLICATE_ID'));
  const reverse = mock(t, 'reverse');
  const pending = reverse.request(packet('waiting', 1));
  await assert.rejects(reverse.request(packet('waiting')), isCode('DUPLICATE_ID'));
  const other = reverse.request(packet('other', 2));
  assert.equal((await pending).result, 1);
  assert.equal((await other).result, 2);
});

test('a request cannot change its wire ID during encoding', async (t) => {
  const rpc = mock(t, 'reverse');
  const original = rpc.request(packet('already-pending', 'original payload'));
  let idReads = 0;
  const changed = new Proxy(packet('bound-id', 'wrong payload'), {
    getOwnPropertyDescriptor(target, key) {
      if (key === 'id') return { configurable: true, enumerable: true, writable: true, value: ++idReads === 1 ? 'bound-id' : 'already-pending' };
      return Object.getOwnPropertyDescriptor(target, key);
    },
  });
  await assert.rejects(rpc.request(changed), isCode('INVALID_REQUEST'));
  assert.equal(rpc.snapshot().submittedRequests, 1, 'changed envelope must never reach stdin');
  const second = rpc.request(packet('second', 'second payload'));
  assert.equal((await original).result, 'original payload');
  assert.equal((await second).result, 'second payload');
});

test('a mismatched response ID fails and closes the owned child', async (t) => {
  const rpc = mock(t, 'bad-id');
  await assert.rejects(rpc.request(packet('expected')), isCode('UNEXPECTED_ID'));
  assert.equal(rpc.snapshot().closedObserved, true);
  assert.equal(rpc.snapshot().pendingRequests, 0);
});

for (const mode of ['oversize', 'oversize-no-newline']) {
  test(`response cap terminates ${mode} output before accepting a response`, async (t) => {
    const rpc = mock(t, mode, { maxResponseBytes: 128 });
    await assert.rejects(rpc.request(packet('cap')), isCode('RESPONSE_TOO_LARGE'));
    assert.equal(rpc.snapshot().closedObserved, true);
  });
}

test('an oversized outgoing packet is never submitted and leaves the session usable', async (t) => {
  const rpc = mock(t, 'echo', { maxPacketBytes: 128 });
  await assert.rejects(rpc.request(packet('too-big', 'x'.repeat(256))), isCode('PACKET_TOO_LARGE'));
  assert.equal(rpc.snapshot().submittedRequests, 0);
  assert.equal((await rpc.request(packet('small', 'ok'))).result, 'ok');
});

test('packet caps count UTF-8 bytes and the JSONL newline', async (t) => {
  const exact = packet('boundary', 'é');
  const bytes = Buffer.byteLength(JSON.stringify(exact) + '\n');
  const fits = mock(t, 'echo', { maxPacketBytes: bytes });
  assert.equal((await fits.request(exact)).result, 'é');
  const short = mock(t, 'echo', { maxPacketBytes: bytes - 1 });
  await assert.rejects(short.request(exact), isCode('PACKET_TOO_LARGE'));
});

test('nonfinite, cyclic, sparse, and accessor inputs are rejected without invoking a getter', async (t) => {
  const rpc = mock(t);
  let getterCalls = 0;
  const getter = { v: 1, id: 'getter', get payload() { getterCalls++; return 1; } };
  const cycle = {};
  cycle.self = cycle;
  for (const [id, value] of [['nan', NaN], ['infinity', Infinity], ['cycle', cycle], ['sparse', new Array(2)], ['undefined', undefined], ['bigint', 1n]]) {
    await assert.rejects(rpc.request({ v: 1, id, payload: value }), isCode('INVALID_REQUEST'));
  }
  await assert.rejects(rpc.request(getter), isCode('INVALID_REQUEST'));
  assert.equal(getterCalls, 0);
  assert.equal(rpc.snapshot().submittedRequests, 0);
  await rpc.request(packet('valid'));
});

for (const [mode, code] of [['malformed', 'MALFORMED_RESPONSE'], ['invalid-utf8', 'MALFORMED_RESPONSE'], ['nonfinite', 'INVALID_RESPONSE'], ['bad-version', 'INVALID_RESPONSE'], ['unterminated', 'UNTERMINATED_RESPONSE']]) {
  test(`${mode} child output is rejected and cleaned up`, async (t) => {
    const rpc = mock(t, mode);
    await assert.rejects(rpc.request(packet(mode)), isCode(code));
    assert.equal(rpc.snapshot().closedObserved, true);
  });
}

test('child exit rejects the pending request after collecting its exit code and stderr', async (t) => {
  const rpc = mock(t, 'exit');
  await assert.rejects(rpc.request(packet('exit')), (error) => {
    isCode('CHILD_EXIT')(error);
    assert.equal(error.details.exitCode, 7);
    assert.equal(error.details.closedObserved, true);
    assert.match(error.details.stderr, /mock exited deliberately/);
    return true;
  });
});

test('request timeout escalates TERM to KILL and does not affect another owned child', async (t) => {
  const sentinel = mock(t, 'echo');
  await sentinel.request(packet('sentinel-before'));
  const rpc = mock(t, 'ignore-term', { requestTimeoutMs: 120, exitTimeoutMs: 40 });
  await assert.rejects(rpc.request(packet('hang')), isCode('REQUEST_TIMEOUT'));
  const result = rpc.snapshot();
  assert.deepEqual(result.signalsSent, ['SIGTERM', 'SIGKILL']);
  assert.equal(result.signal, 'SIGKILL');
  assert.equal(result.closedObserved, true);
  assert.match(result.stderr, /ignored SIGTERM/);
  assert.equal((await sentinel.request(packet('sentinel-after', 'still alive'))).result, 'still alive');
});

test('total timeout covers a request whose individual deadline is longer', async (t) => {
  const rpc = mock(t, 'ignore-term', { requestTimeoutMs: 1_000, totalTimeoutMs: 150, exitTimeoutMs: 30 });
  await assert.rejects(rpc.request(packet('total')), isCode('TOTAL_TIMEOUT'));
  const result = rpc.snapshot();
  assert.equal(result.closedObserved, true);
  assert.ok(result.elapsedMs < 1_000, `bounded operational deadline plus cleanup took ${result.elapsedMs} ms`);
});

test('the write/backpressure phase shares the original request deadline', async (t) => {
  const rpc = mock(t, 'no-read', { requestTimeoutMs: 120, maxPacketBytes: 2_097_152 });
  await assert.rejects(rpc.request(packet('blocked-write', 'x'.repeat(1_048_576))), isCode('REQUEST_TIMEOUT'));
  const result = rpc.snapshot();
  assert.equal(result.submittedRequests, 1);
  assert.equal(result.writesCompleted, 0, 'the child never drained the full packet');
  assert.equal(result.stdoutBytesSeen, 0);
  assert.equal(result.closedObserved, true);
});

test('abort waits for owned process cleanup before rejecting', async (t) => {
  const rpc = mock(t, 'ignore-term');
  const controller = new AbortController();
  const response = rpc.request(packet('abort'), { signal: controller.signal });
  controller.abort();
  await assert.rejects(response, isCode('ABORTED'));
  assert.equal(rpc.snapshot().closedObserved, true);
  assert.equal(rpc.snapshot().pendingRequests, 0);
});

test('elapsed time during outgoing encoding counts toward the request deadline', async (t) => {
  const rpc = mock(t, 'echo', { requestTimeoutMs: 10 });
  const request = new Proxy(packet('slow-encoding'), {
    ownKeys(target) {
      const until = performance.now() + 30;
      while (performance.now() < until) { /* bounded CPU-only encoding stall */ }
      return Reflect.ownKeys(target);
    },
  });
  await assert.rejects(rpc.request(request), isCode('REQUEST_TIMEOUT'));
  assert.equal(rpc.snapshot().submittedRequests, 0);
  assert.equal(rpc.snapshot().closedObserved, true);
});

test('stderr retains only its bounded tail with truthful truncation accounting', async (t) => {
  const rpc = mock(t, 'stderr-tail', { maxStderrBytes: 64 });
  await rpc.request(packet('stderr'));
  const result = await rpc.close();
  assert.equal(result.stderrBytesRetained, 64);
  assert.ok(Buffer.byteLength(result.stderr) <= 64);
  assert.equal(result.stderrTruncated, true);
  assert.ok(result.stderrBytesSeen > 4_096);
  assert.ok(result.stderr.endsWith('FINAL STDERR MARKER'));
});

test('timeout cleanup drains the final shutdown stderr before observing close', async (t) => {
  const rpc = mock(t, 'shutdown-stderr', { requestTimeoutMs: 150, exitTimeoutMs: 100, maxStderrBytes: 64 });
  await assert.rejects(rpc.request(packet('shutdown')), isCode('REQUEST_TIMEOUT'));
  const result = rpc.snapshot();
  assert.equal(result.exitCode, 0);
  assert.equal(result.closedObserved, true);
  assert.equal(result.stderrBytesSeen, 262_144 + Buffer.byteLength('FINAL SHUTDOWN STDERR'));
  assert.ok(result.stderr.endsWith('FINAL SHUTDOWN STDERR'));
});

test('request accounting has a finite cap', async (t) => {
  const rpc = mock(t, 'echo', { maxRequests: 1 });
  await rpc.request(packet('one'));
  await assert.rejects(rpc.request(packet('two')), isCode('REQUEST_LIMIT'));
});

test('invalid command and nonfinite limits fail before spawning', () => {
  assert.throws(() => OwnedRpc.spawn('', []), isCode('INVALID_COMMAND'));
  assert.throws(() => OwnedRpc.spawn(process.execPath, [], { requestTimeoutMs: Infinity }), isCode('INVALID_OPTIONS'));
  assert.throws(() => OwnedRpc.spawn(process.execPath, [], { maxResponseBytes: 0 }), isCode('INVALID_OPTIONS'));
});
