import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdtemp, rm, stat, realpath } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { dirname, join, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { loadQualityRecords, QUALITY_GATES } from '../../../../dist/evaluation.js';
import { preparePrompt } from '../../../../dist/core.js';

export const HERE = dirname(fileURLToPath(import.meta.url));
export const PROTOTYPE = dirname(HERE);
export const ROOT = resolve(HERE, '../../../..');
export const MODEL = join(ROOT, 'models/gemma-4-31B_q4_0-it.gguf');
export const TEMPLATE = join(ROOT, 'models/gemma-4-31B-it.chat_template.jinja');
export const BINARY = join(PROTOTYPE, 'gemma4-label-prototype');
export const EXPECTED = Object.freeze({
  modelSha256: '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b',
  modelBytes: 17651001568,
  templateSha256: 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4',
  templateBytes: 18683,
  parserTemplateSha256: '6a1015c47ccfcfa67c3b772385bccee357a4d37c3cda37bd202e9047f391ab82',
  parserTemplateBytes: 18682,
  sourceSha256: 'f2dc4e3457bb422219c24d6658757f3cd588ff3115d4e320c0c23e9582d332fb',
  binarySha256: '8d20a2b54edc87489f8e6648f81b99f81513328c39c55d14fcbad1f2f09392a8',
  vocabProofSha256: '2567a78d1a02bd8d22316680b3610b735070342d29f0fdf5589ebf80e30c5797',
  jinjaProofSha256: '6f1c7eb9fa97fd8b33dd3dd2ff842d2a361592f5666ec24ba344150571491acd',
  profile: 'gemma4-direct-label-raw-q4-research-v0',
  generationBoundary: '<|turn>model\n<|channel>thought\n<channel|>',
});
export const INPUTS = Object.freeze([
  { name: 'legacy-validation-60', path: join(ROOT, '.build/improvement-experiments/validation-label-audit/legacy-validation-60.jsonl'), records: 60, groups: 30 },
  { name: 'developer-validation-78', path: join(ROOT, '.build/improvement-experiments/validation-label-audit/validation-78.jsonl'), records: 78, groups: 39 },
  { name: 'diagnosis-validation-56', path: join(ROOT, '.build/improvement-experiments/conditional-supervision-comparison/diagnosis-validation-56.jsonl'), records: 56, groups: 14 },
]);
export const LIMITS = Object.freeze({
  requestTimeoutMs: 600000, totalTimeoutMs: 21600000,
  maxPacketBytes: 262144, maxResponseBytes: 67108864,
  maxStderrBytes: 16777216, exitTimeoutMs: 10000,
  max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048,
  maxRecords: 194, nativeProcesses: 1, concurrentRpc: 1,
  generationTokens: 0, prefillStrategy: 'full',
});
export const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
export const insist = (condition, message) => { if (!condition) throw new Error(message); };
export const initRequest = () => ({ v: 1, id: 'init', op: 'init', research_profile: EXPECTED.profile,
  model_file: MODEL, chat_template_file: TEMPLATE, vocab_only: false, device: 'metal',
  max_model_len: LIMITS.max_model_len, max_batch_size: LIMITS.max_batch_size,
  max_batch_tokens: LIMITS.max_batch_tokens });
export function packetBytes(value) {
  const bytes = Buffer.byteLength(JSON.stringify(value)) + 1;
  insist(bytes <= LIMITS.maxPacketBytes, 'Outgoing packet exceeds frozen 256 KiB cap');
  return bytes;
}
export async function fileIdentity(path, { stream = false } = {}) {
  const info = await stat(path);
  insist(info.isFile(), `Expected regular file: ${path}`);
  if (!stream) return { path, bytes: info.size, sha256: sha(await readFile(path)) };
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return { path, bytes: info.size, sha256: hash.digest('hex') };
}
export async function ownedNewPath(path) {
  const absolute = resolve(path);
  const parent = await realpath(dirname(absolute));
  insist(parent === HERE || parent.startsWith(HERE + '/'), 'Output parent must remain inside research-quality');
  try { await stat(absolute); throw new Error('Output already exists; preserve previous evidence'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  return absolute;
}

export function diagnosisGrid(records) {
  const counts = { 'state/order1': 0, 'chat/order1': 0, 'state/order2': 0, 'chat/order2': 0 };
  let valid = records.length === 4 && new Set(records.map(record => record.id)).size === 4;
  for (const record of records) {
    const representation = record.request.state != null ? 'state' : record.request.messages != null ? 'chat' : null;
    const suffix = record.id.match(/-order([12])-(state|chat)$/);
    if (!suffix || suffix[2] !== representation) { valid = false; continue; }
    counts[representation + '/order' + suffix[1]]++;
  }
  return { counts, complete: valid && Object.values(counts).every(count => count === 1) };
}

/** Load only exact validation paths, using immutable byte snapshots and the production loader. */
export async function readInputSets(snapshotDirectory = null) {
  const temporary = snapshotDirectory === null;
  const directory = snapshotDirectory ?? await mkdtemp(join(HERE, '.input-snapshot-'));
  const sets = [];
  const globalIds = new Set();
  const globalGroups = new Set();
  try {
    for (const spec of INPUTS) {
      const bytes = await readFile(spec.path);
      const snapshot = join(directory, spec.name + '.jsonl');
      await writeFile(snapshot, bytes, { flag: 'wx', mode: 0o600 });
      const records = await loadQualityRecords(snapshot);
      insist(sha(await readFile(snapshot)) === sha(bytes), 'Snapshot changed during production load');
      insist(records.length === spec.records, `${spec.name}: expected ${spec.records} records`);
      insist(records.every(record => record.split === 'validation'), 'Any non-validation record is prohibited');
      const groups = new Set(records.map(record => record.group_id));
      insist(groups.size === spec.groups, `${spec.name}: unexpected group coverage`);
      for (const record of records) {
        insist(!globalIds.has(record.id), `Duplicate record ID across inputs: ${record.id}`);
        globalIds.add(record.id);
        const plan = preparePrompt({ ...record.request, options: { ...record.request.options, template_version: 'v2' } }, 'v2');
        for (const branch of plan.questions) packetBytes({ v: 1, id: 'compile-preflight', op: 'compile', branches: [wireBranch(branch)] });
      }
      for (const group of groups) {
        insist(!globalGroups.has(group), `Duplicate group across inputs: ${group}`);
        globalGroups.add(group);
      }
      if (spec.name === 'diagnosis-validation-56') {
        insist(records.every(record => record.request.questions.length === 1 && record.request.questions[0].type === 'choice'), 'Diagnosis requires one choice question per record');
        for (const group of groups) {
          const rows = records.filter(record => record.group_id === group);
          insist(diagnosisGrid(rows).complete, `Diagnosis group requires exactly one state/order1, chat/order1, state/order2, chat/order2: ${group}`);
        }
      }
      sets.push({ ...spec, records, input_sha256: sha(bytes), input_bytes: bytes.length,
        expected_ids: records.map(record => record.id), logical_prompt_sha256: records.map(record => {
          const plan = preparePrompt({ ...record.request, options: { ...record.request.options, template_version: 'v2' } }, 'v2');
          return [record.id, sha(JSON.stringify(plan.questions))];
        }) });
    }
    insist(globalIds.size === 194, 'Exactly 194 distinct records required');
    return sets;
  } finally { if (temporary) await rm(directory, { recursive: true }); }
}
export const wireBranch = branch => ({ branch_id: branch.branch_id, messages: branch.messages,
  answer_prefix: branch.answer_prefix, output_labels: branch.output_labels });

export function validateProvenance(provenance, plan, { vocabulary = false } = {}) {
  insist(provenance?.prototype_source_sha256 === EXPECTED.sourceSha256, 'Executed source mismatch');
  insist(provenance.physical_profile?.id === EXPECTED.profile, 'Physical profile mismatch');
  insist(provenance.physical_profile_sha256 === plan.physical_profile_sha256, 'Physical profile SHA mismatch');
  insist(JSON.stringify(provenance.physical_profile) === JSON.stringify(plan.physical_profile), 'Physical profile contents mismatch');
  insist(sha(JSON.stringify(provenance.physical_profile)) === provenance.physical_profile_sha256, 'Physical profile SHA does not match serialized profile');
  insist(provenance.model_expected_sha256 === EXPECTED.modelSha256, 'Raw model expected SHA mismatch');
  insist(provenance.physical_profile.model_expected_size === EXPECTED.modelBytes, 'Raw model size mismatch');
  insist(provenance.template_raw_identity?.sha256 === EXPECTED.templateSha256 && provenance.template_raw_identity.bytes === EXPECTED.templateBytes && provenance.template_raw_identity.verified === true, 'Raw template identity mismatch');
  insist(provenance.template_parser_identity?.sha256 === EXPECTED.parserTemplateSha256 && provenance.template_parser_identity.bytes === EXPECTED.parserTemplateBytes && provenance.template_parser_identity.verified === true, 'Parser template identity mismatch');
  insist(provenance.bos_token_id === 2 && provenance.bos_piece === '<bos>', 'Reviewed vocabulary BOS identity mismatch');
  insist(provenance.actual_mode === (vocabulary ? 'cpu_vocabulary_only_no_context' : 'quantized_metal'), 'Actual execution mode mismatch');
  insist(provenance.vocab_only === vocabulary && provenance.weights_loaded === !vocabulary && provenance.context_created === !vocabulary && provenance.explicit_backend_init === !vocabulary, 'Weight/context/backend initialization scope mismatch');
  insist(provenance.device === (vocabulary ? 'cpu' : 'metal'), 'Actual device mismatch');
  insist(provenance.effective_limits?.max_model_len === 2048 && provenance.effective_limits.max_batch_size === 1 && provenance.effective_limits.max_batch_tokens === 2048, 'Effective runtime limits mismatch');
  if (!vocabulary) insist(provenance.gpu_layers_requested === 99 && provenance.offload_kqv === true && provenance.op_offload === true && provenance.context_train_limit_checked === true, 'Requested Metal offload/train context mismatch');
}

export async function prerequisiteProofs() {
  const vocab = await fileIdentity(join(PROTOTYPE, 'vocab-proof-root-3/proof.json'));
  const jinja = await fileIdentity(join(PROTOTYPE, 'vocab-proof-root-3/jinja-reference.json'));
  insist(vocab.sha256 === EXPECTED.vocabProofSha256 && jinja.sha256 === EXPECTED.jinjaProofSha256, 'Prerequisite proof SHA mismatch');
  const proof = JSON.parse(await readFile(vocab.path, 'utf8'));
  const reference = JSON.parse(await readFile(jinja.path, 'utf8'));
  insist(proof.stage === 'vocab' && proof.probe_contracts_passed === true && proof.native_exit_code === 0 && proof.vocabulary_only_evaluation_rejected === true, 'Successful zero-weight vocabulary proof required');
  insist(proof.prototype_source_sha256 === EXPECTED.sourceSha256 && proof.binary_sha256 === EXPECTED.binarySha256, 'Vocabulary proof source/binary mismatch');
  insist(reference.kind === 'jev_root_independent_gemma4_render_contract' && reference.vocabulary_proof_sha256 === vocab.sha256 && reference.original_raw_template_sha256 === EXPECTED.templateSha256 && reference.all_exact_render_match === true && reference.zero_weights_or_context === true && reference.checks?.length === 3 && reference.checks.every(check => check.exact_render_match === true && check.BOS_exactly_once === true), 'Successful independent original-template Jinja proof required');
  const provenance = proof.rpc?.find(attempt => attempt.request.op === 'init')?.response?.result?.provenance;
  const profile = { physical_profile: provenance?.physical_profile, physical_profile_sha256: provenance?.physical_profile_sha256 };
  validateProvenance(provenance, profile, { vocabulary: true });
  return { vocab, jinja, ...profile };
}

export async function researchSourceIdentities() {
  const names = ['protocol.mjs', 'quality.mjs', 'runner.mjs', 'rpc.mjs', 'render-reference.py'];
  return Promise.all(names.map(name => fileIdentity(join(HERE, name))));
}
export async function productionSourceIdentities() {
  return Promise.all(['dist/core.js', 'dist/evaluation.js'].map(name => fileIdentity(join(ROOT, name))));
}

export async function rendererRuntimeIdentity() {
  const execute = promisify(execFile);
  const { stdout } = await execute('/usr/bin/env', ['python3', join(HERE, 'render-reference.py'), '--runtime-identity'],
    { cwd: HERE, timeout: 10000, maxBuffer: 1024 * 1024, encoding: 'utf8' });
  const identity = JSON.parse(stdout);
  insist(identity.jinja_version === '3.1.6', 'Independent renderer must use reviewed Jinja 3.1.6');
  return identity;
}

/** Future ROOT-only source freeze. This function reads the binary and raw model; CPU tests never call it. */
export async function freezePlan() {
  const sets = await readInputSets();
  const prerequisites = await prerequisiteProofs();
  const compile = await fileIdentity(join(PROTOTYPE, 'compile-evidence.json'));
  const compileEvidence = JSON.parse(await readFile(compile.path, 'utf8'));
  const source = await fileIdentity(join(PROTOTYPE, 'main.cpp'));
  const binary = await fileIdentity(BINARY);
  const model = await fileIdentity(MODEL, { stream: true });
  const template = await fileIdentity(TEMPLATE);
  insist(source.sha256 === EXPECTED.sourceSha256 && binary.sha256 === EXPECTED.binarySha256, 'Released source/binary changed');
  insist(compileEvidence.compiler_exit_code === 0 && compileEvidence.prototype_source_sha256 === source.sha256 && compileEvidence.binary_sha256 === binary.sha256, 'Compile evidence must bind released source and binary');
  insist(model.sha256 === EXPECTED.modelSha256 && model.bytes === EXPECTED.modelBytes, 'Exact raw official GGUF required');
  insist(template.sha256 === EXPECTED.templateSha256 && template.bytes === EXPECTED.templateBytes, 'Exact original corrected raw Jinja required');
  return { schema_version: 1, kind: 'gemma4_validation_research_frozen_run_plan', frozen_at: new Date().toISOString(),
    scope: 'validation_only_research_no_role_promotion', template_version: 'v2', requested_mode: 'quantized_metal',
    research_profile: EXPECTED.profile, physical_profile: prerequisites.physical_profile, physical_profile_sha256: prerequisites.physical_profile_sha256,
    sources: { research: await researchSourceIdentities(), production: await productionSourceIdentities(), prototype: source, compile },
    host_runtime: { node_version: process.version, node_executable: await fileIdentity(process.execPath), renderer: await rendererRuntimeIdentity() },
    artifacts: { binary, model, template }, prerequisites: { vocab: prerequisites.vocab, jinja: prerequisites.jinja },
    inputs: sets.map(({ records, ...set }) => ({ ...set, records: records.length })),
    execution_order: sets.flatMap(set => set.expected_ids), expected_records: 194,
    runtime_bounds: LIMITS, rpc_init: initRequest(), logical_prompt_rule: 'unchanged production preparePrompt v2; one actual question per compile/evaluate',
    native_question_rule: 'full prefill; one branch; selected label logits; zero generation; no shared prefix',
    independent_render_rule: 'Python Jinja original raw template, disabled thinking, final two user messages merged exactly once, BOS and answer prefix',
    quality_gates: QUALITY_GATES, quality_gate_application: 'original gates and unknown NOUL MAE/coverage independently required on legacy60 and developer78; aggregate reporting only',
    additional_gates: { unknown_noul_mae: 0.1, unknown_noul_mae_application: 'independent complete unknown coverage and MAE per legacy60 and developer78', diagnosis_choice_accuracy: 0.95, exact_194_record_coverage: true, all_14_diagnosis_groups_and_56_representations: true },
    approval_effect: 'none; frozen plan and passing quality do not promote a production registry role or RFDT gate',
    probability_semantics: 'uncalibrated softmax over selected labels only; no whole-vocabulary likelihood or confidence calibration',
    cold_scope: 'new owned native process and new model/context initialization; filesystem caches and prior GPU state may be warm',
  };
}

export async function verifyFrozenIdentities(plan) {
  insist(plan.kind === 'gemma4_validation_research_frozen_run_plan' && plan.template_version === 'v2' && plan.expected_records === 194, 'Unsupported plan');
  insist(JSON.stringify(plan.runtime_bounds) === JSON.stringify(LIMITS), 'Frozen runtime bounds changed');
  insist(JSON.stringify(plan.quality_gates) === JSON.stringify(QUALITY_GATES), 'Production QUALITY_GATES changed');
  insist(JSON.stringify(plan.rpc_init) === JSON.stringify(initRequest()), 'Frozen init request changed');
  for (const identity of [...plan.sources.research, ...plan.sources.production, plan.sources.prototype, plan.sources.compile, plan.artifacts.binary, plan.artifacts.model, plan.artifacts.template, plan.prerequisites.vocab, plan.prerequisites.jinja]) {
    const current = await fileIdentity(identity.path, { stream: identity.path === MODEL });
    insist(current.sha256 === identity.sha256 && current.bytes === identity.bytes, `Frozen artifact changed: ${relative(ROOT, identity.path)}`);
  }
  const prerequisites = await prerequisiteProofs();
  insist(prerequisites.physical_profile_sha256 === plan.physical_profile_sha256, 'Frozen physical profile changed');
  insist(plan.artifacts.model.path === MODEL && plan.artifacts.binary.path === BINARY && plan.artifacts.template.path === TEMPLATE, 'Artifact paths must equal literal reviewed paths');
  insist(plan.artifacts.model.sha256 === EXPECTED.modelSha256 && plan.artifacts.model.bytes === EXPECTED.modelBytes && plan.artifacts.binary.sha256 === EXPECTED.binarySha256 && plan.sources.prototype.sha256 === EXPECTED.sourceSha256, 'Plan literal artifact identity mismatch');
  const expectedSources = [...await researchSourceIdentities(), ...await productionSourceIdentities()];
  insist(JSON.stringify([...plan.sources.research, ...plan.sources.production]) === JSON.stringify(expectedSources), 'Plan must bind every executed host source');
  insist(plan.host_runtime.node_version === process.version && JSON.stringify(plan.host_runtime.node_executable) === JSON.stringify(await fileIdentity(process.execPath)), 'Frozen Node runtime changed');
  insist(JSON.stringify(plan.host_runtime.renderer) === JSON.stringify(await rendererRuntimeIdentity()), 'Frozen Python/Jinja runtime changed');
}
