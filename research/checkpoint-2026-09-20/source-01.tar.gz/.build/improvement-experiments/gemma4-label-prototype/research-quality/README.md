This folder contains a source and CPU mock validation runner for a later, separately ROOT-cleared Gemma 4 research stage. It does not change production sources, registries, native binaries, RFDT gates, fixtures, model roles, or evaluation gates. Passing these CPU checks supplies no inference permission and proves no model quality.

The only allowed data inputs are the exact `legacy-validation-60.jsonl`, `validation-78.jsonl`, and `diagnosis-validation-56.jsonl` files named in `protocol.mjs`. Production `loadQualityRecords` loads immutable copies of their bytes. Every record must be validation. The runner rejects changed counts, overlapping IDs/groups, altered order, and incomplete diagnosis groups. The stage contains exactly 194 one-question records: 102 choice, 46 NOUL, and 46 score questions, with 83 groups. Diagnosis contains all 14 groups and their two candidate orders in both state and chat form, accounting for all 56 records.

Production `evaluateRecords`, `preparePrompt` v2, and `buildResponse(plan, logits, input_tokens, advanced, extra)` provide the host prompt, response, and scoring contract. Validation targets are read only for host scoring. The classifier RPC receives logical messages, output labels, and the existing JSON answer prefix; it never receives targets, split metadata, or group metadata. Native compile and evaluation run once for each actual logical question. Evaluation explicitly uses full prefill, one branch, zero generated tokens, and logits only at the actual selected label tokens. Selected-label softmax is uncalibrated and does not describe whole-vocabulary likelihood.

The frozen physical research profile uses the exact raw official 17,651,001,568-byte GGUF and corrected original 18,683-byte Jinja, with the reviewed parser source identity that removes exactly one terminal LF. The released source, binary, compile evidence, successful zero-weight vocabulary proof, and independent three-branch ROOT Jinja proof are pinned in `protocol.mjs`. Future freeze and run recompute the model SHA in full. The freeze also binds every executed host source, the Node executable, Python executable, Python/Jinja versions and Jinja Python source hashes, input byte SHA, logical prompt SHA, all record IDs/order, physical profile, selected-label semantics, limits, gates, and cold scope before inference.

Before future native launch, the independent Python renderer evaluates the ORIGINAL raw template for all 194 production questions using ROOT's independently established `ImmutableSandboxedEnvironment(trim_blocks=True, lstrip_blocks=True)`, actual reviewed `<bos>`, empty EOS, `add_generation_prompt=True`, `enable_thinking=False`, and no tools argument. It preserves roles/history and merges ONLY the final user message into the immediately preceding user message with `\n\n`. The parity report records this normalization for every record, including the chat score requests. Each actual native compile must then match the independent rendered bytes, have exactly one initial BOS, stay within 2048 actual tokens, and return distinct label token IDs before it may be evaluated.

The RPC helper owns one directly spawned native PID. Native requests are sequential, IDs are unique, outgoing packets are capped at 256 KiB including LF, each response line is capped at 64 MiB including LF, retained stderr is capped at 16 MiB, each RPC is bounded to 600 seconds including encode/write/read/parse, and operational lifetime is bounded to six hours. The maximum combined RPC and question evidence is 128 MiB. Cleanup sends signals only to the directly owned process, waits for exit, and preserves the actual exit/signal/error state. It does not promise descendant-process cleanup; the reviewed native binary creates no subprocesses. Node timers require a responsive event loop and are not kernel CPU/RSS limits. No process discovery, cancellation, or cleanup of another owner's processes is performed.

Native evidence retains raw selected logits, label-to-answer semantics, actual compiled token counts and token SHA, decoded token/forward counters, generation count, per-record and init elapsed time, requested and actual execution mode, physical profile, executed source/binary/model/template identities, bounded raw protocol traces, and actual exit/cleanup state. Native RSS/CPU observations use one-second `ps` samples and clearly distinguish sampled peaks from true peaks. Node `resourceUsage` describes the host runner only. Neither establishes GPU allocations, whole-host memory residency, an admission budget, or calibration. The init cold scope means a new owned native process and model/context initialization; filesystem caches and prior GPU state can remain warm.

All 194 rows remain in the production quality report, including initialization, transport, missing-answer, native compile, render, context, and evaluation failures. A fatal transport stops additional inference and yields explicit failed rows for the remainder. Reports require unchanged original `QUALITY_GATES` independently on legacy60 and developer78, plus unknown NOUL MAE at most 0.1 with complete unknown coverage independently on both sets. Aggregate quality metrics are retained for reporting only. Additional gates require diagnosis choice accuracy at least 0.95, exact ordered 194-row and full-question coverage, and all 14 diagnosis groups/all 56 representations. Native acceptance also requires the returned close result and observed direct-child exit/close, exit zero, no signal, no transport failure, no cleanup error, no audit failure and zero pending work. Failed rows cannot be dropped to make gates pass. CPU uniform mocks intentionally fail the native quality/render gates. This standalone validation report does not prove a benchmark gain or authorize a production role.

To produce a fresh CPU proof (authorized source/CPU activity only):

```bash
node .build/improvement-experiments/gemma4-label-prototype/research-quality/cpu-proof.mjs \
  --proof-dir .build/improvement-experiments/gemma4-label-prototype/research-quality/cpu-proof-1
```

Later, ROOT may review this implementation and freeze artifacts after the prior owned stage has exited. This command reads source, binaries, model bytes, template bytes and runtime identities, but launches no native process:

```bash
node .build/improvement-experiments/gemma4-label-prototype/research-quality/runner.mjs freeze \
  --output .build/improvement-experiments/gemma4-label-prototype/research-quality/frozen-run-plan-root.json
```

ROOT must then write an explicit clearance JSON for that exact output SHA. The runner requires these fields:

```json
{
  "kind": "gemma4_validation_research_root_clearance",
  "stage_cleared": true,
  "clearance_scope": "validation_194_one_owned_sequential_metal_process",
  "run_plan_sha256": "ROOT fills SHA256 of exact frozen plan bytes",
  "successful_vocab_and_independent_jinja_reviewed": true,
  "tiny_three_question_metal_proof_reviewed": true,
  "exact_model_sha256_verified": "179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b",
  "production_role_approval": false
}
```

Only ROOT may review, clear, and execute the future inference stage:

```bash
node .build/improvement-experiments/gemma4-label-prototype/research-quality/runner.mjs run \
  --plan .build/improvement-experiments/gemma4-label-prototype/research-quality/frozen-run-plan-root.json \
  --root-clearance .build/improvement-experiments/gemma4-label-prototype/research-quality/root-clearance.json \
  --proof-dir .build/improvement-experiments/gemma4-label-prototype/research-quality/native-proof-root-1
```

Use fresh output paths every time; existing proof files and directories are refused. No broad quality inference has been authorized or performed by the implementation agent.
