import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile, access } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import ts from '../../../node_modules/typescript/lib/typescript.js';

// Public schema and logical-prompt validation only. There is no classifier,
// tokenizer, native backend, model import, inference, GPU, worker, or training call.
const root = resolve(import.meta.dirname, '../../..');
const proof = import.meta.dirname;
const sourceNames = ['src/automation.ts', 'src/recipes.ts', 'src/core.ts', 'src/evaluation.ts'];
const contextNames = ['README.md', 'package.json', '.gitignore'];
const frozenTrain = '.build/improvement-experiments/rfdt-inputs/combined-train-570.jsonl';
const paths = {
  train: 'fixtures/developer-supplement-train.jsonl',
  validation: 'fixtures/developer-diagnosis-validation.jsonl',
  notes: 'fixtures/developer-supplement.md',
};
const sha = (value) => createHash('sha256').update(value).digest('hex');
const source = Object.fromEntries(await Promise.all(sourceNames.map(async name => [name, await readFile(join(root, name), 'utf8')])));
const sourceHashes = Object.fromEntries(sourceNames.map(name => [name, sha(source[name])]));
const contextHashes = Object.fromEntries(await Promise.all(contextNames.map(async name => [name, sha(await readFile(join(root, name)))])));
const originalTrainHash = sha(await readFile(join(root, frozenTrain)));
const definitionsText = await readFile(join(proof, 'authored-cases.json'), 'utf8');
const definitions = JSON.parse(definitionsText);
const revision = JSON.parse(await readFile(join(proof, 'revision-provenance.json'), 'utf8'));
const priorProof = join(root, revision.prior_proof_path);
const priorSourceHashes = revision.prior_source_hashes;
assert.deepEqual(sourceHashes, priorSourceHashes, 'Production/public sources changed between preparation revisions');
const verifyPriorProof = async () => {
  for (const [name, expected] of Object.entries(revision.prior_proof_hashes))
    assert.equal(sha(await readFile(join(priorProof, name))), expected, `Original proof changed: ${name}`);
};
await verifyPriorProof();
for (const path of Object.values(paths)) {
  let exists = true;
  try { await access(join(root, path)); } catch { exists = false; }
  assert.equal(exists, true, `Owned original output is absent: ${path}`);
  assert.equal(sha(await readFile(join(root, path))), revision.prior_output_hashes[path], `Owned output changed since original freeze: ${path}`);
}

await mkdir(join(proof, 'sources'), { recursive: true });
await mkdir(join(proof, 'public'), { recursive: true });
for (const name of sourceNames) await writeFile(join(proof, 'sources', name.slice(4)), source[name]);
const projections = {
  core: source['src/core.ts'],
  recipes: source['src/recipes.ts'],
  evaluation: source['src/evaluation.ts'],
  'automation-families': source['src/automation.ts'].slice(source['src/automation.ts'].indexOf('export interface RouteFamily'), source['src/automation.ts'].indexOf('export interface JevReport')),
};
const projectionHashes = {};
for (const [name, text] of Object.entries(projections)) {
  const imports = [...text.matchAll(/from\s+["']([^"']+)["']/g)].map(match => match[1]);
  assert(imports.every(specifier => ['node:crypto', 'node:fs/promises', 'node:path', './core.js'].includes(specifier)), `Non-public import in ${name}`);
  const result = ts.transpileModule(text, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 }, reportDiagnostics: true });
  assert.equal((result.diagnostics ?? []).filter(diagnostic => diagnostic.category === ts.DiagnosticCategory.Error).length, 0);
  const code = result.outputText.replaceAll('"./core.js"', '"./core.mjs"');
  await writeFile(join(proof, 'public', name + '.mjs'), code);
  projectionHashes[name] = sha(code);
}
const { canonical, validateRequest, preparePrompt } = await import(pathToFileURL(join(proof, 'public/core.mjs')));
const { buildDeveloperRecipeRequest } = await import(pathToFileURL(join(proof, 'public/recipes.mjs')));
const { validateQualityRecords } = await import(pathToFileURL(join(proof, 'public/evaluation.mjs')));
const { availableRouteFamilies } = await import(pathToFileURL(join(proof, 'public/automation-families.mjs')));
const model = 'google/gemma-3-1b-it';

// Representative tool identifiers are synthetic. Family availability is the
// unchanged production helper's exact output, never a deployed-tool assertion.
const representativeTools = {
  agentscript: 'agentscript_preview', apex: 'sf_apex', flow: 'sf_flow', lwc: 'sf_lwc',
  data360: 'data360_query', soql: 'sf_soql', docs: 'sf_docs', browser: 'sf_browser_snapshot',
  'code-analyzer': 'code_analyzer', slack: 'slack_read', herdr: 'sf_herdr_plan',
};
const fullFamilies = availableRouteFamilies(Object.values(representativeTools));
assert.deepEqual(fullFamilies.map(family => family.id), Object.keys(representativeTools));
const routeInstructionMatch = source['src/automation.ts'].match(/instructions:\s*"(Choose the available Salesforce capability family[^"\n]+)"/);
assert(routeInstructionMatch);
const routeInstruction = routeInstructionMatch[1];
const extraRouteCriteria = ['mixed', 'general'].map(id => {
  const match = source['src/automation.ts'].match(new RegExp('id: "' + id + '",\\s*description:\\s*"([^"\\n]+)"'));
  assert(match);
  return { id, description: match[1] };
});
const categories = ['type-contract', 'async-lifecycle', 'iteration-boundary', 'configuration', 'test-expectation', 'insufficient-evidence', 'multiple-causes'];
const rotateAnswerToPosition = (criteria, answer, position) => {
  assert(position >= 0 && position < criteria.length);
  const targetIndex = criteria.findIndex(candidate => candidate.id === answer);
  assert(targetIndex >= 0);
  const rotation = (targetIndex - position + criteria.length) % criteria.length;
  return structuredClone(criteria.slice(rotation).concat(criteria.slice(0, rotation)));
};
const expandGroup = (group, split, state, question, positions) => {
  assert.notEqual(positions[0], positions[1]);
  return positions.flatMap((position, orderIndex) => {
    const orderedQuestion = { ...structuredClone(question), criteria: rotateAnswerToPosition(question.criteria, group.answer, position) };
    return ['state', 'chat'].map(representation => ({
      id: `${group.id}-order${orderIndex + 1}-${representation}`,
      group_id: group.id,
      split,
      request: validateRequest({
        model,
        ...(representation === 'state' ? { state: structuredClone(state) } : { messages: [{ role: 'user', content: canonical(state) }] }),
        questions: [structuredClone(orderedQuestion)],
        options: { template_version: 'v2' },
      }),
      targets: { [question.id]: { answer: group.answer } },
    }));
  });
};

// Two independently authored operations per production class. Full inventory
// pairs cover G-M three times per order instance; reduced inventories force a
// minimum A-E concentration. This achieves the feasible optimal histogram range.
const fullPositions = [6,7,8,9,10,11,12,6,7,8,9,10,11,12,6,7,8,9,10,11,12,5];
const reducedPositions = [0,1,2,3,4,0,1,2,3,4,0,1,2,3,4,0,1,2,3,4,0,1];
let fullIndex = 0, reducedIndex = 0, mixedIndex = 0, generalIndex = 0;
const groupManifest = [];
const routingRows = definitions.routing.flatMap(group => {
  const selected = group.inventory === 'full' ? Object.keys(representativeTools) : group.inventory;
  const families = availableRouteFamilies(selected.map(id => representativeTools[id]));
  const state = { user_request: group.request, available_families: families };
  const question = { id: 'route', type: 'choice', instructions: routeInstruction, criteria: [...families.map(({ id, description }) => ({ id, description })), ...extraRouteCriteria] };
  let positions;
  if (group.inventory === 'full') { positions = [fullPositions[fullIndex], fullPositions[fullIndex + 11]]; fullIndex++; }
  else if (group.answer === 'mixed') { positions = [[5,0], [5,2]][mixedIndex++]; }
  else if (group.answer === 'general') { positions = [[1,2], [3,4]][generalIndex++]; }
  else { positions = [reducedPositions[reducedIndex], reducedPositions[reducedIndex + 11]]; reducedIndex++; }
  const id = 'developer-supplement-route-' + group.key;
  groupManifest.push({ id, split: 'train', task: 'routing', answer: group.answer, inventory: families.map(family => family.id), answer_positions: positions, context_sha256: sha(canonical(state)), rationale: group.answer === 'mixed' ? 'Two expressly requested operations require different available families.' : group.answer === 'general' ? 'The sole requested family is unavailable and all available substitutes are expressly excluded.' : 'The sole requested operations match the production description of the named available family.' });
  return expandGroup({ ...group, id }, 'train', state, question, positions);
});
assert.deepEqual([fullIndex, reducedIndex, mixedIndex, generalIndex], [11,11,2,2]);

const diagnosisRows = (groups, split) => groups.flatMap((group, index) => {
  const built = buildDeveloperRecipeRequest({ task: group.task, evidence: group.evidence }, model);
  const question = built.questions.find(question => question.id === 'diagnosis');
  assert.equal(question.type, 'choice');
  assert.deepEqual(question.criteria.map(candidate => candidate.id), categories);
  const positions = split === 'train' ? [index % 7, (index + 3) % 7] : [(index + 2) % 7, (index + 6) % 7];
  const id = `developer-${split === 'train' ? 'supplement-diagnosis' : 'diagnosis-validation'}-${group.key}`;
  groupManifest.push({ id, split, task: 'diagnosis', answer: group.answer, mechanism: group.mechanism, answer_positions: positions, context_sha256: sha(canonical(built.state)), rationale: 'The independently authored synthetic facts establish this production diagnosis definition; warnings and proposed repairs do not add a supported cause.' });
  return expandGroup({ ...group, id }, split, built.state, question, positions);
});
const trainRows = [...routingRows, ...diagnosisRows(definitions.diagnosis_train, 'train')];
const validationRows = diagnosisRows(definitions.diagnosis_validation, 'validation');
const allRows = validateQualityRecords([...trainRows, ...validationRows]);
assert.equal(trainRows.length, 160);
assert.equal(validationRows.length, 56);
assert.equal(new Set(trainRows.map(row => row.group_id)).size, 40);
assert.equal(new Set(validationRows.map(row => row.group_id)).size, 14);
assert.equal(new Set(allRows.map(row => row.id)).size, 216);
assert.equal(new Set(groupManifest.map(group => group.context_sha256)).size, 54);
assert.equal(new Set([...definitions.diagnosis_train, ...definitions.diagnosis_validation].map(group => group.mechanism)).size, 28);
assert.equal(new Set([...definitions.diagnosis_train, ...definitions.diagnosis_validation].map(group => group.key)).size, 28);

const histogram = rows => {
  const letters = {}, answers = {}, representations = {}, orders = {}, byTask = {};
  for (const row of rows) {
    const branch = preparePrompt(row.request, 'v2').questions[0];
    const answer = row.targets[branch.question_id].answer;
    const letter = branch.output_labels[branch.answer_labels.indexOf(answer)];
    assert(letter);
    letters[letter] = (letters[letter] ?? 0) + 1;
    answers[answer] = (answers[answer] ?? 0) + 1;
    const representation = row.request.state !== undefined ? 'state' : 'chat';
    representations[representation] = (representations[representation] ?? 0) + 1;
    const order = row.id.includes('-order1-') ? 'order1' : 'order2';
    orders[order] = (orders[order] ?? 0) + 1;
    byTask[branch.question_id] = (byTask[branch.question_id] ?? 0) + 1;
  }
  return { letters: Object.fromEntries(Object.entries(letters).sort()), answers, representations, orders, by_task: byTask };
};
const histograms = { train: histogram(trainRows), routing_train: histogram(routingRows), diagnosis_train: histogram(trainRows.filter(row => row.request.questions[0].id === 'diagnosis')), diagnosis_validation: histogram(validationRows) };
assert(Object.values(histograms.train.answers).every(count => count === 8));
assert(Object.values(histograms.diagnosis_train.letters).every(count => count === 8));
assert(Object.values(histograms.diagnosis_validation.letters).every(count => count === 8));
assert.deepEqual(histograms.routing_train.letters, { A:12, B:12, C:12, D:10, E:10, F:6, G:6, H:6, I:6, J:6, K:6, L:6, M:6 });

for (const group of groupManifest) {
  const rows = allRows.filter(row => row.group_id === group.id);
  assert.equal(rows.length, 4);
  assert(rows.every(row => row.split === group.split));
  for (const order of [1,2]) {
    const state = rows.find(row => row.id.endsWith(`order${order}-state`));
    const chat = rows.find(row => row.id.endsWith(`order${order}-chat`));
    assert.deepEqual(state.request.state, JSON.parse(chat.request.messages[0].content));
    assert.deepEqual(state.request.questions, chat.request.questions);
    assert.deepEqual(state.targets, chat.targets);
  }
  assert.notDeepEqual(rows[0].request.questions[0].criteria, rows[2].request.questions[0].criteria);
  assert.deepEqual(new Set(rows[0].request.questions[0].criteria.map(candidate => candidate.id)), new Set(rows[2].request.questions[0].criteria.map(candidate => candidate.id)));
}

const promptManifest = allRows.map(row => {
  const branch = preparePrompt(row.request, 'v2').questions[0];
  const target = row.targets[branch.question_id].answer;
  return { id: row.id, group_id: row.group_id, split: row.split, question_id: branch.question_id, target, answer_letter: branch.output_labels[branch.answer_labels.indexOf(target)], option_ids: branch.answer_labels, logical_prompt_sha256: sha(canonical(branch.messages)), logical_prompt_characters: canonical(branch.messages).length };
});
const jsonl = rows => rows.map(row => JSON.stringify(row)).join('\n') + '\n';
const trainText = jsonl(trainRows);
const validationText = jsonl(validationRows);
assert.equal(sha(trainText), revision.prior_output_hashes[paths.train], 'TRAIN must remain byte-identical');
const priorValidationLines = (await readFile(join(priorProof, 'frozen-validation.jsonl'), 'utf8')).trimEnd().split('\n');
const priorValidationRows = priorValidationLines.map(line => JSON.parse(line));
const priorDefinitions = JSON.parse(await readFile(join(priorProof, 'authored-cases.json'), 'utf8'));
assert.deepEqual(definitions.routing, priorDefinitions.routing);
assert.deepEqual(definitions.diagnosis_train, priorDefinitions.diagnosis_train);
const changedDefinitionIndices = definitions.diagnosis_validation.flatMap((group, index) => canonical(group) === canonical(priorDefinitions.diagnosis_validation[index]) ? [] : [index]);
assert.deepEqual(changedDefinitionIndices, [revision.replacement_validation_index]);
const changedValidationRows = validationRows.flatMap((row, index) => JSON.stringify(row) === JSON.stringify(priorValidationRows[index]) ? [] : [index]);
assert.deepEqual(changedValidationRows, [20,21,22,23]);
assert.equal(changedValidationRows.length, revision.expected_changed_validation_rows);
const revisedValidationLines = validationText.trimEnd().split('\n');
assert.deepEqual(revisedValidationLines.flatMap((line, index) => line === priorValidationLines[index] ? [] : [index]), changedValidationRows);
for (const index of changedValidationRows) {
  assert.equal(validationRows[index].targets.diagnosis.answer, priorValidationRows[index].targets.diagnosis.answer);
  assert.deepEqual(validationRows[index].request.questions, priorValidationRows[index].request.questions);
}
await writeFile(join(root, paths.train), trainText);
await writeFile(join(root, paths.validation), validationText);
await writeFile(join(proof, 'frozen-train.jsonl'), trainText);
await writeFile(join(proof, 'frozen-validation.jsonl'), validationText);
await writeFile(join(proof, 'groups.json'), JSON.stringify(groupManifest, null, 2) + '\n');
await writeFile(join(proof, 'logical-prompt-manifest.json'), JSON.stringify(promptManifest, null, 2) + '\n');

const letters = 'ABCDEFGHIJKLM'.split('');
const letterTable = '| Corpus | ' + letters.join(' | ') + ' |\n|---|' + letters.map(() => '---:').join('|') + '|\n' + Object.entries(histograms).map(([name, counts]) => '| ' + name + ' | ' + letters.map(letter => counts.letters[letter] ?? 0).join(' | ') + ' |').join('\n');
const sourceTable = Object.entries({ ...sourceHashes, ...contextHashes }).map(([name, hash]) => `| ${name} | \`${hash}\` |`).join('\n');
const originalNotes = await readFile(join(priorProof, 'frozen-notes.md'), 'utf8');
const revisionSummary = `## Revision 2 provenance\n\nFrozen on ${new Date().toISOString()}. Root's source-only review reported that the original empty-range-expansion validation mechanism overlapped an existing protected exclusive-window repair task. Following that root instruction, this revision replaces only that semantic group and all four of its state/chat/order variants with a rectangular-matrix traversal dimension case. The explicit 2x3 input is [[11,12,13],[21,22,23]], the required 3x2 transpose is [[11,21],[12,22],[13,23]], and the observed output [[11,21],[12,22]] omits the third input column because the inner column loop uses grid.length (row count 2) instead of each row's length (column count 3). The iteration-boundary target, candidate descriptions, option orders, answer positions, and counts are unchanged. An unrelated image warning and unsupported timeout proposal remain distracting evidence. No protected repair or private TEST source was inspected.\n\nTRAIN is byte-identical to the original freeze. Exactly four VALIDATION rows changed; the other 52 rows are byte-identical. The original proof under .build/improvement-experiments/supplement-preparation/ is preserved exactly at manifest SHA-256 \`${revision.prior_frozen_manifest_sha256}\`. The new proof is under .build/improvement-experiments/supplement-preparation-r2/ and binds the original proof/output hashes, the root-driven reason, revised definitions, sources, transformations, measured letters, and CPU schema/logical validation.\n\nOriginal output SHA-256 values: TRAIN \`${revision.prior_output_hashes[paths.train]}\`; VALIDATION \`${revision.prior_output_hashes[paths.validation]}\`; notes \`${revision.prior_output_hashes[paths.notes]}\`. Current corpus SHA-256 values: TRAIN \`${sha(trainText)}\`; revised diagnosis VALIDATION \`${sha(validationText)}\`. Root has not adopted the supplement; no supplement model run was launched.\n\n`;
const notes = '# Independently authored developer supervision supplement — revision 2\n\n' + revisionSummary + originalNotes.slice(originalNotes.indexOf('Prepared on ')).replaceAll(revision.prior_output_hashes[paths.validation], sha(validationText)).replace('The proof is under .build/improvement-experiments/supplement-preparation/', 'The current proof is under .build/improvement-experiments/supplement-preparation-r2/');
await writeFile(join(root, paths.notes), notes);
await writeFile(join(proof, 'frozen-notes.md'), notes);
const checks = {
  public_schema_validation: 'pass', logical_prompt_compilation: 'pass', unique_ids: 'pass', unique_context_groups: 'pass', split_integrity: 'pass', four_variants_per_group: 'pass', state_chat_context_equivalence: 'pass', state_chat_option_equivalence: 'pass', option_candidate_set_preservation: 'pass', choice_only: 'pass', production_prompts_descriptions_and_inventory_helper: 'pass', category_and_representation_balance: 'pass', actual_letter_histograms: 'pass', independent_authored_mechanism_descriptions: 'pass', protected_scenarios_or_targets_read: 0, supplement_model_calls: 0, supplement_inference_calls: 0, supplement_tokenizer_calls: 0, supplement_gpu_calls: 0, supplement_training_calls: 0, supplement_network_calls: 0, supplement_build_calls: 0, supplement_git_auth_or_ci_calls: 0,
};
checks.original_proof_preserved = 'pass';
checks.train_byte_identical_to_original = 'pass';
checks.exactly_four_validation_rows_replaced = 'pass';
checks.other_fifty_two_validation_rows_unchanged = 'pass';
checks.no_other_semantic_changes = 'pass';
checks.replacement_gold_options_orders_and_balance_unchanged = 'pass';
await verifyPriorProof();
for (const name of sourceNames) assert.equal(sha(await readFile(join(root, name))), sourceHashes[name], `Source changed during preparation: ${name}`);
assert.equal(sha(await readFile(join(root, frozenTrain))), originalTrainHash, 'Frozen train corpus changed during preparation');
const proofNames = ['revision-provenance.json', 'authored-cases.json', 'prepare.mjs', 'frozen-train.jsonl', 'frozen-validation.jsonl', 'frozen-notes.md', 'groups.json', 'logical-prompt-manifest.json', ...sourceNames.map(name => 'sources/' + name.slice(4)), ...Object.keys(projections).map(name => 'public/' + name + '.mjs')];
const proofHashes = Object.fromEntries(await Promise.all(proofNames.map(async name => [name, sha(await readFile(join(proof, name)))])));
const manifest = {
  schema_version: 1,
  revision: 2,
  revision_provenance: revision,
  frozen_at_utc: new Date().toISOString(),
  conditional_preparation_only: true,
  adoption_launched: false,
  supplement_training_launched: false,
  validation_frozen_before_supplement_training_or_evaluation: true,
  current_root_training_uses_preexisting_corpus_only: true,
  model: model,
  counts: { train_groups:40, train_rows:160, routing_train_groups:26, routing_train_rows:104, diagnosis_train_groups:14, diagnosis_train_rows:56, diagnosis_validation_groups:14, diagnosis_validation_rows:56, total_new_rows:216 },
  source_hashes: sourceHashes,
  guidance_and_context_hashes: contextHashes,
  frozen_train_only_corpus: { path:frozenTrain, before_sha256:originalTrainHash, after_sha256:originalTrainHash, unchanged:true, schema_rows_inspected:3, scenarios_copied:0 },
  output_hashes: { [paths.train]:sha(trainText), [paths.validation]:sha(validationText), [paths.notes]:sha(notes) },
  proof_hashes: proofHashes,
  projected_public_module_hashes: projectionHashes,
  authored_definitions_sha256: sha(definitionsText),
  logical_prompt_manifest_sha256: proofHashes['logical-prompt-manifest.json'],
  histograms: histograms,
  checks: checks,
  transformation_rules: ['One independently authored context per group and one split per group.', 'State object and one-user-message canonical JSON chat preserve identical evidence.', 'Two fixed whole-candidate-list rotations per group preserve IDs/descriptions/targets.', 'Both representations use the same option order for each order index.', 'All four representation/order transforms remain grouped.', 'Targets are candidate IDs; actual letters come from public preparePrompt(v2).'],
  limitations: ['No protected corpus scenario comparisons were performed.', 'Distinct authored mechanism strings are checked; real semantic novelty and label quality require root review.', 'Synthetic prefix-matched tool suffixes do not establish deployed names or availability.', 'No native/tokenizer/model/GPU evidence exists for these fixtures.', 'No developer speed/resource/reliability improvement is claimed.', 'No final TEST file was read, created, or modified.'],
  ownership: { released_to:'root', scope:'Conditional review of the three new fixture files and ignored proof.', existing_source_dist_worker_controller_files_edited:0 },
};
const manifestText = JSON.stringify(manifest, null, 2) + '\n';
await writeFile(join(proof, 'FROZEN.json'), manifestText);
await writeFile(join(proof, 'FROZEN.sha256'), sha(manifestText) + '  FROZEN.json\n');
console.log(JSON.stringify({ outputs: manifest.output_hashes, frozen_manifest_sha256:sha(manifestText), counts:manifest.counts, histograms:manifest.histograms, checks:manifest.checks }, null, 2));
