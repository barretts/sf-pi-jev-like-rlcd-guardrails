import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, readdir, chmod } from 'node:fs/promises';
import { resolve, join } from 'node:path';

const root = resolve(import.meta.dirname, '../../..');
const proof = import.meta.dirname;
const sha = value => createHash('sha256').update(value).digest('hex');
const digest = async path => sha(await readFile(path));
const manifest = JSON.parse(await readFile(join(proof, 'FROZEN.json'), 'utf8'));
const revision = manifest.revision_provenance;
const priorProof = join(root, revision.prior_proof_path);
assert.equal(await digest(join(proof, 'FROZEN.json')), (await readFile(join(proof, 'FROZEN.sha256'), 'utf8')).split(' ')[0]);
for (const [name, hash] of Object.entries(manifest.output_hashes)) assert.equal(await digest(join(root, name)), hash);
for (const [name, hash] of Object.entries(manifest.proof_hashes)) assert.equal(await digest(join(proof, name)), hash);
for (const [name, hash] of Object.entries(manifest.source_hashes)) assert.equal(await digest(join(root, name)), hash);
for (const [name, hash] of Object.entries(revision.prior_proof_hashes)) assert.equal(await digest(join(priorProof, name)), hash);
assert.equal(await digest(join(priorProof, 'FROZEN.json')), revision.prior_frozen_manifest_sha256);
assert.equal(await digest(join(root, manifest.frozen_train_only_corpus.path)), manifest.frozen_train_only_corpus.before_sha256);
assert.equal(await digest(join(root, 'fixtures/developer-supplement-train.jsonl')), revision.prior_output_hashes['fixtures/developer-supplement-train.jsonl']);

const definitions = JSON.parse(await readFile(join(proof, 'authored-cases.json'), 'utf8'));
const rectangular = definitions.diagnosis_validation[revision.replacement_validation_index];
assert.equal(rectangular.key, revision.replacement_group_key);
assert.equal(rectangular.answer, 'iteration-boundary');
const input = rectangular.evidence.input;
assert.equal(input.length, 2);
assert(input.every(row => row.length === 3));
// Execute only this independently authored, fixed synchronous numeric loop.
// It has no imports, IO, model, tokenizer, network, or external process calls.
const actual = new Function('grid', rectangular.evidence.relevant_source)(structuredClone(input));
const correctTranspose = input[0].map((_, column) => input.map(row => row[column]));
assert.deepEqual(actual, rectangular.evidence.actual_output);
assert.deepEqual(correctTranspose, rectangular.evidence.expected_output);
assert.deepEqual(actual, [[11,21],[12,22]]);
assert.deepEqual(correctTranspose, [[11,21],[12,22],[13,23]]);
assert.notDeepEqual(actual, correctTranspose);

const priorLines = (await readFile(join(priorProof, 'frozen-validation.jsonl'), 'utf8')).trimEnd().split('\n');
const revisedLines = (await readFile(join(root, 'fixtures/developer-diagnosis-validation.jsonl'), 'utf8')).trimEnd().split('\n');
const changed = revisedLines.flatMap((line, index) => line === priorLines[index] ? [] : [index]);
assert.deepEqual(changed, [20,21,22,23]);
assert.equal(revisedLines.length, 56);
const records = revisedLines.map(line => JSON.parse(line));
assert.equal(new Set(records.map(row => row.group_id)).size, 14);
const answerCounts = {};
for (const row of records) answerCounts[row.targets.diagnosis.answer] = (answerCounts[row.targets.diagnosis.answer] ?? 0) + 1;
assert.equal(Object.keys(answerCounts).length, 7);
assert(Object.values(answerCounts).every(count => count === 8));
const verification = {
  status: 'pass',
  original_proof_preserved_exactly: true,
  train_byte_identical: true,
  changed_validation_zero_based_line_indices: changed,
  other_validation_rows_byte_identical: 52,
  revised_validation_rows: 56,
  revised_validation_groups: 14,
  class_counts: answerCounts,
  rectangular_source_cpu_execution: { input, actual, correct_transpose:correctTranspose, source_sha256:sha(rectangular.evidence.relevant_source), result:'pass' },
  production_and_public_sources_unchanged: true,
  frozen_570_train_corpus_unchanged: true,
  protected_repair_or_private_test_sources_read: 0,
  supplement_model_native_gpu_tokenizer_network_build_git_auth_or_ci_calls: 0,
};
const verificationText = JSON.stringify(verification, null, 2) + '\n';
await writeFile(join(proof, 'verification.json'), verificationText);
manifest.proof_hashes['verify-final.mjs'] = await digest(join(proof, 'verify-final.mjs'));
manifest.proof_hashes['verification.json'] = sha(verificationText);
manifest.checks.rectangular_case_actual_source_cpu_execution = 'pass';
manifest.final_cpu_verification_sha256 = sha(verificationText);
const frozenText = JSON.stringify(manifest, null, 2) + '\n';
await writeFile(join(proof, 'FROZEN.json'), frozenText);
await writeFile(join(proof, 'FROZEN.sha256'), sha(frozenText) + '  FROZEN.json\n');
for (const [name, hash] of Object.entries(manifest.proof_hashes)) assert.equal(await digest(join(proof, name)), hash);
for (const [name, hash] of Object.entries(revision.prior_proof_hashes)) assert.equal(await digest(join(priorProof, name)), hash);
const freezeReadOnly = async dir => {
  for (const entry of await readdir(dir, { withFileTypes:true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) await freezeReadOnly(path);
    else if (entry.isFile()) await chmod(path, 0o444);
  }
};
await freezeReadOnly(proof);
console.log(JSON.stringify({ status:'pass', output_hashes:manifest.output_hashes, frozen_manifest_sha256:sha(frozenText), verification_sha256:sha(verificationText), prior_frozen_manifest_sha256:revision.prior_frozen_manifest_sha256, verification, ownership_released_to:'root', adoption_launched:false }, null, 2));
