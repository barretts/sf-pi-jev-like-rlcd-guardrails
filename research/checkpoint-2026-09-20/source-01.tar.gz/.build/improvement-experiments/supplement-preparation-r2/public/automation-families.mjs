const FAMILIES = [
    {
        id: "agentscript",
        description: "Build, preview, evaluate, and release Salesforce agents.",
        matches: (n) => n.startsWith("agentscript_"),
    },
    {
        id: "apex",
        description: "Author, diagnose, trace, and test Apex.",
        matches: (n) => n === "sf_apex",
    },
    {
        id: "flow",
        description: "Author and manage Salesforce flows.",
        matches: (n) => n === "sf_flow",
    },
    {
        id: "lwc",
        description: "Develop Lightning Web Components.",
        matches: (n) => n === "sf_lwc",
    },
    {
        id: "data360",
        description: "Connect, prepare, query, and activate Data Cloud data.",
        matches: (n) => n.startsWith("data360_"),
    },
    {
        id: "soql",
        description: "Query Salesforce records with SOQL or SOSL.",
        matches: (n) => n === "sf_soql",
    },
    {
        id: "docs",
        description: "Look up Salesforce documentation and cite sources.",
        matches: (n) => n === "sf_docs",
    },
    {
        id: "browser",
        description: "Inspect and operate Salesforce browser interfaces.",
        matches: (n) => n.startsWith("sf_browser_"),
    },
    {
        id: "code-analyzer",
        description: "Run Salesforce code analysis and interpret diagnostics.",
        matches: (n) => n === "code_analyzer",
    },
    {
        id: "slack",
        description: "Use explicitly authorized Salesforce collaboration tools.",
        matches: (n) => n === "slack" || n.startsWith("slack_"),
    },
    {
        id: "herdr",
        description: "Plan Salesforce multi-agent orchestration.",
        matches: (n) => n === "sf_herdr_plan",
    },
];
export function availableRouteFamilies(activeTools) {
    return FAMILIES.flatMap((family) => {
        const tools = activeTools.filter(family.matches);
        return tools.length
            ? [{ id: family.id, description: family.description, tools }]
            : [];
    });
}
