"""Synthetic BytesIO contracts only; no model, template, native or disk input."""
import hashlib
import importlib.util
import io
from pathlib import Path
import struct
import unittest


spec = importlib.util.spec_from_file_location("header_recipe", Path(__file__).with_name("extract-template.py"))
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def string(data):
    return struct.pack("<Q", len(data)) + data


def field(key, kind, value):
    return string(key.encode()) + struct.pack("<I", kind) + value


def gguf(fields):
    return b"GGUF" + struct.pack("<IQQ", 3, 123, len(fields)) + b"".join(fields)


RAW = b"literal synthetic template\r\n\n"
SHA = hashlib.sha256(RAW).hexdigest()
TEMPLATE = field(helper.KEY, 8, string(RAW))


class HeaderContract(unittest.TestCase):
    def extract(self, data, **changes):
        options = {"header_read_limit": len(data), "expected_template_sha256": SHA}
        options.update(changes)
        return helper.extract(io.BytesIO(data), **options)

    def test_preserves_exact_bytes_and_stops_before_tensor_descriptors(self):
        vocab_array = struct.pack("<IQ", 8, 2) + string(b"mock-a") + string(b"mock-b")
        metadata = gguf([field("tokenizer.mock", 9, vocab_array), TEMPLATE])
        stream = io.BytesIO(metadata + b"FORBIDDEN_TENSOR_SENTINEL")
        raw, report = helper.extract(stream, header_read_limit=len(metadata), expected_template_sha256=SHA)
        self.assertEqual(raw, RAW)
        self.assertEqual(stream.tell(), len(metadata))
        self.assertFalse(report["tensor_payload_read"])

    def test_missing_template(self):
        with self.assertRaisesRegex(helper.HeaderError, "missing"):
            self.extract(gguf([field("general.mock", 4, struct.pack("<I", 1))]))

    def test_duplicate_template(self):
        with self.assertRaisesRegex(helper.HeaderError, "duplicate"):
            self.extract(gguf([TEMPLATE, TEMPLATE]))

    def test_oversize_template_declared_without_allocating_payload(self):
        value = struct.pack("<Q", helper.MAX_TEMPLATE + 1)
        with self.assertRaisesRegex(helper.HeaderError, "byte cap"):
            self.extract(gguf([field(helper.KEY, 8, value)]))

    def test_nonstring_template(self):
        with self.assertRaisesRegex(helper.HeaderError, "not a GGUF STRING"):
            self.extract(gguf([field(helper.KEY, 4, struct.pack("<I", 8))]))

    def test_limit_truncation_and_digest_mismatch_fail(self):
        valid = gguf([TEMPLATE])
        with self.assertRaisesRegex(helper.HeaderError, "boundary"):
            self.extract(valid, header_read_limit=len(valid) - 1)
        with self.assertRaisesRegex(helper.HeaderError, "truncated"):
            self.extract(valid[:-1], header_read_limit=len(valid))
        with self.assertRaisesRegex(helper.HeaderError, "expected SHA"):
            self.extract(valid, expected_template_sha256="0" * 64)

    def test_truncated_skipped_metadata_after_template_is_not_accepted(self):
        data = gguf([TEMPLATE, field("ignored", 8, struct.pack("<Q", 100))])
        with self.assertRaisesRegex(helper.HeaderError, "truncated"):
            self.extract(data, header_read_limit=len(data) + 100)


if __name__ == "__main__":
    unittest.main()
