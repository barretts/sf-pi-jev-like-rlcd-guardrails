"""ROOT-only, bounded GGUF metadata scanner; import has no file side effects.

Layout derived from .vendor/llama.cpp/gguf-py/gguf/gguf_reader.py and
constants.py SOURCE. Never import GGUFReader: it memmaps the whole model.
The supplied boundary must already be verified at or before tensor data.
This scanner stops after KV metadata and never parses tensor descriptors.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct


KEY = "tokenizer.chat_template"
MAX_HEADER = 16 * 1024 * 1024
MAX_TEMPLATE = 64 * 1024
MAX_STRING = 1024 * 1024
MAX_KEYS = 4096
MAX_ARRAY = 1024 * 1024
SCALAR_BYTES = {0: 1, 1: 1, 2: 2, 3: 2, 4: 4, 5: 4,
                6: 4, 7: 1, 10: 8, 11: 8, 12: 8}


class HeaderError(ValueError):
    pass


class Reader:
    def __init__(self, stream, boundary):
        if not isinstance(boundary, int) or not 24 <= boundary <= MAX_HEADER:
            raise HeaderError("verified header boundary must be 24..16MiB")
        self.stream = stream
        self.boundary = boundary
        self.offset = 0

    def read(self, count):
        if count < 0 or self.offset + count > self.boundary:
            raise HeaderError("read would exceed verified header boundary")
        data = self.stream.read(count)
        if len(data) != count:
            raise HeaderError("truncated GGUF metadata")
        self.offset += count
        return data

    def skip(self, count):
        # Drain in bounded blocks to detect truncated values, without keeping
        # or exposing skipped metadata (including vocabulary string arrays).
        if count < 0 or self.offset + count > self.boundary:
            raise HeaderError("skip would exceed verified header boundary")
        while count:
            size = min(count, 65536)
            self.read(size)
            count -= size

    def u32(self):
        return struct.unpack("<I", self.read(4))[0]

    def u64(self):
        return struct.unpack("<Q", self.read(8))[0]

    def string(self, cap, keep):
        count = self.u64()
        if count > cap:
            raise HeaderError("GGUF string exceeds declared byte cap")
        if keep:
            return self.read(count)
        self.skip(count)
        return None

    def skip_value(self, kind):
        if kind in SCALAR_BYTES:
            self.skip(SCALAR_BYTES[kind])
        elif kind == 8:
            self.string(MAX_STRING, False)
        elif kind == 9:
            item_kind, count = self.u32(), self.u64()
            if count > MAX_ARRAY:
                raise HeaderError("GGUF array exceeds element cap")
            if item_kind in SCALAR_BYTES:
                self.skip(count * SCALAR_BYTES[item_kind])
            elif item_kind == 8:
                for _ in range(count):
                    self.string(MAX_STRING, False)
            else:
                raise HeaderError("unsupported array element type (nested arrays rejected)")
        else:
            raise HeaderError("unsupported GGUF metadata value type")


def extract(stream, *, header_read_limit, expected_template_sha256):
    if not re.fullmatch(r"[0-9a-f]{64}", expected_template_sha256):
        raise HeaderError("explicit lowercase expected template SHA-256 required")
    reader = Reader(stream, header_read_limit)
    if reader.read(4) != b"GGUF":
        raise HeaderError("unsupported GGUF magic/endian")
    version = reader.u32()
    if version not in (2, 3):
        raise HeaderError("only little-endian GGUF versions 2 and 3 supported")
    tensor_count, kv_count = reader.u64(), reader.u64()
    if not 1 <= kv_count <= MAX_KEYS:
        raise HeaderError("GGUF key count outside bounded contract")
    names, raw = set(), None
    for _ in range(kv_count):
        try:
            name = reader.string(512, True).decode("utf-8", errors="strict")
        except UnicodeDecodeError as error:
            raise HeaderError("metadata key is not UTF-8") from error
        if not name or name in names:
            raise HeaderError("empty or duplicate GGUF metadata key")
        names.add(name)
        kind = reader.u32()
        if name == KEY:
            if kind != 8:
                raise HeaderError("embedded chat template is not a GGUF STRING")
            raw = reader.string(MAX_TEMPLATE, True)
        else:
            reader.skip_value(kind)
    if raw is None:
        raise HeaderError("missing tokenizer.chat_template")
    if not raw:
        raise HeaderError("empty embedded chat template")
    try:
        raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as error:
        raise HeaderError("embedded chat template is not UTF-8") from error
    digest = hashlib.sha256(raw).hexdigest()
    if digest != expected_template_sha256:
        raise HeaderError("embedded template does not match explicit expected SHA-256")
    return raw, {"raw_template_sha256": digest, "raw_template_bytes": len(raw),
                 "gguf_version": version, "declared_tensor_count": tensor_count,
                 "metadata_end": reader.offset, "header_read_limit": header_read_limit,
                 "tensor_descriptors_read": False, "tensor_payload_read": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root-cleared-header-extraction", action="store_true", required=True)
    parser.add_argument("--model-path", type=Path, required=True)
    parser.add_argument("--output-path", type=Path, required=True)
    parser.add_argument("--expected-template-sha256", required=True)
    parser.add_argument("--header-read-limit", type=int, required=True)
    args = parser.parse_args()
    if not args.model_path.is_absolute() or not args.output_path.is_absolute():
        parser.error("model and fresh output paths must be explicit absolute paths")
    # No stat, mmap, tokenizer/Jinja evaluation, tensor parsing, or full-model
    # hash here. ROOT verifies the complete artifact and boundary separately.
    with args.model_path.open("rb") as source:
        raw, report = extract(source, header_read_limit=args.header_read_limit,
                              expected_template_sha256=args.expected_template_sha256)
    with args.output_path.open("xb") as target:
        target.write(raw)
    report["raw_template_path"] = str(args.output_path)
    report["model_identity_checked_by_helper"] = False
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
