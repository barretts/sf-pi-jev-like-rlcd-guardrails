This folder is a SOURCE recipe, not an execution plan clearance. It prepares the already declared single private `gemma3-4b-raw-f16-alpha-capability-candidate-1` and its three literal synthetic questions. Nothing here compiles, selects, launches or measures a model. Existing candidate files, C091, Alpha, public code and the current matched benchmark are untouched.

Read source ancestry and required pins

- Final private source input: `.build/improvement-experiments/gemma3-4b-alpha-capability-proposal/main.cpp.in`, derived by its `draft-source.mjs` from `.build/improvement-experiments/gemma4-runtime-candidate-1/main.cpp` (C091). ROOT freezes the current exact bytes of both; an old parent/source digest is not a current byte check.
- Logical source remains `.build/improvement-experiments/fractional-score-hypothesis/candidate-2/grid.mjs`, `compileHalfGrid`/`responseHalfGrid`, logical ID `v2-earned-half-grid-alpha-research-1`. Preserve original earned units: categorical half-grid index /2; variance /4. Pass actual `input_tokens` and `advanced:true` to the response helper.
- Compile/link source recipe is `.build/improvement-experiments/gemma4-label-prototype/build.py`. Do not run that old script: its output/protected-file handling belongs to the old prototype and includes broader reads. Copy only its explicit compiler/link argv into a new ROOT-owned artifact directory.
- Template layout source is `.vendor/llama.cpp/gguf-py/gguf/gguf_reader.py` (`__init__`, `_get_str`, `_get_field_parts`, `_build_fields`) plus `constants.py` (`GGUFValueType`). The vendored reader maps the entire model through numpy; the included extractor does not import it or numpy.

ROOT supplies all nine compile macros; the existing source deliberately errors when any are absent:

| Macro | ROOT source of the value |
| --- | --- |
| `GEMMA3_ALPHA_PROPOSAL_SOURCE_SHA256` | SHA-256 of final CPP input bytes after any ROOT changes; same bytes compiled, fresh G3 identity |
| `GEMMA3_ALPHA_PARENT_C091_SOURCE_SHA256` | independently frozen current C091 source bytes |
| `GEMMA3_ALPHA_RAW_TEMPLATE_PATH` | absolute fresh ROOT-owned original embedded raw template copy |
| `GEMMA3_ALPHA_RAW_TEMPLATE_SHA256` | exact raw template UTF-8 bytes, including every final LF/CR byte |
| `GEMMA3_ALPHA_RAW_TEMPLATE_BYTES` | exact raw byte count, not character count |
| `GEMMA3_ALPHA_PARSER_TEMPLATE_SHA256` | exact observed `common_chat_templates_source` byte digest under the pinned common library |
| `GEMMA3_ALPHA_PARSER_TEMPLATE_BYTES` | exact observed parser-source byte count |
| `GEMMA3_ALPHA_PARSER_TRANSFORM` | only `identity` or `remove_exactly_one_terminal_lf`, selected from observed equality |
| `GEMMA3_ALPHA_TEMPLATE_REVISION` | verified offline original G3 template/model provenance revision; no borrowed G4 revision |

The model path, expected full SHA and size are literals in the scaffold. They currently declare `/Users/bsonntag/code/simple-jev-ts/models/gemma-3-4b-it-f16.gguf`, catalog SHA `29f4b518b636635613894282bda2a01bad964c8d474c4147343057b7ac442d50`, and 7,767,474,336 bytes. These are inherited declarations, not measurements in this task. ROOT must freeze the exact whole-file raw model SHA, current size/architecture/mixed F16-F32 inventory and offline Google lineage before any native use. The prototype checks path and size, not full model SHA (`model_sha256_checked_by_prototype:false`). Use `raw_f16_cpu`/`raw_f16_metal`; do not relabel this raw F16 model as quantized or expand CPU weights to F32.

ROOT template extraction recipe

1. Finish/close the current serial native lane, review the source and separately clear bounded header extraction. Establish the current complete artifact identity and a verified numeric header boundary at or before its tensor-data offset. Do not guess this limit from file size or use an unverified large read budget. The helper cannot verify that supplied boundary or whole-model identity itself.
2. Freeze the vendored layout SOURCE and this helper. Use an explicit original expected template digest, independently tied to the exact artifact. The prospective profile records prior template metadata SHA `7de1c58e208eda46e9c7f86397df37ec49883aeece39fb961e0a6b24088dd3c4` and 1532 bytes. This task has not read those bytes or confirmed that declaration. A disagreement is a blocker, not permission to replace the expected digest automatically.
3. Run the future ROOT-cleared command below with literal absolute paths and measured boundary. The helper reads only the fixed GGUF preamble and all KV metadata to detect duplicates, stops before the tensor table, and copies the single STRING `tokenizer.chat_template` byte-for-byte to an exclusive fresh file. It discards other metadata values in bounded blocks, does not interpret token strings, and never renders Jinja or tokenizes. It accepts only little-endian GGUF 2/3, rejects nested metadata arrays, and applies conservative caps (16MiB boundary, 4096 keys, 1MiB string/array caps, 64KiB template). Unsupported actual headers fail rather than falling back.

```text
python3 -B .build/improvement-experiments/gemma3-4b-alpha-root-recipe-preparation/extract-template.py \
  --root-cleared-header-extraction \
  --model-path /ABSOLUTE/ROOT_VERIFIED_RAW_MODEL.gguf \
  --output-path /ABSOLUTE/FRESH_ROOT_ARTIFACT/original.chat_template.jinja \
  --expected-template-sha256 EXPLICIT_ORIGINAL_TEMPLATE_SHA256 \
  --header-read-limit ROOT_VERIFIED_BOUNDARY_INTEGER
```

4. Freeze the returned raw path/SHA/bytes and exact original template source. Before committing parser macros, obtain a separately ROOT-cleared vocabulary-only/parser-source measurement using the pinned current native/common implementation. `identity` requires observed actual parser bytes == all raw bytes. `remove_exactly_one_terminal_lf` requires a raw final byte 0x0A and observed actual parser bytes == raw[:-1] exactly. It is not CRLF normalization, trimming or removal of all trailing LFs. If neither equality holds, the one-candidate scaffold is unsupported; no silent transform/fallback is allowed. The scaffold locks this identity before initialization, so absence of an independently measured parser source remains a compilation/qualification blocker.
5. Independently render the exact original raw source with the qualified independent renderer under `add_generation_prompt:true`, disabled thinking and required BOS behavior; compare against native compiled prompt/token evidence. The fixed `<start_of_turn>model\n` assertion remains prospective. Neither the template metadata digest nor generic G3 SOURCE proves that suffix. Fail if the exact original renderer/native boundary does not match; do not borrow a G4 template or manufacture a thought channel.

Exact ROOT compiler/link recipe

ROOT first freezes compiler identity, current vendor/build identity, the eight unique static archives below and actual linked/loaded runtime libraries/framework identities. Reuse the existing archives; do not rebuild vendor or touch old artifacts. Record the exact argument array, library order and repeated archive, CPP source SHA, macro values, compilation log/exit and fresh output full SHA. Run one compiler job only under separately authorized ROOT compilation. The following is an argv construction recipe, not a script executed by this task. `P` is an explicit ROOT-frozen map keyed by the macro names in the table. Use a byte-identical fresh `main.cpp` copy to avoid extension detection errors with `main.cpp.in`.

```python
import json
from pathlib import Path
ROOT = Path('/Users/bsonntag/code/simple-jev-ts')
SOURCE = Path('/ABSOLUTE/FRESH_ROOT_ARTIFACT/main.cpp')
BINARY = Path('/ABSOLUTE/FRESH_ROOT_ARTIFACT/gemma3-4b-alpha-capability')
VENDOR, LIB = ROOT / '.vendor/llama.cpp', ROOT / '.build/llama'
# P is supplied from ROOT's separately frozen identity map; no defaults.
strings = [
    'GEMMA3_ALPHA_PROPOSAL_SOURCE_SHA256',
    'GEMMA3_ALPHA_RAW_TEMPLATE_PATH', 'GEMMA3_ALPHA_RAW_TEMPLATE_SHA256',
    'GEMMA3_ALPHA_PARSER_TEMPLATE_SHA256', 'GEMMA3_ALPHA_PARSER_TRANSFORM',
    'GEMMA3_ALPHA_PARENT_C091_SOURCE_SHA256', 'GEMMA3_ALPHA_TEMPLATE_REVISION',
]
numbers = ['GEMMA3_ALPHA_RAW_TEMPLATE_BYTES', 'GEMMA3_ALPHA_PARSER_TEMPLATE_BYTES']
assert P['GEMMA3_ALPHA_PARSER_TRANSFORM'] in ('identity', 'remove_exactly_one_terminal_lf')
assert all(isinstance(P[k], str) and P[k] and all(32 <= ord(c) < 127 for c in P[k]) for k in strings)
assert all(type(P[k]) is int and 0 < P[k] <= 65536 for k in numbers)
defs = ['-D' + k + '=' + json.dumps(P[k], ensure_ascii=True) for k in strings]
defs += ['-D' + k + '=' + str(P[k]) for k in numbers]
archives = [
    LIB / 'src/libllama.a', LIB / 'common/libllama-common.a',
    LIB / 'src/libllama.a', LIB / 'ggml/src/libggml.a',
    LIB / 'ggml/src/libggml-cpu.a', LIB / 'ggml/src/ggml-metal/libggml-metal.a',
    LIB / 'ggml/src/libggml-base.a', LIB / 'common/libllama-common-base.a',
    LIB / 'vendor/cpp-httplib/libcpp-httplib.a',
]
argv = [
    '/usr/bin/c++', '-O2', '-DNDEBUG', '-std=gnu++17', '-arch', 'arm64',
    '-fno-lto', '-Wno-deprecated-declarations', '-DGGML_USE_CPU', '-DGGML_USE_METAL',
    '-DLLAMA_SUBPROCESS', *defs,
    '-I' + str(VENDOR / 'vendor'), '-I' + str(VENDOR / 'include'),
    '-I' + str(VENDOR / 'ggml/include'), '-I' + str(VENDOR / 'common'),
    '-I' + str(VENDOR / 'vendor/sheredom'), str(SOURCE), '-o', str(BINARY),
    *map(str, archives[:5]), '-framework', 'Accelerate', str(archives[5]),
    str(archives[6]), '-lm', '-framework', 'Foundation', '-framework', 'Metal',
    '-framework', 'MetalKit', str(archives[7]), str(archives[8]),
]
# Pass argv directly to the compiler, never through shell interpolation.
```

There are nine link positions and eight unique archives; `libllama.a` repeats intentionally. If ROOT compiles `.cpp.in` directly instead, add `-x c++` immediately before that input and `-x none` immediately after it, before archive inputs. Any source/macro/library/compiler change creates a new physical artifact identity and requires its own qualification. No native output is present in this folder.

Profile, requests and evidence limits

- The descriptive `physical-profile.prospective.json` is not the exact native profile object. Compare required semantic fields independently: new G3/raw-F16 ID, architecture `gemma3`, exact model/template/parser identities, logical Alpha ID, disabled thinking, asserted boundary, full one-branch prefill, limits 2048/1/2048, F16 KV, Flash AUTO, batch 2048/u512, context 4096/sequence 2, threads 2, unified KV and inherited SWA. AUTO requests do not establish effective Flash, and Metal selection does not establish actual offload.
- Native `physical_profile_sha256` is SHA-256 of the UTF-8 bytes of `physical_profile().dump()` from `nlohmann::ordered_json`. Preserve the exact native ordered object/compact serialization and independently check its hash. A sorted/canonical JS digest, pretty document digest, or a profile containing additional descriptive fields is a separate semantic/document identity. Do not substitute it for the native ordered hash.
- Each protocol envelope has `v:1`, a nonempty unique `id` and explicit `op`. Init must specify new `research_profile`, exact `model_file` and `chat_template_file`, `device:'cpu', vocab_only:true` for separately cleared feasibility; later actual Metal requires `device:'metal', vocab_only:false`. Explicit limits are 2048/1/2048. Compile receives only host-built Alpha branches; evaluate receives its native compiled single branch and `full:true`. Never send host golds, uncertainty targets or expected answers in packets.
- Use only the existing three literals: red/blue choice; explicitly earned 0.5 on original max 2 rubric; unspecified pet species/unknown truth. Compile every actual selected label and independently prove its token extension preserves the entire rendered prefix, adds exactly one token, and uses distinct token IDs. Dynamic actual BOS must occur exactly once at the leading boundary. Token spelling/alphabet patterns cannot prove this.
- The source clears KV at evaluation boundaries, calls `measured_decode`, and reports actual returned successful prompt-token work. `engine_forwards` means successful public `llama_decode` calls, not internal 512-token microbatch forwards. Preserve `computed_prompt_tokens`, `input_tokens`, raw `partial_native_work`, branch lengths/scored positions/output 0 and exact timing scopes. `logical_prefill_tokens` is an inherited computed-token alias; it is not an independent logical counter. Failed or unreturned calls retain known work and unknown/incomplete remaining work. Do not replace failures with zeros or count zero generation as speed gain.
- ROOT must prove three actual Metal cases, positive actual offload/runtime identity, independent rendering/token/response parity and host-only correctness/uncertainty. Require owned PID identity, no concurrent model lane, observed clean exit plus stdio close and independently confirmed gone; exit0 alone is insufficient. Retain every error. This folder provides no runtime harness or process signals.
- Only after ROOT clears all identity/vocabulary/parity/capability/closure gates may a separately frozen plan authorize full 194 quality. Keep the existing full-quality and 90% per-score definitions, original earned units, uncertainty, coverage and actual timing unchanged. A speed comparison across different models cannot isolate generation removal. Three synthetic successes confer no full-quality, speed or production approval.

CPU command (synthetic BytesIO only):

```text
python3 -B -m unittest discover -s .build/improvement-experiments/gemma3-4b-alpha-root-recipe-preparation -p test_extract_template.py -v
```

The tests check exact byte preservation and stopping before a tensor sentinel; missing/duplicate/nonstrings/oversize template rejection; hard boundary/truncation/hash failure; and truncated skipped metadata rejection. They do not establish compatibility with the actual G3 header, template, parser, vocabulary, native libraries, weights or GPU. Source ownership is released when the final inventory/actual CPU transcript is delivered to ROOT; subsequent ROOT artifact extraction/compilation needs its own explicit stage clearance.
