import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { readFile, writeFile, rename, rm } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { parseArgs } from 'node:util';
import { Classifier, configFromEnv } from '../../dist/backend.js';
import { loadQualityRecords, evaluateRecords, writeQualityReport } from '../../dist/evaluation.js';
import { verifyTrainedArtifactExport } from '../../dist/models.js';

const { values } = parseArgs({ options: {
  artifact: { type: 'string' }, corpus: { type: 'string' },
  'corpus-sha256': { type: 'string' }, output: { type: 'string' },
  progress: { type: 'string' },
} });
for (const key of ['artifact', 'corpus', 'corpus-sha256', 'output', 'progress']) {
  assert.equal(typeof values[key], 'string', `--${key} required`);
}
const digest = value => createHash('sha256').update(value).digest('hex');
const corpusBytes = await readFile(values.corpus);
assert.equal(digest(corpusBytes), values['corpus-sha256'], 'frozen complete developer corpus changed');
const all = await loadQualityRecords(values.corpus);
assert.equal(all.length, 546, 'complete frozen developer corpus required');
const records = all.filter(record => record.split === 'validation');
assert.equal(records.length, 78, 'developer validation requires exactly 78 records');
const counts = Object.fromEntries(['choice', 'score', 'noul'].map(type => [type,
  records.filter(record => record.request.questions.length === 1 && record.request.questions[0].type === type).length,
]));
assert.deepEqual(counts, { choice: 26, score: 26, noul: 26 });
const artifact = JSON.parse(await readFile(values.artifact, 'utf8'));
assert.equal(artifact.template_version, 'v2');
const descriptor = await verifyTrainedArtifactExport(artifact);
const scopedRegistry = resolve(dirname(values.output), `developer-validation-candidate-${randomUUID()}-registry.json`);
const controller = new AbortController();
const cancel = () => controller.abort(new DOMException('Interrupted', 'AbortError'));
process.once('SIGINT', cancel);
process.once('SIGTERM', cancel);
let completed = 0;
const startedAt = new Date().toISOString();
const progress = async phase => {
  const path = resolve(values.progress);
  const part = `${path}.${process.pid}.part`;
  await writeFile(part, JSON.stringify({
    pid: process.pid, phase, split: 'validation', completed_records: completed,
    total_records: 78, started_at: startedAt, observed_at: new Date().toISOString(),
    artifact_id: artifact.id, artifact_sha256: artifact.sha256,
  }, null, 2) + '\n', { mode: 0o600 });
  await rename(part, path);
};
let classifier;
let report;
try {
  await writeFile(scopedRegistry, JSON.stringify({ version: 1, artifacts: [descriptor] }, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  const settings = {
    ...configFromEnv(process.env), modelId: artifact.id, modelFile: artifact.file,
    artifactRegistryPath: scopedRegistry, device: 'metal', templateVersion: 'v2', advanced: true,
  };
  classifier = new Classifier(settings);
  await progress('evaluating');
  report = await evaluateRecords({ classify: async (request, signal) => {
    try {
      return await classifier.classify(request, signal);
    } finally {
      completed += 1;
      await progress('evaluating');
    }
  } }, records, 'v2', { modelId: artifact.id, signal: controller.signal });
} finally {
  try {
    await classifier?.dispose();
  } finally {
    await rm(scopedRegistry, { force: true });
    process.removeListener('SIGINT', cancel);
    process.removeListener('SIGTERM', cancel);
  }
}
assert.equal(report.results.length, 78);
assert.equal(new Set(report.results.map(result => result.id)).size, 78);
assert.ok(report.results.every(result => result.error || (
  result.model === artifact.id && result.metadata?.artifact?.sha256 === artifact.sha256 &&
  result.metadata?.artifact?.size === artifact.size && result.metadata?.backend === 'llama.cpp' &&
  result.metadata?.device === 'metal' && result.metadata?.template_version === 'v2'
)), 'native candidate identity mismatch');
const uncertain = report.summary.noul;
const uncertaintyPassed = uncertain.uncertain_count > 0 &&
  typeof uncertain.uncertainty_mae === 'number' && Number.isFinite(uncertain.uncertainty_mae) &&
  uncertain.uncertainty_mae <= 0.1;
report.experiment = {
  corpus_raw_sha256: values['corpus-sha256'], split: 'validation',
  training_run: artifact.training_run, artifact_id: artifact.id,
  artifact_sha256: artifact.sha256, artifact_size: artifact.size,
  permanent_approval: false, scoped_registry_removed: true,
};
report.experiment_gates = {
  uncertainty_mae: uncertaintyPassed,
  passed: report.summary.gates.passed && uncertaintyPassed,
};
await writeQualityReport(values.output, report);
await progress('complete');
process.stdout.write(JSON.stringify(report, null, 2) + '\n');
if (!report.experiment_gates.passed) process.exitCode = 1;
