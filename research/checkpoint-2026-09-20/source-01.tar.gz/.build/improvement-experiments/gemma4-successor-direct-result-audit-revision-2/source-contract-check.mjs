import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { validateQualityRecords, qualityDatasetDigest } from '../../../dist/evaluation.js';
import { PINS, sha, jsonBytes, strictJson, recordManifest, expectedOriginalTeacherRequest, buildSchedule, wireBranch } from './contracts.mjs';
import { compileHalfGrid } from '../fractional-score-hypothesis/candidate-2/grid.mjs';

// Explicit SOURCE/manifest-only check. It reads the one ROOT-authorized safe
// developer VALIDATION manifest. It never reads actual model results, performs
// rendering/tokenization, or starts inference. No default CLI executes this.
export async function prepareSourceContractMetadata() {
  const input = fileURLToPath(new URL('../validation-label-audit/validation-78.jsonl', import.meta.url));
  const bytes = await readFile(input); assert.equal(bytes.length, PINS.inputBytes); assert.equal(sha(bytes), PINS.input);
  const values = bytes.toString('utf8').trim().split(/\r?\n/).map(line => strictJson(JSON.parse(line)));
  const records = validateQualityRecords(values); assert.equal(records.length, 78);
  assert.equal(new Set(records.map(row => row.group_id)).size, 39); assert.ok(records.every(row => row.split === 'validation' && row.request.questions.length === 1));
  let maxCompilePacket = 0, maxTeacherPost = 0; const types = { choice: 0, score: 0, noul_clear: 0, noul_unknown: 0 };
  for (const record of records) {
    const q = record.request.questions[0]; types[q.type === 'noul' ? record.targets[q.id].answer === null || !Object.hasOwn(record.targets[q.id], 'answer') ? 'noul_unknown' : 'noul_clear' : q.type]++;
    const logical = compileHalfGrid(record.request); assert.equal(logical.questions.length, 1); assert.equal(logical.template_version, PINS.logicalId);
    const compileBytes = Buffer.byteLength(JSON.stringify({ v: 1, id: 'source-only', op: 'compile', branches: logical.questions.map(wireBranch) })) + 1;
    assert.ok(compileBytes <= 262144); maxCompilePacket = Math.max(maxCompilePacket, compileBytes);
    const teacher = expectedOriginalTeacherRequest(record); assert.equal(teacher.messages.length, 2);
    maxTeacherPost = Math.max(maxTeacherPost, Buffer.byteLength(JSON.stringify(teacher)));
  }
  const result = { kind: 'successor312_source_manifest_contract_metadata_ONLY', input: { path: input, bytes: bytes.length, sha256: sha(bytes), records: 78, groups: 39 },
    dataset_digest: qualityDatasetDigest(records), ordered_record_manifest: recordManifest(records), question_types: types,
    schedule: buildSchedule(records.map(row => row.id)), max_outgoing_compile_packet_bytes: maxCompilePacket,
    max_original_RFDT_teacher_POST_bytes: maxTeacherPost,
    actual_selected_logits_or_model_answers_read: false, model_tokenizer_native_GPU_training_network_auth_executed: false,
    Jinja_or_tokenizer_executed: false, actual_prompt_token_counts_proven: false, actual_quality_or_gain_proven: false, approval_effect: 'none' };
  strictJson(result); const output = fileURLToPath(new URL('./manifest-contract-metadata.json', import.meta.url));
  await writeFile(output, jsonBytes(result), { flag: 'wx', mode: 0o600 }); return { path: output, bytes: jsonBytes(result).length, sha256: sha(jsonBytes(result)), question_types: types };
}
