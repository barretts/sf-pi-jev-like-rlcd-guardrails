"""Explicit ROOT closed-stage Jinja reference hook. No model/tokenizer/native calls.

Prepared from the immutable original renderer SOURCE. It independently renders
both Alpha repetitions and every dispatched teacher retry after ROOT closes the
stage. Source preparation and Python syntax checking do not execute this hook.
"""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import time


def runtime_identity():
    import jinja2
    package = Path(jinja2.__file__).parent
    entries = [{'path': str(path.relative_to(package)), 'sha256': sha256(path.read_bytes()).hexdigest()}
               for path in sorted(package.rglob('*.py'))]
    executable = Path(sys.executable).resolve()
    return {'python_executable': str(executable), 'python_executable_sha256': sha256(executable.read_bytes()).hexdigest(),
            'python_version': sys.version, 'jinja_version': jinja2.__version__,
            'jinja_python_sources': entries,
            'jinja_python_sources_sha256': sha256(json.dumps(entries, separators=(',', ':')).encode()).hexdigest()}


def main():
    from jinja2 import __version__ as jinja_version
    from jinja2.sandbox import ImmutableSandboxedEnvironment
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--closed-stage', action='store_true', required=True)
    parser.add_argument('--requests', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--template', required=True)
    parser.add_argument('--expected-sha256', required=True)
    args = parser.parse_args()
    if args.expected_sha256 != 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4':
        raise ValueError('Only the pinned original Gemma4 Jinja SOURCE is allowed')
    started = time.monotonic()
    raw = Path(args.template).read_bytes()
    if len(raw) != 18683 or sha256(raw).hexdigest() != args.expected_sha256:
        raise ValueError('Original raw template byte identity mismatch')
    requests_raw = Path(args.requests).read_bytes()
    requests = json.loads(requests_raw)
    environment = ImmutableSandboxedEnvironment(trim_blocks=True, lstrip_blocks=True)

    def raise_exception(message):
        raise ValueError(message)

    environment.globals['raise_exception'] = raise_exception
    template = environment.from_string(raw.decode('utf-8'))
    rows, seen = [], set()
    for entry in requests:
        branch = entry['branch']
        key = (entry['record_id'], branch['branch_id'])
        if key in seen:
            raise ValueError('Duplicate frozen render request')
        seen.add(key)
        original_messages = branch['messages']
        messages, merged = [], False
        for index, message in enumerate(original_messages):
            if index + 1 == len(original_messages) and message['role'] == 'user' and messages and messages[-1]['role'] == 'user':
                messages[-1]['content'] += '\n\n' + message['content']
                merged = True
            else:
                messages.append(dict(message))
        rendered = template.render(messages=messages, bos_token='<bos>', eos_token='',
                                   add_generation_prompt=True, enable_thinking=False)
        boundary = '<|turn>model\n<|channel>thought\n<channel|>'
        if not rendered.endswith(boundary):
            raise ValueError('Original disabled-thinking generation boundary mismatch')
        rendered += branch['answer_prefix']
        if not rendered.startswith('<bos>'):
            rendered = '<bos>' + rendered
        if rendered.count('<bos>') != 1:
            raise ValueError('Original BOS must occur exactly once')
        rows.append({'record_id': key[0], 'branch_id': key[1], 'rendered': rendered,
                     'rendered_sha256': sha256(rendered.encode()).hexdigest(),
                     'logical_messages_sha256': sha256(json.dumps(original_messages, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest(),
                     'final_two_user_messages_merged': merged, 'messages_before': len(original_messages),
                     'messages_after': len(messages), 'answer_prefix': branch['answer_prefix']})
    identity = runtime_identity()
    result = {'kind': 'gemma4_successor_independent_closed_stage_jinja_render',
              'original_raw_template_sha256': sha256(raw).hexdigest(), 'original_raw_template_bytes': len(raw),
              'requests_sha256': sha256(requests_raw).hexdigest(), 'python_jinja_version': jinja_version,
              'python_version': sys.version, 'runtime_identity': identity,
              'render_options': {'trim_blocks': True, 'lstrip_blocks': True, 'bos_token': '<bos>',
                                 'eos_token': '', 'add_generation_prompt': True, 'enable_thinking': False,
                                 'tools_argument_supplied': False},
              'normalization': 'only final adjacent user messages merge with two LF bytes; supplied earlier roles/history stay intact',
              'native_or_model_execution': False, 'rows': rows, 'elapsed_seconds': time.monotonic() - started}
    with Path(args.output).open('x') as output:
        output.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')


if __name__ == '__main__':
    main()
