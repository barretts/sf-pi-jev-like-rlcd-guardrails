import test from 'node:test';
import assert from 'node:assert/strict';
import { pairedSummary } from '../../../scripts/developer-decision-eval.mjs';
import { attestClosedSuccessor312, attestInjectedCpuSuccessor312, buildTeacherRenderRequests, strictJson, sha, jsonBytes } from './attest.mjs';
import { makeFixture, refreshFixture, syncAttempt, clone, inventedRenderBundle } from './fixtures.cpu.mjs';

const grade = fixture => attestInjectedCpuSuccessor312(refreshFixture(fixture).input, fixture.options);
const recomputeSummaries = fixture => {
  fixture.result.summary = pairedSummary(fixture.result.attempts);
  fixture.result.replicate_summaries = [1, 2].map(rep => pairedSummary(fixture.result.attempts.filter(row => row.repetition === rep)));
};
const expectReject = (fixture, pattern) => assert.throws(() => grade(fixture), pattern);

test('invented fully passing 312 arithmetic cannot qualify ROOT actual gain or promotion', () => {
  const fixture = makeFixture(); const before = sha(fixture.input.resultBytes); const report = grade(fixture);
  assert.equal(report.integrity_attested, true); assert.equal(report.gates.aggregate.passed, true);
  assert.ok(report.gates.per_repetition.every(row => row.passed));
  assert.equal(report.root_qualified_improvement_claim_permitted, false); assert.equal(report.root_receipt_bound, false);
  assert.equal(report.proof_kind, 'invented_injected_CPU_ONLY'); assert.equal(report.approval_effect, 'none');
  assert.equal(report.production_role_approval, false); assert.equal(report.true_DX_gain_established, false);
  assert.equal(report.work_ledger.length, 312); assert.equal(report.exact_coverage.full_frozen_denominator_retained, true);
  assert.equal(before, sha(fixture.input.resultBytes), 'Raw bytes unchanged by attester');
  assert.throws(() => attestClosedSuccessor312(fixture.input), /strictEqual|Expected|frozen|counter/);
});

test('honest complete slower native result keeps all work and fails both twofold conditions', () => {
  const report = grade(makeFixture({ nativeMs: 30, generatedMs: 40 }));
  assert.equal(report.integrity_attested, true); assert.equal(report.execution_failures, 0);
  assert.equal(report.actual_token_cache_and_cleanup_contracts_complete, true);
  assert.equal(report.gates.aggregate.conditional_correct_clear_pair_median_twofold, false);
  assert.equal(report.gates.aggregate.all_attempt_elapsed_per_correct_twofold, false);
  assert.equal(report.honest_negative_attested, true); assert.equal(report.raw_attempts.length, 312);
});

test('all312 unrun initialization failures retain elapsed and expected score/unknown denominators', () => {
  const report = grade(makeFixture({ allUnrun: true }));
  assert.equal(report.unrun_attempts, 312); assert.equal(report.execution_failures, 312);
  assert.equal(report.raw_attempts.length, 312); assert.equal(report.actual_token_cache_and_cleanup_contracts_complete, false);
  assert.equal(report.gates.aggregate.expected_score_count, 52); assert.equal(report.gates.aggregate.direct_score_correct_count, 0);
  assert.equal(report.original_quality[0].expected_unknown_questions, 16);
  assert.equal(report.original_quality[0].observed_unknown_questions, 0);
  assert.equal(report.work_ledger[0].computed_prompt_tokens, null, 'Unsubmitted/unknown execution is not imputed measured zero');
  assert.equal(report.honest_negative_attested, true);
});

test('one substituted record, missing row, wrong seed, or reordered pair cannot obtain coverage', () => {
  const f = makeFixture(); f.result.attempts.pop(); expectReject(f, /312|Expected/);
  const g = makeFixture(); g.result.attempts[1].record_id = g.result.attempts[0].record_id; syncAttempt(g, 1); expectReject(g, /All312/);
  const h = makeFixture(); h.result.attempts[0].seed = 104771; syncAttempt(h, 0); expectReject(h, /Expected/);
});

test('wrong submitted llama_decode count and nonzero native generation are rejected from raw metrics', () => {
  for (const [key, value] of [['engine_forwards', 2], ['branch_output_tokens', 1]]) {
    const f = makeFixture(); const row = f.auditRows.find(row => row.kind === 'native_RPC' && row.request.op === 'evaluate');
    row.response.result.metrics[key] = value;
    // Fully rebind CPU ROOT receipt; unchanged runner accounting flags cannot rescue raw counter failure.
    expectReject(f, /2048|Native actual contract/);
  }
});

test('raw selected logits independently rebuild typed response; forged stored correctness is rejected', () => {
  const f = makeFixture(); const row = f.auditRows.find(row => row.kind === 'native_RPC' && row.request.op === 'evaluate');
  const branch = Object.keys(row.response.result.logits)[0], labels = Object.keys(row.response.result.logits[branch]);
  row.response.result.logits[branch] = Object.fromEntries(labels.map((label, index) => [label, index === 0 ? 20 : -20]));
  expectReject(f, /Alpha envelope reconstructed|Raw.*equality|response/);
});

test('original earned score correctness gate catches distributed misses even when mean error passes', () => {
  const report = grade(makeFixture({ scoreMisses: 3 }));
  assert.equal(report.gates.aggregate.expected_score_count, 52);
  assert.equal(report.gates.aggregate.direct_score_correct_count, 46);
  assert.ok(report.original_quality[0].original_quality.score.normalized_mae <= 0.1);
  assert.equal(report.gates.aggregate.direct_individual_original_score_correctness, false);
  assert.equal(report.gates.per_repetition[0].direct_individual_original_score_correctness, false);
  assert.equal(report.root_qualified_improvement_claim_permitted, false);
});

test('complete native unknown responses can be honest negative; original unknown<=.1 gate remains', () => {
  const report = grade(makeFixture({ unknownWrong: true }));
  assert.equal(report.execution_failures, 0); assert.equal(report.actual_token_cache_and_cleanup_contracts_complete, true);
  assert.equal(report.original_quality[0].observed_unknown_questions, report.original_quality[0].expected_unknown_questions);
  assert.ok(report.original_quality[0].unknown_normalized_mae > 0.1);
  assert.equal(report.original_quality[0].original_external_unknown_gate, false);
  assert.equal(report.gates.aggregate.both_arms_original_quality_unknown_and_coverage, false);
});

test('probability-map NOUL uncertainty cannot dilute the separate original explicit-null gate', () => {
  const report = grade(makeFixture({ unknownWrong: true, probabilityMapNoul: true }));
  const native = report.original_quality[0]; assert.equal(native.expected_unknown_questions, 16);
  assert.equal(native.observed_unknown_questions, 16); assert.ok(native.unknown_normalized_mae > 0.4);
  assert.equal(native.original_external_unknown_gate, false);
  assert.equal(native.original_quality.noul.uncertain_count, 52, 'Actual original scorer still treats all probability targets uncertain');
});

test('unknown elapsed failure work stays null and disables every gain summary', () => {
  const f = makeFixture({ allUnrun: true }); f.result.attempts[0].elapsed_ms = null; syncAttempt(f, 0);
  f.result.summary = null; f.result.replicate_summaries = [null, null]; f.result.summary_error = 'invented unknown elapsed work';
  const report = grade(f); assert.equal(report.unknown_elapsed_attempts, 1); assert.equal(report.raw_attempts[0].elapsed_ms, null);
  assert.equal(report.work_ledger[0].retained_elapsed_ms, null); assert.equal(report.summary, null);
  assert.deepEqual(report.replicate_summaries, [null, null]); assert.equal(report.gates.measurement_qualified, false);
  assert.equal(report.execution_failures, 312); assert.equal(report.gates.aggregate.passed, false);
});

test('generated invalid first target then accepted retry retains both raw POST counters and time', () => {
  const f = makeFixture(); const index = f.result.attempts.findIndex(row => row.method === 'generative'); const attempt = f.result.attempts[index];
  const original = attempt.teacher_tries[0]; const first = clone(original); const second = clone(original); second.ordinal = 1;
  const invalidReply = JSON.parse(first.response_text); invalidReply.choices[0].message.content = '{"unexpected":{"answer":true}}';
  first.response_text = JSON.stringify(invalidReply); first.response_sha256 = sha(first.response_text);
  attempt.teacher_tries = [first, second]; attempt.transport = [first, second];
  attempt.actual_work = { ...attempt.actual_work, dispatched_posts: 2, measured_prefill_posts: 2, measured_generation_posts: 2,
    known_computed_prompt_tokens: 6, known_generated_tokens: 4, computed_prompt_tokens: 6, computed_output_tokens: 4 };
  const auditIndex = f.auditRows.findIndex(row => row.kind === 'teacher_try' && row.record_id === attempt.record_id);
  f.auditRows.splice(auditIndex, 1, { kind: 'teacher_try', record_id: attempt.record_id, ...first }, { kind: 'teacher_try', record_id: attempt.record_id, ...second });
  syncAttempt(f, index); f.teacherRender = inventedRenderBundle(buildTeacherRenderRequests(f.result.attempts), f.plan.host_runtime.renderer); recomputeSummaries(f);
  const report = grade(f); const ledger = report.work_ledger[index];
  assert.equal(ledger.dispatched_posts, 2); assert.equal(ledger.known_generated_tokens, 4);
  assert.equal(ledger.work.computed_prompt_tokens, 6); assert.ok(ledger.diagnostics.some(row => row.includes('strict original target rejection')));
  assert.equal(report.summary.methods.generative.work.actual_provider_posts, 157);
  assert.equal(report.raw_attempts[index].transport.length, 2);
});

test('POST response integrity, cache_n0, teacher target schema and complete duration cannot be faked', () => {
  const f = makeFixture(); const row = f.result.attempts.find(row => row.method === 'generative'); row.transport[0].response_sha256 = sha('wrong raw bytes');
  const firstAudit = f.auditRows.findIndex(item => item.kind === 'teacher_try' && item.record_id === row.record_id);
  f.auditRows[firstAudit] = { kind: 'teacher_try', record_id: row.record_id, ...row.transport[0] };
  expectReject(f, /byte integrity/);
  const g = makeFixture(); const index = g.result.attempts.findIndex(row => row.method === 'generative'); const post = g.result.attempts[index].transport[0];
  const reply = JSON.parse(post.response_text); reply.timings.cache_n = 1; post.server_timings.cache_n = 1;
  post.response_text = JSON.stringify(reply); post.response_sha256 = sha(post.response_text); syncAttempt(g, index);
  const secondAudit = g.auditRows.findIndex(item => item.kind === 'teacher_try' && item.record_id === g.result.attempts[index].record_id);
  g.auditRows[secondAudit] = { kind: 'teacher_try', record_id: g.result.attempts[index].record_id, ...post };
  expectReject(g, /Expected/);
  const h = makeFixture(); const i = h.result.attempts.findIndex(row => row.method === 'generative'); h.result.attempts[i].elapsed_ms = 0.1;
  syncAttempt(h, i); expectReject(h, /Full attempt duration/);
});

test('fresh all156 independent Jinja output and BOS checks are required despite runner match flags', () => {
  const f = makeFixture(); const reference = JSON.parse(f.alphaRender.referenceBytes); reference.rows.pop(); f.alphaRender.referenceBytes = jsonBytes(reference);
  expectReject(f, /Expected/);
  const g = makeFixture(); const row = g.auditRows.find(row => row.kind === 'native_RPC' && row.request.op === 'compile'); row.response.result[0].tokens = [2, 2, 12];
  expectReject(g, /Exactly one BOS/);
  const h = makeFixture(); h.rootFacts.render_executions[0].exit_code = 1;
  refreshFixture(h); h.input.rootFacts.render_executions[0].executed_after_stage_closed = false;
  assert.throws(() => attestInjectedCpuSuccessor312(h.input, h.options), /Expected/);
});

test('fresh qualification bytes, new physical identity and full current artifact inventory are enforced', () => {
  const f = makeFixture(); f.fresh194Bytes.report = Buffer.from('{}'); expectReject(f, /Fresh194 exact bytes/);
  const g = makeFixture(); g.plan.direct.research_profile = 'gemma4-direct-label-raw-q4-research-v0'; g.result.direct_physical_identity = g.plan.direct;
  expectReject(g, /Expected/);
  const h = makeFixture(); refreshFixture(h); h.input.rootFacts.current_verified_identities = h.rootFacts.current_verified_identities.filter(row => !row.path.endsWith('raw.gguf'));
  assert.throws(() => attestInjectedCpuSuccessor312(h.input, h.options), /full source.*identity inventory/);
});

test('cleanup requires raw exit/stdio plus separate ROOT gone fact for every process', () => {
  const f = makeFixture(); f.rootFacts.owned_process_observations[0].pid_gone.absent = false; expectReject(f, /Expected/);
  const g = makeFixture(); g.result.blocks[0].cleanup.snapshot.closedObserved = false; expectReject(g, /Expected/);
  const h = makeFixture(); const cleanup = h.result.blocks[1].cleanup; cleanup.logs = cleanup.logs.replace('K (f16):600MiB', 'K (q8_0):600MiB');
  h.rootFacts.owned_process_observations[1].logs_sha256 = sha(cleanup.logs);
  h.auditRows.find(row => row.kind === 'owned_server_process' && row.pid === cleanup.pid).logs = cleanup.logs;
  expectReject(h, /every KV buffer dtype is F16/);
});

test('own finite JSON boundary rejects inherited attribution, getters, sparse arrays and Infinity before serialization', () => {
  const bad = [Object.create({ actor: 'ROOT' }), { count: Infinity }, { get actor() { throw new Error('getter executed'); } }, [,,]];
  for (const value of bad) assert.throws(() => strictJson(value), /plain|Nonfinite|Accessor|Sparse/);
  const f = makeFixture(); f.input.rootFacts = Object.create(f.rootFacts);
  assert.throws(() => attestInjectedCpuSuccessor312(f.input, f.options), /Own plain JSON/);
});

test('every raw native RPC PID belongs to block cleanup/init and classifier elapsed is enclosed', () => {
  const f = makeFixture();
  for (const attempt of f.result.attempts.filter(row => row.method === 'native')) for (const receipt of attempt.native_RPC) receipt.pid = 99991;
  for (const row of f.auditRows.filter(row => row.kind === 'native_RPC' && row.request.op !== 'init')) row.pid = 99991;
  expectReject(f, /that block owned init\/cleanup PID/);
  const g = makeFixture({ nativeMs: 0.25 }); expectReject(g, /complete native classifier envelope time/);
  const h = makeFixture(); const extra = clone(h.auditRows.find(row => row.kind === 'native_RPC' && row.request.op === 'init'));
  extra.block = h.plan.schedule[1]; extra.pid = 99992; h.auditRows.unshift(extra);
  expectReject(h, /Every native initialization/);
  const i = makeFixture(); const terminal = clone(i.auditRows.find(row => row.kind === 'owned_native_process'));
  terminal.pid = 99993; i.auditRows.push(terminal); expectReject(i, /Every owned terminal receipt/);
});

// These are invented startup/ownership receipts; they do not inspect a listener.
const replaceListenerPolls = (fixture, change) => {
  const cleanup = fixture.result.blocks.find(row => row.method === 'generative').cleanup;
  const positive = clone(cleanup.listener_observations[0]);
  const empty = { ...clone(positive), only_owned_listener: false, observed_listeners: [], observed_at: '2026-09-20T13:59:59.000Z' };
  cleanup.listener_observations = change(positive, empty);
  fixture.auditRows.find(row => row.kind === 'owned_server_process' && row.pid === cleanup.pid).listener_observations = clone(cleanup.listener_observations);
  return fixture;
};

test('empty startup prefix followed by retained owned listener arrays preserves all312 quality and accounting', () => {
  const f = replaceListenerPolls(makeFixture(), (positive, empty) => [empty, positive, clone(positive)]);
  const before = sha(refreshFixture(f).input.resultBytes); const report = grade(f);
  assert.equal(report.research_schema, 'independent-successor-312-result-attestation-2');
  assert.equal(report.integrity_attested, true); assert.equal(report.actual_token_cache_and_cleanup_contracts_complete, true);
  assert.equal(report.raw_attempts.length, 312); assert.equal(report.gates.aggregate.passed, true);
  assert.ok(report.gates.per_repetition.every(row => row.passed));
  assert.deepEqual(report.raw_blocks[1].cleanup.listener_observations, f.result.blocks[1].cleanup.listener_observations);
  assert.equal(sha(f.input.resultBytes), before, 'Listener validation never rewrites retained results');
  assert.equal(report.root_qualified_improvement_claim_permitted, false, 'Invented CPU startup receipts are not native proof');
});

test('foreign startup and foreign positive listeners cannot satisfy owned loopback attribution', () => {
  const f = replaceListenerPolls(makeFixture(), (positive, empty) => [{ ...empty, observed_listeners: [{ pid: 99998, comm: 'foreign', address: '127.0.0.1:8089' }] }, positive]);
  expectReject(f, /Only an empty startup/);
  const g = replaceListenerPolls(makeFixture(), positive => [{ ...positive, observed_listeners: [{ pid: 99998, comm: 'foreign', address: '127.0.0.1:8089' }] }]);
  expectReject(g, /Every actual listener belongs/);
  const h = replaceListenerPolls(makeFixture(), positive => [{ ...positive, observed_listeners: [{ ...positive.observed_listeners[0], address: '*:8089' }] }]);
  expectReject(h, /exact owned loopback port/);
});

test('positive listener flags require retained nonempty noncontradictory observed arrays', () => {
  const f = replaceListenerPolls(makeFixture(), positive => [{ ...positive, observed_listeners: [] }]);
  expectReject(f, /Positive listener ownership requires/);
  const g = replaceListenerPolls(makeFixture(), positive => { delete positive.observed_listeners; return [positive]; });
  expectReject(g, /Explicit retained listener array/);
  const h = replaceListenerPolls(makeFixture(), positive => [{ ...positive, only_owned_listener: false }]);
  expectReject(h, /Only an empty startup/);
});

test('listener ownership cannot disappear after startup and never-owned histories fail', () => {
  const f = replaceListenerPolls(makeFixture(), (positive, empty) => [positive, { ...empty, observed_at: '2026-09-20T14:00:01.000Z' }]);
  expectReject(f, /ownership cannot be lost/);
  const g = replaceListenerPolls(makeFixture(), (_, empty) => [empty]); expectReject(g, /At least one positively/);
});

test('listener history rejects unknown states errors invalid times and wrong observer PID or port', () => {
  for (const patch of [{ only_owned_listener: null }, { error: 'invented lsof error' }, { observed_at: 'invalid-time' },
    { observed_at: 0 }, { actor: 'agent' }, { pid: 99997 }, { port: 8090 }, { method: '' }]) {
    const f = replaceListenerPolls(makeFixture(), positive => [{ ...positive, ...patch }]);
    expectReject(f, /Known listener|no error|timestamp|Expected|method/);
  }
  const g = replaceListenerPolls(makeFixture(), (positive, empty) => [positive, { ...clone(positive), observed_at: empty.observed_at }]);
  expectReject(g, /chronological startup order/);
});

test('listener startup allowance retains distinct exit1 recovery status without inventing runner success', () => {
  const f = replaceListenerPolls(makeFixture(), (positive, empty) => [empty, positive]);
  f.result.status = 'ROOT_recovered_complete_inference_after_runner_final_serialization_failure';
  f.result.recovery = { actor: 'ROOT', original_runner_unified_exit_code: 1, native_inference_replayed: false,
    original_result_and_driver_close_proof_absent: true, recovery_does_not_make_original_runner_successful: true };
  f.rootFacts.original_runner_exit_code = 1; f.rootFacts.original_runner_successful = false;
  const report = grade(f);
  assert.equal(report.result_status, f.result.status); assert.equal(report.execution_failures, 0);
  assert.equal(report.actual_token_cache_and_cleanup_contracts_complete, true);
  assert.equal(f.result.recovery.original_runner_unified_exit_code, 1); assert.equal(f.rootFacts.original_runner_successful, false);
  assert.equal(report.root_qualified_improvement_claim_permitted, false); assert.equal(report.approval_effect, 'none');
});
