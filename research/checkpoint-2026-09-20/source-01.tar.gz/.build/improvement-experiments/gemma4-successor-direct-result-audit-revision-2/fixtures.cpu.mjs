// Entirely invented fixtures. No original records, targets, logits, model files,
// quality outputs, runtime processes or tokenizer execution are read here.
import { validateQualityRecords, scorePrediction } from '../../../dist/evaluation.js';
import { scoreAnswer, pairedSummary } from '../../../scripts/developer-decision-eval.mjs';
import { compileHalfGrid, responseHalfGrid } from '../fractional-score-hypothesis/candidate-2/grid.mjs';
import { PINS, sha, jsonBytes, buildSchedule, recordManifest, wireBranch, BOUNDARY, expectedOriginalTeacherRequest } from './contracts.mjs';
import { buildAlphaRenderRequests, buildTeacherRenderRequests } from './attest.mjs';

const path = name => '/invented-CPU/' + name;
const identity = (name, hash = sha(name), bytes = 1) => ({ path: path(name), bytes, sha256: hash });
export const clone = value => structuredClone(value);
function renderRows(requests) {
  return requests.map(entry => {
    const branch = entry.branch, messages = branch.messages;
    const merged = messages.length > 1 && messages.at(-1).role === 'user' && messages.at(-2).role === 'user';
    // Obvious invented render, deliberately not a real Jinja execution claim.
    const rendered = '<bos>INVENTED CPU RENDER\n' + sha(JSON.stringify(messages)) + BOUNDARY + branch.answer_prefix;
    return { record_id: entry.record_id, branch_id: branch.branch_id, rendered, rendered_sha256: sha(rendered),
      logical_messages_sha256: sha(JSON.stringify(messages)), final_two_user_messages_merged: merged,
      messages_before: messages.length, messages_after: messages.length - Number(merged), answer_prefix: branch.answer_prefix };
  });
}
export function inventedRenderBundle(requests, runtime) {
  const requestsBytes = jsonBytes(requests); const reference = { kind: 'gemma4_successor_independent_closed_stage_jinja_render',
    requests_sha256: sha(requestsBytes), original_raw_template_sha256: PINS.template, original_raw_template_bytes: PINS.templateBytes,
    native_or_model_execution: false, runtime_identity: runtime, python_jinja_version: '3.1.6',
    render_options: { trim_blocks: true, lstrip_blocks: true, bos_token: '<bos>', eos_token: '', add_generation_prompt: true,
      enable_thinking: false, tools_argument_supplied: false }, rows: renderRows(requests) };
  return { requestsBytes, referenceBytes: jsonBytes(reference) };
}
function rowGrade(record, returned, method) {
  const q = record.request.questions[0]; const raw = method === 'native' ? returned.answers[q.id] : returned[q.id];
  const decision = scoreAnswer(q, record.targets[q.id], raw, method);
  const prediction = method === 'native' ? raw : { id: q.id, type: q.type, ...(q.type === 'choice' ? { choice: decision.predicted } : q.type === 'score' ? { score: decision.predicted } : { noul: decision.predicted }) };
  return { answers: [decision], original_quality_grades: [scorePrediction(q, record.targets[q.id], prediction)],
    correct_judgment: decision.correct_judgment, completed_clear_decision: decision.completed_clear_decision, abstention: decision.abstention };
}
function nativeFold(metrics) { return { computed_prompt_tokens: metrics.computed_prompt_tokens, computed_output_tokens: 0, engine_forwards: metrics.engine_forwards,
  output_counter_source: 'unchanged native metrics.branch_output_tokens; engine has no generation/sampler path',
  forwards_source: 'unchanged native metrics.engine_forwards: submitted llama_decode calls, not Metal kernels or ubatches' }; }
function serverFold(post) { return { dispatched_posts: 1, measured_prefill_posts: 1, measured_generation_posts: 1,
  known_computed_prompt_tokens: post.server_timings.prompt_n, known_generated_tokens: post.server_timings.predicted_n,
  computed_prompt_tokens: post.server_timings.prompt_n, computed_output_tokens: post.server_timings.predicted_n,
  engine_forwards: null, engine_forwards_source: 'server API does not expose submitted llama_decode calls' }; }
function terminal(pid) { return { pid, state: 'closed', exitedObserved: true, closedObserved: true, exitCode: 0, signal: null,
  failureCode: null, pendingRequests: 0, stderr: 'MTL0 offloaded 61/61 layers to GPU', stderrTruncated: false }; }
function gone(pid) { return { actor: 'ROOT', pid, absent: true, observed_at: '2026-09-20T14:00:00.000Z', method: 'invented CPU observation' }; }
export function makeFixture({ nativeMs = 10, generatedMs = 40, scoreMisses = 0, unknownWrong = false, allUnrun = false, probabilityMapNoul = false } = {}) {
  const rawRecords = Array.from({ length: 78 }, (_, i) => {
    const type = i < 26 ? 'choice' : i < 52 ? 'score' : 'noul';
    const q = { id: 'q', type, instructions: 'Invented question; earned half credit is explicit where used.',
      ...(type === 'choice' ? { criteria: [{ id: 'yes', description: 'Yes' }, { id: 'no', description: 'No' }] }
        : type === 'score' ? { criteria: ['zero', 'one', 'two'] } : {}) };
    return { id: 'invented-' + i, group_id: 'invented-group-' + Math.floor(i / 2), split: 'validation', regression: i === 0,
      request: { model: PINS.modelId, state: 'Invented context ' + i, questions: [q], options: { template_version: 'v2' } },
      targets: { q: { answer: type === 'choice' ? 'yes' : type === 'score' ? (i % 2 ? 0.5 : 1) : i % 3 === 0 ? null : i % 2 === 0 } } };
  });
  if (probabilityMapNoul) for (const row of rawRecords) if (row.request.questions[0].type === 'noul' && row.targets.q.answer !== null)
    row.targets.q = { probabilities: Object.fromEntries(Array.from({ length: 9 }, (_, index) => [String(index + 1), index === 0 ? 1 : 0])) };
  const inputBytes = Buffer.from(rawRecords.map(row => JSON.stringify(row)).join('\n') + '\n');
  const records = validateQualityRecords(rawRecords); const schedule = buildSchedule(records.map(row => row.id));
  const physical_profile = { id: PINS.profileId, model_expected_size: PINS.modelBytes, model_expected_sha256: PINS.model,
    decode_chunk: 2048, sequence_capacity: 2, swa_full: true, kv_unified: true };
  const pins = { ...PINS, profile: sha(JSON.stringify(physical_profile)), input: sha(inputBytes), inputBytes: inputBytes.length };
  const runtime = { python_executable: path('python'), python_executable_sha256: sha('invented python'), python_version: 'invented CPU only',
    jinja_version: '3.1.6', jinja_python_sources: [], jinja_python_sources_sha256: sha('invented Jinja sources') };
  const qualificationPlan = { logical_id: PINS.logicalId, physical_profile, physical_profile_sha256: pins.profile,
    sources: { prototype: identity('main.cpp', PINS.source), host: [identity('candidate-2/grid.mjs', PINS.grid)] },
    artifacts: { binary: identity('native-binary', PINS.binary, PINS.binaryBytes), model: identity('raw.gguf', PINS.model, PINS.modelBytes) } };
  const qualityGates = { original_contract_passed: true, prospective_developer_score_correctness: true, passed: true };
  const scoreCorrectness = { accuracy: 1, passed: true };
  const envelopes = Array.from({ length: 194 }, (_, index) => ({ record_id: 'invented-194-' + index }));
  const qualificationReport = { gates: qualityGates, prospective_developer_score_correctness: scoreCorrectness, run_envelopes: envelopes };
  const qualificationStage = { run_plan_sha256: sha(jsonBytes(qualificationPlan)), passed: true, native_contracts_passed: true,
    root_pid_gone_passed: true, exact_194_envelope_order: true, quality_gates_passed: true, logical_id: PINS.logicalId,
    research_profile: PINS.profileId, physical_profile_sha256: pins.profile, actual_native_process_launches: 1,
    old_proofs_used_to_qualify_changed_candidate: false, held_out_TEST_read: false, native_pid: 999,
    root_pid_gone_observation: { actor: 'ROOT', pid: 999, gone: true } };
  const fresh194Bytes = { plan: jsonBytes(qualificationPlan), stage: jsonBytes(qualificationStage), report: jsonBytes(qualificationReport), envelopes: jsonBytes(envelopes) };
  const refs = Object.fromEntries(Object.entries(fresh194Bytes).map(([key, bytes]) => [key, { path: path('invented194/' + key + '.json'), bytes: bytes.length, sha256: sha(bytes) }]));
  const receipt = { kind: 'ROOT_successor_full_validation_194_result_attestation', validation_quality_qualified: true, all_quality_gates_passed: true,
    honest_completed_negative: false, approval_effect: 'none', run_plan_sha256: refs.plan.sha256, stage_sha256: refs.stage.sha256,
    quality_report_sha256: refs.report.sha256, run_envelopes_sha256: refs.envelopes.sha256,
    logical_id: PINS.logicalId, research_profile: PINS.profileId, physical_profile_sha256: pins.profile, physical_profile_file_sha256: PINS.profileFile,
    prototype_source_sha256: PINS.source, binary_sha256: PINS.binary, raw_model_sha256: PINS.model, raw_model_bytes: PINS.modelBytes,
    records: 194, independent_groups: 83, actual_inference_errors: 0, no_new_TEST_inference: true, production_role_approved: false,
    benchmark_gain_established: false, full_developer_workflow_gain_established: false, owned_pid_absent: true,
    independent_exit_and_stdio_close_observed: true, native_full_validation_contracts_attested: true, owned_pid: 999,
    quality_gates: qualityGates, developer_score_correctness: scoreCorrectness };
  fresh194Bytes.receipt = jsonBytes(receipt); refs.receipt = { path: path('invented194/receipt.json'), bytes: fresh194Bytes.receipt.length, sha256: sha(fresh194Bytes.receipt) };
  const qualification_refs = Object.fromEntries(['plan', 'receipt', 'report', 'stage'].map(key => [key, refs[key]]));
  const source_files = [identity('candidate-2/grid.mjs', PINS.grid), identity('dist/core.js', PINS.core), identity('dist/evaluation.js', PINS.evaluation),
    identity('dist/rfdt.js', PINS.rfdt), identity('scripts/developer-decision-eval.mjs', PINS.decision), identity('gemma4-successor-direct-proposal/runner.mjs', PINS.benchmarkRunner),
    ...Array.from({ length: 33 }, (_, index) => identity('invented-dependency-' + index))];
  const benchmarkReleaseBytes = jsonBytes({ kind: 'gemma4_successor_direct_matched312_source_release', release_revision: 2,
    source_identities: source_files, native_execution_authorized: false, production_role_approval: false });
  const plan = { kind: 'gemma4_successor_direct_matched312_frozen_plan', status: 'root_frozen', inference_ready: true,
    prospective_protocol: identity('prospective.json', PINS.prospective), original_server_profile_metadata: identity('baseline.json', PINS.baselineMetadata),
    dataset: { records: 78, groups: 39, input_sha256: pins.input, input_bytes: pins.inputBytes, expected_ids: records.map(row => row.id), record_manifest: recordManifest(records) },
    schedule, conditions: { seeds: [42, 104771], total_attempts: 312, scope: 'implementation_comparison_not_pure_generation_isolation_not_normal_Pi_workflow' },
    direct: { logical_id: PINS.logicalId, logical_source_sha256: PINS.grid, source_sha256: PINS.source, binary_sha256: PINS.binary,
      physical_profile_sha256: pins.profile, physical_profile_file_sha256: PINS.profileFile, research_profile: PINS.profileId },
    generative: { model_id: PINS.modelId, context_size: 4096, parallel: 1, port: 8089, cache_ram_mib: 0, cache_prompt: false,
      max_tokens: 2048, temperature: 0, production_teacher_tries_max: 3, chat_template_kwargs: { enable_thinking: false },
      binary: path('server'), binary_bytes: 1, binary_sha256: PINS.server },
    held_out_TEST_authorized: false, production_role_approval: false, qualification_refs,
    qualified_fresh194_plan_sha256: refs.plan.sha256, source_release: identity('source-release.json', sha(benchmarkReleaseBytes), benchmarkReleaseBytes.length), source_files,
    native_source: identity('main.cpp', PINS.source), libraries: [], native_runtime_libraries: [], model_registry: identity('registry.json'),
    artifacts: { model: identity('raw.gguf', PINS.model, PINS.modelBytes), binary: identity('native-binary', PINS.binary, PINS.binaryBytes),
      template: identity('original.jinja', PINS.template, PINS.templateBytes) },
    host_runtime: { node_executable: identity('node'), renderer: runtime } };
  const provenance = { prototype_source_sha256: PINS.source, physical_profile, physical_profile_sha256: pins.profile, model_expected_sha256: PINS.model,
    template_raw_identity: { sha256: PINS.template, bytes: PINS.templateBytes, verified: true },
    template_parser_identity: { sha256: PINS.parserTemplate, bytes: PINS.parserTemplateBytes, verified: true },
    bos_token_id: 2, bos_piece: '<bos>', actual_mode: 'quantized_metal', vocab_only: false, weights_loaded: true,
    context_created: true, explicit_backend_init: true, device: 'metal', flash_attn_effective: null,
    flash_attn_effective_status: 'unobserved; AUTO is a request and may resolve enabled or disabled', gpu_layers_requested: 99,
    offload_kqv: true, op_offload: true, context_train_limit_checked: true,
    effective_limits: { max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048, context_capacity: 4096 } };
  const alphaRender = inventedRenderBundle(buildAlphaRenderRequests(records), runtime); const renderMap = new Map(JSON.parse(alphaRender.referenceBytes).rows.map(row => [row.record_id, row]));
  const byId = new Map(records.map(row => [row.id, row])), calls = { native: 0, generative: 0 }; const attempts = [], blocks = [], auditRows = [], owned = [];
  for (const [blockIndex, block] of schedule.entries()) {
    const pid = 1001 + blockIndex;
    if (!allUnrun && block.method === 'native') auditRows.push({ kind: 'native_RPC', block, pid, elapsed_ms: 0.1,
      request: { v: 1, id: 'init', op: 'init', research_profile: PINS.profileId, model_file: plan.artifacts.model.path,
        chat_template_file: plan.artifacts.template.path, vocab_only: false, device: 'metal', max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048 },
      response: { id: 'init', result: { ready: true, device: 'metal', architecture: 'gemma4', provenance } } });
    for (const [recordIndex, id] of block.record_ids.entries()) {
      const record = byId.get(id), q = record.request.questions[0], logical = compileHalfGrid(record.request), branch = logical.questions[0];
      const uncertain = q.type === 'noul' && (!Object.hasOwn(record.targets.q, 'answer') || record.targets.q.answer === null);
      const attempt = { block_index: blockIndex + 1, method: block.method, repetition: block.repetition, seed: block.seed,
        record_id: id, group_id: record.group_id, regression: record.regression === true, pair_key: `${block.repetition}:${id}`,
        method_call_index: ++calls[block.method], expected_questions: [{ id: 'q', type: q.type, uncertain }], expected_clear_decision: !uncertain,
        attempted: !allUnrun, status: allUnrun ? 'unrun' : 'completed', answers: [], transport: [], correct_judgment: false,
        completed_clear_decision: false, abstention: false, accounting_complete: !allUnrun, cache_clear_proved: !allUnrun,
        elapsed_ms: block.method === 'native' ? nativeMs : generatedMs };
      if (allUnrun) { attempt.error = 'Invented initialization failure; never dispatched'; attempts.push(attempt); auditRows.push({ kind: 'attempt', ...attempt }); continue; }
      let returned;
      if (block.method === 'native') {
        const prefix = 'r' + String(recordIndex).padStart(3, '0') + 'q0'; const render = renderMap.get(`${block.repetition}:${id}`);
        const compiled = { branch_id: branch.branch_id, tokens: [2, 11, 12], token_ids: Object.fromEntries(branch.output_labels.map((label, i) => [label, 100 + i])),
          rendered: render.rendered, rendered_generation_boundary: BOUNDARY + branch.answer_prefix, provenance };
        const desired = q.type === 'choice' ? 'yes' : q.type === 'score' ? (Number(id.split('-')[1]) - 26 < scoreMisses ? 2 : record.targets.q.answer)
          : record.targets.q.answer === null ? (unknownWrong ? 1 : 0.5) : record.targets.q.answer ? 0.99 : 0.01;
        const winner = q.type === 'choice' ? branch.answer_labels.indexOf(desired) : q.type === 'score' ? branch.research_score_values.indexOf(desired)
          : Math.round((desired - 0.01) / 0.98 * 8);
        const selected = Object.fromEntries(branch.output_labels.map((label, index) => [label, index === winner ? 20 : -20]));
        const metrics = { backend: 'llama.cpp', prefill_strategy: 'full', prefix_tokens: 0, branch_output_tokens: 0,
          padded_suffix_tokens: 0, scored_positions: 1, suffix_batch_sizes: [1], computed_prompt_tokens: 3,
          branch_prompt_tokens: 3, logical_prefill_tokens: 3, engine_forwards: 1, provenance };
        const evaluated = { input_tokens: 3, metrics, logits: { [branch.branch_id]: selected } };
        const native_RPC = [{ pid, elapsed_ms: 0.1, request: { v: 1, id: prefix + '-compile', op: 'compile', branches: [wireBranch(branch)] }, response: { id: prefix + '-compile', result: [compiled] } },
          { pid, elapsed_ms: 0.1, request: { v: 1, id: prefix + '-evaluate', op: 'evaluate', full: true, branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] }, response: { id: prefix + '-evaluate', result: evaluated } }];
        const responsePlan = { ...logical, request: { ...logical.request, options: { ...logical.request.options, raw_logits: true } } };
        returned = responseHalfGrid(responsePlan, evaluated.logits, 3, true, { metrics: { per_question_native: [metrics] }, metadata: {
          backend: 'llama.cpp', actual_mode: 'quantized_metal', research_profile: PINS.profileId, physical_profile_sha256: pins.profile,
          logical_id: PINS.logicalId, prototype_source_sha256: PINS.source, binary_sha256: PINS.binary, raw_model_sha256: PINS.model, raw_model_bytes: PINS.modelBytes,
          raw_template_sha256: PINS.template, parser_template_sha256: PINS.parserTemplate, independent_render_match: true, actual_question_count: 1,
          production_role_approval: false, probability_semantics: 'uncalibrated softmax over selected labels only', usage_accounting: 'actual full-prefill prompt tokens; zero generated output tokens' } });
        const envelope = { record_id: id, logical_id: PINS.logicalId, logical_prompt_sha256: logical.logical_prompt_sha256,
          research_profile: PINS.profileId, physical_profile_sha256: pins.profile, raw_model_sha256: PINS.model, raw_model_bytes: PINS.modelBytes,
          prototype_source_sha256: PINS.source, binary_sha256: PINS.binary, model: record.request.model, elapsed_ms: 0.5, actual_mode: 'quantized_metal', response: returned,
          questions: [{ question_id: 'q', branch_id: branch.branch_id, actual_prompt_tokens: 3, rendered_sha256: sha(compiled.rendered),
            selected_label_token_ids: compiled.token_ids, labels: branch.output_labels, answer_labels: branch.answer_labels, generation_tokens: 0,
            raw_selected_label_logits: selected, native_metrics: metrics, compiled_token_sha256: sha(JSON.stringify(compiled.tokens)) }] };
        attempt.native_RPC = native_RPC; attempt.native_envelope = envelope;
        attempt.actual_work = nativeFold(metrics); attempt.native_response = { ...returned, metrics: { ...returned.metrics, ...attempt.actual_work } };
        auditRows.push(...native_RPC.map(row => ({ kind: 'native_RPC', block, ...row })), { kind: 'native_alpha_envelope', block, ...envelope });
      } else {
        const expected = expectedOriginalTeacherRequest(record); const actual = { ...expected, chat_template_kwargs: { enable_thinking: false }, id_slot: 0, cache_prompt: false };
        const idTeacher = `${block.repetition}:${id}:teacher:0`; const fresh = renderRows([{ record_id: idTeacher, branch: { branch_id: idTeacher, messages: actual.messages, answer_prefix: '' } }])[0];
        returned = { q: clone(record.targets.q) };
        const reply = { model: PINS.modelId, choices: [{ message: { content: JSON.stringify(returned) } }],
          usage: { prompt_tokens: 3, completion_tokens: 2, total_tokens: 5 }, timings: { prompt_n: 3, predicted_n: 2, cache_n: 0 } };
        const response_text = JSON.stringify(reply); const tokens = [{ id: 2, piece: '<bos>' }, { id: 11, piece: 'invented' }, { id: 12, piece: 'CPU' }];
        const post = { ordinal: 0, dispatched: true, elapsed_ms: 1, original_teacher_request: expected, actual_request: actual,
          cache_reset: { n_erased: 0 }, cache_reset_elapsed_ms: 0.1, POST_elapsed_ms: 0.2, apply_template_response: { prompt: fresh.rendered.slice(5) },
          server_automatic_BOS_tokenization: { tokens }, original_explicit_BOS_tokenization: { tokens }, actual_tokenized_prompt_count: 3,
          independent_Jinja_row: { ...fresh, record_id: 'old-source-render-id', branch_id: 'old-source-render-id' },
          ok: true, status: 200, response_text, response_sha256: sha(response_text), provider_usage: reply.usage, server_timings: reply.timings };
        attempt.teacher_tries = [post]; attempt.transport = [post]; attempt.actual_generated_targets = returned;
        attempt.actual_work = serverFold(post); attempt.label_summary = { file: path('proof/trial-' + String(calls.generative).padStart(6, '0') + '/labeled.jsonl'),
          cache_hits: 0, examples: 1, teacher_estimates: 1, teacher_model: PINS.modelId };
        auditRows.push({ kind: 'teacher_try', record_id: id, ...post });
      }
      const grade = rowGrade(record, returned, block.method); attempt.raw_grade = grade; Object.assign(attempt, {
        answers: grade.answers, correct_judgment: grade.correct_judgment, completed_clear_decision: grade.completed_clear_decision, abstention: grade.abstention });
      attempts.push(attempt); auditRows.push({ kind: 'attempt', ...attempt });
    }
    let cleanup = null;
    if (!allUnrun) {
      const isNative = block.method === 'native'; const logs = isNative ? terminal(pid).stderr : "MTL0 offloaded 61/61 layers to GPU\nn_ctx = 4096\nn_batch = 2048\nn_ubatch = 512\nkv_unified = false\nllama_kv_cache: size = 320 MiB (4096 cells, 16 layers, 1/1 seqs), K (f16):160MiB, V (f16):160MiB\nllama_kv_cache: size = 1200 MiB (4096 cells, 45 layers, 1/1 seqs), K (f16):600MiB, V (f16):600MiB";
      cleanup = { pid, owned_cleanup_complete: true, exit_and_stdio_close_observed: true, root_pid_gone: gone(pid), error: null,
        ...(isNative ? { close_result: terminal(pid), snapshot: terminal(pid) }
          : { exited: true, stdio_closed: true, intentional_owned_shutdown: true, exit_code: 0, exit_signal: null, logs,
            native_observations: { truncated: false }, listener_observations: [{ actor: 'ROOT', pid, port: 8089, only_owned_listener: true,
              observed_at: '2026-09-20T14:00:00.000Z', method: 'invented CPU listener',
              observed_listeners: [{ pid, comm: 'llama-server', address: '127.0.0.1:8089' }] }] }) };
      owned.push({ pid, block_index: blockIndex + 1, exit_observed: true, stdio_close_observed: true, pid_gone: gone(pid), logs_sha256: sha(logs) });
    }
    const blockRow = { ...block, block_index: blockIndex + 1, initialization_ms: 1, adapter_created: !allUnrun,
      run_invocations: allUnrun ? 0 : 78, cleanup, initialization_error: allUnrun ? 'invented initialization failure' : null };
    if (cleanup) {
      const { root_pid_gone, ...terminalReceipt } = cleanup;
      auditRows.push({ kind: block.method === 'native' ? 'owned_native_process' : 'owned_server_process',
        ...(block.method === 'native' ? { block } : {}), ...terminalReceipt });
    }
    blocks.push(blockRow); auditRows.push({ kind: 'block', ...blockRow });
  }
  const result = { kind: 'gemma4_successor_direct_performance_result', plan_sha256: sha(jsonBytes(plan)), source_release_sha256: plan.source_release.sha256,
    qualification_refs, direct_logical_id: PINS.logicalId, direct_physical_identity: plan.direct, generated_profile: plan.generative,
    held_out_TEST_read: false, production_role_approval: false, improvement_claim_permitted: false,
    status: allUnrun ? 'incomplete' : 'completed', attempts, blocks, summary: pairedSummary(attempts),
    replicate_summaries: [1, 2].map(rep => pairedSummary(attempts.filter(row => row.repetition === rep))) };
  const teacherRender = inventedRenderBundle(buildTeacherRenderRequests(attempts), runtime);
  const rootFacts = { kind: 'ROOT_successor_closed312_independent_facts', actor: 'ROOT', proof_kind: 'invented_CPU_NO_native_execution',
    owned_process_observations: owned, all_started_owned_processes_closed_and_gone: true, python_executable_bytes: 1,
    current_full_artifact_hashes_verified: true, current_runtime_and_attester_source_hashes_verified: true,
    fresh194_all_five_artifacts_verified: true, fresh194_native_contract_and_quality_receipt_independently_verified: true,
    single_active_native_gpu_execution_verified: true, monotonic_clock_unmodified_verified: true, host_only_gold_and_no_TEST_verified: true,
    no_other_native_model_calls_verified: true, held_out_TEST_read: false, production_role_approval: false,
    fresh194_refs: qualification_refs, attester_source_identities: [identity('render-reference.py')] };
  const fixture = { plan, result, auditRows, inputBytes, alphaRender, teacherRender, rootFacts, fresh194Bytes, benchmarkReleaseBytes,
    options: { inputSha256: pins.input, inputBytes: pins.inputBytes, emittedProfileSha256: pins.profile, qualificationRefs: refs,
      benchmarkReleaseSha256: sha(benchmarkReleaseBytes), benchmarkReleaseBytes: benchmarkReleaseBytes.length } };
  refreshFixture(fixture); return fixture;
}
export function refreshFixture(fixture) {
  const { plan, result, rootFacts, fresh194Bytes } = fixture;
  result.plan_sha256 = sha(jsonBytes(plan)); const alpha = renderIdentity(fixture.alphaRender), teacher = renderIdentity(fixture.teacherRender);
  rootFacts.artifact_hashes = { plan_sha256: result.plan_sha256, result_sha256: sha(jsonBytes(result)), audit_sha256: sha(auditBytes(fixture)),
    input_sha256: sha(fixture.inputBytes), alpha_render: alpha, teacher_render: teacher, benchmark_source_release_sha256: sha(fixture.benchmarkReleaseBytes),
    fresh194: Object.fromEntries(Object.entries(fixture.options.qualificationRefs).map(([key, ref]) => [key, ref.sha256])) };
  const expected = [...plan.source_files, plan.native_source, ...Object.values(plan.artifacts), ...plan.libraries, ...plan.native_runtime_libraries,
    { path: plan.generative.binary, bytes: plan.generative.binary_bytes, sha256: plan.generative.binary_sha256 }, plan.model_registry,
    plan.host_runtime.node_executable, { path: plan.host_runtime.renderer.python_executable, bytes: 1, sha256: plan.host_runtime.renderer.python_executable_sha256 }];
  rootFacts.current_verified_identities = [...new Map(expected.map(row => [row.path, row])).values()].sort((a, b) => a.path.localeCompare(b.path));
  rootFacts.render_executions = [alpha, teacher].map(artifact_binding => ({ actor: 'ROOT', artifact_binding, executed_after_stage_closed: true,
    exit_code: 0, native_or_model_execution: false, runtime_identity: plan.host_runtime.renderer,
    hook_source_sha256: rootFacts.attester_source_identities[0].sha256 }));
  fixture.input = { stageClosed: true, planBytes: jsonBytes(plan), resultBytes: jsonBytes(result), auditBytes: auditBytes(fixture),
    inputBytes: fixture.inputBytes, rootFacts, fresh194Bytes, alphaRender: fixture.alphaRender, teacherRender: fixture.teacherRender,
    benchmarkReleaseBytes: fixture.benchmarkReleaseBytes };
  return fixture;
}
function renderIdentity(bundle) { return { requests_sha256: sha(bundle.requestsBytes), requests_bytes: bundle.requestsBytes.length,
  reference_sha256: sha(bundle.referenceBytes), reference_bytes: bundle.referenceBytes.length }; }
function auditBytes(fixture) { return Buffer.from(fixture.auditRows.map(row => JSON.stringify(row)).join('\n') + '\n'); }
export function syncAttempt(fixture, index) {
  let cursor = -1; for (let row = 0; row < fixture.auditRows.length; row++) if (fixture.auditRows[row].kind === 'attempt' && ++cursor === index) {
    fixture.auditRows[row] = { kind: 'attempt', ...fixture.result.attempts[index] }; break; }
}
