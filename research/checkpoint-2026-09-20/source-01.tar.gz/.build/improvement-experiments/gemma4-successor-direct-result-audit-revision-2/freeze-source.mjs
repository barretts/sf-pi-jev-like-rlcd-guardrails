import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { PINS, sha, jsonBytes, strictJson } from './contracts.mjs';

// SOURCE/CPU release only. External identities are inherited from the original
// frozen metadata; ROOT must independently hash all current bytes before use.
// No external artifacts, dataset, qualification output or original CPU output
// are read here. The one reviewed ROOT driver is read strictly as SOURCE.
const here = new URL('./', import.meta.url);
const root = new URL('../../../', here);
const parentDirectory = new URL('../gemma4-successor-direct-result-audit/', here);
const parentRelease = new URL('source-freeze.json', parentDirectory);
const parentSha = '96f73187cd3e980ad5885301543dd168bbcf37aac6f447fa68037004a3f54695';
const own = ['attest.mjs', 'contracts.mjs', 'fixtures.cpu.mjs', 'attest.cpu.test.mjs', 'render-reference.py',
  'source-contract-check.mjs', 'README.md', 'freeze-source.mjs'];
const driver = new URL('.build/improvement-experiments/gemma4-runtime-candidate-1/root-successor-direct-312-revision-2.mjs', root);
const command = 'node --test --test-reporter=tap .build/improvement-experiments/gemma4-successor-direct-result-audit-revision-2/attest.cpu.test.mjs';
async function identity(url) { const bytes = await readFile(url); return { path: fileURLToPath(url), bytes: bytes.length, sha256: sha(bytes) }; }

export async function freezeSourcePreparation({ observedCpuExitCode, observedCpuSessionClosed, expectedTests }) {
  assert.equal(observedCpuExitCode, 0); assert.equal(observedCpuSessionClosed, true); assert.equal(expectedTests, 23);
  const output = await readFile(new URL('cpu-tap.txt', here)); const text = output.toString('utf8');
  for (const [name, value] of Object.entries({ tests: expectedTests, pass: expectedTests, fail: 0, cancelled: 0, skipped: 0, todo: 0 }))
    assert.match(text, new RegExp('^# ' + name + ' ' + value + '$', 'm'), 'Focused invented CPU observed ' + name);
  const duration = Number(text.match(/^# duration_ms ([0-9.]+)$/m)?.[1]); assert.ok(Number.isFinite(duration) && duration > 0);
  const proof = { kind: 'successor312_invented_injected_CPU_proof_ONLY', observed_at: new Date().toISOString(),
    command, tests: expectedTests, passed: expectedTests, failed: 0, observed_exit_code: observedCpuExitCode,
    observed_session_closed: true, duration_ms: duration, raw_CPU_output: await identity(new URL('cpu-tap.txt', here)),
    tests_are_entirely_invented: true, no_actual_model_response_or_qualification_output_read: true,
    model_tokenizer_native_GPU_training_network_auth_executed: false, no_actual_quality_or_gain_proven: true, approval_effect: 'none' };
  strictJson(proof); await writeFile(new URL('cpu-proof.json', here), jsonBytes(proof), { flag: 'wx', mode: 0o600 });
  const parentBytes = await readFile(parentRelease); assert.equal(sha(parentBytes), parentSha);
  const parent = JSON.parse(parentBytes); assert.equal(parent.release_revision, 1); assert.equal(parent.source_identities.length, 32);
  const inherited = parent.source_identities.filter(ref => !ref.path.startsWith(fileURLToPath(parentDirectory)));
  assert.equal(inherited.length, 24, 'All unchanged external source/metadata pins retained');
  const ownIdentities = await Promise.all(own.map(name => identity(new URL(name, here))));
  const driverIdentity = await identity(driver);
  const sources = [...inherited, ...ownIdentities, driverIdentity].sort((a, b) => a.path.localeCompare(b.path));
  assert.equal(sources.length, 33); assert.equal(new Set(sources.map(row => row.path)).size, sources.length);
  const release = { kind: 'successor312_independent_result_attester_source_release', release_revision: 2,
    released_at: new Date().toISOString(), research_schema: 'independent-successor-312-result-attestation-2', source_and_CPU_only: true,
    parent_source_release: { path: fileURLToPath(parentRelease), bytes: parentBytes.length, sha256: parentSha },
    source_identities: sources, own_source_identities: ownIdentities.sort((a, b) => a.path.localeCompare(b.path)),
    inherited_external_source_identities_reverified_by_source_agent: false,
    ROOT_full_current_source_artifact_runtime_verification_still_required: true,
    cpu_proof: await identity(new URL('cpu-proof.json', here)), source_manifest_metadata: parent.source_manifest_metadata,
    benchmark_source_release_sha256: PINS.benchmarkRelease, benchmark_runner_sha256: PINS.benchmarkRunner,
    benchmark_final_source_revision: 2, existing_successor_grade_sha256_unchanged: '0821757efa2dd445e645a2f6d22751d455895d30543aadcc32901a2c6fda794b',
    bounded_change: { empty_false_listener_polls_allowed_only_in_startup_prefix: true,
      retained_positive_listener_arrays_required_and_PID_address_bound: true, at_least_one_owned_poll_required: true,
      ownership_loss_foreign_contradictory_unknown_error_and_invalid_time_rejected: true,
      dispatch_gating_source: [driverIdentity, inherited.find(row => row.path.endsWith('/gemma4-successor-direct-proposal/runner.mjs'))],
      absolute_POST_dispatch_timestamps_in_existing_receipts: false,
      dispatch_order_basis: 'reviewed frozen runner awaits true ownsListener before local fetch and teacher dispatched flag; no timestamps imputed',
      quality_timing_coverage_exit1_recovery_semantics_unchanged: true },
    raw_weight_or_native_artifact_full_SHA_verification_by_source_agent: false,
    actual_model_quality_performance_or_gain_proven: false, actual_run_outputs_read: false,
    original_frozen_sources_edited: false, held_out_TEST_read: false, native_execution_authorized: false,
    production_role_approval: false, approval_effect: 'none', source_ownership_released_to_ROOT: true };
  strictJson(release); await writeFile(new URL('source-freeze.json', here), jsonBytes(release), { flag: 'wx', mode: 0o600 });
  return { release: await identity(new URL('source-freeze.json', here)), cpu_proof: release.cpu_proof,
    attester: ownIdentities.find(row => row.path.endsWith('/attest.mjs')), sources: sources.length };
}
