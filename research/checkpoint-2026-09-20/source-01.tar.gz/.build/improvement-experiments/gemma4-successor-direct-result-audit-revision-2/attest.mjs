import assert from 'node:assert/strict';
import { validateQualityRecords, scorePrediction, summarizeQuality, qualityDatasetDigest } from '../../../dist/evaluation.js';
import { scoreAnswer, pairedSummary } from '../../../scripts/developer-decision-eval.mjs';
import { compileHalfGrid, responseHalfGrid } from '../fractional-score-hypothesis/candidate-2/grid.mjs';
import { PINS, QUALIFICATION_REFS, BOUNDARY, sha, jsonBytes, same, counter, duration, canonical,
  strictJson, parseJson, wireBranch, buildSchedule, recordManifest, expectedOriginalTeacherRequest, strictTeacherTargets } from './contracts.mjs';

// PURE CLOSED-STAGE API. No filesystem defaults, CLI, model/tokenizer/native
// construction, network, process observation, inference launch, or artifact writes.
const fields = (object, names) => Object.fromEntries(names.map(name => [name, object[name]]));
const strip = (object, ...keys) => Object.fromEntries(Object.entries(object).filter(([key]) => !keys.includes(key)));
const typedMetadata = pins => ({ backend: 'llama.cpp', actual_mode: 'quantized_metal', research_profile: pins.profileId,
  physical_profile_sha256: pins.profile, logical_id: pins.logicalId, prototype_source_sha256: pins.source,
  binary_sha256: pins.binary, raw_model_sha256: pins.model, raw_model_bytes: pins.modelBytes,
  raw_template_sha256: pins.template, parser_template_sha256: pins.parserTemplate,
  independent_render_match: true, actual_question_count: 1, production_role_approval: false,
  probability_semantics: 'uncalibrated softmax over selected labels only',
  usage_accounting: 'actual full-prefill prompt tokens; zero generated output tokens' });
export function reconstructedAlphaResponse(record, evaluated, pins = PINS) {
  const logical = compileHalfGrid(record.request);
  const responsePlan = { ...logical, request: { ...logical.request, options: { ...logical.request.options, raw_logits: true } } };
  return responseHalfGrid(responsePlan, evaluated.logits, evaluated.input_tokens, true,
    { metrics: { per_question_native: [evaluated.metrics] }, metadata: typedMetadata(pins) });
}
function foldNative(metrics) {
  return { computed_prompt_tokens: metrics.computed_prompt_tokens, computed_output_tokens: metrics.branch_output_tokens,
    engine_forwards: metrics.engine_forwards,
    output_counter_source: 'unchanged native metrics.branch_output_tokens; engine has no generation/sampler path',
    forwards_source: 'unchanged native metrics.engine_forwards: submitted llama_decode calls, not Metal kernels or ubatches' };
}
function partialNative(receipts) {
  const evaluations = receipts.filter(row => row.request?.op === 'evaluate');
  const known = key => evaluations.map(row => row.response?.result?.metrics?.[key]).filter(value => Number.isSafeInteger(value) && value >= 0);
  const prompt = known('computed_prompt_tokens'), output = known('branch_output_tokens'), forwards = known('engine_forwards');
  const sum = rows => rows.reduce((a, b) => a + b, 0);
  return { submitted_evaluate_requests: evaluations.length, measured_prefill_evaluations: prompt.length,
    measured_output_evaluations: output.length, measured_forward_evaluations: forwards.length,
    known_computed_prompt_tokens: sum(prompt), known_generated_tokens: sum(output), known_submitted_llama_decode_calls: sum(forwards),
    computed_prompt_tokens: evaluations.length && prompt.length === evaluations.length ? sum(prompt) : null,
    computed_output_tokens: evaluations.length && output.length === evaluations.length ? sum(output) : null,
    engine_forwards: evaluations.length && forwards.length === evaluations.length ? sum(forwards) : null,
    complete_native_contracts_proved: false,
    source: 'retained actual evaluate RPC replies; missing or partial execution work remains unknown' };
}
function partialServer(posts) {
  const known = key => posts.map(post => post.server_timings?.[key]).filter(value => Number.isSafeInteger(value) && value >= 0);
  const prompt = known('prompt_n'), output = known('predicted_n'); const sum = rows => rows.reduce((a, b) => a + b, 0);
  return { dispatched_posts: posts.length, measured_prefill_posts: prompt.length, measured_generation_posts: output.length,
    known_computed_prompt_tokens: sum(prompt), known_generated_tokens: sum(output),
    computed_prompt_tokens: posts.length && prompt.length === posts.length ? sum(prompt) : null,
    computed_output_tokens: posts.length && output.length === posts.length ? sum(output) : null,
    engine_forwards: null, engine_forwards_source: 'server API does not expose submitted llama_decode calls' };
}
function measuredServer(posts) {
  assert.ok(posts.length > 0 && posts.length <= 3);
  for (const post of posts) {
    counter(post.server_timings?.prompt_n, 'server prompt_n', 1); counter(post.server_timings?.predicted_n, 'server predicted_n');
    assert.equal(post.server_timings.cache_n, 0); assert.equal(post.server_timings.prompt_n, post.actual_tokenized_prompt_count);
    assert.equal(post.provider_usage?.prompt_tokens, post.server_timings.prompt_n);
    assert.equal(counter(post.provider_usage?.completion_tokens, 'provider completion'), post.server_timings.predicted_n);
  } return partialServer(posts);
}
function provenance(provenance, qualificationPlan, pins) {
  assert.equal(provenance?.prototype_source_sha256, pins.source);
  assert.equal(provenance.physical_profile?.id, pins.profileId);
  assert.equal(provenance.physical_profile_sha256, pins.profile);
  assert.equal(sha(JSON.stringify(provenance.physical_profile)), pins.profile);
  assert.equal(JSON.stringify(provenance.physical_profile), JSON.stringify(qualificationPlan.physical_profile), 'Exact emitted ordered profile');
  assert.equal(provenance.model_expected_sha256, pins.model); assert.equal(provenance.physical_profile.model_expected_size, pins.modelBytes);
  same(fields(provenance.template_raw_identity, ['sha256', 'bytes', 'verified']), { sha256: pins.template, bytes: pins.templateBytes, verified: true });
  same(fields(provenance.template_parser_identity, ['sha256', 'bytes', 'verified']), { sha256: pins.parserTemplate, bytes: pins.parserTemplateBytes, verified: true });
  assert.equal(provenance.bos_token_id, 2); assert.equal(provenance.bos_piece, '<bos>');
  for (const [key, value] of Object.entries({ actual_mode: 'quantized_metal', vocab_only: false, weights_loaded: true,
    context_created: true, explicit_backend_init: true, device: 'metal', flash_attn_effective: null,
    flash_attn_effective_status: 'unobserved; AUTO is a request and may resolve enabled or disabled',
    gpu_layers_requested: 99, offload_kqv: true, op_offload: true, context_train_limit_checked: true })) assert.equal(provenance[key], value, 'Native provenance ' + key);
  same(fields(provenance.effective_limits, ['max_model_len', 'max_batch_size', 'max_batch_tokens', 'context_capacity']),
    { max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048, context_capacity: 4096 });
}
function compiledContract(compiled, branch, render, qualificationPlan, pins) {
  assert.equal(compiled?.branch_id, branch.branch_id); assert.ok(Array.isArray(compiled.tokens) && compiled.tokens.length > 0 && compiled.tokens.length <= 2048);
  compiled.tokens.forEach(token => counter(token, 'compiled token')); assert.equal(compiled.tokens[0], 2);
  assert.equal(compiled.tokens.filter(token => token === 2).length, 1, 'Exactly one BOS');
  same(Object.keys(compiled.token_ids).sort(), [...branch.output_labels].sort(), 'Exact selected-label token map');
  Object.values(compiled.token_ids).forEach(token => counter(token, 'selected label token'));
  assert.equal(new Set(Object.values(compiled.token_ids)).size, branch.output_labels.length);
  assert.equal(compiled.rendered, render.rendered, 'Fresh independently executed original Jinja');
  assert.equal(sha(compiled.rendered), render.rendered_sha256);
  assert.equal(compiled.rendered_generation_boundary, BOUNDARY + branch.answer_prefix);
  assert.ok(compiled.rendered.endsWith(compiled.rendered_generation_boundary)); provenance(compiled.provenance, qualificationPlan, pins);
}
function evaluationContract(evaluated, compiled, branch, qualificationPlan, pins) {
  const metrics = evaluated?.metrics;
  for (const [key, value] of Object.entries({ backend: 'llama.cpp', prefill_strategy: 'full', prefix_tokens: 0,
    branch_output_tokens: 0, padded_suffix_tokens: 0, scored_positions: 1 })) assert.equal(metrics?.[key], value, 'Native actual contract ' + key);
  same(metrics.suffix_batch_sizes, [1]);
  for (const key of ['computed_prompt_tokens', 'branch_prompt_tokens', 'logical_prefill_tokens']) assert.equal(metrics[key], compiled.tokens.length);
  assert.equal(metrics.engine_forwards, Math.ceil(compiled.tokens.length / 2048), 'Actual submitted llama_decode calls /2048');
  assert.equal(evaluated.input_tokens, compiled.tokens.length); provenance(metrics.provenance, qualificationPlan, pins);
  same(Object.keys(evaluated.logits), [branch.branch_id], 'Exact selected-logit branch');
  // Actual responseHalfGrid/buildResponse enforces finite exact selected-logit keys.
}
export function buildAlphaRenderRequests(records) {
  const byId = new Map(records.map(record => [record.id, record]));
  return buildSchedule(records.map(record => record.id)).filter(block => block.method === 'native').flatMap(block => block.record_ids.map(id => ({
    record_id: `${block.repetition}:${id}`, branch: wireBranch(compileHalfGrid(byId.get(id).request).questions[0]) })));
}
export function buildTeacherRenderRequests(attempts) {
  return attempts.filter(attempt => attempt.method === 'generative').flatMap(attempt => (attempt.teacher_tries ?? []).filter(row => row.dispatched === true)
    .map(row => { const id = `${attempt.repetition}:${attempt.record_id}:teacher:${row.ordinal}`;
      return { record_id: id, branch: { branch_id: id, messages: row.actual_request.messages, answer_prefix: '' } }; }));
}
function renderBundle(bundle, expectedRequests, runtime, pins, name) {
  assert.ok(bundle, 'Missing fresh independent ' + name + ' render bundle');
  const requestBytes = Buffer.from(bundle.requestsBytes), referenceBytes = Buffer.from(bundle.referenceBytes);
  const requests = parseJson(requestBytes), reference = parseJson(referenceBytes); same(requests, expectedRequests, 'Fresh render exact requests/order');
  assert.equal(reference.kind, 'gemma4_successor_independent_closed_stage_jinja_render');
  assert.equal(reference.requests_sha256, sha(requestBytes)); assert.equal(reference.original_raw_template_sha256, pins.template);
  assert.equal(reference.original_raw_template_bytes, pins.templateBytes); assert.equal(reference.native_or_model_execution, false);
  same(reference.runtime_identity, runtime, 'Frozen Python/Jinja runtime'); assert.equal(reference.python_jinja_version, '3.1.6');
  same(reference.render_options, { trim_blocks: true, lstrip_blocks: true, bos_token: '<bos>', eos_token: '',
    add_generation_prompt: true, enable_thinking: false, tools_argument_supplied: false });
  assert.equal(reference.rows.length, requests.length); const map = new Map();
  for (const [index, request] of requests.entries()) {
    const row = reference.rows[index], branch = request.branch, messages = branch.messages;
    assert.equal(row.record_id, request.record_id); assert.equal(row.branch_id, branch.branch_id);
    const key = row.record_id + ':' + row.branch_id; assert.ok(!map.has(key)); map.set(key, row);
    assert.equal(row.logical_messages_sha256, sha(JSON.stringify(messages))); assert.equal(row.answer_prefix, branch.answer_prefix);
    const merged = messages.length > 1 && messages.at(-1).role === 'user' && messages.at(-2).role === 'user';
    assert.equal(row.final_two_user_messages_merged, merged); assert.equal(row.messages_before, messages.length); assert.equal(row.messages_after, messages.length - Number(merged));
    assert.equal(typeof row.rendered, 'string'); assert.equal(row.rendered_sha256, sha(row.rendered));
    assert.ok(row.rendered.startsWith('<bos>')); assert.equal(row.rendered.split('<bos>').length, 2);
    assert.ok(row.rendered.endsWith(BOUNDARY + branch.answer_prefix));
  }
  return { map, identity: { requests_sha256: sha(requestBytes), requests_bytes: requestBytes.length,
    reference_sha256: sha(referenceBytes), reference_bytes: referenceBytes.length }, reference };
}
function auditGroups(auditRows, attempts, auditFailed) {
  const groups = []; let cursor = 0, pending = [];
  for (const row of auditRows) {
    if (row.kind === 'attempt') {
      assert.ok(attempts[cursor], 'Extra audited attempt'); same(strip(row, 'kind'), attempts[cursor], 'Raw result/audit attempt equality');
      groups.push(pending); pending = []; cursor++;
    } else if (row.kind === 'native_RPC' && row.request?.op !== 'init' || row.kind === 'native_alpha_envelope' || row.kind === 'teacher_try') pending.push(row);
  }
  if (!auditFailed) { assert.equal(cursor, attempts.length, 'All312 raw audit attempts'); assert.equal(pending.length, 0, 'Unassigned inference receipts'); }
  else {
    assert.ok(cursor <= attempts.length); if (cursor < attempts.length) { groups.push(pending); cursor++; pending = []; }
    while (cursor++ < attempts.length) groups.push([]);
  }
  return { groups, complete: !auditFailed && groups.length === 312 };
}
function rawBlock(row, attempt, schedule) {
  same(row.block, schedule[attempt.block_index - 1], 'Raw native receipt frozen block');
  counter(row.pid, 'owned native PID', 1);
}
function nativeOutcome(record, attempt, rows, plan, qualificationPlan, renderMap, pins, ownedPid) {
  const logical = compileHalfGrid(record.request), branch = logical.questions[0];
  const receipts = rows.filter(row => row.kind === 'native_RPC'); const alphaRows = rows.filter(row => row.kind === 'native_alpha_envelope');
  same(attempt.native_RPC ?? [], receipts.map(row => strip(row, 'kind', 'block')), 'Native attempt/RPC audit equality');
  assert.ok(receipts.length <= 2 && alphaRows.length <= 1, 'One compile/evaluate/envelope per native attempt');
  const compile = receipts.find(row => row.request?.op === 'compile'), evaluate = receipts.find(row => row.request?.op === 'evaluate');
  assert.ok(!evaluate || compile, 'No evaluate without compile');
  if (receipts.length) same(receipts.map(row => row.request.op), evaluate ? ['compile', 'evaluate'] : ['compile']);
  const prefix = 'r' + String((attempt.method_call_index - 1) % 78).padStart(3, '0') + 'q0';
  for (const row of receipts) { rawBlock(row, attempt, plan.schedule); assert.equal(row.pid, ownedPid, 'Every raw RPC belongs to that block owned init/cleanup PID'); duration(row.elapsed_ms, 'native RPC'); }
  for (const row of alphaRows) {
    duration(row.elapsed_ms, 'complete native classifier envelope');
    if (attempt.elapsed_ms !== null) assert.ok(row.elapsed_ms <= attempt.elapsed_ms + 0.01, 'Full attempt contains complete native classifier envelope time');
  }
  if (compile) same(compile.request, { v: 1, id: prefix + '-compile', op: 'compile', branches: [wireBranch(branch)] }, 'Actual original-Alpha compile request');
  let returned = null, complete = false; const diagnostics = [];
  if (compile && !compile.error && !compile.response?.error && compile.response?.result) {
    assert.equal(compile.response.id, compile.request.id); assert.equal(compile.response.result.length, 1);
    const compiled = compile.response.result[0];
    // Invalid response attribution is an integrity failure, not a model failure.
    compiledContract(compiled, branch, renderMap.get(`${attempt.repetition}:${record.id}:${branch.branch_id}`), qualificationPlan, pins);
    if (evaluate) {
      same(evaluate.request, { v: 1, id: prefix + '-evaluate', op: 'evaluate', full: true,
        branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] }, 'Actual full single-question evaluate');
      if (!evaluate.error && !evaluate.response?.error && evaluate.response?.result) {
        assert.equal(evaluate.response.id, evaluate.request.id);
        evaluationContract(evaluate.response.result, compiled, branch, qualificationPlan, pins);
        returned = reconstructedAlphaResponse(record, evaluate.response.result, pins); complete = true;
        if (alphaRows.length) {
          const envelope = strip(alphaRows[0], 'kind', 'block'); same(alphaRows[0].block, plan.schedule[attempt.block_index - 1]);
          assert.equal(envelope.record_id, record.id); assert.equal(envelope.logical_id, pins.logicalId);
          assert.equal(envelope.logical_prompt_sha256, logical.logical_prompt_sha256); assert.equal(envelope.model, record.request.model);
          for (const [key, value] of Object.entries({ research_profile: pins.profileId, physical_profile_sha256: pins.profile,
            prototype_source_sha256: pins.source, binary_sha256: pins.binary, raw_model_sha256: pins.model, raw_model_bytes: pins.modelBytes, actual_mode: 'quantized_metal' })) assert.equal(envelope[key], value);
          if (envelope.response) same(envelope.response, returned, 'Actual Alpha envelope reconstructed from raw selected logits');
          assert.equal(envelope.questions.length, 1); const q = envelope.questions[0];
          same(q.raw_selected_label_logits, evaluate.response.result.logits[branch.branch_id]); same(q.native_metrics, evaluate.response.result.metrics);
          assert.equal(q.compiled_token_sha256, sha(JSON.stringify(compiled.tokens))); assert.equal(q.rendered_sha256, sha(compiled.rendered));
          assert.equal(q.actual_prompt_tokens, compiled.tokens.length); assert.equal(q.generation_tokens, 0);
          assert.equal(q.question_id, branch.question_id); assert.equal(q.branch_id, branch.branch_id);
          same(q.labels, branch.output_labels); same(q.answer_labels, branch.answer_labels); same(q.selected_label_token_ids, compiled.token_ids);
          if (attempt.native_envelope) same(attempt.native_envelope, envelope, 'Raw retained native envelope equality');
        } else { complete = false; diagnostics.push('missing independently audited Alpha envelope'); }
        if (attempt.native_response) {
          const folded = { ...returned, metrics: { ...returned.metrics, ...foldNative(evaluate.response.result.metrics) } };
          same(attempt.native_response, folded, 'Stored native_response is raw reconstructed response with exact observed metric fold');
        }
      } else diagnostics.push('evaluate failed or execution counters unknown');
    } else diagnostics.push('evaluate not dispatched');
  } else diagnostics.push('compile absent/failed');
  if (!complete || !returned) assert.ok(attempt.error, 'Incomplete native raw evidence must retain failure');
  if (attempt.status === 'completed') assert.ok(complete && returned && attempt.native_response && alphaRows.length === 1 && !alphaRows[0].error);
  const work = complete ? foldNative(returned.metrics.per_question_native[0]) : partialNative(receipts);
  if (attempt.actual_work) same(attempt.actual_work, work, 'Native work independently folded from unchanged raw receipts');
  return { returned, complete, cache_complete: complete, work, diagnostics,
    ...partialNative(receipts), unknown_prefill_evaluations: receipts.filter(row => row.request.op === 'evaluate').length - partialNative(receipts).measured_prefill_evaluations,
    unknown_forward_evaluations: receipts.filter(row => row.request.op === 'evaluate').length - partialNative(receipts).measured_forward_evaluations };
}
function teacherPrompt(post, freshRow) {
  const template = post.apply_template_response;
  assert.equal(typeof template?.prompt, 'string'); assert.ok(!template.prompt.includes('<bos>')); assert.ok(template.prompt.endsWith(BOUNDARY));
  const automatic = post.server_automatic_BOS_tokenization?.tokens, explicit = post.original_explicit_BOS_tokenization?.tokens;
  assert.ok(Array.isArray(automatic) && automatic.length > 0 && automatic.length <= 4096); same(automatic, explicit, 'Automatic versus original explicit BOS tokenization');
  automatic.forEach(token => { counter(token.id, 'server token'); assert.equal(typeof token.piece, 'string'); });
  assert.equal(automatic[0].id, 2); assert.equal(automatic[0].piece, '<bos>'); assert.equal(automatic.filter(token => token.id === 2).length, 1);
  assert.equal(post.actual_tokenized_prompt_count, automatic.length);
  assert.equal(freshRow.rendered, '<bos>' + template.prompt, 'Fresh teacher original Jinja versus actual apply-template');
  const oldRow = post.independent_Jinja_row; assert.ok(oldRow); assert.equal(oldRow.rendered, freshRow.rendered);
  assert.equal(oldRow.rendered_sha256, sha(oldRow.rendered)); assert.equal(oldRow.logical_messages_sha256, freshRow.logical_messages_sha256);
}
function generatedOutcome(record, attempt, rows, plan, renderMap, pins) {
  const tries = rows.filter(row => row.kind === 'teacher_try').map(row => strip(row, 'kind', 'record_id'));
  same(attempt.teacher_tries ?? [], tries, 'All teacher retries/undispatched failures retained'); assert.ok(tries.length <= 3);
  same(attempt.transport ?? [], tries.filter(row => row.dispatched === true), 'All dispatched teacher POST work retained');
  const expected = expectedOriginalTeacherRequest(record, pins.modelId); const candidates = [], diagnostics = []; let cacheComplete = tries.length > 0;
  for (const [index, post] of tries.entries()) {
    assert.equal(rows.filter(row => row.kind === 'teacher_try')[index].record_id, record.id); assert.equal(post.ordinal, index);
    duration(post.elapsed_ms, 'complete teacher try'); assert.ok(candidates.length === 0, 'No retries after accepting first strict original teacher candidate');
    if (post.original_teacher_request) same(post.original_teacher_request, expected, 'Unchanged original RFDT teacher schema/instructions/context');
    if (post.dispatched) {
      assert.ok(post.original_teacher_request); same(post.actual_request, { ...expected, chat_template_kwargs: { enable_thinking: false }, id_slot: 0, cache_prompt: false }, 'Actual teacher additions precisely disclosed');
      counter(post.cache_reset?.n_erased, 'owned slot erase ACK'); assert.ok(!post.reset_error);
      duration(post.cache_reset_elapsed_ms, 'erase ACK'); duration(post.POST_elapsed_ms, 'teacher POST');
      assert.ok(post.POST_elapsed_ms + post.cache_reset_elapsed_ms <= post.elapsed_ms + 0.01, 'Teacher duration contains erase and POST');
      const id = `${attempt.repetition}:${record.id}:teacher:${post.ordinal}`; teacherPrompt(post, renderMap.get(id + ':' + id));
    } else { assert.ok(post.error, 'Undispatched teacher try must retain error'); cacheComplete = false; diagnostics.push('undispatched retry/erase/prompt failure retained'); }
    if (!post.dispatched) continue;
    if (post.response_text === undefined) { assert.ok(post.error, 'Unknown POST result must retain transport failure'); cacheComplete = false; diagnostics.push('POST execution work/response unknown'); continue; }
    assert.equal(post.response_sha256, sha(Buffer.from(post.response_text)), 'Raw provider response byte integrity');
    let reply; try { reply = parseJson(Buffer.from(post.response_text)); } catch { assert.ok(post.error, 'Malformed outer JSON must retain failure'); cacheComplete = false; diagnostics.push('malformed raw outer JSON'); continue; }
    same(post.provider_usage, reply.usage ?? null); same(post.server_timings, reply.timings ?? null);
    if (reply.timings?.cache_n !== 0) cacheComplete = false;
    if (!post.error) {
      assert.equal(reply.model, pins.modelId); const message = reply.choices?.[0]?.message;
      assert.ok(!message?.reasoning_content && !message?.reasoning && !message?.tool_calls && !message?.function_call);
      measuredServer([post]);
      if (post.provider_usage.total_tokens !== undefined) assert.equal(post.provider_usage.total_tokens, post.provider_usage.prompt_tokens + post.provider_usage.completion_tokens);
    }
    assert.equal(post.ok, Number.isSafeInteger(post.status) && post.status >= 200 && post.status <= 299, 'Actual HTTP status/ok coherence');
    if (post.error || !post.ok) { diagnostics.push('HTTP/transport/prompt/counter failure retained'); continue; }
    try { candidates.push(strictTeacherTargets(reply.choices?.[0]?.message?.content, record.request.questions)); }
    catch (error) { diagnostics.push('strict original target rejection: ' + error.message); }
  }
  const posts = tries.filter(row => row.dispatched === true); let work = partialServer(posts), complete = false;
  try { work = measuredServer(posts); complete = true; } catch { diagnostics.push('partial or unknown provider native accounting'); }
  if (attempt.actual_work) same(attempt.actual_work, work, 'Generated work independently folded from every raw dispatched retry');
  if (attempt.actual_generated_targets) { assert.equal(candidates.length, 1); same(attempt.actual_generated_targets, candidates[0], 'Generated target is exact first valid raw teacher JSON candidate'); }
  else assert.ok(attempt.error, 'Missing generated targets must retain failure');
  if (attempt.label_summary) {
    assert.equal(attempt.label_summary.cache_hits, 0); assert.equal(attempt.label_summary.examples, 1);
    assert.equal(attempt.label_summary.teacher_estimates, record.request.questions.length); assert.equal(attempt.label_summary.teacher_model, pins.modelId);
  }
  if (attempt.status === 'completed') assert.ok(complete && cacheComplete && attempt.actual_generated_targets && attempt.label_summary);
  return { returned: candidates[0] ?? null, complete, cache_complete: cacheComplete, work, diagnostics, ...partialServer(posts),
    unknown_prefill_posts: posts.length - partialServer(posts).measured_prefill_posts,
    unknown_generation_posts: posts.length - partialServer(posts).measured_generation_posts,
    undispatched_tries: tries.length - posts.length };
}
function qualityView(record, attempt, returned) {
  const decisions = returned ? record.request.questions.map(q => scoreAnswer(q, record.targets[q.id], attempt.method === 'native' ? returned.answers[q.id] : returned[q.id], attempt.method)) : [];
  const grades = returned ? record.request.questions.map((q, index) => {
    const raw = attempt.method === 'native' ? returned.answers[q.id] : { id: q.id, type: q.type,
      ...(q.type === 'choice' ? { choice: decisions[index].predicted } : q.type === 'score' ? { score: decisions[index].predicted } : { noul: decisions[index].predicted }) };
    return scorePrediction(q, record.targets[q.id], raw);
  }) : [];
  return { decisions, grades };
}
function fresh194(bytes, expectedRefs, pins) {
  same(Object.keys(bytes ?? {}).sort(), ['envelopes', 'plan', 'receipt', 'report', 'stage']); const parsed = {};
  for (const [key, ref] of Object.entries(expectedRefs)) { const raw = Buffer.from(bytes[key]); assert.equal(raw.length, ref.bytes, 'Fresh194 exact bytes: ' + key);
    assert.equal(sha(raw), ref.sha256, 'Fresh194 exact artifact binding: ' + key); parsed[key] = parseJson(raw); }
  const { plan, stage, report, receipt, envelopes } = parsed;
  assert.equal(receipt.kind, 'ROOT_successor_full_validation_194_result_attestation'); assert.equal(receipt.validation_quality_qualified, true);
  assert.equal(receipt.all_quality_gates_passed, true); assert.equal(receipt.honest_completed_negative, false); assert.equal(receipt.approval_effect, 'none');
  for (const [key, value] of Object.entries({ run_plan_sha256: expectedRefs.plan.sha256, stage_sha256: expectedRefs.stage.sha256,
    quality_report_sha256: expectedRefs.report.sha256, run_envelopes_sha256: expectedRefs.envelopes.sha256,
    logical_id: pins.logicalId, research_profile: pins.profileId, physical_profile_sha256: pins.profile,
    physical_profile_file_sha256: pins.profileFile, prototype_source_sha256: pins.source, binary_sha256: pins.binary,
    raw_model_sha256: pins.model, raw_model_bytes: pins.modelBytes, records: 194, independent_groups: 83,
    actual_inference_errors: 0, no_new_TEST_inference: true, production_role_approved: false,
    benchmark_gain_established: false, full_developer_workflow_gain_established: false,
    owned_pid_absent: true, independent_exit_and_stdio_close_observed: true, native_full_validation_contracts_attested: true })) assert.equal(receipt[key], value, 'Fresh194 receipt ' + key);
  assert.equal(plan.logical_id, pins.logicalId); assert.equal(plan.physical_profile_sha256, pins.profile);
  assert.equal(sha(JSON.stringify(plan.physical_profile)), pins.profile); assert.equal(plan.sources.prototype.sha256, pins.source);
  assert.equal(plan.artifacts.binary.sha256, pins.binary); assert.equal(plan.artifacts.model.sha256, pins.model); assert.equal(plan.artifacts.model.bytes, pins.modelBytes);
  assert.ok(plan.sources.host.some(row => row.sha256 === pins.grid && row.path.endsWith('/candidate-2/grid.mjs')));
  assert.equal(stage.run_plan_sha256, expectedRefs.plan.sha256);
  for (const key of ['passed', 'native_contracts_passed', 'root_pid_gone_passed', 'exact_194_envelope_order', 'quality_gates_passed']) assert.equal(stage[key], true);
  assert.equal(stage.logical_id, pins.logicalId); assert.equal(stage.research_profile, pins.profileId); assert.equal(stage.physical_profile_sha256, pins.profile);
  assert.equal(stage.actual_native_process_launches, 1); assert.equal(stage.old_proofs_used_to_qualify_changed_candidate, false); assert.equal(stage.held_out_TEST_read, false);
  assert.equal(stage.native_pid, receipt.owned_pid); assert.equal(stage.root_pid_gone_observation.actor, 'ROOT');
  assert.equal(stage.root_pid_gone_observation.pid, stage.native_pid); assert.equal(stage.root_pid_gone_observation.gone, true);
  assert.equal(report.gates.original_contract_passed, true); assert.equal(report.gates.prospective_developer_score_correctness, true); assert.equal(report.gates.passed, true);
  assert.equal(report.prospective_developer_score_correctness.passed, true); assert.ok(report.prospective_developer_score_correctness.accuracy >= 0.9);
  same(receipt.quality_gates, report.gates); same(receipt.developer_score_correctness, report.prospective_developer_score_correctness);
  assert.equal(report.run_envelopes.length, 194); assert.equal(new Set(report.run_envelopes.map(row => row.record_id)).size, 194);
  const rawEnvelopes = Array.isArray(envelopes) ? envelopes : envelopes.run_envelopes;
  same(rawEnvelopes, report.run_envelopes, 'Fresh194 raw output/report unchanged binding'); return parsed;
}
function nativeTerminal(value, pid) {
  assert.equal(value.pid, pid); assert.equal(value.state, 'closed'); assert.equal(value.exitedObserved, true); assert.equal(value.closedObserved, true);
  assert.equal(value.exitCode, 0); assert.equal(value.signal, null); assert.equal(value.failureCode, null); assert.equal(value.pendingRequests, 0); assert.ok(!value.cleanupError);
}
function gone(value, pid) {
  assert.equal(value?.actor, 'ROOT'); assert.equal(value.pid, pid); assert.equal(value.absent, true);
  assert.ok(Number.isFinite(Date.parse(value.observed_at))); assert.ok(typeof value.method === 'string' && value.method.length > 0); assert.ok(!value.error);
}
function listenerOwnership(observations, pid) {
  assert.ok(Array.isArray(observations) && observations.length > 0, 'Retained listener observations required');
  let owned = false, previousTime = -Infinity;
  for (const listener of observations) {
    assert.equal(listener.actor, 'ROOT'); assert.equal(listener.pid, pid); assert.equal(listener.port, 8089);
    assert.equal(typeof listener.observed_at, 'string');
    const time = Date.parse(listener.observed_at);
    assert.ok(Number.isFinite(time) && new Date(time).toISOString() === listener.observed_at, 'Canonical listener observation timestamp');
    assert.ok(time >= previousTime, 'Listener observations retain chronological startup order'); previousTime = time;
    assert.ok(typeof listener.method === 'string' && listener.method.trim().length > 0 && listener.error == null, 'Listener observation has a method and no error');
    assert.equal(typeof listener.only_owned_listener, 'boolean', 'Known listener ownership state required');
    assert.ok(Array.isArray(listener.observed_listeners), 'Explicit retained listener array required');
    if (!listener.only_owned_listener) {
      assert.equal(listener.observed_listeners.length, 0, 'Only an empty startup listener poll may lack ownership');
      assert.equal(owned, false, 'Listener ownership cannot be lost after startup');
      continue;
    }
    assert.ok(listener.observed_listeners.length > 0, 'Positive listener ownership requires observed listeners');
    for (const observed of listener.observed_listeners) {
      assert.ok(observed && typeof observed === 'object' && !Array.isArray(observed), 'Observed listener object required');
      assert.equal(observed.pid, pid, 'Every actual listener belongs to this owned PID');
      assert.equal(observed.address, '127.0.0.1:8089', 'Every actual listener binds the exact owned loopback port');
      if (Object.hasOwn(observed, 'comm')) assert.ok(typeof observed.comm === 'string' && observed.comm.trim().length > 0, 'Observed command, when supplied, is retained');
    }
    owned = true;
  }
  assert.equal(owned, true, 'At least one positively observed owned listener is required');
}
function validateBlocks(blocks, auditRows, schedule, attempts, rootFacts, plan, qualificationPlan, pins) {
  assert.equal(blocks.length, 4); same(blocks, auditRows.filter(row => row.kind === 'block').map(row => strip(row, 'kind')), 'Raw block/audit equality');
  const nativeInitializations = auditRows.filter(row => row.kind === 'native_RPC' && row.request?.op === 'init');
  for (const row of nativeInitializations) {
    const index = schedule.findIndex(block => canonical(block) === canonical(row.block));
    assert.ok(index >= 0 && schedule[index].method === 'native', 'Every native initialization belongs to an expected native block');
    assert.equal(row.pid, blocks[index].cleanup?.pid, 'Every native init belongs to expected owned PID');
  }
  assert.equal(nativeInitializations.length, blocks.filter(block => block.method === 'native' && block.cleanup?.pid).length,
    'No extra/unassigned native initialization receipts');
  const pids = []; let cleanupComplete = true;
  for (const [index, block] of blocks.entries()) {
    same(fields(block, ['method', 'repetition', 'seed', 'record_ids']), schedule[index]); assert.equal(block.block_index, index + 1);
    duration(block.initialization_ms, 'separate actual owned initialization');
    assert.equal(block.run_invocations, attempts.filter(row => row.block_index === index + 1 && row.attempted === true).length);
    if (!block.adapter_created) { assert.equal(block.run_invocations, 0); continue; }
    const cleanup = block.cleanup;
    if (!cleanup || !Number.isSafeInteger(cleanup.pid) || cleanup.pid <= 0) { cleanupComplete = false; continue; }
    pids.push(cleanup.pid); assert.ok(!pids.slice(0, -1).includes(cleanup.pid), 'Four fresh owned processes cannot share a PID');
    if (block.cleanup_error || cleanup.error || cleanup.cleanupError || cleanup.owned_cleanup_complete !== true || cleanup.exit_and_stdio_close_observed !== true) { cleanupComplete = false; continue; }
    gone(cleanup.root_pid_gone, cleanup.pid);
    assert.ok(rootFacts.owned_process_observations.some(row => row.pid === cleanup.pid && row.block_index === index + 1), 'Separate ROOT process observation required');
    const observation = rootFacts.owned_process_observations.find(row => row.pid === cleanup.pid && row.block_index === index + 1);
    assert.equal(observation.exit_observed, true); assert.equal(observation.stdio_close_observed, true); gone(observation.pid_gone, cleanup.pid);
    const terminalKind = block.method === 'native' ? 'owned_native_process' : 'owned_server_process';
    const terminalRows = auditRows.filter(row => row.kind === terminalKind && row.pid === cleanup.pid);
    assert.equal(terminalRows.length, 1, 'One independently retained owned process terminal receipt per spawned PID');
    const terminalRow = strip(terminalRows[0], 'kind', 'block', 'root_pid_gone');
    same(terminalRow, strip(cleanup, 'root_pid_gone'), 'Retained owned process receipt matches block cleanup before separate ROOT observation');
    if (block.method === 'native') {
      nativeTerminal(cleanup.close_result, cleanup.pid); nativeTerminal(cleanup.snapshot, cleanup.pid);
      assert.equal(cleanup.snapshot.stderrTruncated, false); assert.equal(typeof cleanup.snapshot.stderr, 'string');
      const offloads = [...cleanup.snapshot.stderr.matchAll(/offloaded (\d+)\/(\d+) layers to GPU/g)];
      assert.equal(offloads.length, 1); assert.equal(offloads[0][1], '61'); assert.equal(offloads[0][2], '61');
      assert.equal(observation.logs_sha256, sha(cleanup.snapshot.stderr));
      const init = auditRows.filter(row => row.kind === 'native_RPC' && row.request?.op === 'init' && row.block?.method === 'native' && row.block.repetition === block.repetition);
      assert.equal(init.length, 1); assert.equal(init[0].pid, cleanup.pid); assert.ok(!init[0].error && !init[0].response?.error);
      same(init[0].request, { v: 1, id: 'init', op: 'init', research_profile: pins.profileId,
        model_file: plan.artifacts.model.path, chat_template_file: plan.artifacts.template.path, vocab_only: false,
        device: 'metal', max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048 });
      assert.equal(init[0].response.id, 'init'); assert.equal(init[0].response.result.ready, true);
      assert.equal(init[0].response.result.device, 'metal'); assert.equal(init[0].response.result.architecture, 'gemma4');
      provenance(init[0].response.result.provenance, qualificationPlan, pins);
    } else {
      assert.equal(cleanup.exited, true); assert.equal(cleanup.stdio_closed, true); assert.equal(cleanup.intentional_owned_shutdown, true);
      assert.ok(cleanup.exit_code === 0 || cleanup.exit_signal === 'SIGTERM'); assert.equal(typeof cleanup.logs, 'string');
      assert.equal(observation.logs_sha256, sha(cleanup.logs), 'ROOT verifies exact fresh server log bytes');
      const settings = name => { const values = [...cleanup.logs.matchAll(new RegExp('\\b' + name + '\\s*=\\s*(\\d+)', 'g'))].map(row => +row[1]);
        assert.ok(values.length > 0 && values.every(value => value === values[0])); return values[0]; };
      assert.equal(settings('n_ctx'), 4096); assert.equal(settings('n_batch'), 2048); assert.equal(settings('n_ubatch'), 512);
      const assignments = name => [...cleanup.logs.matchAll(new RegExp('\\b' + name + '\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\'|([^\\s,;]+))', 'g'))]
        .map(row => row[1] ?? row[2] ?? row[3]);
      const explicitK = assignments('type_k'), explicitV = assignments('type_v');
      assert.equal(explicitK.length, [...cleanup.logs.matchAll(/\btype_k\s*=/g)].length);
      assert.equal(explicitV.length, [...cleanup.logs.matchAll(/\btype_v\s*=/g)].length);
      assert.ok(explicitK.length === 0 && explicitV.length === 0 || explicitK.length > 0 && explicitV.length > 0, 'Both explicit KV dtype sides required');
      const summaryLines = cleanup.logs.split('\n').filter(line => /\bllama_kv_cache:\s*size\s*=/.test(line));
      const geometry = [], k = [...explicitK], v = [...explicitV];
      for (const line of summaryLines) {
        const header = line.match(/\bllama_kv_cache:\s*size\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*MiB\s*\(\s*(\d+)\s*cells,\s*(\d+)\s*layers,\s*(\d+)\/(\d+)\s*seqs\s*\)/);
        assert.ok(header, 'Recognized actual KV buffer geometry'); geometry.push(header.slice(2).map(Number).join(':'));
        const K = [...line.matchAll(/\bK\s*\(\s*([a-zA-Z0-9_]+)\s*\)\s*:/g)].map(row => row[1]);
        const V = [...line.matchAll(/\bV\s*\(\s*([a-zA-Z0-9_]+)\s*\)\s*:/g)].map(row => row[1]);
        assert.equal(K.length, 1); assert.equal(V.length, 1); k.push(...K); v.push(...V);
      }
      assert.ok(summaryLines.length === 0 || summaryLines.length === 2 && new Set(geometry).size === 2, 'Both distinct baseline KV buffers observed without duplicates');
      assert.ok(k.length > 0 && v.length > 0 && k.every(value => value === 'f16') && v.every(value => value === 'f16'), 'Observed every KV buffer dtype is F16');
      const unified = assignments('kv_unified'); assert.equal(unified.length, [...cleanup.logs.matchAll(/\bkv_unified\s*=/g)].length);
      assert.ok(unified.length > 0 && unified.every(value => value === '0' || value === 'false'), 'Observed nonunified KV, no contradictions or unknown assignment');
      const offloads = [...cleanup.logs.matchAll(/offloaded (\d+)\/(\d+) layers to GPU/g)]; assert.equal(offloads.length, 1); assert.equal(offloads[0][1], '61'); assert.equal(offloads[0][2], '61');
      assert.match(cleanup.logs, /MTL\d|Metal/); assert.equal(cleanup.native_observations.truncated, false);
      listenerOwnership(cleanup.listener_observations, cleanup.pid);
    }
  }
  assert.equal(rootFacts.all_started_owned_processes_closed_and_gone, true, 'No attestation on a live owned child');
  same([...rootFacts.owned_process_observations.map(row => row.pid)].sort(), [...pids].sort(), 'ROOT covers every and only owned spawned PID');
  for (const row of auditRows.filter(row => row.kind === 'owned_native_process' || row.kind === 'owned_server_process')) {
    const block = blocks.find(block => block.cleanup?.pid === row.pid);
    assert.ok(block && row.kind === (block.method === 'native' ? 'owned_native_process' : 'owned_server_process'),
      'Every owned terminal receipt belongs to an expected spawned block/PID');
  }
  return { cleanupComplete, pids };
}
function rootBinding(facts, identities, plan, alpha, teacher, pins, injected) {
  strictJson(facts); assert.equal(facts.kind, 'ROOT_successor_closed312_independent_facts'); assert.equal(facts.actor, 'ROOT');
  same(facts.artifact_hashes, identities, 'ROOT receipt binds exact input/plan/result/audit/fresh renders');
  const expected = [...plan.source_files, plan.native_source, ...Object.values(plan.artifacts), ...plan.libraries, ...plan.native_runtime_libraries,
    { path: plan.generative.binary, bytes: plan.generative.binary_bytes, sha256: plan.generative.binary_sha256 }, plan.model_registry,
    plan.host_runtime.node_executable, { path: plan.host_runtime.renderer.python_executable, bytes: facts.python_executable_bytes, sha256: plan.host_runtime.renderer.python_executable_sha256 }];
  const unique = [...new Map(expected.map(row => [row.path, row])).values()].sort((a, b) => a.path.localeCompare(b.path));
  same(facts.current_verified_identities, unique, 'ROOT exact current full source/binary/library/template/model/runtime identity inventory');
  assert.equal(plan.artifacts.model.sha256, pins.model); assert.equal(plan.artifacts.model.bytes, pins.modelBytes);
  assert.equal(plan.artifacts.binary.sha256, pins.binary); assert.equal(plan.artifacts.binary.bytes, pins.binaryBytes);
  assert.equal(plan.artifacts.template.sha256, pins.template); assert.equal(plan.artifacts.template.bytes, pins.templateBytes);
  assert.equal(plan.native_source.sha256, pins.source); assert.equal(plan.generative.binary_sha256, pins.server);
  for (const [suffix, hash] of Object.entries({ '/candidate-2/grid.mjs': pins.grid, '/dist/core.js': pins.core,
    '/dist/evaluation.js': pins.evaluation, '/dist/rfdt.js': pins.rfdt, '/scripts/developer-decision-eval.mjs': pins.decision })) {
    assert.ok(plan.source_files.some(row => row.path.endsWith(suffix) && row.sha256 === hash), 'Frozen actual export source ' + suffix);
  }
  for (const key of ['current_full_artifact_hashes_verified', 'current_runtime_and_attester_source_hashes_verified',
    'fresh194_all_five_artifacts_verified', 'fresh194_native_contract_and_quality_receipt_independently_verified',
    'single_active_native_gpu_execution_verified', 'monotonic_clock_unmodified_verified', 'host_only_gold_and_no_TEST_verified',
    'no_other_native_model_calls_verified']) assert.equal(facts[key], true, 'ROOT independent fact: ' + key);
  assert.equal(facts.held_out_TEST_read, false); assert.equal(facts.production_role_approval, false);
  same(facts.fresh194_refs, plan.qualification_refs, 'ROOT fresh194 source/output refs');
  const renderIdentities = [alpha.identity, teacher.identity]; assert.equal(facts.render_executions.length, 2);
  for (const [index, execution] of facts.render_executions.entries()) {
    assert.equal(execution.actor, 'ROOT'); same(execution.artifact_binding, renderIdentities[index]);
    assert.equal(execution.executed_after_stage_closed, true); assert.equal(execution.exit_code, 0);
    assert.equal(execution.native_or_model_execution, false); same(execution.runtime_identity, plan.host_runtime.renderer);
    assert.ok(facts.attester_source_identities.some(row => row.path.endsWith('/render-reference.py') && row.sha256 === execution.hook_source_sha256));
  }
  return !injected && facts.proof_kind === 'ROOT_observed_actual_native_closed_stage';
}
function originalQuality(records, attempts, outcomes, method, repetition = null) {
  const selected = attempts.filter(row => row.method === method && (repetition === null || row.repetition === repetition));
  const byId = new Map(records.map(record => [record.id, record])); const resultRows = selected.map(row => {
    const record = byId.get(row.record_id), grades = outcomes.get(`${row.repetition}:${row.method}:${row.record_id}`).grades;
    const failed = !!row.error || row.status !== 'completed';
    return { id: `${row.repetition}:${record.id}`, group_id: record.group_id, regression: record.regression === true,
      elapsed_ms: row.elapsed_ms, answers: failed ? [] : grades, ...(failed ? { error: row.error ?? 'unrun/incomplete' } : {}) };
  });
  const summary = summarizeQuality(resultRows); const expectedUnknown = selected.flatMap(row => byId.get(row.record_id).request.questions.map(q => ({ q, target: byId.get(row.record_id).targets[q.id] })))
    .filter(({ q, target }) => q.type === 'noul' && Object.hasOwn(target, 'answer') && target.answer === null).length;
  // Preserve attachValidationCoverage's EXPLICIT NULL population. The actual
  // scorePrediction/summarizeQuality still retain all uncertain probability-map
  // targets separately; they cannot dilute this original external null gate.
  const unknownGrades = resultRows.flatMap(row => row.answers).filter(row => row.type === 'noul' && Object.hasOwn(row.target, 'answer') && row.target.answer === null);
  const unknownMean = unknownGrades.length ? unknownGrades.reduce((sum, row) => sum + row.normalized_absolute_error, 0) / unknownGrades.length : null;
  const questionCoverage = resultRows.flatMap(row => row.answers).length === selected.length;
  const unknownPassed = expectedUnknown > 0 && unknownGrades.length === expectedUnknown && Number.isFinite(unknownMean) && unknownMean <= 0.1;
  return { expected_attempts: selected.length, expected_unknown_questions: expectedUnknown, observed_unknown_questions: unknownGrades.length,
    unknown_normalized_mae: unknownMean, original_quality: summary, complete_question_coverage: questionCoverage,
    original_external_unknown_gate: unknownPassed, passed: summary.gates.passed && questionCoverage && unknownPassed };
}
function comparison(summary, qualities, attempts, outcomes) {
  const native = attempts.filter(row => row.method === 'native');
  const scores = native.filter(row => row.expected_questions[0].type === 'score');
  const correct = scores.filter(row => !row.error && row.status === 'completed' && outcomes.get(`${row.repetition}:native:${row.record_id}`).grades[0]?.correct === true).length;
  const scoreAccuracy = scores.length ? correct / scores.length : null;
  const gates = { original_paired_gates: summary.paired.improvement_claim_permitted === true,
    both_arms_original_quality_unknown_and_coverage: qualities.every(row => row.passed),
    direct_individual_original_score_correctness: scores.length > 0 && scoreAccuracy >= 0.9,
    conditional_correct_clear_pair_median_twofold: Number.isFinite(summary.paired.conditional_both_correct_generative_over_native_latency?.median) && summary.paired.conditional_both_correct_generative_over_native_latency.median >= 2,
    all_attempt_elapsed_per_correct_twofold: Number.isFinite(summary.paired.all_attempts_elapsed_per_accepted_judgment_generative_over_native) && summary.paired.all_attempts_elapsed_per_accepted_judgment_generative_over_native >= 2 };
  return { ...gates, expected_score_count: scores.length, direct_score_correct_count: correct, direct_score_accuracy: scoreAccuracy,
    passed: Object.values(gates).every(value => value === true) };
}
function attestCore(input, options) {
  assert.equal(input.stageClosed, true, 'ROOT must close stage before byte injection'); const pins = options.pins;
  strictJson(input.rootFacts); const planBytes = Buffer.from(input.planBytes), resultBytes = Buffer.from(input.resultBytes), auditBytes = Buffer.from(input.auditBytes), inputBytes = Buffer.from(input.inputBytes);
  assert.equal(inputBytes.length, pins.inputBytes); assert.equal(sha(inputBytes), pins.input, 'Exact frozen original developer manifest, targets, order and bytes');
  const records = validateQualityRecords(inputBytes.toString('utf8').trim().split(/\r?\n/).map(line => parseJson(Buffer.from(line))));
  const plan = parseJson(planBytes), result = parseJson(resultBytes), auditRows = auditBytes.toString('utf8').split(/\r?\n/).filter(line => line.trim()).map(line => parseJson(Buffer.from(line)));
  const allowedKinds = new Set(['native_RPC', 'native_alpha_envelope', 'teacher_try', 'attempt', 'block',
    'owned_native_process', 'owned_server_process', 'server_initialization_observations']);
  for (const row of auditRows) {
    assert.ok(allowedKinds.has(row.kind), 'Unknown/unassigned raw audit receipt');
    if (row.kind === 'native_RPC') assert.ok(['init', 'compile', 'evaluate'].includes(row.request?.op), 'Unexpected native operation in actual benchmark receipts');
  }
  assert.equal(records.length, 78); assert.equal(new Set(records.map(row => row.group_id)).size, 39);
  assert.ok(records.every(row => row.split === 'validation' && row.request.questions.length === 1));
  assert.equal(plan.kind, 'gemma4_successor_direct_matched312_frozen_plan'); assert.equal(plan.status, 'root_frozen'); assert.equal(plan.inference_ready, true);
  assert.equal(plan.prospective_protocol.sha256, pins.prospective); assert.equal(plan.original_server_profile_metadata.sha256, pins.baselineMetadata);
  assert.equal(plan.dataset.records, 78); assert.equal(plan.dataset.groups, 39); assert.equal(plan.dataset.input_sha256, pins.input); assert.equal(plan.dataset.input_bytes, pins.inputBytes);
  same(plan.dataset.expected_ids, records.map(row => row.id)); same(plan.dataset.record_manifest, recordManifest(records), 'Exact original request/target/v2/Alpha manifests');
  const schedule = buildSchedule(records.map(row => row.id)); same(plan.schedule, schedule); same(plan.conditions.seeds, [42, 104771]);
  assert.equal(plan.conditions.total_attempts, 312); assert.equal(plan.conditions.scope, 'implementation_comparison_not_pure_generation_isolation_not_normal_Pi_workflow');
  for (const [key, value] of Object.entries({ logical_id: pins.logicalId, logical_source_sha256: pins.grid, source_sha256: pins.source,
    binary_sha256: pins.binary, physical_profile_sha256: pins.profile, physical_profile_file_sha256: pins.profileFile, research_profile: pins.profileId })) assert.equal(plan.direct[key], value);
  for (const [key, value] of Object.entries({ model_id: pins.modelId, context_size: 4096, parallel: 1, port: 8089,
    cache_ram_mib: 0, cache_prompt: false, max_tokens: 2048, temperature: 0, production_teacher_tries_max: 3 })) assert.equal(plan.generative[key], value);
  same(plan.generative.chat_template_kwargs, { enable_thinking: false }); assert.equal(plan.held_out_TEST_authorized, false); assert.equal(plan.production_role_approval, false);
  const qualified = fresh194(input.fresh194Bytes, options.qualificationRefs, pins);
  const benchmarkReleaseBytes = Buffer.from(input.benchmarkReleaseBytes);
  assert.equal(sha(benchmarkReleaseBytes), pins.benchmarkRelease, 'Exact ROOT final benchmark source release revision2');
  assert.equal(benchmarkReleaseBytes.length, pins.benchmarkReleaseBytes); const benchmarkRelease = parseJson(benchmarkReleaseBytes);
  assert.equal(benchmarkRelease.kind, 'gemma4_successor_direct_matched312_source_release'); assert.equal(benchmarkRelease.release_revision, 2);
  assert.equal(benchmarkRelease.source_identities.length, 39); same(benchmarkRelease.source_identities, plan.source_files, 'Exact final39 released benchmark dependencies');
  assert.equal(benchmarkRelease.native_execution_authorized, false); assert.equal(benchmarkRelease.production_role_approval, false);
  assert.equal(plan.source_release.sha256, pins.benchmarkRelease); assert.equal(plan.source_release.bytes, pins.benchmarkReleaseBytes);
  assert.ok(plan.source_files.some(row => row.path.endsWith('/gemma4-successor-direct-proposal/runner.mjs') && row.sha256 === pins.benchmarkRunner));
  for (const [key, ref] of Object.entries(plan.qualification_refs)) { assert.ok(options.qualificationRefs[key]); assert.equal(ref.sha256, options.qualificationRefs[key].sha256); assert.equal(ref.bytes, options.qualificationRefs[key].bytes); }
  same(Object.keys(plan.qualification_refs).sort(), ['plan', 'receipt', 'report', 'stage']); assert.equal(plan.qualified_fresh194_plan_sha256, options.qualificationRefs.plan.sha256);
  assert.equal(result.kind, 'gemma4_successor_direct_performance_result'); assert.equal(result.plan_sha256, sha(planBytes));
  assert.equal(result.source_release_sha256, plan.source_release.sha256); same(result.qualification_refs, plan.qualification_refs);
  assert.equal(result.direct_logical_id, pins.logicalId); same(result.direct_physical_identity, plan.direct); same(result.generated_profile, plan.generative);
  assert.equal(result.held_out_TEST_read, false); assert.equal(result.production_role_approval, false);
  assert.equal(result.improvement_claim_permitted, false, 'Released runner must defer actual claim to independent ROOT attestation');
  const attempts = result.attempts; assert.equal(attempts.length, 312);
  const expectedKeys = schedule.flatMap(block => block.record_ids.map(id => `${block.repetition}:${block.method}:${id}`));
  same(attempts.map(row => `${row.repetition}:${row.method}:${row.record_id}`), expectedKeys, 'All312 original attempts, both orderings, no substitutions/dropped failures');
  const alpha = renderBundle(input.alphaRender, buildAlphaRenderRequests(records), plan.host_runtime.renderer, pins, 'all156 Alpha');
  const teacher = renderBundle(input.teacherRender, buildTeacherRenderRequests(attempts), plan.host_runtime.renderer, pins, 'all dispatched teacher retries');
  const identities = { plan_sha256: sha(planBytes), result_sha256: sha(resultBytes), audit_sha256: sha(auditBytes), input_sha256: sha(inputBytes),
    alpha_render: alpha.identity, teacher_render: teacher.identity, benchmark_source_release_sha256: pins.benchmarkRelease,
    fresh194: Object.fromEntries(Object.entries(options.qualificationRefs).map(([key, ref]) => [key, ref.sha256])) };
  const rootQualified = rootBinding(input.rootFacts, identities, plan, alpha, teacher, pins, options.injected);
  const auditFailed = !!result.audit_error || !!result.audit_failure;
  const { groups, complete: auditComplete } = auditGroups(auditRows, attempts, auditFailed);
  const byId = new Map(records.map(row => [row.id, row])), calls = { native: 0, generative: 0 }, outcomes = new Map(), rescored = [], ledger = [];
  let elapsedComplete = true;
  for (const [index, attempt] of attempts.entries()) {
    const record = byId.get(attempt.record_id), block = schedule[Math.floor(index / 78)];
    assert.equal(attempt.group_id, record.group_id); assert.equal(attempt.block_index, Math.floor(index / 78) + 1); assert.equal(attempt.seed, block.seed);
    assert.equal(attempt.method_call_index, ++calls[attempt.method]); assert.equal(attempt.pair_key, `${attempt.repetition}:${record.id}`);
    assert.equal(attempt.regression, record.regression === true);
    const expectedQuestions = record.request.questions.map(q => ({ id: q.id, type: q.type,
      uncertain: q.type === 'noul' && (!Object.hasOwn(record.targets[q.id], 'answer') || record.targets[q.id].answer === null) }));
    same(attempt.expected_questions, expectedQuestions); assert.equal(attempt.expected_clear_decision, expectedQuestions.every(q => !q.uncertain));
    assert.equal(typeof attempt.attempted, 'boolean');
    if (attempt.elapsed_ms === null) { assert.ok(attempt.error); elapsedComplete = false; }
    else duration(attempt.elapsed_ms, 'all-attempt full classifier/RFDT elapsed');
    if (!attempt.attempted) { assert.ok(attempt.error); assert.ok(attempt.status === 'unrun' || attempt.status === 'execution_unknown_after_runner_error'); }
    if (attempt.status !== 'completed') assert.ok(attempt.error, 'Failed/unrun rows retain explicit error');
    const rows = groups[index] ?? [];
    let reconstruction;
    if (!rows.length && auditFailed) reconstruction = { returned: null, complete: false, cache_complete: false, work: null, diagnostics: ['raw audit evidence unknown after capture failure'] };
    else reconstruction = attempt.method === 'native' ? nativeOutcome(record, attempt, rows, plan, qualified.plan, alpha.map, pins,
      result.blocks[attempt.block_index - 1]?.cleanup?.pid)
      : generatedOutcome(record, attempt, rows, plan, teacher.map, pins);
    const contained = rows.filter(row => row.kind === 'native_RPC' || row.kind === 'teacher_try').reduce((sum, row) => sum + duration(row.elapsed_ms, 'raw contained work'), 0);
    if (attempt.elapsed_ms !== null) assert.ok(contained <= attempt.elapsed_ms + 0.01, 'Full attempt duration retains every contained raw call and retry');
    const view = qualityView(record, attempt, reconstruction.returned); outcomes.set(`${attempt.repetition}:${attempt.method}:${record.id}`, view);
    const failed = !!attempt.error || attempt.status !== 'completed';
    const flags = { correct_judgment: !failed && view.decisions.length > 0 && view.decisions.every(row => row.correct_judgment),
      completed_clear_decision: !failed && view.decisions.length > 0 && view.decisions.every(row => row.completed_clear_decision),
      abstention: view.decisions.some(row => row.abstention) };
    if (attempt.raw_grade) {
      same(attempt.raw_grade.answers, view.decisions, 'Stored host decisions rescore actual original target/tolerance');
      same(attempt.raw_grade.original_quality_grades, view.grades, 'Stored original grades reconstruct actual production scorePrediction');
    }
    const retainedDecisions = attempt.raw_grade || !failed ? view.decisions : [];
    same(attempt.answers, retainedDecisions, 'Retained host decisions independently reconstructed, including failures after host grading');
    if (failed) { assert.equal(attempt.correct_judgment, false); assert.equal(attempt.completed_clear_decision, false); }
    for (const [key, value] of Object.entries(flags)) if (key !== 'abstention' || !failed) assert.equal(attempt[key], value, 'Independent judgment flag ' + key);
    if (attempt.status === 'completed') { assert.ok(reconstruction.complete && reconstruction.cache_complete); assert.equal(attempt.accounting_complete, true); assert.equal(attempt.cache_clear_proved, true); }
    const independent = { ...attempt, answers: retainedDecisions, ...flags,
      // Unknown elapsed stays null in retained evidence; pairedSummary cannot make
      // a gain claim from a coerced zero. We skip summaries entirely below.
      native_response: attempt.method === 'native' && reconstruction.returned ? { ...reconstruction.returned,
        metrics: { ...reconstruction.returned.metrics, ...reconstruction.work } } : undefined,
      transport: attempt.method === 'generative' ? (attempt.teacher_tries ?? []).filter(row => row.dispatched === true) : [] };
    if (independent.native_response === undefined) delete independent.native_response;
    rescored.push(independent);
    const { returned, ...rawLedger } = reconstruction;
    ledger.push({ method: attempt.method, repetition: attempt.repetition, record_id: record.id, status: attempt.status,
      attempted: attempt.attempted, retained_error: attempt.error ?? null, retained_elapsed_ms: attempt.elapsed_ms,
      independent_original_grades: view.grades, reconstructed_answers: returned?.answers ?? (attempt.method === 'generative' ? returned : null), ...rawLedger });
  }
  const cleanup = validateBlocks(result.blocks, auditRows, schedule, attempts, input.rootFacts, plan, qualified.plan, pins);
  const generatedOutputs = attempts.filter(row => row.method === 'generative' && row.label_summary).map(row => row.label_summary.file);
  assert.ok(generatedOutputs.every(path => typeof path === 'string' && /\/trial-\d{6}\/labeled\.jsonl$/.test(path)), 'Each RFDT output belongs to its fresh owned trial');
  assert.equal(new Set(generatedOutputs).size, generatedOutputs.length, 'Unique RFDT trial/output and source-bound empty per-attempt label caches');
  const generatedPids = new Set(result.blocks.filter(row => row.method === 'generative').map(row => row.cleanup?.pid).filter(Boolean));
  const serverInitializations = auditRows.filter(row => row.kind === 'server_initialization_observations');
  assert.equal(new Set(serverInitializations.map(row => row.pid)).size, serverInitializations.length, 'No duplicated fresh server initialization receipts');
  for (const row of serverInitializations) assert.ok(generatedPids.has(row.pid), 'Every fresh server initialization is assigned to an owned generated block');
  const rawComplete = auditComplete && elapsedComplete && ledger.every(row => row.complete && row.cache_complete) && cleanup.cleanupComplete &&
    attempts.every(row => row.attempted === true && row.status === 'completed' && !row.error) &&
    !['audit_error', 'audit_failure', 'stage_abort_error', 'clock_error', 'summary_error', 'gate_error', 'coverage_error', 'cleanup_error', 'runner_prelaunch_error'].some(key => result[key]);
  const summary = elapsedComplete ? pairedSummary(rescored) : null;
  const reps = elapsedComplete ? [1, 2].map(rep => pairedSummary(rescored.filter(row => row.repetition === rep))) : [null, null];
  if (elapsedComplete && auditComplete && !result.summary_error && result.summary) {
    same(result.summary, summary, 'Runner aggregate recomputed by actual original pairedSummary');
    same(result.replicate_summaries, reps, 'Both original paired repetition summaries independently recomputed');
  }
  const qualities = elapsedComplete ? ['native', 'generative'].map(method => originalQuality(records, rescored, outcomes, method)) : [];
  const replicateQualities = elapsedComplete ? [1, 2].map(rep => ['native', 'generative'].map(method => originalQuality(records, rescored, outcomes, method, rep))) : [[], []];
  const aggregate = summary ? comparison(summary, qualities, rescored, outcomes) : { passed: false, reason: 'unknown elapsed work retained' };
  const perRepetition = reps.map((row, index) => row ? comparison(row, replicateQualities[index], rescored.filter(attempt => attempt.repetition === index + 1), outcomes) : { passed: false });
  const claim = rootQualified && rawComplete && aggregate.passed && perRepetition.every(row => row.passed);
  const report = { research_schema: 'independent-successor-312-result-attestation-2', kind: 'independent_successor_direct_performance_result_attestation',
    integrity_attested: true, proof_kind: options.injected ? 'invented_injected_CPU_ONLY' : 'ROOT_closed_actual_artifacts',
    original_dataset_digest: qualityDatasetDigest(records), exact_coverage: { attempts: 312, attempts_per_arm: 156,
      repetitions: 2, unique_records: 78, independent_groups: 39, paired_records: 156, seeds: [42, 104771],
      blocks: ['direct_rep1', 'generated_rep1', 'generated_rep2', 'direct_rep2'], full_frozen_denominator_retained: true },
    result_status: result.status, execution_failures: attempts.filter(row => row.error).length, unrun_attempts: attempts.filter(row => !row.attempted).length,
    unknown_elapsed_attempts: attempts.filter(row => row.elapsed_ms === null).length, audit_complete: auditComplete,
    root_receipt_bound: rootQualified, actual_token_cache_and_cleanup_contracts_complete: rawComplete,
    gates: { aggregate, per_repetition: perRepetition, measurement_qualified: rootQualified && rawComplete, passed: claim },
    honest_negative_attested: !claim, root_qualified_improvement_claim_permitted: claim,
    production_role_approval: false, full_developer_workflow_gain_established: false, true_DX_gain_established: false,
    held_out_TEST_read: false, approval_effect: 'none', cpu_mocks_cannot_prove_native_quality_or_gain: true,
    comparison_scope: 'implementation_comparison_not_pure_generation_isolation_not_normal_Pi_workflow',
    physical_differences_retained: { generated_POST_cache_prompt: false, original_generated_POST_cache_prompt: 'omitted',
      direct: 'new sequence capacity 2, full SWA and unified KV; 2048 submitted decode chunks/512 ubatch; requested AUTO flash effective field remains null',
      generated: 'original context4096/one slot/F16 KV/2048 batch/512 ubatch/nonunified KV; fresh logs retain AUTO effective observations' },
    RFDT_label_cache_scope: 'frozen runner creates unique fresh owned trial, wx gold-free input and mkdir empty cache per attempt; retained label summaries report cache_hits0; owned erase ACK precedes every dispatched retry',
    accounting_scope: 'submitted llama_decode calls are native engine forwards; server API forwards remain unknown; no Metal peak, energy, currency or cold-machine claim',
    identities, summary, replicate_summaries: reps, original_quality: qualities, per_repetition_original_quality: replicateQualities,
    work_ledger: ledger,
    raw_attempts: attempts, raw_blocks: result.blocks,
    trust_boundary: 'ROOT independently verifies full current artifacts/runtime/sources, source-bound fresh Python execution, raw ownership/clock and every PID disappearance. This pure module reconstructs response/logit/JSON/grade/counter/denominator bindings.' };
  strictJson(report); return report;
}
export function attestClosedSuccessor312(input) {
  return attestCore(input, { pins: PINS, qualificationRefs: QUALIFICATION_REFS, injected: false });
}
// Explicitly different API for INVENTED CPU fixtures. It cannot qualify actual gain,
// even when all synthetic accounting, quality and twofold gates happen to pass.
export function attestInjectedCpuSuccessor312(input, { inputSha256, inputBytes, emittedProfileSha256, qualificationRefs, benchmarkReleaseSha256, benchmarkReleaseBytes }) {
  assert.match(inputSha256, /^[a-f0-9]{64}$/); assert.match(emittedProfileSha256, /^[a-f0-9]{64}$/);
  assert.match(benchmarkReleaseSha256, /^[a-f0-9]{64}$/);
  return attestCore(input, { pins: { ...PINS, input: inputSha256, inputBytes, profile: emittedProfileSha256,
    benchmarkRelease: benchmarkReleaseSha256, benchmarkReleaseBytes }, qualificationRefs, injected: true });
}
export { PINS, QUALIFICATION_REFS, strictJson, jsonBytes, sha, buildSchedule, expectedOriginalTeacherRequest } from './contracts.mjs';
