import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { resolve, join } from 'node:path';

assert.equal(process.argv[2], '--stage-closed', 'ROOT must observe terminal execution before this helper');
const root = '/Users/bsonntag/code/simple-jev-ts';
assert.equal(resolve(process.cwd()), root);
const execute = promisify(execFile), sha = bytes => createHash('sha256').update(bytes).digest('hex');
const proposal = join(root, '.build/improvement-experiments/gemma4-direct-proposal');
const proof = join(proposal, 'performance-native-proof-root-1');
const planBytes = await readFile(join(proposal, 'performance-root-frozen-plan-1.json'));
assert.equal(sha(planBytes), 'b86374313ece4139ea1c8c6bfcb864a48a901e5ceaa76d36588307cc34765f1c');
const plan = JSON.parse(planBytes);
const resultBytes = await readFile(join(proof, 'result.json')), result = JSON.parse(resultBytes);
const auditBytes = await readFile(join(proof, 'audit.jsonl'));
const rows = auditBytes.toString('utf8').split('\n').filter(Boolean).map(JSON.parse);
assert.equal(result.status, 'completed'); assert.equal(result.cleanup_error, null);
assert.equal(result.blocks.length, 4); assert.equal(result.attempts.length, 312);
assert.equal(result.plan_sha256, sha(planBytes)); assert.equal(result.audit_bytes, auditBytes.length);
const { stdout: processes } = await execute('/bin/ps', ['-axo', 'pid,ppid,rss,comm'], { timeout: 10000, maxBuffer: 1024 * 1024 });
const pids = new Set(processes.split('\n').map(line => Number(line.trim().split(/\s+/)[0])));
const ownedPids = result.blocks.map(block => {
  const cleanup = block.cleanup;
  assert.equal(cleanup.owned_cleanup_complete, true); assert.ok(!block.cleanup_error);
  assert.ok(Number.isSafeInteger(cleanup.pid) && cleanup.pid > 0); assert.ok(!pids.has(cleanup.pid));
  if (block.method === 'native') {
    for (const key of ['exitedObserved', 'closedObserved']) assert.equal(cleanup[key], true);
    assert.equal(cleanup.state, 'closed'); assert.equal(cleanup.exitCode, 0); assert.equal(cleanup.signal, null);
    assert.equal(cleanup.failureCode, null); assert.equal(cleanup.pendingRequests, 0);
  } else {
    assert.equal(cleanup.exited, true); assert.equal(cleanup.stdio_closed, true);
    assert.equal(cleanup.exit_code, 0); assert.equal(cleanup.exit_signal, null);
  }
  return cleanup.pid;
});
const otherNative = processes.split('\n').filter(line => /llama-server|gemma4-label-prototype/.test(line));
assert.deepEqual(otherNative, []);
for (const relative of ['.build/rfdt-training.lock', '.jev/artifacts.json']) {
  try { await stat(join(root, relative)); throw new Error('Unexpected live lock or role approval: ' + relative); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
}
const verified = [];
async function identity(path) {
  const info = await stat(path); assert.ok(info.isFile());
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return { path, bytes: info.size, sha256: hash.digest('hex') };
}
async function verify(expected) {
  const actual = await identity(expected.path); assert.equal(actual.sha256, expected.sha256, expected.path);
  if (expected.bytes !== undefined) assert.equal(actual.bytes, expected.bytes, expected.path);
  verified.push(actual); return actual;
}
for (const expected of [...plan.source_files, ...Object.values(plan.artifacts), ...plan.native_runtime_libraries,
  plan.prototype_source, plan.render_reference, plan.qualified_plan, plan.qualified_quality_report,
  plan.qualified_root_attestation, plan.actual_server_capability_attestation, plan.runtime_preflight,
  plan.host_runtime.node_executable]) await verify(expected);
await verify({ path: plan.generative.binary, sha256: plan.generative.binary_sha256 });
assert.equal(process.version, plan.host_runtime.node_version);
const renderer = join(root, '.build/improvement-experiments/gemma4-label-prototype/research-quality/render-reference.py');
const { stdout: runtimeText } = await execute(plan.host_runtime.renderer.python_executable,
  [renderer, '--runtime-identity'], { timeout: 10000, maxBuffer: 1024 * 1024 });
assert.deepEqual(JSON.parse(runtimeText), plan.host_runtime.renderer);
const protectedStage = JSON.parse(await readFile(join(root, '.build/improvement-experiments/evidence-supervision-comparison/supplemented-stage.json')));
for (const [path, digest] of Object.entries(protectedStage.old_evidence_hashes)) await verify({ path, sha256: digest });

// Independently rerender all 156 actually compiled direct prompts. Their input
// branches are separately checked against production compilation by attester.
const compiles = rows.filter(row => row.kind === 'native_rpc' && row.request.op === 'compile');
assert.equal(compiles.length, 156);
const renderInputs = compiles.map((row, index) => ({ record_id: String(index), branch: row.request.branches[0] }));
const renderInputPath = join(proof, 'root-render-requests-1.json');
const renderOutputPath = join(proof, 'root-independent-render-1.json');
await writeFile(renderInputPath, JSON.stringify(renderInputs) + '\n', { flag: 'wx', mode: 0o600 });
await execute(plan.host_runtime.renderer.python_executable, [renderer, '--requests', renderInputPath,
  '--output', renderOutputPath, '--template', plan.artifacts.template.path,
  '--expected-sha256', plan.artifacts.template.sha256], { timeout: 60000, maxBuffer: 1024 * 1024 });
const renderBytes = await readFile(renderOutputPath), rendered = JSON.parse(renderBytes);
assert.equal(rendered.rows.length, 156); assert.deepEqual(rendered.runtime_identity, plan.host_runtime.renderer);
compiles.forEach((row, index) => assert.equal(row.response.result[0].rendered, rendered.rows[index].rendered));

const attesterPath = join(root, '.build/improvement-experiments/gemma4-direct-result-audit/attest.mjs');
await verify({ path: attesterPath, sha256: 'fcc39dff9f6b08cdc3b0630408f36c3c367b620a1403b2b3de72a680e3b40a83' });
const receipt = { kind: 'ROOT_direct_performance_final_receipt', observed_at: new Date().toISOString(),
  plan_sha256: sha(planBytes), result_sha256: sha(resultBytes), audit_sha256: sha(auditBytes),
  current_frozen_artifacts_verified: true, current_runtime_hashes_verified: true, owned_pids_absent: true,
  single_active_native_gpu_execution_verified: true, monotonic_clock_unmodified_verified: true,
  all_actual_direct_prompts_independent_original_jinja_match: true, independently_rendered_direct_prompts: 156,
  root_render_sha256: sha(renderBytes), owned_pids: ownedPids, identities: verified,
  earlier_held_out_evidence_unchanged: true, permanent_role_approved: false,
  execution_scope: 'ROOT-started serial D/G/G/D owned lane; observed process inventories; not an OS GPU tracer',
  clock_scope: 'unchanged source and ROOT runtime monotonic clock; no injected timing functions',
  helper_sha256: sha(await readFile(new URL(import.meta.url))) };
await writeFile(join(proof, 'root-final-receipt-1.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx', mode: 0o400 });
const { runClosedStage } = await import('./gemma4-direct-result-audit/attest.mjs');
const report = await runClosedStage({ stageClosed: true, rootReceipt: receipt,
  outputPath: join(root, '.build/improvement-experiments/gemma4-direct-result-audit/result-attestation-root-1.json') });
console.log(JSON.stringify({ root_receipt_sha256: sha(await readFile(join(proof, 'root-final-receipt-1.json'))),
  integrity_attested: report.integrity_attested, honest_negative_attested: report.honest_negative_attested,
  root_qualified_improvement_claim_permitted: report.root_qualified_improvement_claim_permitted,
  result_attestation_sha256: sha(await readFile(join(root, '.build/improvement-experiments/gemma4-direct-result-audit/result-attestation-root-1.json'))) }));
