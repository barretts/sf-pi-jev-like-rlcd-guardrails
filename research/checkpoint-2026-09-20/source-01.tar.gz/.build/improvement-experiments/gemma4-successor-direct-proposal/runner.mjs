import assert from 'node:assert/strict';
import { spawn, execFile } from 'node:child_process';
import { createServer } from 'node:net';
import { createReadStream } from 'node:fs';
import { mkdir, mkdtemp, readFile, realpath, stat, writeFile, appendFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve, relative, basename } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { performance } from 'node:perf_hooks';
import { PINS, BOUNDS, sha256, jsonBytes, canonical, finiteJson, buildSchedule, checkRootPermit, verifyFresh194Qualification,
  foldDirectMetrics, foldServerMetrics, partialServerMetrics, partialDirectMetrics } from './protocol.mjs';
import { proveTeacherPrompt, serverStderrObservations, serverProfilePassed, verifyIndependentRender } from './capability.mjs';
import { executeBlocks } from './harness.mjs';

export const HERE = dirname(fileURLToPath(import.meta.url));
export const ROOT = resolve(HERE, '../../..');
const QUALITY = join(ROOT, '.build/improvement-experiments/gemma4-runtime-candidate-1/quality-run');
const CANDIDATE = dirname(QUALITY);
const ORIGINAL = join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality');
const GRID = join(ROOT, '.build/improvement-experiments/fractional-score-hypothesis/candidate-2/grid.mjs');
const INPUT = join(ROOT, '.build/improvement-experiments/validation-label-audit/validation-78.jsonl');
const executeFile = promisify(execFile);
const writeJson = (path, value) => writeFile(path, jsonBytes(finiteJson(value)), { flag: 'wx', mode: 0o600 });
const importPinned = identity => import(pathToFileURL(identity.path).href + '?sha256=' + identity.sha256);

// These functions are declarations only. No artifact reads/imports or native defaults on import.
export async function fileIdentity(path) {
  const details = await stat(path); assert.ok(details.isFile()); const digest = createHash('sha256');
  for await (const chunk of createReadStream(path)) digest.update(chunk);
  return { path: resolve(path), bytes: details.size, sha256: digest.digest('hex') };
}
async function verifiedBytes(identity) {
  const bytes = await readFile(identity.path); assert.equal(bytes.length, identity.bytes); assert.equal(sha256(bytes), identity.sha256); return bytes;
}
async function verifyIdentity(identity) { const current = await fileIdentity(identity.path); assert.deepEqual(current, identity, 'Frozen identity changed: ' + identity.path); return current; }
function authorization(value, stage) { assert.equal(value?.actor, 'ROOT'); assert.equal(value.explicit, true); assert.equal(value.stage, stage);
  assert.equal(value.logical_id, PINS.logicalId); assert.equal(value.research_profile, PINS.profileId); assert.equal(value.prototype_source_sha256, PINS.source); assert.equal(value.production_role_approval, false); }
async function ownedDirectory(path) {
  const absolute = resolve(path); assert.equal(await realpath(dirname(absolute)), await realpath(HERE));
  assert.ok(basename(absolute) && !basename(absolute).startsWith('.')); return absolute;
}

export async function verifiedQualitySources() {
  const path = join(QUALITY, 'source-release-revision-2.json'); const bytes = await readFile(path); assert.equal(sha256(bytes), PINS.qualityRelease);
  const release = JSON.parse(bytes); const sources = release.source_identities ?? release.sources;
  assert.ok(Array.isArray(sources) && sources.length === 20, 'Exact frozen quality release inventory');
  for (const identity of sources) await verifyIdentity(identity);
  return [...sources, { path, bytes: bytes.length, sha256: sha256(bytes) }];
}
export async function expectedSourcePaths() {
  return [...new Set([
    ...['protocol.mjs', 'harness.mjs', 'capability.mjs', 'runner.mjs', 'root-entry.mjs', 'source.cpu.test.mjs', 'harness.cpu.test.mjs', 'README.md'].map(name => join(HERE, name)),
    ...['dist/backend.js', 'dist/core.js', 'dist/evaluation.js', 'dist/models.js', 'dist/rfdt.js', 'scripts/developer-decision-eval.mjs'].map(name => join(ROOT, name)),
    GRID, join(ORIGINAL, 'rpc.mjs'), join(ORIGINAL, 'render-reference.py'),
    join(HERE, 'prospective-protocol-root-1.json'), join(HERE, 'root-original-server-profile-metadata-1.json'),
    join(CANDIDATE, 'root-qualification-metadata-1.json'),
    join(CANDIDATE, 'main.cpp'), join(CANDIDATE, 'physical-profile.json'), join(CANDIDATE, 'compile-evidence-root-1.json'),
    ...(await verifiedQualitySources()).map(identity => identity.path),
  ])].sort();
}
export async function sourceIdentities() {
  const paths = await expectedSourcePaths(); const identities = await Promise.all(paths.map(fileIdentity));
  for (const [path, hash] of [[GRID, PINS.grid], [join(ORIGINAL, 'rpc.mjs'), PINS.rpc], [join(ORIGINAL, 'render-reference.py'), PINS.renderer],
    [join(ROOT, 'dist/rfdt.js'), PINS.rfdt], [join(ROOT, 'scripts/developer-decision-eval.mjs'), PINS.decision], [join(ROOT, 'dist/evaluation.js'), PINS.evaluation],
    [join(HERE, 'prospective-protocol-root-1.json'), PINS.prospective], [join(HERE, 'root-original-server-profile-metadata-1.json'), PINS.baselineMetadata],
    [join(CANDIDATE, 'root-qualification-metadata-1.json'), PINS.qualificationMetadata]])
    assert.equal(identities.find(identity => identity.path === path).sha256, hash);
  assert.equal(identities.find(identity => identity.path === join(CANDIDATE, 'main.cpp')).sha256, PINS.source);
  assert.equal(identities.find(identity => identity.path === join(CANDIDATE, 'physical-profile.json')).sha256, PINS.profileFile);
  return identities;
}
async function verifyReleasedSources(sourceReleaseRef, sourceExpectations) {
  const release = JSON.parse(await verifiedBytes(sourceReleaseRef)); assert.equal(sourceReleaseRef.path, join(HERE, 'source-release-revision-2.json'));
  assert.equal(release.release_revision, 2, 'Explicit successor source revision 2 required; release 1 remains immutable');
  assert.equal(release.kind, 'gemma4_successor_direct_matched312_source_release'); assert.equal(release.native_execution_authorized, false);
  assert.deepEqual(release.source_identities, sourceExpectations); assert.deepEqual(sourceExpectations.map(identity => identity.path).sort(), await expectedSourcePaths());
  for (const identity of sourceExpectations) await verifyIdentity(identity);
}

export async function safeDeveloperManifest() {
  const bytes = await readFile(INPUT); assert.equal(bytes.length, PINS.inputBytes); assert.equal(sha256(bytes), PINS.input);
  const coreIdentity = await fileIdentity(join(ROOT, 'dist/core.js')); assert.equal(coreIdentity.sha256, PINS.core);
  const evaluation = await fileIdentity(join(ROOT, 'dist/evaluation.js')); assert.equal(evaluation.sha256, PINS.evaluation);
  const { validateQualityRecords } = await importPinned(evaluation);
  const records = validateQualityRecords(bytes.toString('utf8').trim().split('\n').map(line => JSON.parse(line)));
  assert.equal(records.length, 78); assert.equal(new Set(records.map(record => record.id)).size, 78); assert.equal(new Set(records.map(record => record.group_id)).size, 39);
  assert.ok(records.every(record => record.split === 'validation' && record.request.questions.length === 1));
  const compilerIdentity = await fileIdentity(GRID); assert.equal(compilerIdentity.sha256, PINS.grid);
  const compiler = await importPinned(compilerIdentity); const { preparePrompt } = await importPinned(coreIdentity);
  const recordManifest = records.map(record => ({ record_id: record.id, group_id: record.group_id,
    original_request_sha256: sha256(JSON.stringify(record.request)), original_target_sha256: sha256(JSON.stringify(record.targets)),
    original_v2_prompt_sha256: sha256(JSON.stringify(preparePrompt({ ...record.request, options: { ...record.request.options, template_version: 'v2' } }, 'v2').questions)),
    logical_prompt_sha256: compiler.compileHalfGrid(record.request).logical_prompt_sha256 }));
  return { records, bytes, dataset: { path: INPUT, records: 78, groups: 39, input_bytes: bytes.length, input_sha256: PINS.input,
    expected_ids: records.map(record => record.id), record_manifest: recordManifest } };
}
export async function sourceCpuPlan() {
  const { dataset } = await safeDeveloperManifest(); const baseline = JSON.parse(await readFile(join(HERE, 'root-original-server-profile-metadata-1.json')));
  return { kind: 'gemma4_successor_direct_matched312_source_cpu_plan', status: 'qualified194_metadata_released_matched312_inference_pending_ROOT',
    prospective_protocol_sha256: PINS.prospective, original_server_metadata_sha256: PINS.baselineMetadata,
    dataset, schedule: buildSchedule(dataset.expected_ids), source_identities: await sourceIdentities(),
    direct: { logical_id: PINS.logicalId, logical_source_sha256: PINS.grid, source_sha256: PINS.source, binary_sha256: PINS.binary,
      physical_profile_sha256: PINS.profile, physical_profile_file_sha256: PINS.profileFile },
    generated_baseline_metadata: baseline, runtime_bounds: BOUNDS,
    no_old_profile_qualification: true, native_execution_authorized: false, model_tokenizer_native_GPU_training_network_auth_executed: false,
    production_role_approval: false, held_out_TEST_read: false, actual_quality_or_gain_proven: false };
}

export async function qualificationRefsFromReleasedMetadata() {
  const bytes = await readFile(join(CANDIDATE, 'root-qualification-metadata-1.json')); assert.equal(sha256(bytes), PINS.qualificationMetadata);
  const metadata = JSON.parse(bytes); assert.equal(metadata.kind, 'ROOT_successor_194_qualification_metadata_refs');
  assert.equal(metadata.receipt_projection.validation_quality_qualified, true);
  return Object.fromEntries(Object.entries({ plan: 'run-plan.json', report: 'quality-report.json', stage: 'stage-proof.json', receipt: 'root-final-receipt-1.json' })
    .map(([key, name]) => { const identity = metadata.refs.find(reference => basename(reference.path) === name); assert.ok(identity); return [key, identity]; }));
}

async function qualification(refs) {
  assert.deepEqual(Object.keys(refs ?? {}).sort(), ['plan', 'receipt', 'report', 'stage']);
  assert.deepEqual(refs, await qualificationRefsFromReleasedMetadata(), 'Only authoritative fresh194 ROOT descriptor refs qualify');
  const names = { plan: 'run-plan.json', report: 'quality-report.json', stage: 'stage-proof.json', receipt: 'root-final-receipt-1.json' };
  const allowed = join(QUALITY, 'native-proof-root-1'); const parsed = {};
  for (const key of Object.keys(names)) { const identity = refs[key]; assert.ok(identity && identity.path === join(allowed, names[key]), 'Only fresh successor194 refs qualify');
    assert.match(identity.sha256 ?? '', /^[a-f0-9]{64}$/); assert.ok(Number.isSafeInteger(identity.bytes) && identity.bytes > 0); parsed[key] = JSON.parse(await verifiedBytes(identity)); }
  verifyFresh194Qualification({ ...parsed, refs }); return parsed;
}
export async function freezeRootMatched312({ rootAuthorization, qualificationRefs, sourceReleaseRef, sourceExpectations }) {
  authorization(rootAuthorization, 'successor_matched312_freeze');
  // Semantic fresh194 check comes before any full model/binary/library/template read.
  const qualified = await qualification(qualificationRefs); await verifyReleasedSources(sourceReleaseRef, sourceExpectations);
  const [{ dataset }, runtime, baselineBytes] = await Promise.all([safeDeveloperManifest(),
    importPinned(sourceExpectations.find(identity => identity.path === join(QUALITY, 'runner.mjs'))), readFile(join(HERE, 'root-original-server-profile-metadata-1.json'))]);
  assert.equal(sha256(baselineBytes), PINS.baselineMetadata); const baseline = JSON.parse(baselineBytes);
  const artifacts = { model: await fileIdentity(join(ROOT, 'models/gemma-4-31B_q4_0-it.gguf')),
    binary: await fileIdentity(join(CANDIDATE, 'gemma4-label-prototype')), template: await fileIdentity(join(ROOT, 'models/gemma-4-31B-it.chat_template.jinja')) };
  assert.equal(artifacts.model.sha256, PINS.model); assert.equal(artifacts.model.bytes, PINS.modelBytes); assert.equal(artifacts.binary.sha256, PINS.binary);
  assert.equal(artifacts.binary.bytes, PINS.binaryBytes); assert.equal(artifacts.template.sha256, PINS.template);
  const libraries = []; for (const [path, hash] of Object.entries(runtime.STATIC_LIBRARIES)) { const identity = await fileIdentity(join(ROOT, path)); assert.equal(identity.sha256, hash); libraries.push(identity); }
  const server = await fileIdentity(baseline.generative.binary); assert.equal(server.sha256, PINS.server);
  assert.equal(baseline.native_runtime_libraries.length, 9); for (const identity of baseline.native_runtime_libraries) await verifyIdentity(identity);
  const nativeSource = await fileIdentity(join(CANDIDATE, 'main.cpp')); assert.equal(nativeSource.sha256, PINS.source);
  const registry = await fileIdentity(join(ROOT, 'models/registry.json'));
  const renderer = qualified.plan.host_runtime.renderer;
  assert.equal((await fileIdentity(renderer.python_executable)).sha256, renderer.python_executable_sha256);
  assert.deepEqual(await runtime.rendererRuntimeIdentity(), renderer, 'Fresh194 qualified renderer runtime must remain unchanged');
  const generative = { ...baseline.generative, binary_bytes: server.bytes, context_size: 4096, port: 8089, parallel: 1,
    cache_prompt: false, cache_ram_mib: 0, production_teacher_tries_max: 3,
    requested_native_settings_source: 'original server argv preserves context4096/parallel1; pinned binary defaults are independently checked against each fresh startup log for batch2048/ubatch512/F16/nonunifiedKV. AUTO effective flash is reported from logs.',
    explicit_physical_difference_from_original_POST: 'cache_prompt:false; original adapter omitted this flag. Owned erase ACK and observed cache_n:0 remain required.' };
  return { kind: 'gemma4_successor_direct_matched312_frozen_plan', status: 'root_frozen', inference_ready: true, frozen_at: new Date().toISOString(),
    prospective_protocol: { path: join(HERE, 'prospective-protocol-root-1.json'), bytes: 3887, sha256: PINS.prospective },
    original_server_profile_metadata: { path: join(HERE, 'root-original-server-profile-metadata-1.json'), bytes: baselineBytes.length, sha256: PINS.baselineMetadata },
    qualification_refs: qualificationRefs, qualified_fresh194_plan_sha256: qualificationRefs.plan.sha256, source_release: sourceReleaseRef, source_files: sourceExpectations,
    native_source: nativeSource, libraries, native_runtime_libraries: baseline.native_runtime_libraries, model_registry: registry,
    artifacts, generative, direct: { logical_id: PINS.logicalId, logical_source_sha256: PINS.grid, source_sha256: PINS.source, binary_sha256: PINS.binary,
      physical_profile_sha256: PINS.profile, physical_profile_file_sha256: PINS.profileFile, research_profile: PINS.profileId },
    dataset, schedule: buildSchedule(dataset.expected_ids), runtime_bounds: BOUNDS, host_runtime: { node_executable: await fileIdentity(process.execPath), node_version: process.version, renderer },
    conditions: { seeds: [42, 104771], total_attempts: 312, scope: 'implementation_comparison_not_pure_generation_isolation_not_normal_Pi_workflow',
      cold_scope: 'separate fresh owned process initialization; not cold machine or identical host workflow' },
    no_old_profile_qualification: true, held_out_TEST_authorized: false, production_role_approval: false, quality_or_gain_proven: false };
}
export async function verifyFrozen(plan) {
  await qualification(plan.qualification_refs); await verifyReleasedSources(plan.source_release, plan.source_files);
  const baseline = JSON.parse(await verifiedBytes(plan.original_server_profile_metadata));
  assert.deepEqual(plan.native_runtime_libraries, baseline.native_runtime_libraries); assert.equal(plan.native_runtime_libraries.length, 9);
  assert.equal(plan.generative.binary, baseline.generative.binary); assert.equal(plan.generative.binary_sha256, PINS.server);
  assert.equal(plan.native_source.path, join(CANDIDATE, 'main.cpp')); assert.equal(plan.native_source.sha256, PINS.source);
  assert.equal(plan.artifacts.model.path, join(ROOT, 'models/gemma-4-31B_q4_0-it.gguf')); assert.equal(plan.artifacts.binary.path, join(CANDIDATE, 'gemma4-label-prototype'));
  assert.equal(plan.artifacts.template.path, join(ROOT, 'models/gemma-4-31B-it.chat_template.jinja')); assert.equal(plan.model_registry.path, join(ROOT, 'models/registry.json'));
  assert.equal(process.execPath, plan.host_runtime.node_executable.path); assert.equal(process.version, plan.host_runtime.node_version);
  for (const identity of [plan.native_source, ...Object.values(plan.artifacts), ...plan.libraries, ...plan.native_runtime_libraries,
    { path: plan.generative.binary, bytes: plan.generative.binary_bytes, sha256: plan.generative.binary_sha256 }, plan.model_registry,
    plan.prospective_protocol, plan.original_server_profile_metadata, plan.host_runtime.node_executable]) await verifyIdentity(identity);
  assert.ok(!Object.keys(process.env).some(key => /^(DYLD_|LD_PRELOAD$)/.test(key)), 'Loader overrides break frozen native attribution');
  assert.equal((await fileIdentity(plan.host_runtime.renderer.python_executable)).sha256, plan.host_runtime.renderer.python_executable_sha256);
  const frozenRunner = plan.source_files.find(identity => identity.path === join(QUALITY, 'runner.mjs'));
  const qualityRunner = await importPinned(frozenRunner);
  assert.deepEqual(Object.fromEntries(plan.libraries.map(identity => [relative(ROOT, identity.path), identity.sha256])), qualityRunner.STATIC_LIBRARIES);
  assert.equal(plan.libraries.length, 8);
  const runtime = await qualityRunner.rendererRuntimeIdentity(); assert.deepEqual(runtime, plan.host_runtime.renderer, 'Frozen Python/Jinja runtime changed');
  const { records, bytes, dataset } = await safeDeveloperManifest(); assert.deepEqual(dataset, plan.dataset); return { records, bytes };
}

export async function boundedReply(response, limit) {
  let count = 0; const parts = []; for await (const part of response.body ?? []) { count += part.byteLength; assert.ok(count <= limit, 'HTTP response cap exceeded'); parts.push(Buffer.from(part)); }
  return Buffer.concat(parts);
}
async function availablePort(port) {
  await new Promise((resolvePromise, reject) => { const listener = createServer(); listener.once('error', reject);
    listener.listen(port, '127.0.0.1', () => listener.close(error => error ? reject(error) : resolvePromise())); });
}
export async function boundedRootObservation(observer, args, { signal, timeoutMs = BOUNDS.exit_timeout_ms } = {}) {
  assert.equal(typeof observer, 'function'); assert.ok(Number.isSafeInteger(timeoutMs) && timeoutMs > 0 && timeoutMs <= BOUNDS.exit_timeout_ms);
  signal?.throwIfAborted(); let timer, onAbort;
  try { const races = [Promise.resolve().then(() => observer(...args)), new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('ROOT observation deadline')), timeoutMs); })];
    if (signal) races.push(new Promise((_, reject) => { onAbort = () => reject(signal.reason ?? new Error('ROOT observation aborted')); signal.addEventListener('abort', onAbort, { once: true }); if (signal.aborted) onAbort(); }));
    const observation = await Promise.race(races); signal?.throwIfAborted(); return finiteJson(observation);
  } finally { clearTimeout(timer); if (onAbort) signal.removeEventListener('abort', onAbort); }
}
async function observeRootGone(observer, pid, evidence) {
  const observation = await boundedRootObservation(observer, [pid, evidence]);
    assert.equal(observation?.actor, 'ROOT'); assert.equal(observation.pid, pid); assert.equal(observation.absent, true);
    assert.ok(Number.isFinite(Date.parse(observation.observed_at)) && typeof observation.method === 'string' && observation.method.length > 0 && !observation.error); return observation;
}
async function startServer({ plan, proof, audit, signal, observeOwnedListener }) {
  assert.equal(typeof observeOwnedListener, 'function'); signal.throwIfAborted(); await availablePort(plan.generative.port); signal.throwIfAborted();
  assert.equal(await realpath(dirname(proof)), await realpath(HERE)); const slotPath = await mkdtemp(join(proof, 'owned-server-slot-store-'));
  const args = ['--model', plan.artifacts.model.path, '--jinja', '--chat-template-file', plan.artifacts.template.path,
    '--alias', plan.generative.model_id, '--host', '127.0.0.1', '--port', '8089', '--ctx-size', '4096', '--parallel', '1', '--n-gpu-layers', 'all',
    '--verbosity', '4', '--reasoning', 'on', '--slots', '--cache-ram', '0', '--slot-save-path', slotPath,
    '--cors-origins', '', '--no-cors-credentials', '--no-webui', '--no-agent'];
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !/^(LLAMA_|AIP_)/.test(key)));
  const child = spawn(plan.generative.binary, args, { cwd: HERE, stdio: ['ignore', 'pipe', 'pipe'], env });
  let logs = '', totalBytes = 0, truncated = false, error = null, exited = false, closed = false, exitCode = null, exitSignal = null, stopping = false;
  let finish; const closing = new Promise(resolvePromise => { finish = resolvePromise; });
  child.once('error', value => { error = String(value); }); child.once('exit', (code, sig) => { exited = true; exitCode = code; exitSignal = sig; if (!stopping) error ??= 'Unexpected owned server exit'; });
  child.once('close', () => { closed = true; finish(); });
  const abort = () => { error ??= 'Owned server stage aborted'; stopping = true; child.kill('SIGTERM'); };
  signal.addEventListener('abort', abort, { once: true }); if (signal.aborted) abort();
  const log = part => { totalBytes += part.length; if (totalBytes > BOUNDS.max_stderr_bytes) { truncated = true; error ??= 'Owned server log cap exceeded'; stopping = true; child.kill('SIGTERM'); }
    else logs += part.toString('utf8'); };
  child.stdout?.on('data', log); child.stderr?.on('data', log);
  const listenerObservations = [];
  return { pid: child.pid, logs: () => logs, failure: () => error || (exited ? 'Owned server exited' : null),
    ownsListener: async () => { const receipt = await boundedRootObservation(observeOwnedListener, [child.pid, plan.generative.port], { signal }); listenerObservations.push(receipt);
      return receipt?.actor === 'ROOT' && receipt.pid === child.pid && receipt.port === 8089 && receipt.only_owned_listener === true && Number.isFinite(Date.parse(receipt.observed_at)) && typeof receipt.method === 'string' && receipt.method.length > 0 && !receipt.error; },
    close: async () => { stopping = true; if (!exited) child.kill('SIGTERM');
      const wait = async () => { let timer; try { await Promise.race([closing, new Promise(resolvePromise => { timer = setTimeout(resolvePromise, BOUNDS.exit_timeout_ms); })]); } finally { clearTimeout(timer); } };
      await wait(); if (!closed) { child.kill('SIGKILL'); await wait(); } signal.removeEventListener('abort', abort);
      const observations = serverStderrObservations(logs, { truncated, pid: child.pid });
      const receipt = { pid: child.pid ?? null, exited, stdio_closed: closed, exit_code: exitCode, exit_signal: exitSignal, error,
        intentional_owned_shutdown: true, exit_and_stdio_close_observed: exited && closed, owned_cleanup_complete: exited && closed && !error && (exitCode === 0 || exitSignal === 'SIGTERM'),
        native_profile_passed: serverProfilePassed(observations), native_observations: observations, listener_observations: listenerObservations, args, logs };
      try { await audit('owned_server_process', receipt); } catch (failure) { receipt.audit_error = String(failure); receipt.owned_cleanup_complete = false; } return receipt;
    } };
}

export async function makeGenerativeAdapter({ plan, proof, audit, labelRfdt, originalFetch, nextTrial, renderOriginal,
  observeRootPidGone, observeOwnedListener, startServerImpl }) {
  assert.equal(typeof startServerImpl, 'function', 'Injected server factory required; exported adapter has no native launch default');
  let server, source, attempt, stageSignal; let active = false; const base = 'http://127.0.0.1:8089';
  const localReply = async (path, options = {}, signal) => { assert.ok(['/health', '/v1/models', '/slots/0?action=erase', '/apply-template', '/tokenize'].includes(path));
    signal?.throwIfAborted(); assert.ok(!server.failure() && await server.ownsListener(), 'Owned loopback listener required');
    signal?.throwIfAborted();
    const response = await originalFetch(base + path, { ...options, signal, redirect: 'error' }); const bytes = await boundedReply(response, BOUNDS.http_response_bytes);
    assert.ok(response.ok, `Owned server ${path} HTTP ${response.status}`); signal?.throwIfAborted(); return bytes; };
  return {
    initialize: async signal => { stageSignal = signal; signal.throwIfAborted(); server = await startServerImpl({ plan, proof, audit, signal, observeOwnedListener });
      const started = performance.now(); let ready = false;
      while (performance.now() - started < BOUNDS.request_timeout_ms) { signal.throwIfAborted(); if (server.failure()) throw new Error(server.failure());
        try { await localReply('/health', {}, AbortSignal.any([signal, AbortSignal.timeout(5000)])); ready = true; break; }
        catch { await new Promise(resolvePromise => setTimeout(resolvePromise, 250)); } }
      assert.ok(ready); const observations = serverStderrObservations(server.logs(), { pid: server.pid }); assert.ok(serverProfilePassed(observations), 'Fresh original server settings/Metal61 not proved');
      await audit('server_initialization_observations', observations);
      const models = JSON.parse(await localReply('/v1/models', {}, signal)); assert.ok(models.data?.some(model => model.id === PINS.modelId));
      assert.equal(globalThis.fetch, originalFetch, 'Exclusive fetch wrapper ownership required'); active = true;
      globalThis.fetch = async (input, init = {}) => {
        assert.ok(attempt && source); const teacherTry = { ordinal: attempt.teacher_tries.length, dispatched: false, elapsed_ms: 0 };
        attempt.teacher_tries.push(teacherTry); const started = performance.now();
        try {
          assert.ok(teacherTry.ordinal < 3, 'Unchanged RFDT permits max three teacher tries'); assert.equal(String(input), base + '/v1/chat/completions'); assert.equal(init.method, 'POST');
          const signal = AbortSignal.any([stageSignal, init.signal].filter(Boolean)); signal.throwIfAborted();
          const body = JSON.parse(init.body); teacherTry.original_teacher_request = structuredClone(body);
          assert.equal(body.model, PINS.modelId); assert.equal(body.temperature, 0); assert.equal(body.max_tokens, 2048);
          assert.equal(body.response_format?.type, 'json_schema'); assert.equal(body.response_format.json_schema.strict, true);
          assert.equal(body.messages?.length, 2); assert.equal(body.messages[0].role, 'system'); assert.equal(body.messages[1].role, 'user');
          assert.deepEqual(JSON.parse(body.messages[1].content), { context: source.request.state ?? source.request.messages, questions: source.request.questions });
          for (const field of ['tools', 'tool_choice', 'functions', 'function_call', 'reasoning_effort']) assert.ok(!Object.hasOwn(body, field));
          const headers = new Headers(init.headers); assert.ok(!headers.has('authorization') && !headers.has('cookie'));
          const reset = performance.now(); try { teacherTry.cache_reset = JSON.parse(await localReply('/slots/0?action=erase', { method: 'POST' }, signal));
            assert.ok(Number.isSafeInteger(teacherTry.cache_reset.n_erased) && teacherTry.cache_reset.n_erased >= 0); teacherTry.erase_ACK_proved = true;
          } catch (failure) { teacherTry.reset_error = String(failure); throw failure; } finally { teacherTry.cache_reset_elapsed_ms = performance.now() - reset; }
          body.chat_template_kwargs = { enable_thinking: false }; body.id_slot = 0; body.cache_prompt = false; teacherTry.actual_request = body;
          await proveTeacherPrompt({ body, teacherTry, localReply, signal, renderOriginal }); signal.throwIfAborted();
          assert.ok(!server.failure() && await server.ownsListener()); signal.throwIfAborted(); teacherTry.dispatched = true; attempt.transport.push(teacherTry);
          const sent = performance.now(); try { const response = await originalFetch(String(input), { ...init, signal, body: JSON.stringify(body), redirect: 'error' });
            const bytes = await boundedReply(response, BOUNDS.http_response_bytes); teacherTry.ok = response.ok; teacherTry.status = response.status;
            teacherTry.response_text = bytes.toString('utf8'); teacherTry.response_sha256 = sha256(bytes); const reply = JSON.parse(teacherTry.response_text);
            teacherTry.provider_usage = reply.usage ?? null; teacherTry.server_timings = reply.timings ?? null;
            assert.equal(reply.model, PINS.modelId); assert.ok(!reply.choices?.[0]?.message?.reasoning_content && !reply.choices?.[0]?.message?.reasoning);
            assert.ok(!reply.choices?.[0]?.message?.tool_calls && !reply.choices?.[0]?.message?.function_call);
            foldServerMetrics([teacherTry]); signal.throwIfAborted(); return new Response(bytes, { status: response.status, headers: response.headers });
          } finally { teacherTry.POST_elapsed_ms = performance.now() - sent; }
        } catch (failure) { teacherTry.error = String(failure); throw failure; }
        finally { teacherTry.elapsed_ms = performance.now() - started; await audit('teacher_try', { record_id: source.id, ...teacherTry }); }
      };
    },
    run: async (goldFreeSource, signal, row) => { source = goldFreeSource; attempt = row; row.teacher_tries = [];
      const trial = join(proof, `trial-${String(nextTrial()).padStart(6, '0')}`); await mkdir(trial, { mode: 0o700 });
      const input = join(trial, 'unlabeled.jsonl'), output = join(trial, 'labeled.jsonl'), cache = join(trial, 'fresh-label-cache');
      await writeFile(input, JSON.stringify({ ...goldFreeSource, targets: {} }) + '\n', { flag: 'wx', mode: 0o600 }); await mkdir(cache, { mode: 0o700 });
      try { signal.throwIfAborted(); const result = await labelRfdt(input, { outputPath: output, cacheDir: cache, teacherUrl: base + '/v1', teacherModel: PINS.modelId, signal });
        row.label_summary = result; assert.equal(result.cache_hits, 0); const labeled = JSON.parse((await readFile(output, 'utf8')).trim());
        assert.deepEqual(labeled.request, goldFreeSource.request); row.actual_generated_targets = labeled.targets; signal.throwIfAborted(); return labeled.targets;
      } finally { row.actual_work = partialServerMetrics(row.transport);
        try { row.actual_work = foldServerMetrics(row.transport); row.accounting_complete = true; } catch (failure) { row.accounting_complete = false; row.work_accounting_error = String(failure); }
        row.cache_clear_proved = row.transport.length > 0 && row.teacher_tries.every(teacherTry => !teacherTry.dispatched || teacherTry.erase_ACK_proved === true && teacherTry.server_timings?.cache_n === 0 && teacherTry.actual_request?.cache_prompt === false && teacherTry.BOS_tokenization_proved && teacherTry.original_Jinja_parity_proved);
        source = null; attempt = null; }
    },
    close: async () => { if (active) { globalThis.fetch = originalFetch; active = false; }
      if (!server) return { no_process_started: true, owned_cleanup_complete: true, exit_and_stdio_close_observed: true };
      const receipt = await server.close(); try { receipt.root_pid_gone = await observeRootGone(observeRootPidGone, server.pid, receipt); }
      catch (failure) { receipt.owned_cleanup_complete = false; receipt.root_observation_error = String(failure); }
      receipt.owned_cleanup_complete &&= receipt.native_profile_passed === true; return receipt; }
  };
}

async function renderRows(plan, proof, requests, stem, signal, modules) {
  const requestBytes = jsonBytes(requests); const input = join(proof, stem + '-requests.json'); const output = join(proof, stem + '-render.json');
  await writeFile(input, requestBytes, { flag: 'wx', mode: 0o600 });
  const runtime = plan.host_runtime.renderer;
  const python = await fileIdentity(runtime.python_executable); assert.equal(python.sha256, runtime.python_executable_sha256, 'Frozen Python executable changed before execution');
  assert.deepEqual(await modules.qualityRunner.rendererRuntimeIdentity(), runtime, 'Frozen renderer runtime changed immediately before execution'); signal?.throwIfAborted();
  const execution = await executeFile(runtime.python_executable, [join(ORIGINAL, 'render-reference.py'), '--requests', input, '--output', output,
    '--template', plan.artifacts.template.path, '--expected-sha256', PINS.template], { cwd: HERE, timeout: Math.min(60000, BOUNDS.request_timeout_ms), maxBuffer: 1048576, encoding: 'utf8', signal });
  const bytes = await readFile(output); const reference = JSON.parse(bytes); verifyIndependentRender(reference, requests, requestBytes, runtime);
  return { reference, sha256: sha256(bytes), stdout: execution.stdout, stderr: execution.stderr };
}
async function makeDirectAdapter({ plan, qualifiedPlan, proof, block, records, modules, audit, reference, observeRootPidGone }) {
  let rpc, lifecycle, classifier, stageSignal; const receipts = []; const ordered = records.map(record => ({ id: record.id, group_id: record.group_id, split: record.split, request: structuredClone(record.request) }));
  let cursor = 0, current = null; const nativePlan = { ...qualifiedPlan, inputs: [{ record_manifest: plan.dataset.record_manifest }] };
  return {
    initialize: async signal => { stageSignal = signal; await verifyFrozen(plan); signal.throwIfAborted();
      rpc = modules.rpc.OwnedRpc.spawn(plan.artifacts.binary.path, [], { cwd: HERE, requestTimeoutMs: BOUNDS.request_timeout_ms, totalTimeoutMs: BOUNDS.total_timeout_ms,
        maxPacketBytes: BOUNDS.max_packet_bytes, maxResponseBytes: BOUNDS.max_native_response_bytes, maxStderrBytes: BOUNDS.max_stderr_bytes, exitTimeoutMs: BOUNDS.exit_timeout_ms, maxRequests: BOUNDS.native_max_requests });
      lifecycle = modules.qualityRunner.ownedLifecycle(rpc, signal);
      const audited = { snapshot: () => rpc.snapshot(), request: async (request, options = {}) => { stageSignal.throwIfAborted();
        const entry = { pid: rpc.snapshot().pid, request }; const sent = performance.now();
        try { entry.response = await rpc.request(request, { signal: AbortSignal.any([stageSignal, options.signal].filter(Boolean)) }); return entry.response; }
        catch (failure) { entry.error = String(failure); throw failure; }
        finally { entry.elapsed_ms = performance.now() - sent; receipts.push(entry); if (current) current.native_RPC.push(entry); await audit('native_RPC', { block, ...entry }); } } };
      const init = await audited.request(modules.qualityProtocol.initRequest(), { signal }); assert.ok(!init.error); modules.qualityProtocol.validateProvenance(init.result?.provenance, nativePlan);
      assert.equal(init.result.ready, true); assert.equal(init.result.device, 'metal'); assert.equal(init.result.architecture, 'gemma4');
      classifier = new modules.classifier.SuccessorResearchClassifier({ rpc: audited, plan: nativePlan, compiler: modules.compiler, orderedRecords: ordered,
        renderReference: reference, evidenceSink: envelope => audit('native_alpha_envelope', { block, ...envelope }), signal });
    },
    run: async (source, signal, row) => { const record = ordered[cursor++]; assert.equal(source.id, record.id); assert.deepEqual(source.request, record.request);
      current = row; row.native_RPC = []; try { const envelope = await classifier.classifyRecord(record, signal); row.native_envelope = envelope;
        if (envelope.response) row.native_response = envelope.response; assert.ok(!envelope.error && envelope.response); signal.throwIfAborted();
        const folded = foldDirectMetrics(envelope.response); row.native_response = { ...envelope.response, metrics: { ...envelope.response.metrics, ...folded } };
        row.actual_work = folded; row.accounting_complete = true;
        const evaluate = row.native_RPC.filter(entry => entry.request.op === 'evaluate');
        assert.equal(evaluate.length, 1); assert.equal(evaluate[0].request.full, true); assert.ok(!evaluate[0].error && !evaluate[0].response.error);
        assert.equal(evaluate[0].response.result.metrics.branch_output_tokens, 0); assert.equal(plan.native_source.sha256, PINS.source);
        row.cache_clear_proved = true; row.cache_clear_proof_source = 'retained actual full:true evaluate request/response plus frozen C091 native source full llama_memory_clear(data=true) before and after; not allocator telemetry';
        return envelope.response;
      } finally { if (!row.actual_work) row.actual_work = partialDirectMetrics(row.native_RPC); current = null; } },
    close: async () => { if (!rpc) return { no_process_started: true, owned_cleanup_complete: true, exit_and_stdio_close_observed: true };
      let closeResult, error = null; try { closeResult = await rpc.close(); } catch (failure) { error = String(failure); }
      try { await lifecycle?.dispose(); } catch (failure) { error ??= 'Owned lifecycle disposal: ' + String(failure); }
      const snapshot = rpc.snapshot(), pid = snapshot.pid;
      const observations = modules.qualityRunner.nativeStderrObservations(snapshot);
      const receipt = { pid, close_result: closeResult ?? null, snapshot, error,
        exit_and_stdio_close_observed: lifecycle?.exitObserved() === true && snapshot.exitedObserved === true && snapshot.closedObserved === true,
        owned_cleanup_complete: !error && modules.qualityProtocol.cleanOwnedTerminal(closeResult, pid) && modules.qualityProtocol.cleanOwnedTerminal(snapshot, pid) && lifecycle?.exitObserved() === true && observations.qualifying_full_metal_offload === true,
        fresh_native_stderr_observations: observations };
      try { receipt.root_pid_gone = await observeRootGone(observeRootPidGone, pid, receipt); } catch (failure) { receipt.owned_cleanup_complete = false; receipt.root_observation_error = String(failure); }
      try { await audit('owned_native_process', { block, ...receipt }); } catch (failure) { receipt.owned_cleanup_complete = false; receipt.audit_error = String(failure); } return receipt;
    }
  };
}

export function makeHostJudge({ scoreAnswer, scorePrediction }) {
  return (record, returned, method) => {
    const answers = []; const originalGrades = [];
    const predictions = method === 'native' ? new Map(Object.entries(returned.answers)) : new Map(Object.entries(returned));
    assert.deepEqual([...predictions.keys()].sort(), record.request.questions.map(question => question.id).sort());
    for (const question of record.request.questions) { const raw = predictions.get(question.id); const decision = scoreAnswer(question, record.targets[question.id], raw, method);
      answers.push(decision);
      // Only the host grading view converts the generated target to a typed prediction. Raw inference stays unchanged.
      const prediction = method === 'native' ? raw : { id: question.id, type: question.type,
        ...(question.type === 'choice' ? { choice: decision.predicted } : question.type === 'score' ? { score: decision.predicted } : { noul: decision.predicted }) };
      originalGrades.push(scorePrediction(question, record.targets[question.id], prediction));
    }
    return { answers, original_quality_grades: originalGrades, correct_judgment: answers.every(answer => answer.correct_judgment),
      completed_clear_decision: answers.every(answer => answer.completed_clear_decision), abstention: answers.some(answer => answer.abstention) };
  };
}
export async function retainPrelaunchFailure({ plan, records, error, evidenceSink, pairedSummary, signal, retainedAttempts = [], retainedBlocks = [], executionStarted = false }) {
  const result = await executeBlocks({ plan, records, createAdapter: async () => { throw new Error('No native launch after runner prelaunch failure: ' + String(error)); },
    judge: () => { throw new Error('No grading after prelaunch failure'); }, pairedSummary: pairedSummary ?? (() => null),
    evidenceSink, proofKind: 'injected_cpu', abortSignal: signal });
  result.runner_prelaunch_error = String(error); result.evidence.proof_kind = 'failed_prelaunch_no_actual_native';
  if (executionStarted) {
    const known = new Map(retainedAttempts.map(attempt => [`${attempt.repetition}:${attempt.method}:${attempt.record_id}`, attempt]));
    result.attempts = result.attempts.map(attempt => known.get(`${attempt.repetition}:${attempt.method}:${attempt.record_id}`) ?? { ...attempt,
      status: 'execution_unknown_after_runner_error', submitted_work_unknown: true, elapsed_ms: null });
    result.retained_block_observations = retainedBlocks; result.summary = null; result.replicate_summaries = [null, null];
    result.evidence.proof_kind = 'failed_runner_partial_actual_evidence_native_status_unknown'; result.evidence.full_developer_coverage = false;
    result.summary_error = 'Unexpected runner failure: missing actual elapsed work remains unknown; raw retained attempts and block observations preserved';
  }
  result.status = 'incomplete'; result.improvement_claim_permitted = false; result.pending_independent_ROOT_final_attestation = true;
  return result;
}
export async function runRootMatched312({ rootAuthorization, planBytes, clearanceBytes, proofDirectory, observeRootPidGone, observeOwnedListener, signal: externalSignal }) {
  authorization(rootAuthorization, 'successor_matched312_run'); const plan = checkRootPermit(planBytes, JSON.parse(clearanceBytes), rootAuthorization);
  assert.equal(typeof observeRootPidGone, 'function'); assert.equal(typeof observeOwnedListener, 'function');
  const { records, bytes } = await verifyFrozen(plan); const qualified = await qualification(plan.qualification_refs);
  const output = await ownedDirectory(proofDirectory); await mkdir(output, { mode: 0o700 });
  await writeJson(join(HERE, 'once-only-native-reservation-' + sha256(planBytes) + '.json'), { kind: 'ROOT_successor_matched312_once_only_reservation', plan_sha256: sha256(planBytes), proof_directory: output });
  await writeFile(join(output, 'run-plan.json'), planBytes, { flag: 'wx', mode: 0o600 }); await writeFile(join(output, 'root-clearance.json'), clearanceBytes, { flag: 'wx', mode: 0o600 });
  await writeFile(join(output, 'developer-validation-78.jsonl'), bytes, { flag: 'wx', mode: 0o600 });
  const controller = new AbortController(); const interrupted = () => controller.abort(new Error('ROOT matched312 interrupted'));
  process.once('SIGINT', interrupted); process.once('SIGTERM', interrupted);
  const signal = AbortSignal.any([controller.signal, externalSignal, AbortSignal.timeout(BOUNDS.total_timeout_ms)].filter(Boolean)); let auditBytes = 0, auditFailure = null;
  const retainedAttempts = [], retainedBlocks = [];
  const audit = async (kind, value) => { if (kind === 'attempt') retainedAttempts.push(value); if (kind === 'block') retainedBlocks.push(value);
    try { const data = Buffer.from(JSON.stringify(finiteJson({ kind, ...value })) + '\n'); auditBytes += data.length;
      assert.ok(auditBytes <= BOUNDS.max_audit_bytes); await appendFile(join(output, 'audit.jsonl'), data, { mode: 0o600 }); }
    catch (failure) { auditFailure = String(failure); controller.abort(new Error('Evidence capture failed: ' + auditFailure)); throw failure; } };
  const originalFetch = globalThis.fetch;
  const get = name => plan.source_files.find(identity => identity.path === name);
  let modules = {}; let result; let executionStarted = false;
  try {
  modules = { qualityRunner: await importPinned(get(join(QUALITY, 'runner.mjs'))), qualityProtocol: await importPinned(get(join(QUALITY, 'protocol.mjs'))),
    classifier: await importPinned(get(join(QUALITY, 'classifier.mjs'))), rpc: await importPinned(get(join(ORIGINAL, 'rpc.mjs'))), compiler: await importPinned(get(GRID)),
    rfdt: await importPinned(get(join(ROOT, 'dist/rfdt.js'))), decision: await importPinned(get(join(ROOT, 'scripts/developer-decision-eval.mjs'))),
    evaluation: await importPinned(get(join(ROOT, 'dist/evaluation.js'))) };
  let trial = 0, renderIndex = 0;
    const requests = records.map(record => ({ record_id: record.id, branch: modules.qualityProtocol.wireBranch(modules.compiler.compileHalfGrid(record.request).questions[0]) }));
    let directRender = null, prelaunchError = null;
    try { directRender = await renderRows(plan, output, requests, 'all78-alpha-before-launch', signal, modules); } catch (failure) { prelaunchError = String(failure); }
    const createAdapter = async (block, orderedRecords) => { if (prelaunchError) throw new Error('No native launch after independent all78 Jinja failure: ' + prelaunchError); signal.throwIfAborted(); await verifyFrozen(plan); signal.throwIfAborted();
      if (block.method === 'native') return makeDirectAdapter({ plan, qualifiedPlan: qualified.plan, proof: output, block, records: orderedRecords, modules, audit, reference: directRender.reference, observeRootPidGone });
      return makeGenerativeAdapter({ plan, proof: output, audit, labelRfdt: modules.rfdt.labelRfdt, originalFetch, nextTrial: () => ++trial, observeRootPidGone, observeOwnedListener,
        startServerImpl: startServer,
        renderOriginal: async (messages, requestSignal, teacherTry) => { const id = 'teacher-' + String(++renderIndex).padStart(6, '0');
          const rendering = await renderRows(plan, output, [{ record_id: id, branch: { branch_id: id, messages, answer_prefix: '' } }], id, requestSignal, modules);
          teacherTry.independent_render_sha256 = rendering.sha256; return rendering.reference.rows[0]; } }); };
    executionStarted = true;
    result = await executeBlocks({ plan, records, createAdapter, judge: makeHostJudge(modules.decision.scoreAnswer ? { scoreAnswer: modules.decision.scoreAnswer, scorePrediction: modules.evaluation.scorePrediction } : {}),
      pairedSummary: modules.decision.pairedSummary, evidenceSink: audit, proofKind: 'root_attested_actual_native', abortSignal: signal });
    result.evidence.fresh194_qualification_bound = true;
    result.plan_sha256 = sha256(planBytes); result.source_release_sha256 = plan.source_release.sha256; result.qualification_refs = plan.qualification_refs;
    result.direct_logical_id = PINS.logicalId; result.direct_physical_identity = plan.direct; result.generated_profile = plan.generative;
    result.actual_quality_or_gain_proven_by_source = false; result.held_out_TEST_read = false; result.production_role_approval = false;
    result.pending_independent_ROOT_final_attestation = true; result.audit_failure = auditFailure;
    // A source-run summary cannot independently establish ROOT's sole GPU lane/artifact/receipt observations.
    result.improvement_claim_permitted = false;
    await writeJson(join(output, 'result.json'), result); return result;
  } catch (failure) {
    if (result) throw failure; // A final write failure cannot be repaired by claiming an unrun execution.
    const capturedAttempts = [...retainedAttempts], capturedBlocks = [...retainedBlocks];
    result = await retainPrelaunchFailure({ plan, records, error: failure, evidenceSink: audit, pairedSummary: modules.decision?.pairedSummary, signal,
      retainedAttempts: capturedAttempts, retainedBlocks: capturedBlocks, executionStarted });
    result.plan_sha256 = sha256(planBytes); result.audit_failure = auditFailure;
    await writeJson(join(output, 'result.json'), result); return result;
  } finally { globalThis.fetch = originalFetch; process.removeListener('SIGINT', interrupted); process.removeListener('SIGTERM', interrupted); }
}

// Deliberately no CLI and no default main/import-triggered launch.
