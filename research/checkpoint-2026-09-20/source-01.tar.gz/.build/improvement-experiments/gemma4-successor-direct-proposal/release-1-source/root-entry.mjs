// No CLI. ROOT must verify the released source inventory before importing this file.
export { sourceCpuPlan, qualificationRefsFromReleasedMetadata, freezeRootMatched312, runRootMatched312 } from './runner.mjs';
export const nativeStageStatus = Object.freeze({ status: 'qualified194_metadata_released_matched312_inference_pending_ROOT',
  native_execution_authorized_by_source: false, held_out_TEST_authorized: false, production_role_approval: false,
  actual_quality_or_gain_proven: false });
