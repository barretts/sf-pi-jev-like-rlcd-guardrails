import assert from 'node:assert/strict';
import test from 'node:test';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { PINS, BOUNDS, sha256, jsonBytes, finiteJson, buildSchedule, foldDirectMetrics, partialDirectMetrics,
  foldServerMetrics, partialServerMetrics, verifyFresh194Qualification, checkRootPermit } from './protocol.mjs';
import { BOUNDARY, proveTeacherPrompt, serverStderrObservations, serverProfilePassed } from './capability.mjs';
import { HERE, makeGenerativeAdapter, makeHostJudge, freezeRootMatched312, boundedRootObservation, retainPrelaunchFailure } from './runner.mjs';
import { scorePrediction } from '../../../dist/evaluation.js';
import { scoreAnswer } from '../../../scripts/developer-decision-eval.mjs';

// Every context, response, log, token list, PID and receipt below is invented CPU evidence.
// No actual VAL response, native/model/tokenizer, proof, server binary/library or network is read.
const logs = 'MTL0 (Invented CPU fixture)\noffloaded 61/61 layers to GPU\nn_ctx = 4096\nn_batch = 2048\nn_ubatch = 512\ntype_k = f16\ntype_v = f16\nkv_unified = false\nresolve_fused_ops: Flash Attention enabled\nMTL0 KV buffer size = 320.00 MiB\nMTL0 KV buffer size = 1200.00 MiB\n';
const authorization = stage => ({ actor: 'ROOT', explicit: true, stage, logical_id: PINS.logicalId,
  research_profile: PINS.profileId, prototype_source_sha256: PINS.source, production_role_approval: false });
const identity = (name, value) => ({ path: '/invented/' + name, bytes: jsonBytes(value).length, sha256: sha256(jsonBytes(value)) });
function inventedQualification() {
  const pid = 123456;
  const plan = { logical_id: PINS.logicalId, physical_profile_sha256: PINS.profile,
    sources: { prototype: { sha256: PINS.source }, host: [{ path: '/invented/candidate-2/grid.mjs', sha256: PINS.grid }] },
    artifacts: { binary: { sha256: PINS.binary }, model: { sha256: PINS.model, bytes: PINS.modelBytes } } };
  const report = { gates: { original_contract_passed: true, prospective_developer_score_correctness: true, passed: true },
    prospective_developer_score_correctness: { expected_count: 26, scored_count: 26, correct_count: 26, accuracy: 1, threshold: 0.9, passed: true },
    run_envelopes: Array.from({ length: 194 }, (_, index) => ({ record_id: 'invented194-' + index })) };
  const stage = { run_plan_sha256: identity('plan', plan).sha256, passed: true, native_contracts_passed: true, root_pid_gone_passed: true,
    exact_194_envelope_order: true, quality_gates_passed: true, actual_native_process_launches: 1, logical_id: PINS.logicalId,
    research_profile: PINS.profileId, physical_profile_sha256: PINS.profile, old_proofs_used_to_qualify_changed_candidate: false,
    held_out_TEST_read: false, native_pid: pid, root_pid_gone_observation: { actor: 'ROOT', pid, gone: true } };
  const refs = { plan: identity('plan', plan), report: identity('report', report), stage: identity('stage', stage) };
  const receipt = { kind: 'ROOT_successor_full_validation_194_result_attestation', observed_at: '2000-01-01T00:00:00.000Z',
    run_plan_sha256: refs.plan.sha256, stage_sha256: refs.stage.sha256, quality_report_sha256: refs.report.sha256,
    validation_quality_qualified: true, all_quality_gates_passed: true, honest_completed_negative: false, approval_effect: 'none',
    no_new_TEST_inference: true, production_role_approved: false, benchmark_gain_established: false, full_developer_workflow_gain_established: false,
    prototype_source_sha256: PINS.source, binary_sha256: PINS.binary, physical_profile_sha256: PINS.profile,
    physical_profile_file_sha256: PINS.profileFile, raw_model_sha256: PINS.model, raw_model_bytes: PINS.modelBytes,
    logical_id: PINS.logicalId, research_profile: PINS.profileId, records: 194, independent_groups: 83,
    original_targets_units_and_gates_unchanged: true, all_194_actual_responses_reconstructed_from_raw_native_logits: true,
    all_194_original_Jinja_BOS_and_one_token_guards_verified: true, independent_original_grade_and_all_per_set_and_diagnosis_and_score_gates_reproduced: true,
    current_full_source_artifact_model_template_and_prerequisite_hashes_verified: true, independent_exit_and_stdio_close_observed: true,
    owned_pid_absent: true, native_full_validation_contracts_attested: true, emitted_flash_effective_field_remains_null: true,
    actual_offloaded_layers: 61, generated_output_tokens: 0, owned_native_processes: 1, actual_inference_errors: 0,
    quality_gates: report.gates, developer_score_correctness: report.prospective_developer_score_correctness, owned_pid: pid };
  return { receipt, report, stage, plan, refs };
}

test('fixed schedule uses seeds 42/104771, paired78, D/G/G/D', () => {
  const ids = Array.from({ length: 78 }, (_, index) => 'invented-' + index); const schedule = buildSchedule(ids);
  assert.deepEqual(schedule.map(block => [block.method, block.repetition, block.seed]), [['native', 1, 42], ['generative', 1, 42], ['generative', 2, 104771], ['native', 2, 104771]]);
  assert.deepEqual(schedule[0].record_ids, schedule[1].record_ids); assert.deepEqual(schedule[2].record_ids, schedule[3].record_ids);
  assert.notDeepEqual(schedule[0].record_ids, schedule[2].record_ids); assert.throws(() => buildSchedule(ids.slice(1)));
});
test('source freeze fails absent fresh194 prerequisite before artifact access', async () => {
  await assert.rejects(freezeRootMatched312({ rootAuthorization: authorization('successor_matched312_freeze'), qualificationRefs: {} }));
  await assert.rejects(freezeRootMatched312({ rootAuthorization: authorization('wrong_stage'), qualificationRefs: {} }));
  await assert.rejects(makeGenerativeAdapter({}), /no native launch default/);
});
test('invented semantic qualification verifies exact successor identities and original gates', () => {
  assert.equal(verifyFresh194Qualification(inventedQualification()), true);
  for (const mutate of [
    value => { value.receipt.physical_profile_sha256 = PINS.profileFile; }, value => { value.receipt.logical_id = 'v2'; },
    value => { value.receipt.owned_pid_absent = false; }, value => { value.receipt.developer_score_correctness.passed = false; },
    value => { value.report.prospective_developer_score_correctness.accuracy = 0.89; }, value => { value.stage.root_pid_gone_passed = false; },
    value => { value.receipt.actual_offloaded_layers = 60; }, value => { value.report.run_envelopes.pop(); },
    value => { value.receipt.quality_report_sha256 = '0'.repeat(64); }, value => { value.receipt.validation_quality_qualified = false; },
    value => { value.receipt.honest_completed_negative = true; }, value => { value.receipt.production_role_approved = true; },
  ]) { const fixture = inventedQualification(); mutate(fixture); assert.throws(() => verifyFresh194Qualification(fixture)); }
});
test('strict evidence JSON rejects disappearing metadata and nonfinite numbers', () => {
  assert.throws(() => finiteJson({ omitted: undefined })); assert.throws(() => finiteJson({ value: Infinity }));
  assert.throws(() => finiteJson(Object.create({ actor: 'ROOT' }))); assert.throws(() => finiteJson({ get actor() { return 'ROOT'; } }));
  assert.deepEqual(JSON.parse(JSON.stringify(finiteJson({ present: false, unknown: null }))), { present: false, unknown: null });
});
test('native actual emitted output counter and actual decode2048 accounting are required', () => {
  const row = { backend: 'llama.cpp', prefill_strategy: 'full', prefix_tokens: 0, scored_positions: 1, branch_output_tokens: 0, computed_prompt_tokens: 2048, engine_forwards: 1 };
  const response = { metrics: { per_question_native: [row] } }; assert.equal(foldDirectMetrics(response).computed_output_tokens, 0);
  delete row.branch_output_tokens; assert.throws(() => foldDirectMetrics(response)); row.branch_output_tokens = 0; row.engine_forwards = 4;
  assert.throws(() => foldDirectMetrics(response)); row.engine_forwards = 1;
  const partial = partialDirectMetrics([{ request: { op: 'evaluate' }, error: 'invented interrupted request' }]);
  assert.equal(partial.computed_prompt_tokens, null); assert.equal(partial.engine_forwards, null);
});
test('generated accounting preserves partial work and rejects missing actual timings', () => {
  const post = { server_timings: { prompt_n: 2, predicted_n: 3, cache_n: 0 }, actual_tokenized_prompt_count: 2, provider_usage: { prompt_tokens: 2, completion_tokens: 3 } };
  assert.equal(foldServerMetrics([post]).computed_output_tokens, 3); assert.throws(() => foldServerMetrics([post, { error: 'invented disconnect' }]));
  const partial = partialServerMetrics([post, { error: 'invented disconnect' }]); assert.equal(partial.known_generated_tokens, 3); assert.equal(partial.computed_output_tokens, null);
});
test('fresh server profile is exact, flash source tagged and truncation disqualifies', () => {
  const value = serverStderrObservations(logs, { pid: 123456 }); assert.equal(serverProfilePassed(value), true); assert.equal(value.flash_observation, 'enabled');
  assert.equal(value.actual_KV_buffer_MiB_observations.length, 2); assert.equal(serverProfilePassed(serverStderrObservations(logs, { truncated: true })), false);
  assert.equal(serverProfilePassed(serverStderrObservations(logs.replace('61/61', '60/61'))), false);
  assert.equal(serverProfilePassed(serverStderrObservations(logs.replace('n_ctx = 4096', 'n_ctx = 16384'))), false);
  assert.equal(serverProfilePassed(serverStderrObservations(logs + 'type_k = q8_0\n')), false);
  assert.equal(serverProfilePassed(serverStderrObservations(logs + 'kv_unified = true\n')), false);
});
test('ROOT observation deadlines and aborts stop nonreturning callbacks', async () => {
  await assert.rejects(boundedRootObservation(() => new Promise(() => {}), [], { timeoutMs: 5 }), /deadline/);
  const controller = new AbortController(); const pending = boundedRootObservation(() => new Promise(() => {}), [], { signal: controller.signal, timeoutMs: 50 });
  controller.abort(new Error('invented CPU abort')); await assert.rejects(pending, /invented CPU abort/);
  await assert.rejects(boundedRootObservation(() => ({ actor: 'ROOT', invisible: undefined }), [], { timeoutMs: 5 }));
});
test('protected prelaunch failure retains312 nonqualified rows without constructing native adapters', async () => {
  const records = Array.from({ length: 78 }, (_, index) => ({ id: 'invented-' + index, group_id: 'group-' + Math.floor(index / 2), split: 'validation',
    request: { model: 'invented-cpu', state: 'Invented prelaunch context', questions: [{ id: 'q', type: 'score', criteria: ['Invented zero', 'Invented one'] }] }, targets: { q: { answer: 1 } } }));
  const plan = { dataset: { expected_ids: records.map(record => record.id), records: 78, groups: 39 }, runtime_bounds: BOUNDS, conditions: {} };
  const result = await retainPrelaunchFailure({ plan, records, error: new Error('Invented import failure'), evidenceSink: async () => {} });
  assert.equal(result.attempts.length, 312); assert.equal(result.blocks.length, 4); assert.ok(result.attempts.every(row => !row.attempted && row.status === 'unrun'));
  assert.equal(result.improvement_claim_permitted, false); finiteJson(result);
  const retained = { ...result.attempts[0], attempted: true, status: 'completed', native_envelope: { logical_id: PINS.logicalId, error: 'Invented retained native failure' } };
  const partial = await retainPrelaunchFailure({ plan, records, error: new Error('Invented late runner error'), evidenceSink: async () => {}, executionStarted: true, retainedAttempts: [retained] });
  assert.equal(partial.attempts[0], retained); assert.equal(partial.attempts[1].elapsed_ms, null); assert.equal(partial.summary, null);
  assert.equal(partial.improvement_claim_permitted, false); finiteJson(partial);
});
test('perPOST BOS/tokenizer and independent original Jinja parity guard', async () => {
  const body = { messages: [{ role: 'system', content: 'Invented instruction' }, { role: 'user', content: 'Invented context' }] };
  const rendered = 'Invented render' + BOUNDARY; const tokens = [{ id: 2, piece: '<bos>' }, { id: 42, piece: 'Invented' }];
  const localReply = async path => Buffer.from(JSON.stringify(path === '/apply-template' ? { prompt: rendered } : { tokens }));
  const renderOriginal = async () => ({ rendered: '<bos>' + rendered, rendered_sha256: sha256('<bos>' + rendered) });
  const teacherTry = {}; await proveTeacherPrompt({ body, teacherTry, localReply, renderOriginal }); assert.equal(teacherTry.actual_tokenized_prompt_count, 2);
  await assert.rejects(proveTeacherPrompt({ body, teacherTry: {}, localReply, renderOriginal: async () => ({ rendered: 'changed', rendered_sha256: sha256('changed') }) }));
  tokens.push({ id: 2, piece: '<bos>' }); await assert.rejects(proveTeacherPrompt({ body, teacherTry: {}, localReply, renderOriginal }));
});
test('unchanged actual host scorer preserves alpha response and unknown has no correct field', () => {
  const question = { id: 'unknown', type: 'noul', instructions: 'Invented unknown fixture' };
  const record = { request: { questions: [question] }, targets: { unknown: { answer: null } } };
  const response = { answers: { unknown: { type: 'noul', noul: 0.5 } }, metadata: { template_version: PINS.logicalId, logical_prompt_sha256: 'invented' } };
  const original = JSON.stringify(response); const grade = makeHostJudge({ scoreAnswer, scorePrediction })(record, response, 'native');
  assert.equal(grade.correct_judgment, true); assert.equal(grade.completed_clear_decision, false); assert.equal(grade.abstention, true);
  assert.equal(Object.hasOwn(grade.original_quality_grades[0], 'correct'), false); assert.equal(grade.original_quality_grades[0].uncertain, true);
  assert.equal(JSON.stringify(response), original);
});
test('generated adapter retains erase failures ordinals0/1 plus dispatched ordinal2, no network', async () => {
  const proof = await mkdtemp(join(HERE, 'cpu-fixture-generated-')); const priorFetch = globalThis.fetch; let resets = 0, posts = 0, audit = [];
  const prompt = 'Invented RFDT template' + BOUNDARY; const tokens = [{ id: 2, piece: '<bos>' }, { id: 42, piece: 'Invented' }];
  const fakeFetch = async (input, options = {}) => { const url = String(input);
    if (url.endsWith('/health')) return Response.json({ status: 'ok' });
    if (url.endsWith('/v1/models')) return Response.json({ data: [{ id: PINS.modelId }] });
    if (url.endsWith('/slots/0?action=erase')) { if (++resets <= 2) throw new Error('invented erase failure'); return Response.json({ n_erased: 0 }); }
    if (url.endsWith('/apply-template')) return Response.json({ prompt });
    if (url.endsWith('/tokenize')) return Response.json({ tokens });
    assert.ok(url.endsWith('/v1/chat/completions')); posts++; const body = JSON.parse(options.body);
    assert.equal(body.cache_prompt, false); assert.equal(body.id_slot, 0); assert.deepEqual(body.chat_template_kwargs, { enable_thinking: false });
    return Response.json({ model: PINS.modelId, usage: { prompt_tokens: 2, completion_tokens: 3, total_tokens: 5 },
      timings: { prompt_n: 2, predicted_n: 3, cache_n: 0 }, choices: [{ message: { content: 'invented target' } }] }); };
  globalThis.fetch = fakeFetch;
  const source = { id: 'invented-rfdt', group_id: 'invented-group', split: 'validation', request: { model: 'invented-request-model', state: 'Invented source context',
    questions: [{ id: 'q', type: 'choice', instructions: 'Invented question', criteria: [{ id: 'a', description: 'Invented A' }, { id: 'b', description: 'Invented B' }] }] } };
  const labelRfdt = async (input, options) => { const row = JSON.parse((await readFile(input, 'utf8')).trim()); assert.deepEqual(row.targets, {});
    const body = { model: PINS.modelId, temperature: 0, max_tokens: 2048, response_format: { type: 'json_schema', json_schema: { strict: true, schema: {} } },
      messages: [{ role: 'system', content: 'Invented frozen teacher instruction' }, { role: 'user', content: JSON.stringify({ context: source.request.state, questions: source.request.questions }) }] };
    let succeeded = false; for (let ordinal = 0; ordinal < 3; ordinal++) { try { await globalThis.fetch(options.teacherUrl + '/chat/completions', { method: 'POST', body: JSON.stringify(body), signal: options.signal }); succeeded = true; break; } catch { /* mimic unchanged RFDT max3 retry boundary */ } }
    assert.ok(succeeded); await writeFile(options.outputPath, JSON.stringify({ ...row, targets: { q: { answer: 'a' } } }) + '\n', { flag: 'wx' }); return { cache_hits: 0 }; };
  const adapter = await makeGenerativeAdapter({ plan: { generative: { model_id: PINS.modelId } }, proof, audit: async (kind, value) => { finiteJson(value); audit.push(kind); }, labelRfdt,
    originalFetch: fakeFetch, nextTrial: () => 1, renderOriginal: async () => ({ rendered: '<bos>' + prompt, rendered_sha256: sha256('<bos>' + prompt) }),
    observeRootPidGone: async pid => ({ actor: 'ROOT', pid, absent: true, observed_at: '2000-01-01T00:00:00.000Z', method: 'invented no process' }),
    startServerImpl: async () => ({ pid: 123456, failure: () => null, logs: () => logs, ownsListener: async () => true,
      close: async () => ({ pid: 123456, owned_cleanup_complete: true, exit_and_stdio_close_observed: true, native_profile_passed: true }) }) });
  try { const signal = new AbortController().signal; await adapter.initialize(signal); const attempt = { transport: [] };
    const targets = await adapter.run(source, signal, attempt); assert.deepEqual(targets, { q: { answer: 'a' } });
    assert.deepEqual(attempt.teacher_tries.map(row => row.ordinal), [0, 1, 2]); assert.deepEqual(attempt.teacher_tries.map(row => row.dispatched), [false, false, true]);
    assert.ok(attempt.teacher_tries[0].reset_error && attempt.teacher_tries[1].reset_error); assert.equal(attempt.transport.length, 1);
    assert.equal(resets, 3); assert.equal(posts, 1); assert.equal(attempt.accounting_complete, true); assert.equal(attempt.cache_clear_proved, true);
    assert.equal(attempt.actual_work.computed_output_tokens, 3); assert.equal(audit.filter(kind => kind === 'teacher_try').length, 3); finiteJson(attempt);
    const cleanup = await adapter.close(); assert.equal(cleanup.root_pid_gone.absent, true);
  } finally { await adapter.close(); globalThis.fetch = priorFetch; await rm(proof, { recursive: true }); }
});
