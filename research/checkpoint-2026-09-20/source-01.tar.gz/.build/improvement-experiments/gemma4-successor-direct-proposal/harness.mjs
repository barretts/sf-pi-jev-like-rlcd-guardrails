import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { buildSchedule, exactAttemptCoverage, comparisonGates } from './protocol.mjs';

const ACTUAL_PROOF = 'root_attested_actual_native';
const REAL_NOW = () => performance.now();
const message = error => error instanceof Error ? error.message : String(error);
const RESERVED_ATTEMPT_KEYS = new Set([
  'method', 'repetition', 'seed', 'block_index', 'record_id', 'group_id', 'regression',
  'pair_key', 'method_call_index', 'expected_clear_decision', 'expected_questions',
  'attempted', 'status', 'elapsed_ms', 'error', 'raw_grade', 'raw_measurement',
  'correct_judgment', 'completed_clear_decision', 'abstention', 'answers',
]);

function goldFree(record) {
  return {
    id: record.id, group_id: record.group_id, split: record.split,
    ...(record.regression === undefined ? {} : { regression: record.regression }),
    request: JSON.parse(JSON.stringify(structuredClone(record.request))),
  };
}

function questionsFor(record) {
  return record.request.questions.map(question => ({
    id: question.id, type: question.type,
    uncertain: question.type === 'noul' &&
      (!Object.hasOwn(record.targets?.[question.id] ?? {}, 'answer') || record.targets[question.id].answer === null),
  }));
}

function mergeAdapterEvidence(attempt, evidence) {
  for (const [key, value] of Object.entries(evidence)) {
    if (!RESERVED_ATTEMPT_KEYS.has(key)) attempt[key] = value;
  }
}

function explicitFlag(adapterEvidence, grade, key) {
  const values = [adapterEvidence, grade].filter(value => value && Object.hasOwn(value, key)).map(value => value[key]);
  return values.length > 0 && values.every(value => value === true);
}

function rejectAcceptance(attempt, error, status = 'failed') {
  attempt.error = attempt.error ? `${attempt.error}; ${message(error)}` : message(error);
  attempt.correct_judgment = false;
  attempt.completed_clear_decision = false;
  attempt.status = status;
}

export function validateOwnedCleanup(receipt) {
  assert.ok(receipt && typeof receipt === 'object', 'Missing owned cleanup receipt');
  assert.ok(Number.isSafeInteger(receipt.pid) && receipt.pid > 0, 'Owned cleanup requires a positive PID');
  assert.equal(receipt.owned_cleanup_complete, true, 'Missing owned cleanup proof');
  assert.equal(receipt.exit_and_stdio_close_observed, true, 'Missing independent exit and stdio-close observations');
  assert.ok(!receipt.error && !receipt.cleanupError, 'Owned cleanup recorded failure');
  const gone = receipt.root_pid_gone;
  assert.ok(gone && typeof gone === 'object', 'Missing separate ROOT PID-gone receipt');
  assert.equal(gone.actor, 'ROOT', 'PID disappearance must be observed by ROOT');
  assert.equal(gone.pid, receipt.pid, 'PID-gone receipt refers to a different process');
  assert.equal(gone.absent, true, 'Owned PID disappearance is not proved');
  assert.ok(typeof gone.observed_at === 'string' && Number.isFinite(Date.parse(gone.observed_at)), 'PID-gone observation time is missing or invalid');
  assert.ok(typeof gone.method === 'string' && gone.method.trim().length > 0, 'PID-gone observation method is missing');
  return true;
}

// Only the guarded runner supplies actual adapters. CPU callers inject invented
// records, adapters, clocks, and paired summaries; their proof kind cannot qualify.
export async function executeBlocks({
  plan, records, createAdapter, judge, pairedSummary, evidenceSink, proofKind,
  abortSignal, now = REAL_NOW,
}) {
  assert.equal(typeof now, 'function');
  assert.equal(typeof createAdapter, 'function');
  assert.equal(typeof judge, 'function');
  assert.equal(typeof pairedSummary, 'function');
  assert.equal(typeof evidenceSink, 'function');
  assert.equal(plan.dataset.records, 78, 'The matched stage requires 78 records');
  assert.equal(plan.dataset.groups, 39, 'The matched stage requires 39 independent groups');
  assert.equal(records.length, 78, 'The matched stage requires all 78 records');
  assert.equal(new Set(records.map(record => record.group_id)).size, 39, 'Expected 39 distinct input groups');
  assert.ok(records.every(record => record.split === 'validation'), 'Matched stage is VAL only');
  assert.ok(Number.isSafeInteger(plan.runtime_bounds.total_timeout_ms) && plan.runtime_bounds.total_timeout_ms > 0);
  assert.ok(Number.isSafeInteger(plan.runtime_bounds.request_timeout_ms) && plan.runtime_bounds.request_timeout_ms > 0);
  const schedule = buildSchedule(plan.dataset.expected_ids);
  assert.deepEqual(schedule.map(block => block.method), ['native', 'generative', 'generative', 'native']);
  assert.deepEqual(schedule.map(block => block.repetition), [1, 1, 2, 2]);
  assert.equal(schedule.length, 4);
  for (const block of schedule) {
    assert.equal(block.record_ids.length, 78);
    if (Object.hasOwn(block, 'seed')) assert.equal(block.seed, block.repetition === 1 ? 42 : 104771);
  }
  assert.deepEqual(schedule[0].record_ids, schedule[1].record_ids, 'Repetition 1 arms must have the same frozen order');
  assert.deepEqual(schedule[2].record_ids, schedule[3].record_ids, 'Repetition 2 arms must have the same frozen order');
  const byId = new Map(records.map(record => [record.id, record]));
  assert.equal(byId.size, 78, 'Duplicate input record ID');
  assert.deepEqual([...byId.keys()].sort(), [...plan.dataset.expected_ids].sort(), 'Input IDs differ from the frozen plan');

  let lastClock = null; let clockError = null;
  const readClock = () => {
    const value = now();
    if (!Number.isFinite(value) || (lastClock !== null && value < lastClock)) {
      clockError ??= 'Monotonic clock returned a nonfinite or decreasing value';
    }
    if (Number.isFinite(value)) lastClock = value;
    return value;
  };
  const duration = since => {
    const value = readClock() - since;
    return Number.isFinite(value) && value >= 0 ? value : null;
  };
  const attempts = []; const blocks = []; const started = readClock();
  const stageDeadline = AbortSignal.timeout(plan.runtime_bounds.total_timeout_ms);
  const stageSignal = abortSignal ? AbortSignal.any([abortSignal, stageDeadline]) : stageDeadline;
  let cleanupError = null; let auditError = null; let stageAbortError = null; let stopReason = null;
  const methodCalls = { native: 0, generative: 0 };
  const stageFailure = () => {
    if (clockError) return clockError;
    if (stageSignal.aborted) {
      stageAbortError ??= message(stageSignal.reason ?? new Error('Matched stage aborted'));
      return stageAbortError;
    }
    const elapsed = readClock() - started;
    if (clockError) return clockError;
    if (!Number.isFinite(elapsed) || elapsed >= plan.runtime_bounds.total_timeout_ms) {
      stageAbortError ??= 'Matched stage total deadline expired';
      return stageAbortError;
    }
    return null;
  };
  const emit = async (kind, value) => {
    if (auditError) return false;
    try { await evidenceSink(kind, value); return true; }
    catch (error) {
      auditError = message(error);
      stopReason = `Remaining work is unrun after audit failure: ${auditError}`;
      return false;
    }
  };

  for (const [blockIndex, block] of schedule.entries()) {
    const row = {
      block_index: blockIndex + 1, method: block.method, repetition: block.repetition,
      seed: block.repetition === 1 ? 42 : 104771, record_ids: [...block.record_ids],
      initialization_ms: null, initialization_error: null, cleanup: null,
      adapter_created: false, initialization_started: false, run_invocations: 0, errors: [],
    };
    let adapter = null; let initializationError = null;
    const initStarted = readClock();
    try {
      stopReason ??= stageFailure();
      if (stopReason) throw new Error(stopReason);
      adapter = await createAdapter({ ...block, record_ids: [...block.record_ids] }, block.record_ids.map(id => goldFree(byId.get(id))));
      row.adapter_created = true;
      assert.ok(adapter && typeof adapter.initialize === 'function' && typeof adapter.run === 'function' && typeof adapter.close === 'function', 'Invalid owned adapter');
      const failure = stageFailure();
      if (failure) { stopReason ??= failure; throw new Error(failure); }
      row.initialization_started = true;
      await adapter.initialize(stageSignal);
      const afterInitialization = stageFailure();
      if (afterInitialization) { stopReason ??= afterInitialization; throw new Error(afterInitialization); }
    } catch (error) {
      initializationError = message(error);
      row.initialization_error = initializationError;
      row.errors.push({ phase: 'initialization', error: initializationError });
    } finally { row.initialization_ms = duration(initStarted); }

    try {
      for (const recordId of block.record_ids) {
        const record = byId.get(recordId);
        const expectedQuestions = questionsFor(record);
        const attempt = {
          block_index: blockIndex + 1, method: block.method, repetition: block.repetition,
          seed: row.seed, record_id: recordId, group_id: record.group_id,
          regression: record.regression === true, pair_key: `${block.repetition}:${recordId}`,
          method_call_index: ++methodCalls[block.method], expected_questions: expectedQuestions,
          expected_clear_decision: expectedQuestions.every(question => !question.uncertain),
          attempted: false, status: 'unrun', answers: [], transport: [],
          correct_judgment: false, completed_clear_decision: false, abstention: false,
          accounting_complete: false, cache_clear_proved: false,
        };
        // This object contains no golds or gold-derived expectation metadata.
        const adapterEvidence = {
          method: block.method, repetition: block.repetition, record_id: recordId,
          group_id: record.group_id, pair_key: attempt.pair_key, transport: [],
        };
        const sent = readClock(); let requestSignal = null; let grade = null;
        try {
          stopReason ??= stageFailure();
          if (stopReason) throw new Error(stopReason);
          if (initializationError) throw new Error(initializationError);
          const remaining = plan.runtime_bounds.total_timeout_ms - (readClock() - started);
          assert.ok(Number.isFinite(remaining) && remaining > 0, 'Matched stage total deadline expired');
          requestSignal = AbortSignal.any([stageSignal,
            AbortSignal.timeout(Math.max(1, Math.min(plan.runtime_bounds.request_timeout_ms, Math.floor(remaining))))]);
          requestSignal.throwIfAborted();
          attempt.attempted = true; row.run_invocations++;
          const returned = await adapter.run(goldFree(record), requestSignal, adapterEvidence);
          mergeAdapterEvidence(attempt, adapterEvidence);
          grade = await judge(record, returned, block.method);
          assert.ok(grade && typeof grade === 'object', 'Host grader returned no grade');
          attempt.raw_grade = grade;
          attempt.answers = grade.answers ?? [];
          attempt.correct_judgment = grade.correct_judgment === true;
          attempt.completed_clear_decision = grade.completed_clear_decision === true;
          attempt.abstention = grade.abstention === true;
          attempt.accounting_complete = explicitFlag(adapterEvidence, grade, 'accounting_complete');
          attempt.cache_clear_proved = explicitFlag(adapterEvidence, grade, 'cache_clear_proved');
          requestSignal.throwIfAborted();
          const afterRequest = stageFailure();
          if (afterRequest) { stopReason ??= afterRequest; throw new Error(afterRequest); }
          assert.equal(attempt.accounting_complete, true, 'Actual native work accounting incomplete');
          assert.equal(attempt.cache_clear_proved, true, 'Native cache reset not proved');
          assert.ok(Array.isArray(attempt.answers), 'Host grader answers are missing');
          assert.equal(attempt.answers.length, expectedQuestions.length, 'Incomplete host question grading');
          assert.deepEqual(attempt.answers.map(answer => [answer.question_id, answer.type]),
            expectedQuestions.map(question => [question.id, question.type]), 'Host grades differ from the expected question order/types');
          attempt.status = 'completed';
        } catch (error) {
          mergeAdapterEvidence(attempt, adapterEvidence);
          attempt.accounting_complete = explicitFlag(adapterEvidence, grade, 'accounting_complete');
          attempt.cache_clear_proved = explicitFlag(adapterEvidence, grade, 'cache_clear_proved');
          const failure = stageFailure();
          if (failure) stopReason ??= failure;
          rejectAcceptance(attempt, error, attempt.attempted ? 'failed' : 'unrun');
          row.errors.push({ phase: attempt.attempted ? 'attempt' : 'unrun', record_id: recordId, error: attempt.error });
        } finally {
          attempt.raw_measurement = {
            ...(Object.hasOwn(adapterEvidence, 'accounting_complete')
              ? { adapter_accounting_complete: adapterEvidence.accounting_complete } : {}),
            ...(Object.hasOwn(adapterEvidence, 'cache_clear_proved')
              ? { adapter_cache_clear_proved: adapterEvidence.cache_clear_proved } : {}),
            ...(grade && Object.hasOwn(grade, 'accounting_complete')
              ? { grader_accounting_complete: grade.accounting_complete } : {}),
            ...(grade && Object.hasOwn(grade, 'cache_clear_proved')
              ? { grader_cache_clear_proved: grade.cache_clear_proved } : {}),
          };
          attempt.elapsed_ms = duration(sent);
          if (clockError || attempt.elapsed_ms === null) {
            const error = clockError ?? 'Missing elapsed time';
            rejectAcceptance(attempt, error, attempt.attempted ? 'failed' : 'unrun');
            row.errors.push({ phase: 'clock', record_id: recordId, error });
          }
          attempts.push(attempt);
          const auditAlreadyFailed = auditError !== null;
          if (!await emit('attempt', attempt) && !attempt.audit_error) {
            attempt.audit_error = auditError;
            rejectAcceptance(attempt, `Attempt audit could not be retained: ${auditError}`, attempt.attempted ? 'failed' : 'unrun');
            if (!auditAlreadyFailed) row.errors.push({ phase: 'audit', record_id: recordId, error: auditError });
          }
        }
      }
    } finally {
      if (adapter) {
        try {
          row.cleanup = await adapter.close();
          validateOwnedCleanup(row.cleanup);
        } catch (error) {
          row.cleanup_error = message(error); cleanupError ??= row.cleanup_error;
          row.errors.push({ phase: 'cleanup', error: row.cleanup_error });
          stopReason ??= `Remaining work is unrun after owned cleanup failure: ${row.cleanup_error}`;
        }
      }
      row.audit_error = auditError;
      row.stage_abort_error = stageAbortError;
      blocks.push(row);
      const auditAlreadyFailed = auditError !== null;
      if (!await emit('block', row)) {
        row.audit_error = auditError;
        if (!auditAlreadyFailed) row.errors.push({ phase: 'block_audit', error: auditError });
      }
    }
  }

  let fullCoverage = false; let coverageError = null;
  try { fullCoverage = exactAttemptCoverage(attempts, schedule, records) === true; }
  catch (error) { coverageError = message(error); }
  let summary = null; let summaryError = null; const replicateSummaries = [];
  try { summary = await pairedSummary(attempts); } catch (error) { summaryError = message(error); }
  for (const repetition of [1, 2]) {
    try { replicateSummaries.push(await pairedSummary(attempts.filter(attempt => attempt.repetition === repetition))); }
    catch (error) { summaryError ??= message(error); replicateSummaries.push(null); }
  }
  const cleanupProved = !cleanupError && blocks.every(block => !block.adapter_created ||
    (block.cleanup?.owned_cleanup_complete === true && block.cleanup?.exit_and_stdio_close_observed === true && block.cleanup?.root_pid_gone?.absent === true));
  const evidence = {
    proof_kind: proofKind, exact_frozen_artifacts: proofKind === ACTUAL_PROOF,
    host_only_gold_scoring: true, explicit_disabled_thinking_both_arms: proofKind === ACTUAL_PROOF,
    cache_clear_proved_both_arms: attempts.every(attempt => attempt.cache_clear_proved === true),
    actual_native_work_complete: attempts.every(attempt => attempt.accounting_complete === true),
    full_developer_coverage: fullCoverage, single_active_native_gpu_execution: cleanupProved,
    exit_and_stdio_close_observed: cleanupProved, root_pid_gone_proved: cleanupProved,
    audit_complete: !auditError, stage_not_aborted: !stageAbortError,
    monotonic_clock_unmodified: now === REAL_NOW && !clockError &&
      attempts.every(attempt => Number.isFinite(attempt.elapsed_ms) && attempt.elapsed_ms >= 0),
    all_frozen_attempts_executed: attempts.every(attempt => attempt.attempted === true),
    fresh194_qualification_bound: proofKind === ACTUAL_PROOF &&
      plan.qualification_refs !== null && typeof plan.qualification_refs === 'object' &&
      Object.keys(plan.qualification_refs).length === 4,
    root_pid_gone_all_started_blocks: cleanupProved,
    no_audit_failure: !auditError,
  };
  let gates; let gateError = null;
  try { gates = comparisonGates(summary, replicateSummaries, attempts, evidence); }
  catch (error) {
    gateError = message(error);
    gates = { per_repetition: [], aggregate: {}, measurement_qualified: false, passed: false, improvement_claim_permitted: false };
  }
  const stageComplete = fullCoverage && !cleanupError && !auditError && !stageAbortError && !clockError && !summaryError && !gateError &&
    attempts.every(attempt => attempt.attempted === true && attempt.status === 'completed' && !attempt.error);
  if (proofKind !== ACTUAL_PROOF || !stageComplete || !evidence.monotonic_clock_unmodified) {
    gates = { ...gates, measurement_qualified: false, passed: false, improvement_claim_permitted: false };
  }
  return {
    kind: 'gemma4_successor_direct_performance_result', status: stageComplete ? 'completed' : 'incomplete',
    attempts, blocks, summary, replicate_summaries: replicateSummaries, evidence, gates,
    initialization_scope: plan.conditions?.cold_scope ?? 'separate_actual_owned_process_initialization',
    cleanup_error: cleanupError, audit_error: auditError, stage_abort_error: stageAbortError,
    clock_error: clockError, coverage_error: coverageError, summary_error: summaryError, gate_error: gateError,
    improvement_claim_permitted: proofKind === ACTUAL_PROOF && stageComplete &&
      gates.measurement_qualified === true && gates.passed === true && gates.improvement_claim_permitted === true,
  };
}
