import assert from 'node:assert/strict';
import test from 'node:test';
import { executeBlocks, validateOwnedCleanup } from './harness.mjs';
import { finiteJson } from './protocol.mjs';

// All identities, records, counters, PIDs, times, and adapters in this file are
// invented CPU fixtures. No model, dataset, native binary, or actual proof is read.
function inventedRecords() {
  return Array.from({ length: 78 }, (_, index) => {
    const type = ['choice', 'score', 'noul'][index % 3];
    const question = { id: `question-${index}`, type, instructions: `Invented fixture question ${index}` };
    if (type === 'choice') question.criteria = [{ id: 'first', description: 'Invented first option' }, { id: 'second', description: 'Invented second option' }];
    if (type === 'score') question.criteria = ['Invented zero', 'Invented one', 'Invented two'];
    return {
      id: `invented-record-${String(index).padStart(2, '0')}`,
      group_id: `invented-group-${Math.floor(index / 2)}`, split: 'validation',
      regression: index === 0,
      request: {
        model: 'invented-cpu-model', state: `Invented context for group ${Math.floor(index / 2)}`,
        questions: [question], options: { template_version: 'v2' },
      },
      targets: { [question.id]: { answer: type === 'choice' ? 'first' : type === 'score' ? 1 : index % 2 === 0 ? null : true } },
    };
  });
}

function cleanup(pid) {
  return {
    pid, owned_cleanup_complete: true, exit_and_stdio_close_observed: true,
    root_pid_gone: {
      actor: 'ROOT', pid, absent: true, observed_at: '2000-01-01T00:00:00.000Z',
      method: 'invented_CPU_fixture_no_process_observed',
    },
  };
}

function rawGrade(record) {
  const question = record.request.questions[0];
  const uncertain = question.type === 'noul' && record.targets[question.id].answer === null;
  return {
    answers: [{
      question_id: question.id, type: question.type, correct_judgment: true,
      completed_clear_decision: !uncertain, abstention: uncertain,
      normalized_absolute_error: 0, ...(question.type === 'noul' ? { uncertain, squared_error: 0 } : {}),
    }],
    correct_judgment: true, completed_clear_decision: !uncertain, abstention: uncertain,
  };
}

function inventedSummary(attempts) {
  const method = name => {
    const rows = attempts.filter(attempt => attempt.method === name);
    return {
      gates: { passed: true }, attempts: rows.length,
      accepted_correct_judgments: rows.filter(attempt => attempt.correct_judgment).length,
      correct_judgment_rate: 1, completed_clear_decision_rate: 1,
      elapsed_all_attempts_per_accepted_judgment_ms: name === 'native' ? 1 : 3,
    };
  };
  return {
    methods: { native: method('native'), generative: method('generative') },
    paired: {
      improvement_claim_permitted: true, quality_gates_both_passed: true,
      comparable_correctness: true, eligible_clear_pair_completion_coverage: 1,
      conditional_both_correct_generative_over_native_latency: { median: 3 },
      all_attempts_elapsed_per_accepted_judgment_generative_over_native: 3,
    },
  };
}

function fixture(overrides = {}) {
  const records = inventedRecords();
  const plan = {
    dataset: { records: 78, groups: 39, expected_ids: records.map(record => record.id) },
    conditions: { cold_scope: 'invented_CPU_initialization_only' },
    runtime_bounds: { request_timeout_ms: 10_000, total_timeout_ms: 600_000 },
  };
  let tick = 0;
  const context = { initialized: [], ran: [], closed: [], events: [], ordered: [] };
  const args = {
    plan, records, proofKind: 'injected_cpu', now: () => ++tick,
    judge: rawGrade, pairedSummary: inventedSummary,
    evidenceSink: async (kind, value) => { context.events.push({ kind, value }); },
    createAdapter: async (block, orderedRecords) => {
      const blockIndex = context.ordered.length + 1;
      const pid = 50_000 + blockIndex;
      context.ordered.push({ block, records: orderedRecords });
      return {
        initialize: async () => { context.initialized.push(block); },
        run: async (source, signal, attempt) => {
          signal.throwIfAborted(); context.ran.push({ block, source, attempt });
          attempt.accounting_complete = true; attempt.cache_clear_proved = true;
          if (block.method === 'native') attempt.native_response = {
            fixture_kind: 'invented_CPU_response', metrics: {
              computed_prompt_tokens: 17, computed_output_tokens: 0, engine_forwards: 1,
            },
          };
          else attempt.transport.push({
            fixture_kind: 'invented_CPU_POST', dispatched: true, ok: true,
            server_timings: { prompt_n: 17, predicted_n: 3, cache_n: 0 },
          });
          return { fixture_kind: 'invented_CPU_returned_value' };
        },
        close: async () => { context.closed.push(block); return cleanup(pid); },
      };
    },
    ...overrides,
  };
  return { args, context, records, plan };
}

function assertRetained(result) {
  assert.equal(result.attempts.length, 312);
  assert.equal(result.blocks.length, 4);
  assert.equal(new Set(result.attempts.map(attempt => `${attempt.repetition}:${attempt.method}:${attempt.record_id}`)).size, 312);
  assert.deepEqual(result.blocks.map(block => block.method), ['native', 'generative', 'generative', 'native']);
  assert.deepEqual(result.blocks.map(block => block.seed), [42, 42, 104771, 104771]);
  assert.equal(result.attempts.filter(attempt => attempt.method === 'native').length, 156);
  assert.equal(result.attempts.filter(attempt => attempt.method === 'generative').length, 156);
  for (const repetition of [1, 2]) {
    const native = result.attempts.filter(attempt => attempt.repetition === repetition && attempt.method === 'native');
    const generated = result.attempts.filter(attempt => attempt.repetition === repetition && attempt.method === 'generative');
    assert.deepEqual(native.map(attempt => attempt.record_id), generated.map(attempt => attempt.record_id));
    assert.equal(new Set(native.map(attempt => attempt.group_id)).size, 39);
  }
  assert.equal(result.improvement_claim_permitted, false);
  assert.equal(result.gates.measurement_qualified, false);
  assert.equal(result.gates.passed, false);
}

test('invented CPU run retains the exact paired blocks and cannot qualify', async () => {
  const { args, context } = fixture();
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(result.status, 'completed');
  assert.equal(result.evidence.monotonic_clock_unmodified, false);
  assert.equal(result.evidence.full_developer_coverage, true);
  assert.equal(context.initialized.length, 4);
  assert.equal(context.closed.length, 4);
  assert.equal(context.ran.length, 312);
  assert.ok(result.attempts.every(attempt => attempt.attempted && attempt.elapsed_ms > 0));
  const unknown = result.attempts.find(attempt => attempt.expected_questions[0].uncertain);
  assert.equal(unknown.correct_judgment, true);
  assert.equal(unknown.abstention, true);
  assert.equal(unknown.completed_clear_decision, false);
  assert.equal(unknown.raw_grade.correct_judgment, true);
});

test('the default real host clock retains invented CPU coverage without native qualification', async () => {
  const { args, context } = fixture();
  delete args.now;
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(result.status, 'completed');
  assert.equal(result.clock_error, null);
  assert.equal(result.evidence.monotonic_clock_unmodified, true);
  assert.equal(result.evidence.proof_kind, 'injected_cpu');
  assert.equal(result.evidence.exact_frozen_artifacts, false);
  assert.equal(result.evidence.full_developer_coverage, true);
  assert.equal(context.ran.length, 312);
  assert.ok(result.attempts.every(attempt => Number.isFinite(attempt.elapsed_ms) && attempt.elapsed_ms >= 0));
  finiteJson(result);
  assert.deepEqual(JSON.parse(JSON.stringify(result)), result);
});

test('adapters receive no gold targets or gold-derived expectations', async () => {
  const { args, context } = fixture();
  await executeBlocks(args);
  for (const block of context.ordered) {
    for (const record of block.records) {
      assert.equal(Object.hasOwn(record, 'targets'), false);
      assert.equal(Object.hasOwn(record, 'expected_questions'), false);
    }
  }
  for (const { source, attempt } of context.ran) {
    assert.equal(Object.hasOwn(source, 'targets'), false);
    assert.equal(Object.hasOwn(attempt, 'expected_questions'), false);
    assert.equal(Object.hasOwn(attempt, 'expected_clear_decision'), false);
  }
});

test('measurement rejection keeps the raw host grade and invalidates acceptance', async () => {
  const { args, context } = fixture();
  const original = args.createAdapter;
  args.createAdapter = async (...values) => {
    const adapter = await original(...values); const run = adapter.run;
    adapter.run = async (...runValues) => {
      const result = await run(...runValues);
      if (context.ran.length === 1) runValues[2].accounting_complete = false;
      return result;
    };
    return adapter;
  };
  const result = await executeBlocks(args);
  assertRetained(result);
  const first = result.attempts[0];
  assert.equal(first.raw_grade.correct_judgment, true);
  assert.equal(first.correct_judgment, false);
  assert.equal(first.completed_clear_decision, false);
  assert.match(first.error, /accounting incomplete/);
  assert.equal(result.evidence.actual_native_work_complete, false);
  assert.equal(result.status, 'incomplete');
  assert.equal(context.ran.length, 312);
});

test('cache rejection retains failed work without accepting the raw correct grade', async () => {
  const { args } = fixture(); const original = args.createAdapter;
  args.createAdapter = async (...values) => {
    const adapter = await original(...values); const run = adapter.run;
    adapter.run = async (...runValues) => {
      const result = await run(...runValues); runValues[2].cache_clear_proved = false; return result;
    };
    return adapter;
  };
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.ok(result.attempts.every(attempt => attempt.raw_grade.correct_judgment && !attempt.correct_judgment));
  assert.ok(result.attempts.every(attempt => attempt.elapsed_ms > 0 && attempt.error));
  assert.equal(result.evidence.cache_clear_proved_both_arms, false);
});

test('initialization failure is retained and later blocks wait for proven cleanup', async () => {
  const { args, context } = fixture(); const original = args.createAdapter;
  args.createAdapter = async (...values) => {
    assert.equal(context.closed.length, context.ordered.length, 'The previous owned adapter must close before another is constructed');
    const adapter = await original(...values);
    if (context.ordered.length === 1) adapter.initialize = async () => { throw new Error('invented initialization failure'); };
    return adapter;
  };
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(context.closed.length, 4);
  assert.equal(context.ran.length, 234);
  assert.ok(result.attempts.slice(0, 78).every(attempt => !attempt.attempted && attempt.status === 'unrun' && attempt.error));
  assert.equal(result.blocks[0].cleanup.root_pid_gone.absent, true);
  assert.match(result.blocks[0].initialization_error, /invented initialization failure/);
  assert.equal(result.status, 'incomplete');
});

test('cleanup without separate ROOT PID disappearance prevents every later launch', async () => {
  const { args, context } = fixture(); const original = args.createAdapter;
  args.createAdapter = async (...values) => {
    const adapter = await original(...values);
    adapter.close = async () => { context.closed.push(values[0]); return { pid: 50_001, owned_cleanup_complete: true, exit_and_stdio_close_observed: true }; };
    return adapter;
  };
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(context.ordered.length, 1);
  assert.equal(context.ran.length, 78);
  assert.match(result.cleanup_error, /ROOT PID-gone/);
  assert.ok(result.attempts.slice(78).every(attempt => !attempt.attempted && attempt.error));
  assert.equal(result.evidence.single_active_native_gpu_execution, false);
});

test('audit rejection retains all frozen rows, closes the current adapter, and stops launch', async () => {
  let sinkCalls = 0;
  const { args, context } = fixture({ evidenceSink: async () => { sinkCalls++; throw new Error('invented audit failure'); } });
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(sinkCalls, 1);
  assert.equal(context.ran.length, 1);
  assert.equal(context.ordered.length, 1);
  assert.equal(context.closed.length, 1);
  assert.equal(result.attempts[0].raw_grade.correct_judgment, true);
  assert.equal(result.attempts[0].correct_judgment, false);
  assert.ok(result.attempts.every(attempt => attempt.error));
  assert.equal(result.evidence.audit_complete, false);
  assert.match(result.audit_error, /invented audit failure/);
});

test('block audit rejection prevents the next block and preserves completed raw work', async () => {
  const { args, context } = fixture({ evidenceSink: async kind => { if (kind === 'block') throw new Error('invented block audit failure'); } });
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(context.ran.length, 78);
  assert.equal(context.closed.length, 1);
  assert.equal(context.ordered.length, 1);
  assert.ok(result.attempts.slice(0, 78).every(attempt => attempt.raw_grade));
  assert.ok(result.attempts.slice(78).every(attempt => !attempt.attempted && attempt.error));
  assert.match(result.blocks[0].audit_error, /invented block audit failure/);
});

test('abort after adapter return keeps the raw grade, rejects acceptance, and stops all later work', async () => {
  const controller = new AbortController();
  const { args, context } = fixture({ abortSignal: controller.signal }); const original = args.createAdapter;
  args.createAdapter = async (...values) => {
    const adapter = await original(...values); const run = adapter.run;
    adapter.run = async (...runValues) => { const returned = await run(...runValues); controller.abort(new Error('invented stage abort')); return returned; };
    return adapter;
  };
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(context.ran.length, 1);
  assert.equal(context.closed.length, 1);
  assert.equal(context.ordered.length, 1);
  assert.equal(result.attempts[0].raw_grade.correct_judgment, true);
  assert.equal(result.attempts[0].correct_judgment, false);
  assert.ok(result.attempts.every(attempt => attempt.error));
  assert.equal(result.evidence.stage_not_aborted, false);
  assert.match(result.stage_abort_error, /invented stage abort/);
});

test('an already aborted stage retains all rows and never constructs an adapter', async () => {
  const controller = new AbortController(); controller.abort(new Error('invented pre-stage abort'));
  const { args, context } = fixture({ abortSignal: controller.signal });
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(context.ordered.length, 0);
  assert.equal(context.closed.length, 0);
  assert.ok(result.attempts.every(attempt => !attempt.attempted && attempt.status === 'unrun'));
});

test('owned cleanup rejects wrong actor/PID, absent exit, and missing observation details', () => {
  assert.equal(validateOwnedCleanup(cleanup(50_000)), true);
  const mutations = [
    value => { value.pid = 0; },
    value => { value.exit_and_stdio_close_observed = false; },
    value => { value.root_pid_gone.actor = 'adapter'; },
    value => { value.root_pid_gone.pid++; },
    value => { value.root_pid_gone.absent = false; },
    value => { value.root_pid_gone.observed_at = 'invalid'; },
    value => { value.root_pid_gone.method = ''; },
  ];
  for (const mutate of mutations) { const value = cleanup(50_000); mutate(value); assert.throws(() => validateOwnedCleanup(value)); }
});

test('missing host question grades retain score denominators and cannot be accepted', async () => {
  const { args } = fixture({ judge: () => ({ answers: [], correct_judgment: true, completed_clear_decision: true }) });
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.ok(result.attempts.every(attempt => attempt.expected_questions.length === 1 && !attempt.correct_judgment));
  assert.equal(result.attempts.filter(attempt => attempt.method === 'native' && attempt.expected_questions[0].type === 'score').length, 52);
  assert.ok(result.attempts.every(attempt => /Incomplete host question grading/.test(attempt.error)));
  assert.equal(result.gates.aggregate.original_paired_gates, true);
  assert.equal(result.gates.aggregate.expected_score_count, 52);
  assert.equal(result.gates.aggregate.direct_score_correct_count, 0);
  assert.equal(result.gates.aggregate.direct_individual_score_accuracy_min, false);
  assert.equal(result.gates.aggregate.full_question_coverage, false);
  assert.ok(result.gates.per_repetition.every(gate => gate.expected_score_count === 26 && gate.direct_score_correct_count === 0 && !gate.full_question_coverage));
});

test('all successful and all unrun failure rows preserve strict finite JSON serialization', async () => {
  const good = fixture();
  const successful = await executeBlocks(good.args);
  const controller = new AbortController(); controller.abort(new Error('invented serialization fixture abort'));
  const failed = fixture({ abortSignal: controller.signal });
  const failures = await executeBlocks(failed.args);
  for (const result of [successful, failures]) {
    assertRetained(result);
    finiteJson(result);
    assert.deepEqual(JSON.parse(JSON.stringify(result)), result);
    for (const attempt of result.attempts) {
      finiteJson(attempt);
      assert.deepEqual(JSON.parse(JSON.stringify(attempt)), attempt);
      assert.equal(Object.hasOwn(attempt.raw_measurement, 'grader_accounting_complete'), false);
      assert.equal(Object.hasOwn(attempt.raw_measurement, 'grader_cache_clear_proved'), false);
    }
  }
  assert.ok(failures.attempts.every(attempt => attempt.status === 'unrun' && Object.keys(attempt.raw_measurement).length === 0));
  assert.equal(successful.evidence.fresh194_qualification_bound, false);
  assert.equal(successful.evidence.root_pid_gone_all_started_blocks, true);
  assert.equal(successful.evidence.no_audit_failure, true);
});

test('present false and null raw grader flags remain visible and finite', async () => {
  const { args } = fixture({ judge: record => ({
    ...rawGrade(record), accounting_complete: null, cache_clear_proved: false,
  }) });
  const result = await executeBlocks(args);
  assertRetained(result);
  finiteJson(result);
  assert.deepEqual(JSON.parse(JSON.stringify(result)), result);
  for (const attempt of result.attempts) {
    assert.equal(attempt.raw_measurement.adapter_accounting_complete, true);
    assert.equal(attempt.raw_measurement.adapter_cache_clear_proved, true);
    assert.equal(attempt.raw_measurement.grader_accounting_complete, null);
    assert.equal(attempt.raw_measurement.grader_cache_clear_proved, false);
    assert.equal(attempt.raw_grade.accounting_complete, null);
    assert.equal(attempt.raw_grade.cache_clear_proved, false);
    assert.equal(attempt.correct_judgment, false);
    assert.equal(attempt.completed_clear_decision, false);
  }
});

test('comparison retains original paired gates and CPU refs cannot establish fresh qualification', async () => {
  const { args, plan } = fixture({ pairedSummary: attempts => {
    const summary = inventedSummary(attempts);
    summary.paired.improvement_claim_permitted = false;
    return summary;
  } });
  plan.qualification_refs = {
    report: { fixture_kind: 'invented_CPU_reference' },
    stage: { fixture_kind: 'invented_CPU_reference' },
    plan: { fixture_kind: 'invented_CPU_reference' },
    receipt: { fixture_kind: 'invented_CPU_reference' },
  };
  const result = await executeBlocks(args);
  assertRetained(result);
  assert.equal(result.gates.aggregate.original_paired_gates, false);
  assert.ok(result.gates.per_repetition.every(gate => gate.original_paired_gates === false));
  assert.equal(result.gates.aggregate.expected_score_count, 52);
  assert.equal(result.gates.aggregate.direct_score_correct_count, 52);
  assert.equal(result.gates.aggregate.full_question_coverage, true);
  assert.equal(result.evidence.fresh194_qualification_bound, false);
});
