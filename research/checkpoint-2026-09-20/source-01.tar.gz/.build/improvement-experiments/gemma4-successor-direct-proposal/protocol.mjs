import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

// Pure host guards. Importing this module performs no file, process or HTTP work.
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
export const METHODS = Object.freeze(['native', 'generative']);
export const PINS = Object.freeze({
  prospective: '174fb1b26dea9c81398c2bf7183fdfb2e5df33c8722d3445afbbb2f981a4c3e0',
  baselineMetadata: '3bcb91579b7035b43aeb067603cd5c679ee3183f08829a285a5c4cc7bee7211b',
  qualificationMetadata: '2cbb17ca76b32870071cf2e202785e77cec93bafac70d2e9ff5dd7657a8aa9ef',
  input: '4ca805a0eb60be5add66db7c79f673a41141b47b1b309ced228af908ada50ef0', inputBytes: 158054,
  source: 'c0919f79087e4bf3ce4f6332956b79d7b9e9bb415a250288fb47bcecd7ca64b8',
  binary: 'cd437329ecbecbcd3db2fc81b90f22c2b603d77b9f4b97f1abf0861b333fdfd2', binaryBytes: 9671688,
  model: '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b', modelBytes: 17651001568,
  template: 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4',
  profileFile: 'd0e4f0aa97661a9fffbbf80a649b6e8b1add435d76366e3f775504d00b5058c7',
  profile: '48dda5a0b1630b607f0e5c691366ced92843ea43f0d5d4aab9bc62cc2a7416fc',
  profileId: 'gemma4-direct-label-raw-q4-runtime-candidate-1', logicalId: 'v2-earned-half-grid-alpha-research-1',
  grid: '92176c96d6a49a600c281c43578eb55aea20082b0847019bfef64282f7b40872',
  rpc: '8980b01e27b306ebd21f1ad788056f1eb2e5a1a3124f97691ba0e10b16b5f770',
  renderer: 'cd7aa8aa765d5870c7619656bd8009e638f65248107faed2c7fc2c26cf941546',
  qualityRelease: '53533082ec1f142b9ed6a56b905b7153da0bc59a3477917c5304e138b53d3f3d',
  server: 'b866bbcd1d84545b3032787295205ad5a0674fcb62fc28bb8bcef42ed36948bb',
  rfdt: '22043a9e556481d818334854bb057a2368607bb1b0035fc4435abf098c3942f0',
  decision: '17608f6645c240524b6e30a6c5a5f2ec9966de795f78ebe6aec086c3e65e490a',
  evaluation: '061b14257c4ac198a1cb9dd44203ed5cc0ceedf95f1c7b39cf4c27fe6729fe62',
  core: '2ee6c409a12b6a4f7b7a7d63c37d84923740e46f8732f625a65d0f39ef04bdf6',
  modelId: 'google/gemma-4-31B-it-qat-q4_0',
});
export const BOUNDS = Object.freeze({ request_timeout_ms: 600000, total_timeout_ms: 21600000,
  exit_timeout_ms: 10000, max_packet_bytes: 262144, max_native_response_bytes: 67108864,
  max_stderr_bytes: 16777216, http_response_bytes: 4194304, max_audit_bytes: 134217728,
  native_max_requests: 157 });
export const canonical = value => JSON.stringify(sort(value));
function sort(value) { return Array.isArray(value) ? value.map(sort) : value && typeof value === 'object'
  ? Object.fromEntries(Object.keys(value).sort().map(key => [key, sort(value[key])])) : value; }

export function finiteJson(value) {
  const seen = new Set(); let nodes = 0;
  const visit = (item, depth = 0) => {
    assert.ok(++nodes <= 1000000 && depth <= 60, 'JSON structural limit');
    if (item === null || typeof item === 'string' || typeof item === 'boolean') return;
    if (typeof item === 'number') { assert.ok(Number.isFinite(item), 'Nonfinite evidence'); return; }
    assert.ok(item && typeof item === 'object' && !seen.has(item), 'Evidence must be finite acyclic JSON');
    assert.ok(Array.isArray(item) || Object.getPrototypeOf(item) === Object.prototype || Object.getPrototypeOf(item) === null, 'Plain JSON only');
    assert.equal(Object.getOwnPropertySymbols(item).length, 0); seen.add(item);
    for (const [key, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(item))) {
      if (Array.isArray(item) && key === 'length') continue;
      assert.ok(Object.hasOwn(descriptor, 'value') && descriptor.enumerable, 'Evidence accessors/nonenumerable fields forbidden'); visit(descriptor.value, depth + 1);
    }
    seen.delete(item);
  }; visit(value); return value;
}
function shuffled(values, seed) {
  let state = seed >>> 0;
  const random = () => { state += 0x6d2b79f5; let value = Math.imul(state ^ state >>> 15, 1 | state);
    value ^= value + Math.imul(value ^ value >>> 7, 61 | value); return ((value ^ value >>> 14) >>> 0) / 4294967296; };
  const result = [...values]; for (let i = result.length - 1; i > 0; i--) { const j = Math.floor(random() * (i + 1)); [result[i], result[j]] = [result[j], result[i]]; } return result;
}
export function buildSchedule(ids) {
  assert.equal(ids.length, 78); assert.equal(new Set(ids).size, 78);
  return [0, 1].flatMap(rep => { const order = shuffled(ids, 42 + rep * 104729); return (rep ? [...METHODS].reverse() : METHODS)
    .map(method => ({ repetition: rep + 1, seed: 42 + rep * 104729, method, record_ids: [...order] })); });
}
export function exactAttemptCoverage(attempts, schedule, records) {
  assert.equal(attempts.length, 312); assert.deepEqual(schedule, buildSchedule(records.map(record => record.id)));
  const byId = new Map(records.map(record => [record.id, record])); assert.equal(byId.size, 78);
  assert.equal(new Set(records.map(record => record.group_id)).size, 39);
  const expected = schedule.flatMap(block => block.record_ids.map(id => `${block.repetition}:${block.method}:${id}`));
  assert.deepEqual(attempts.map(row => `${row.repetition}:${row.method}:${row.record_id}`), expected, 'Exact frozen ordered 312 coverage');
  for (const row of attempts) { const record = byId.get(row.record_id); assert.equal(row.group_id, record.group_id);
    assert.ok(Number.isFinite(row.elapsed_ms) && row.elapsed_ms >= 0); }
  return true;
}
const counter = (value, name, minimum = 0) => { assert.ok(Number.isSafeInteger(value) && value >= minimum, 'Invalid actual ' + name); return value; };
export function foldDirectMetrics(response, questionCount = 1) {
  const rows = response?.metrics?.per_question_native; assert.equal(rows?.length, questionCount);
  const totals = { computed_prompt_tokens: 0, computed_output_tokens: 0, engine_forwards: 0 };
  for (const row of rows) {
    assert.equal(row.backend, 'llama.cpp'); assert.equal(row.prefill_strategy, 'full'); assert.equal(row.prefix_tokens, 0);
    assert.equal(row.scored_positions, 1); assert.ok(Object.hasOwn(row, 'branch_output_tokens')); assert.equal(row.branch_output_tokens, 0);
    totals.computed_prompt_tokens += counter(row.computed_prompt_tokens, 'native prefill', 1);
    totals.computed_output_tokens += counter(row.branch_output_tokens, 'native emitted output');
    totals.engine_forwards += counter(row.engine_forwards, 'submitted llama_decode calls', 1);
    assert.equal(row.engine_forwards, Math.ceil(row.computed_prompt_tokens / 2048));
  }
  return { ...totals, output_counter_source: 'unchanged native metrics.branch_output_tokens; engine has no generation/sampler path',
    forwards_source: 'unchanged native metrics.engine_forwards: submitted llama_decode calls, not Metal kernels or ubatches' };
}
export function partialDirectMetrics(receipts) {
  const evaluations = receipts.filter(entry => entry.request?.op === 'evaluate');
  const sumKnown = key => evaluations.map(entry => entry.response?.result?.metrics?.[key]).filter(value => Number.isSafeInteger(value) && value >= 0);
  const prompt = sumKnown('computed_prompt_tokens'), output = sumKnown('branch_output_tokens'), forwards = sumKnown('engine_forwards');
  return { submitted_evaluate_requests: evaluations.length, measured_prefill_evaluations: prompt.length, measured_output_evaluations: output.length, measured_forward_evaluations: forwards.length,
    known_computed_prompt_tokens: prompt.reduce((a, b) => a + b, 0), known_generated_tokens: output.reduce((a, b) => a + b, 0), known_submitted_llama_decode_calls: forwards.reduce((a, b) => a + b, 0),
    computed_prompt_tokens: evaluations.length && prompt.length === evaluations.length ? prompt.reduce((a, b) => a + b, 0) : null,
    computed_output_tokens: evaluations.length && output.length === evaluations.length ? output.reduce((a, b) => a + b, 0) : null,
    engine_forwards: evaluations.length && forwards.length === evaluations.length ? forwards.reduce((a, b) => a + b, 0) : null,
    complete_native_contracts_proved: false, source: 'retained actual evaluate RPC replies; missing or partial execution work remains unknown' };
}
export function partialServerMetrics(posts) {
  const measured = key => posts.map(post => post.server_timings?.[key]).filter(value => Number.isSafeInteger(value) && value >= 0);
  const prompts = measured('prompt_n'), generated = measured('predicted_n');
  return { dispatched_posts: posts.length, measured_prefill_posts: prompts.length, measured_generation_posts: generated.length,
    known_computed_prompt_tokens: prompts.reduce((a, b) => a + b, 0), known_generated_tokens: generated.reduce((a, b) => a + b, 0),
    computed_prompt_tokens: posts.length && prompts.length === posts.length ? prompts.reduce((a, b) => a + b, 0) : null,
    computed_output_tokens: posts.length && generated.length === posts.length ? generated.reduce((a, b) => a + b, 0) : null,
    engine_forwards: null, engine_forwards_source: 'server API does not expose submitted llama_decode calls' };
}
export function foldServerMetrics(posts) {
  assert.ok(posts.length > 0 && posts.length <= 3); const partial = partialServerMetrics(posts);
  for (const post of posts) { counter(post.server_timings?.prompt_n, 'server prompt_n', 1); counter(post.server_timings?.predicted_n, 'server predicted_n');
    assert.equal(post.server_timings.cache_n, 0); assert.equal(post.server_timings.prompt_n, post.actual_tokenized_prompt_count);
    assert.equal(post.server_timings.prompt_n, post.provider_usage?.prompt_tokens); counter(post.provider_usage?.completion_tokens, 'provider output');
    assert.equal(post.server_timings.predicted_n, post.provider_usage.completion_tokens); }
  return partial;
}

// The receipt is a NEW semantic ROOT projection. Old candidate/proof receipts cannot qualify it.
export function verifyFresh194Qualification({ receipt, report, stage, plan, refs }) {
  finiteJson(receipt); finiteJson(report); finiteJson(stage); finiteJson(plan);
  assert.equal(receipt?.kind, 'ROOT_successor_full_validation_194_result_attestation');
  assert.equal(receipt.validation_quality_qualified, true); assert.equal(receipt.all_quality_gates_passed, true); assert.equal(receipt.honest_completed_negative, false);
  assert.equal(receipt.approval_effect, 'none'); assert.equal(receipt.no_new_TEST_inference, true); assert.equal(receipt.production_role_approved, false);
  assert.equal(receipt.benchmark_gain_established, false); assert.equal(receipt.full_developer_workflow_gain_established, false);
  for (const [key, hash] of Object.entries({ prototype_source_sha256: PINS.source, binary_sha256: PINS.binary,
    physical_profile_sha256: PINS.profile, physical_profile_file_sha256: PINS.profileFile, raw_model_sha256: PINS.model })) assert.equal(receipt[key], hash);
  assert.equal(receipt.raw_model_bytes, PINS.modelBytes); assert.equal(receipt.logical_id, PINS.logicalId); assert.equal(receipt.research_profile, PINS.profileId);
  for (const [key, receiptKey] of Object.entries({ plan: 'run_plan_sha256', report: 'quality_report_sha256', stage: 'stage_sha256' })) { assert.match(refs?.[key]?.sha256 ?? '', /^[a-f0-9]{64}$/);
    assert.equal(receipt[receiptKey], refs[key].sha256); }
  assert.ok(plan.sources.host.some(identity => identity.sha256 === PINS.grid && identity.path.endsWith('/candidate-2/grid.mjs'))); assert.equal(plan.logical_id, PINS.logicalId); assert.equal(plan.physical_profile_sha256, PINS.profile);
  assert.equal(plan.sources.prototype.sha256, PINS.source); assert.equal(plan.artifacts.binary.sha256, PINS.binary);
  assert.equal(plan.artifacts.model.sha256, PINS.model); assert.equal(plan.artifacts.model.bytes, PINS.modelBytes);
  assert.equal(stage.run_plan_sha256, refs.plan.sha256); assert.equal(stage.passed, true); assert.equal(stage.native_contracts_passed, true);
  assert.equal(stage.root_pid_gone_passed, true); assert.equal(stage.exact_194_envelope_order, true); assert.equal(stage.quality_gates_passed, true);
  assert.equal(stage.actual_native_process_launches, 1); assert.equal(stage.logical_id, PINS.logicalId);
  assert.equal(stage.research_profile, PINS.profileId); assert.equal(stage.physical_profile_sha256, PINS.profile);
  assert.equal(stage.old_proofs_used_to_qualify_changed_candidate, false); assert.equal(stage.held_out_TEST_read, false);
  assert.equal(report.gates.original_contract_passed, true); assert.equal(report.gates.prospective_developer_score_correctness, true); assert.equal(report.gates.passed, true);
  assert.ok(report.prospective_developer_score_correctness.accuracy >= 0.9);
  assert.equal(report.run_envelopes.length, 194); assert.equal(new Set(report.run_envelopes.map(row => row.record_id)).size, 194);
  assert.equal(receipt.records, 194); assert.equal(receipt.independent_groups, 83);
  for (const key of ['original_targets_units_and_gates_unchanged', 'all_194_actual_responses_reconstructed_from_raw_native_logits',
    'all_194_original_Jinja_BOS_and_one_token_guards_verified', 'independent_original_grade_and_all_per_set_and_diagnosis_and_score_gates_reproduced',
    'current_full_source_artifact_model_template_and_prerequisite_hashes_verified', 'independent_exit_and_stdio_close_observed', 'owned_pid_absent',
    'native_full_validation_contracts_attested', 'emitted_flash_effective_field_remains_null']) assert.equal(receipt[key], true);
  assert.equal(receipt.actual_offloaded_layers, 61); assert.equal(receipt.generated_output_tokens, 0); assert.equal(receipt.owned_native_processes, 1);
  assert.equal(receipt.actual_inference_errors, 0); assert.deepEqual(receipt.quality_gates, report.gates);
  assert.deepEqual(receipt.developer_score_correctness, report.prospective_developer_score_correctness);
  assert.equal(receipt.developer_score_correctness.passed, true);
  assert.ok(Number.isSafeInteger(stage.native_pid) && stage.native_pid > 0); assert.equal(receipt.owned_pid, stage.native_pid);
  assert.equal(stage.root_pid_gone_observation?.actor, 'ROOT'); assert.equal(stage.root_pid_gone_observation.pid, stage.native_pid); assert.equal(stage.root_pid_gone_observation.gone, true);
  assert.ok(Number.isFinite(Date.parse(receipt.observed_at))); return true;
}
export function checkRootPermit(planBytes, clearance, rootAuthorization) {
  const plan = JSON.parse(planBytes); finiteJson(plan); finiteJson(clearance);
  assert.equal(rootAuthorization?.actor, 'ROOT'); assert.equal(rootAuthorization?.explicit, true); assert.equal(rootAuthorization.stage, 'successor_matched312_run');
  assert.equal(plan.kind, 'gemma4_successor_direct_matched312_frozen_plan'); assert.equal(plan.status, 'root_frozen'); assert.equal(plan.inference_ready, true);
  assert.equal(plan.prospective_protocol.sha256, PINS.prospective); assert.equal(plan.original_server_profile_metadata.sha256, PINS.baselineMetadata);
  assert.equal(clearance.kind, 'ROOT_successor_direct_matched312_clearance'); assert.equal(clearance.actor, 'ROOT'); assert.equal(clearance.stage_cleared, true);
  assert.equal(clearance.plan_sha256, sha256(planBytes)); assert.equal(clearance.scope, 'full_developer_validation_78_DGGD_312_attempts_only');
  assert.equal(clearance.other_native_gpu_work_idle, true); assert.equal(clearance.held_out_TEST_authorized, false); assert.equal(clearance.production_role_approval, false);
  assert.equal(plan.dataset.records, 78); assert.equal(plan.dataset.groups, 39); assert.equal(plan.dataset.input_sha256, PINS.input);
  assert.deepEqual(plan.schedule, buildSchedule(plan.dataset.expected_ids)); assert.deepEqual(plan.conditions.seeds, [42, 104771]);
  assert.deepEqual(plan.runtime_bounds, BOUNDS); assert.equal(plan.direct.logical_id, PINS.logicalId); assert.equal(plan.direct.source_sha256, PINS.source);
  assert.equal(plan.direct.binary_sha256, PINS.binary); assert.equal(plan.direct.physical_profile_sha256, PINS.profile);
  assert.equal(plan.direct.logical_source_sha256, PINS.grid); assert.equal(plan.direct.physical_profile_file_sha256, PINS.profileFile); assert.equal(plan.direct.research_profile, PINS.profileId);
  assert.equal(plan.artifacts.model.sha256, PINS.model); assert.equal(plan.artifacts.model.bytes, PINS.modelBytes);
  assert.equal(plan.artifacts.binary.sha256, PINS.binary); assert.equal(plan.artifacts.binary.bytes, PINS.binaryBytes); assert.equal(plan.artifacts.template.sha256, PINS.template);
  assert.equal(plan.generative.binary_sha256, PINS.server); assert.equal(plan.generative.context_size, 4096); assert.equal(plan.generative.parallel, 1);
  assert.equal(plan.generative.port, 8089); assert.equal(plan.generative.cache_ram_mib, 0); assert.equal(plan.generative.cache_prompt, false);
  assert.equal(plan.generative.max_tokens, 2048); assert.equal(plan.generative.temperature, 0); assert.equal(plan.generative.model_id, PINS.modelId);
  assert.equal(plan.generative.chat_template_kwargs.enable_thinking, false); assert.equal(plan.generative.production_teacher_tries_max, 3);
  assert.equal(plan.conditions.scope, 'implementation_comparison_not_pure_generation_isolation_not_normal_Pi_workflow');
  return plan;
}
function resultGate(summary, attempts) {
  const expected = attempts.filter(row => row.method === 'native').flatMap(row => row.expected_questions ?? []);
  const native = attempts.filter(row => row.method === 'native');
  let scoreCorrect = 0, returned = 0;
  for (const row of native) { if (row.error) continue; const answers = row.answers ?? [];
    for (const question of row.expected_questions ?? []) { const matches = answers.filter(answer => answer.question_id === question.id && answer.type === question.type);
      if (matches.length === 1) { returned++; if (question.type === 'score' && matches[0].correct_judgment === true) scoreCorrect++; } } }
  const denominator = expected.filter(question => question.type === 'score').length;
  const accuracy = denominator ? scoreCorrect / denominator : null;
  return { original_paired_gates: summary?.paired?.improvement_claim_permitted === true,
    conditional_twofold: Number.isFinite(summary?.paired?.conditional_both_correct_generative_over_native_latency?.median) && summary.paired.conditional_both_correct_generative_over_native_latency.median >= 2,
    all_attempt_twofold: Number.isFinite(summary?.paired?.all_attempts_elapsed_per_accepted_judgment_generative_over_native) && summary.paired.all_attempts_elapsed_per_accepted_judgment_generative_over_native >= 2,
    direct_individual_score_accuracy_min: denominator > 0 && accuracy >= 0.9,
    expected_score_count: denominator, direct_score_correct_count: scoreCorrect, direct_score_accuracy: accuracy,
    full_question_coverage: returned === expected.length && expected.length === native.length };
}
export function comparisonGates(summary, reps, attempts, evidence) {
  const aggregate = resultGate(summary, attempts); const perRepetition = [1, 2].map((rep, index) => resultGate(reps[index], attempts.filter(row => row.repetition === rep)));
  const qualify = row => row.original_paired_gates && row.conditional_twofold && row.all_attempt_twofold && row.direct_individual_score_accuracy_min && row.full_question_coverage;
  const measurement = evidence?.proof_kind === 'root_attested_actual_native' && ['exact_frozen_artifacts', 'host_only_gold_scoring', 'explicit_disabled_thinking_both_arms',
    'cache_clear_proved_both_arms', 'actual_native_work_complete', 'full_developer_coverage', 'single_active_native_gpu_execution', 'monotonic_clock_unmodified',
    'fresh194_qualification_bound', 'root_pid_gone_all_started_blocks', 'no_audit_failure'].every(key => evidence[key] === true);
  const passed = measurement && reps.length === 2 && qualify(aggregate) && perRepetition.every(qualify);
  return { aggregate, per_repetition: perRepetition, measurement_qualified: measurement, passed, improvement_claim_permitted: passed };
}
