import assert from 'node:assert/strict';
import { sha256, PINS, canonical } from './protocol.mjs';

export const BOUNDARY = '<|turn>model\n<|channel>thought\n<channel|>';
export function verifyIndependentRender(reference, requests, requestBytes, runtime) {
  assert.ok(requests.length === 78 || requests.length === 1, 'Only frozen all78 or one actual teacher try');
  assert.equal(reference?.kind, 'gemma4_independent_full_validation_jinja_render'); assert.equal(reference.requests_sha256, sha256(requestBytes));
  assert.equal(reference.original_raw_template_sha256, PINS.template); assert.equal(reference.original_raw_template_bytes, 18683);
  assert.equal(reference.native_or_model_execution, false); assert.equal(canonical(reference.runtime_identity), canonical(runtime));
  assert.equal(reference.python_jinja_version, '3.1.6'); assert.equal(reference.rows?.length, requests.length);
  assert.equal(reference.render_options?.enable_thinking, false); assert.equal(reference.render_options.add_generation_prompt, true);
  assert.equal(reference.render_options.bos_token, '<bos>'); assert.equal(reference.render_options.eos_token, ''); assert.equal(reference.render_options.tools_argument_supplied, false);
  const seen = new Set();
  for (const [index, request] of requests.entries()) { const row = reference.rows[index], messages = request.branch.messages;
    const key = row.record_id + ':' + row.branch_id; assert.ok(!seen.has(key)); seen.add(key);
    assert.equal(row.record_id, request.record_id); assert.equal(row.branch_id, request.branch.branch_id);
    assert.equal(row.logical_messages_sha256, sha256(JSON.stringify(messages))); assert.equal(row.answer_prefix, request.branch.answer_prefix);
    const merged = messages.length > 1 && messages.at(-1).role === 'user' && messages.at(-2).role === 'user';
    assert.equal(row.final_two_user_messages_merged, merged); assert.equal(row.messages_before, messages.length); assert.equal(row.messages_after, messages.length - Number(merged));
    assert.equal(typeof row.rendered, 'string'); assert.equal(row.rendered_sha256, sha256(row.rendered)); assert.ok(row.rendered.startsWith('<bos>'));
    assert.equal(row.rendered.split('<bos>').length, 2); assert.ok(row.rendered.endsWith(BOUNDARY + request.branch.answer_prefix));
  } return true;
}
// The injected renderer must use the unchanged original Jinja file. No defaults execute it.
export async function proveTeacherPrompt({ body, teacherTry, localReply, signal, renderOriginal }) {
  signal?.throwIfAborted(); assert.equal(typeof renderOriginal, 'function');
  const template = JSON.parse(await localReply('/apply-template', { method: 'POST', headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ messages: body.messages, add_generation_prompt: true, chat_template_kwargs: { enable_thinking: false } }) }, signal));
  teacherTry.apply_template_response = template;
  assert.equal(typeof template.prompt, 'string'); assert.ok(!template.prompt.includes('<bos>')); assert.ok(template.prompt.endsWith(BOUNDARY));
  const tokenized = [];
  for (const [content, add_special] of [[template.prompt, true], ['<bos>' + template.prompt, false]]) {
    signal?.throwIfAborted(); tokenized.push(JSON.parse(await localReply('/tokenize', { method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ content, add_special, parse_special: true, with_pieces: true }) }, signal)));
  }
  teacherTry.server_automatic_BOS_tokenization = tokenized[0]; teacherTry.original_explicit_BOS_tokenization = tokenized[1];
  assert.ok(Array.isArray(tokenized[0].tokens) && tokenized[0].tokens.length > 0 && tokenized[0].tokens.length <= 4096);
  assert.deepEqual(tokenized[0].tokens, tokenized[1].tokens, 'Original explicit and automatic BOS tokens must match');
  assert.equal(tokenized[0].tokens[0].id, 2); assert.equal(tokenized[0].tokens[0].piece, '<bos>');
  assert.equal(tokenized[0].tokens.filter(token => token.id === 2).length, 1);
  const reference = await renderOriginal(body.messages, signal, teacherTry);
  teacherTry.independent_Jinja_row = reference;
  assert.equal(reference.rendered, '<bos>' + template.prompt); assert.equal(reference.rendered_sha256, sha256(reference.rendered));
  assert.ok(reference.rendered.endsWith(BOUNDARY)); signal?.throwIfAborted();
  teacherTry.actual_tokenized_prompt_count = tokenized[0].tokens.length;
  teacherTry.BOS_tokenization_proved = true; teacherTry.original_Jinja_parity_proved = true;
  teacherTry.no_hidden_server_prompt_change_proved = true;
  return teacherTry;
}

export function serverStderrObservations(logs, { truncated = false, pid = null } = {}) {
  assert.equal(typeof logs, 'string');
  const offloads = [...logs.matchAll(/offloaded (\d+)\/(\d+) layers to GPU/g)].map(match => ({ offloaded: +match[1], total: +match[2] }));
  const setting = name => { const values = [...logs.matchAll(new RegExp('\\b' + name + '\\s*=\\s*(\\d+)', 'g'))].map(match => +match[1]);
    return values.length && values.every(value => value === values[0]) ? values[0] : null; };
  const assignments = names => [...logs.matchAll(new RegExp('\\b(' + names + ')\\s*=\\s*(?:"([^"]*)"|\'([^\']*)\'|([^\\s,;]+))', 'g'))]
    .map(match => ({ key: match[1], value: match[2] ?? match[3] ?? match[4], source_text: match[0] }));
  const explicitDtypes = assignments('type_k|type_v');
  const explicitMentions = [...logs.matchAll(/\btype_(?:k|v)\s*=/g)].length;
  const summaryDtypes = logs.split('\n').filter(line => /\bllama_kv_cache:\s*size\s*=/.test(line)).map(line => {
    const header = line.match(/\bllama_kv_cache:\s*size\s*=\s*([0-9]+(?:\.[0-9]+)?)\s*MiB\s*\(\s*(\d+)\s*cells,\s*(\d+)\s*layers,\s*(\d+)\/(\d+)\s*seqs\s*\)/);
    return { source_line: line, buffer_identity: header ? header.slice(2).map(Number).join(':') : null,
      K: [...line.matchAll(/\bK\s*\(\s*([a-zA-Z0-9_]+)\s*\)\s*:/g)].map(match => match[1]),
      V: [...line.matchAll(/\bV\s*\(\s*([a-zA-Z0-9_]+)\s*\)\s*:/g)].map(match => match[1]) };
  });
  const explicitComplete = explicitMentions === explicitDtypes.length && (!explicitMentions ||
    explicitDtypes.some(row => row.key === 'type_k') && explicitDtypes.some(row => row.key === 'type_v'));
  // This frozen baseline has two KV buffers. Missing/duplicate summary sides or a missing buffer cannot prove both dtypes.
  const summariesComplete = !summaryDtypes.length || summaryDtypes.length === 2 &&
    new Set(summaryDtypes.map(row => row.buffer_identity)).size === 2 && summaryDtypes.every(row => row.buffer_identity !== null && row.K.length === 1 && row.V.length === 1);
  const allDtypes = [...explicitDtypes.map(row => row.value), ...summaryDtypes.flatMap(row => [...row.K, ...row.V])];
  const f16 = explicitComplete && summariesComplete && allDtypes.length > 0 && allDtypes.every(value => value === 'f16');
  const unifiedAssignments = assignments('kv_unified');
  const unifiedMentions = [...logs.matchAll(/\bkv_unified\s*=/g)].length;
  const unifiedValues = unifiedAssignments.map(row => row.value === '1' || row.value === 'true' ? true : row.value === '0' || row.value === 'false' ? false : null);
  const unified = unifiedMentions === unifiedAssignments.length && unifiedValues.length && unifiedValues.every(value => value !== null && value === unifiedValues[0]) ? unifiedValues[0] : null;
  const enabled = /resolve_fused_ops: Flash Attention enabled/.test(logs), disabled = /resolve_fused_ops: Flash Attention disabled/.test(logs);
  const kv = [...logs.matchAll(/([^\n]*\b(?:KV|llama_kv_cache)[^\n]*?(?:buffer|size)[^\n]*?)([0-9]+(?:\.[0-9]+)?)\s*MiB/gi)].map(match => ({ line: match[0], MiB: +match[2] }));
  return { source: 'fresh_owned_server_stdout_and_stderr_after_cleanup', pid, logs_sha256: sha256(logs), logs_bytes: Buffer.byteLength(logs), truncated,
    offload_observations: offloads, exact_61_of_61_Metal_offload: !truncated && offloads.length === 1 && offloads[0].offloaded === 61 && offloads[0].total === 61 && /(?:MTL\d|Metal)/.test(logs),
    actual_n_ctx: setting('n_ctx'), actual_n_batch: setting('n_batch'), actual_n_ubatch: setting('n_ubatch'), actual_KV_f16_observed: f16,
    actual_KV_dtype_observations: { explicit_settings: explicitDtypes, buffer_summaries: summaryDtypes, explicit_complete: explicitComplete, summaries_complete: summariesComplete },
    actual_kv_unified_observations: unifiedAssignments,
    actual_kv_unified: unified, flash_requested: 'AUTO', flash_observation: enabled && !disabled ? 'enabled' : disabled && !enabled ? 'disabled' : enabled && disabled ? 'ambiguous' : 'unknown',
    flash_observation_source: 'fresh owned server logs; prior observations do not establish this process setting', actual_KV_buffer_MiB_observations: kv,
    requested_profile: { n_ctx: 4096, n_batch: 2048, n_ubatch: 512, parallel: 1, cache_type_k: 'f16', cache_type_v: 'f16', cache_ram_mib: 0 },
    quality_or_gain_proven: false };
}
export function serverProfilePassed(observations) {
  return observations?.truncated === false && observations.exact_61_of_61_Metal_offload === true && observations.actual_n_ctx === 4096 &&
    observations.actual_n_batch === 2048 && observations.actual_n_ubatch === 512 && observations.actual_KV_f16_observed === true && observations.actual_kv_unified === false;
}
