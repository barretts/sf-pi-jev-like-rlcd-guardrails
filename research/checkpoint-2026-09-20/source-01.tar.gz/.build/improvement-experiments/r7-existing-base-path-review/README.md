The original pinned Google Gemma 3 1B HF base used by R6 remains local at:

```text
/Users/bsonntag/code/simple-jev-ts/.build/hf-session-1_s2hbhu/home/hub/models--google--gemma-3-1b-it/snapshots/dcc83ea841ab6100d6b47a070329e1ba4cf78752
```

R6 job model/path metadata and its recorded train/export arguments both identify this exact snapshot. This is the existing original base directory for a later fresh R7 run. The directory contains the original tokenizer.json, tokenizer.model, tokenizer_config.json, special_tokens_map.json and added_tokens.json filenames. No tokenizer payload was loaded or inspected. The 1,156,999-byte tokenizer_config.json was statted only because it exceeds this review's conservative 256 KiB metadata bound; its SHA is intentionally unverified here.

The 899-byte original config has SHA256 `19cb5d28c97778271ba2b3c3df47bf76bdd6706724777a2318b3522230afe91e`. It declares unquantized gemma3_text, 26 layers, hidden size 1152, intermediate size 6912, 4 attention heads, 1 KV head, head dimension 256, vocabulary 262144 and BF16. The 662-byte special-token map has SHA256 `2f7b0adf4fb469770bb1490e3e35df87b1dc578246c5e7e6fc76ecf33213a397`.

R6's `run/fused` directory is a derived output. Its 5,100-byte RFDT fused manifest declares `fused:true` and `fusion_dtype:float32`; it lacks the base manifest needed for a local base outside the approved snapshot layout. Its config retains the architecture and BF16 declaration, so config dimensions or dtype alone cannot establish original checkpoint identity. Do not substitute that directory for the original base.

The normal `/Users/bsonntag/.cache/huggingface/hub` root exists but has no direct `models--google--gemma-3-1b-it` repository directory. TS `.build/models` does not exist. The bounded search found the original at the explicit R6 snapshot path; it was not an exhaustive search of the host. Reviewed native prompt preparation uses the separate GGUF at `/Users/bsonntag/code/simple-jev-ts/models/gemma-3-1b-it-f16.gguf`.

Current source requires Python 3.13, MLX 0.32.2, Transformers 5.11.0 and pinned MLX-LM commit `9d1e356e7cc6549e7d1697adabe2ea01ff8e062c`. The Gemma base/revision are fixed, maximum prompt length is 2048 with no truncation, and training uses query/value LoRA across 26 layers with seed 42, rank 16, scale 2, dropout 0, batch 1, accumulation 8 and Adam learning rate 1e-4. R7 must use its already-frozen 970 TRAIN stage and frozen step count rather than inheriting an old 570-row stage or R6's 512 steps implicitly.

Root identifies the frozen R7 protocol at `.build/improvement-experiments/evidence-supervision-comparison/protocol.json`. This review neither reads nor changes it. Root reports one intentional dependency drift: dist/evaluation.js changed from the `ea38daad` SHA prefix to `061b14257c4ac198a1cb9dd44203ed5cc0ceedf95f1c7b39cf4c27fe6729fe62`, with the scorer exported and its body identical at TS commit 80de0e6. That statement is root-provided metadata, not a Git/source comparison performed here. A runner binding the old protocol's dist needs new explicit root source clearance for the unchanged training semantics and current exported scorer. Preserve the frozen protocol; do not silently rebind it to current sources.

Existing local paths are resolved before any HF snapshot-download branch. Both train and export need the explicit model path; export does not automatically reuse the recorded training path. There is no worker offline CLI flag. The future root launch should set `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1` and `HF_DATASETS_OFFLINE=1` and retain the explicit path. No login, access change or download is required by this path review.

The commands below are a plan only. Root must first supply R7_RUN and R7_STEPS from its frozen plan, complete the authoritative benchmark/GPU checks and grant execution:

```sh
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 node /Users/bsonntag/code/simple-jev-ts/dist/cli.js rfdt train --run "$R7_RUN" --steps "$R7_STEPS" --model-path /Users/bsonntag/code/simple-jev-ts/.build/hf-session-1_s2hbhu/home/hub/models--google--gemma-3-1b-it/snapshots/dcc83ea841ab6100d6b47a070329e1ba4cf78752 --python /Users/bsonntag/code/simple-jev-ts/.build/rfdt-venv/bin/python
HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 HF_DATASETS_OFFLINE=1 node /Users/bsonntag/code/simple-jev-ts/dist/cli.js rfdt export --run "$R7_RUN" --model-path /Users/bsonntag/code/simple-jev-ts/.build/hf-session-1_s2hbhu/home/hub/models--google--gemma-3-1b-it/snapshots/dcc83ea841ab6100d6b47a070329e1ba4cf78752 --python /Users/bsonntag/code/simple-jev-ts/.build/rfdt-venv/bin/python
```

The next minimal root checks are: authoritative benchmark terminal/GPU clearance; explicit source clearance accounting for the scorer export without changing the frozen protocol; exact frozen 970 TRAIN count and isolation; fresh R7 output directory; source/dist/controller bindings; pinned runtime/converter availability; and offline full per-file, tokenizer, weight and parity checks after the 312 lane closes. This review deliberately performed no weight verification, model/tokenizer/native imports or calls, target/prediction/log/result/held-out inspection, environment/credential reading, process/Git/network operations or existing-source writes. It grants no launch permission.
