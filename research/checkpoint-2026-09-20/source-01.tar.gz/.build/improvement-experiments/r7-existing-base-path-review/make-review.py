#!/usr/bin/env python3
"""Bounded source and metadata review; no model/tokenizer/tensor operations."""

import hashlib
import json
from pathlib import Path

ROOT = Path("/Users/bsonntag/code/simple-jev-ts")
OUT = Path(__file__).resolve().parent
REVISION = "dcc83ea841ab6100d6b47a070329e1ba4cf78752"
BASE = ROOT / f".build/hf-session-1_s2hbhu/home/hub/models--google--gemma-3-1b-it/snapshots/{REVISION}"
R6 = ROOT / ".build/improvement-experiments/rfdt-round-6"
FUSED = R6 / "run/fused"
TINY_BOUND = 256 * 1024


def tiny_metadata(path, selected):
    size = path.stat().st_size
    assert size <= TINY_BOUND, f"Tiny metadata bound exceeded: {path}"
    raw = path.read_bytes()
    document = json.loads(raw)
    return {
        "path": str(path), "resolved_path": str(path.resolve()), "size_bytes": size,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "selected_metadata": {key: document[key] for key in selected if key in document},
    }


architecture = [
    "model_type", "architectures", "num_hidden_layers", "hidden_size", "intermediate_size",
    "num_attention_heads", "num_key_value_heads", "head_dim", "vocab_size", "torch_dtype",
    "quantization", "quantization_config",
]
original_config = tiny_metadata(BASE / "config.json", architecture)
expected = {"model_type": "gemma3_text", "num_hidden_layers": 26, "hidden_size": 1152,
            "intermediate_size": 6912, "num_attention_heads": 4, "num_key_value_heads": 1,
            "head_dim": 256, "vocab_size": 262144}
assert all(original_config["selected_metadata"][key] == value for key, value in expected.items())
assert not original_config["selected_metadata"].get("quantization")
assert not original_config["selected_metadata"].get("quantization_config")
special = tiny_metadata(BASE / "special_tokens_map.json", ["bos_token", "eos_token", "pad_token", "unk_token", "image_token"])
derived_config = tiny_metadata(FUSED / "config.json", architecture)
derived_manifest = tiny_metadata(FUSED / "rfdt-fused-manifest.json", ["fused", "fusion_dtype", "format", "output_dir"])

# Only project allowed model/path/run-parameter metadata from the existing job.
# Do not copy or report its training/validation/results/progress fields.
job_path = R6 / "job.json"
assert job_path.stat().st_size < 1024 * 1024
job = json.loads(job_path.read_text())
allowed = ["base_model", "base_revision", "base_model_path", "round", "steps",
           "run_directory", "fresh_base", "old_adapter_used", "offline"]
r6_metadata = {key: job[key] for key in allowed if key in job}
assert r6_metadata["base_model"] == "google/gemma-3-1b-it"
assert r6_metadata["base_revision"] == REVISION
assert r6_metadata["base_model_path"] == str(BASE)
command_flags = {"--model-path", "--model", "--model-file", "--steps", "--python"}
commands = []
for entry in job.get("phase_history", []):
    if entry.get("phase") in {"prepare", "train", "export"}:
        argv = entry["command"]
        parameters = {arg: argv[index + 1] for index, arg in enumerate(argv[:-1]) if arg in command_flags}
        commands.append({"phase": entry["phase"], "parameters": parameters})
assert all(entry["parameters"]["--model-path"] == str(BASE) for entry in commands if entry["phase"] in {"train", "export"})
del job

tokenizer_paths = {
    name: {"path": str(BASE / name), "resolved_path": str((BASE / name).resolve()), "present": (BASE / name).is_file()}
    for name in ["tokenizer.json", "tokenizer.model", "tokenizer_config.json", "special_tokens_map.json", "added_tokens.json"]
}
tokenizer_paths["tokenizer_config.json"].update({
    "size_bytes": (BASE / "tokenizer_config.json").stat().st_size,
    "contents_read": False, "sha256": None,
    "read_status": "not read or hashed because its 1,156,999 bytes exceed the conservative tiny metadata bound",
})
assert all(entry["present"] for entry in tokenizer_paths.values())
assert (BASE / "model.safetensors").is_file()  # Filesystem existence only; no tensor bytes or hash.
normal_cache = Path("/Users/bsonntag/.cache/huggingface/hub")
proof = {
    "review": "R7 already-local original base paths and source prerequisites only",
    "original_base": {"path": str(BASE), "resolved_path": str(BASE.resolve()),
                      "model": "google/gemma-3-1b-it", "revision": REVISION,
                      "config": original_config, "special_tokens_map": special,
                      "tokenizer_paths": tokenizer_paths, "tensor_filename_present": "model.safetensors",
                      "weight_contents_read": False, "weight_hash_computed": False,
                      "safetensors_index_present": (BASE / "model.safetensors.index.json").is_file()},
    "r6_allowed_metadata": r6_metadata,
    "r6_recorded_command_parameters": commands,
    "derived_output": {"path": str(FUSED), "config": derived_config, "manifest": derived_manifest,
                       "rfdt_base_manifest_present": (FUSED / "rfdt-base-manifest.json").is_file(),
                       "use_as_fresh_base": False},
    "bounded_search": {
        "ts_build_models_exists": (ROOT / ".build/models").is_dir(),
        "reviewed_native_gguf_path": str(ROOT / "models/gemma-3-1b-it-f16.gguf"),
        "normal_cache_root": str(normal_cache), "normal_cache_root_exists": normal_cache.is_dir(),
        "google_gemma_3_1b_repository_present_directly_in_normal_cache": (normal_cache / "models--google--gemma-3-1b-it").is_dir(),
        "original_snapshot_found_in_explicit_r6_path": True,
        "search_was_exhaustive_for_host": False,
    },
    "source_sha256": {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in [ROOT / "rfdt/worker.py", ROOT / "src/rfdt.ts"]},
    "r7_expected_optimizer_rows_from_root_directive": 970,
    "frozen_r7_protocol_from_root_directive": {
        "path": str(ROOT / ".build/improvement-experiments/evidence-supervision-comparison/protocol.json"),
        "read_or_changed_by_review": False,
        "root_reported_intentional_dependency_drift": {
            "file": "dist/evaluation.js", "old_sha256_prefix": "ea38daad",
            "new_sha256": "061b14257c4ac198a1cb9dd44203ed5cc0ceedf95f1c7b39cf4c27fe6729fe62",
            "basis": "Root reports exported scorer with identical body at TS commit80de0e6; not independently verified by this bounded review",
        },
        "silent_protocol_rebinding_permitted": False,
    },
    "offline_flags_for_later_root_launch": {"HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1"},
    "next_root_only_checks": [
        "Wait for authoritative frozen 312 benchmark terminal status and grant the exclusive GPU slot.",
        "Obtain new explicit root source clearance for unchanged training semantics/current exported scorer if the runner binds the protocol's old dist; preserve the old frozen protocol rather than silently rebinding it.",
        "Bind the frozen R7 stage and parameters; verify exactly 970 TRAIN optimizer rows and no validation/test rows.",
        "Use the exact existing original snapshot path for both train and export, with no old adapter.",
        "After the 312 lane closes, root must perform offline full per-file/tokenizer/weight integrity and parity checks against the existing cached original and established checksum.",
        "Use a fresh R7 run directory; preserve R6, canceled rounds, old student and held-out evidence.",
        "Verify pinned Python/dependencies/converter and frozen source/dist bindings without installing or downloading anything.",
    ],
    "model_or_tokenizer_imports_or_calls": 0, "gpu_calls": 0, "network_calls": 0,
    "credentials_or_environment_read": False, "training_or_heldout_contents_read": False,
    "source_mutations": False, "launch_permission_granted_by_review": False,
}
path = OUT / "existing-base-path-proof.json"
with path.open("x") as handle:
    handle.write(json.dumps(proof, indent=2) + "\n")
print(json.dumps({"proof": str(path), "base": str(BASE), "architecture_matches": True,
                  "r6_train_export_paths_match": True, "model_calls": 0,
                  "source_sha256": proof["source_sha256"]}))
