# Prospective fractional-score label hypothesis

Status: source/CPU audit only. No product code, prompt template, model, tokenizer,
native engine, optimizer input, qualified profile, benchmark, or validation run
was changed or executed. The frozen Gemma 4 comparison is outside this audit.
The previously reported aggregate normalized score MAE of 0.048 is a supplied
premise, not a result independently inspected here.

## What the permitted sources establish

- `src/core.ts` accepts 2–50 ordered rubric entries. Their public score scale is
  the zero-based ordinal range `0..criteria.length - 1`. `preparePrompt` makes one
  candidate per integer rubric index, using numeric output labels through ten
  levels and alphabetic labels beyond that. Output labels and answer identities
  are separate arrays.
- `buildResponse` applies stable softmax only over the selected label logits and
  returns `sum(p[i] * i)`. This score is already continuous between zero and the
  original rubric maximum. The advanced fields explicitly say
  `calibrated: false`, `scoring: direct_level_logits`, and
  `score_mapping: label_to_zero_based_level`; response metadata says
  `calibration: not_calibrated`. Confidence is the largest selected-label
  probability, not a calibrated measure of scoring accuracy.
- `src/evaluation.ts` permits finite numeric gold answers anywhere within the
  original range, including half points. A score answer is individually correct
  when `abs(prediction - target) / originalMaximum <= 0.1`. The quality gate uses
  the *mean* of those errors, also with threshold 0.1. An aggregate pass does not
  prove every score answer passes. Known regression records must individually
  pass all their answers.
- The explicitly permitted `developer-evidence-train.jsonl` is entirely TRAIN:
  240 records in 90 groups. There are 120 score answers in 30 source groups,
  including 32 fractional answers in eight groups: 12 targets of 0.5 and 20 of
  1.5. The score maxima are 2, 3, and 4. The instructions explicitly distinguish
  fractional earned work from confidence and permit half credit only under
  stated condition rules. The accompanying notes retain existing thresholds and
  require complete validation coverage and no automatic TEST or permanent
  approval.
- `tests/core.test.ts` checks score label/index mapping at 2, 10, 11, and 50
  levels and rejects malformed/nonfinite logit rows. Those CPU checks do not
  establish that any newly proposed label is a valid single token for a model.

## Bounded hypothesis

A half-point *internal categorical grid* is a legitimate research hypothesis
for rubrics whose instructions explicitly permit half credit. Give each
permitted score value a distinct output label, tell the model what earned point
value that label denotes, and compute an expectation over those original-scale
values. For maximum `m`, a full half grid would have values
`v[j] = j / 2` for `j = 0..2*m`, with score
`sum(p[j] * v[j])` and variance `sum(p[j] * (v[j] - score)^2)`.

The hypothesized benefit is that an explicit earned score such as 0.5 can be the
meaning of one high-probability candidate, rather than needing a specific
mixture over integer meanings. This is a representation/prompt and possibly
training-target hypothesis. It is not a proof that the current logits caused a
particular error, and it is not probability calibration. Additional labels can
also worsen ranking, label bias, or probability mass allocation.

The arithmetic makes the distinction clear without any model inference:
current integer values `[0, 1, 2]` with probabilities `[0.5, 0.5, 0]` already give
score 0.5. A half grid can give the same score with all mass on its 0.5 candidate.
Uniform probabilities give the rubric midpoint in either grid; simply adding
bins does not solve incorrect evidence judgments. A finer grid therefore does
not fix a numerical quantization limitation in the existing expectation.

## Constraints that keep a prospective experiment minimal and honest

1. Keep the submitted public rubric and its original maximum unchanged. Do not
   insert synthetic entries into `request.questions[].criteria`: that would
   change both the public ordinal scale and the evaluation denominator. Map
   internal candidate labels back to explicit original-scale values instead of
   multiplying their grid indices by one.
2. Derive permitted intermediate meanings from public rubric/instruction
   semantics only. The TRAIN records expressly permit half credit; arbitrary
   ordered rubrics need not. A proposed universal midpoint policy would add a
   semantic assumption and require its own justification.
3. Treat the proposed labels as categorical symbols, separate from numeric
   point values. A decimal spelling such as `0.5` is not evidence of a one-token
   label. The existing one-token guard must remain authoritative, check every
   proposed label in its actual answer-prefix context for the selected model,
   and reject unsupported labels rather than silently generating a decimal or
   dropping candidates. No tokenizer or vocabulary viability was inspected.
4. Preserve zero generated output tokens and direct selected-label scoring.
   More evaluated candidates need not require generation, but source arithmetic
   alone does not prove the native implementation supports this revised plan.
   This audit did not inspect or exercise the guard or engine.
5. Bound vocabulary size explicitly. A full half grid has `2*m + 1` candidates.
   The permitted TRAIN maxima 2–4 need only 5–9 candidates, while a public
   50-level rubric would need 99. The current compiler has only 50 alphabetic
   symbols. Do not claim general 2–50-rubric support without a separate approved
   design for capacity, unique labels, and token viability. Restricting a first
   experiment to the known small score ranges is a defensible research bound,
   not an implemented product restriction.
6. Resolve response semantics before implementation. Current probability/logit
   keys and legend refer to original integer levels. Exposing fractional keys
   would change those public fields. Collapsing half-bin mass back to adjacent
   integer levels can preserve the expectation and original probability keys,
   but those probabilities would be derived, and raw logits would no longer map
   directly to original levels. Either choice needs truthful mapping metadata
   and a deliberate compatibility decision; neither can retain misleading
   `direct_level_logits` attribution unchanged.
7. Use an isolated successor logical template/profile if implementation is
   later authorized. The source currently names only v1 and v2; new candidate
   meanings and labels change logical prompts, mappings, prompt hashes, and
   likely target construction. Silently replacing qualified v2 would invalidate
   its attribution. Do not retrofit this proposal into the running/frozen
   comparison or treat its earlier approval as approval of this change.

## Required evidence before any qualification claim

First obtain authorization for the concrete successor experiment and freeze its
template, label/value mapping, response policy, objective/target policy if
training is involved, vocabulary bounds, and acceptance criteria. CPU checks
should prove endpoint, midpoint, original-range, variance, strict logit-row,
and response-key behavior. Those checks can establish mapping arithmetic only.
Any later token preflight must prove each categorical label passes the unchanged
one-token guard in the real model/prefix context while generation remains zero.

After permitted development on TRAIN, run a **fresh complete current VALIDATION
protocol** for the changed template/profile. Retain the unchanged original
quality gates, unknown-Noul tolerance, complete coverage, zero execution
failures, and diagnosis requirements of that protocol, and examine per-answer
score failures as well as aggregate normalized MAE. Do not substitute a selected
fractional subset or old template results for the full gate. If a per-record
score improvement criterion is added, freeze it before that run; it does not
erase other required gates. No protected validation/test content or evaluation
predictions were read for this audit. No TEST access, promotion, or permanent
approval follows automatically from a research result.

Conclusion: this is a plausible small representation experiment for explicit
half-credit scoring. It remains unimplemented and unqualified, with tokenizer,
native, public-response, and fresh full-validation evidence still required.
