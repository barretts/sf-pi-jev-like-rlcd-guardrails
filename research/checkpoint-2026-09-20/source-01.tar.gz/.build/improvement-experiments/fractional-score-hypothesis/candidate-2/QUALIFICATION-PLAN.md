# Alphabet-label half-grid research candidate

Status: source/CPU preparation only; unqualified; no artifact approval or production installation.

Logical ID: `v2-earned-half-grid-alpha-research-1`.

This prospective representation choice uses alphabetic categorical labels for every score grid, including small rubrics, with a string JSON answer prefix. It separates output symbols from the original earned numeric values. Decimal earned values remain mapping values, never generated label strings. This choice is motivated only by TRAIN-side semantic representation considerations; it is not a claim about model logits, token feasibility, model quality, or an optimized VALIDATION result.

The public request, original integer rubric anchors, original maximum, half-grid increment of 0.5, response mean and variance in original point units, and probability/raw-logit earned-value keys remain unchanged. Choice and NOUL branches and typed answers retain production v2 behavior. Original score maxima above 24 reject explicitly; maximum 24 has 49 alphabet labels from `A` through `w`.

CPU evidence: `cpu-test-proof.txt` records the bounded `node --test grid.test.mjs` run. It exercises synthetic supplied logits and the explicit TRAIN240 fixture, whose required SHA is `a2252720fc7da7ad2aa2bd2a71fe231ceed866ddc49d44429c241cfad01ba54b`. These assertions do not establish native execution, generation behavior, tokenizer feasibility, or model quality.

Prospective qualification requirements, to be frozen before any candidate-2 VALIDATION is accessed or run:

1. Keep this candidate separate from candidate-1 and from the original immutable benchmark. After the frozen current run closes, use a separate research inference path carrying this exact logical ID and the actual compiled research prompt SHA for every record. Retain actual raw responses, selected logits, runtime attribution, and failures unchanged.
2. Prove every emitted alphabet label is exactly one token in the actual runtime and answer-prefix context, including case-sensitive labels used at the capacity boundary. Require zero generated output tokens and the actual runtime guard; a source declaration or supplied-logit adapter is insufficient. This feasibility remains unproved.
3. Run fresh, complete 194-record VALIDATION against the frozen original dataset and record manifest. Require exact unique coverage, preserve failed records as failures, and use the original questions, targets, rubric maxima, and evaluation denominators. Do not reuse candidate-1 responses or relabel production v2 prompt hashes as research inference evidence.
4. Reuse unchanged production grading rather than copying scoring rules. The smallest future API change is exporting the existing `scorePrediction` helper after the frozen current run closes. A separate research grading adapter can then use `validateQualityRecords`, `qualityDatasetDigest`, `scorePrediction`, and `summarizeQuality`, with metadata-free grading views alongside untouched research response envelopes.
5. Apply the existing production score, unknown, diagnosis, regression, and failure gates unchanged. Preserve any external unknown/diagnosis gate implementations and frozen thresholds. The production summary alone does not enforce complete194 coverage or every external gate.
6. Additionally require at least 90% correctness for the existing developer-score slice, declared prospectively here. Use the unchanged production per-answer predicate of normalized absolute error at most 0.1, normalized by the original `criteria.length - 1`; retain every expected developer-score answer in the denominator and count failures as unsuccessful. This criterion does not replace the production normalized-score-MAE gate.

Until all required fresh evidence passes, the candidate remains unqualified and `approval_effect` remains `none`.
