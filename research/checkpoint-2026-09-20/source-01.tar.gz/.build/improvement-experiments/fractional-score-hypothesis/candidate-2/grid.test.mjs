import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { preparePrompt, buildResponse } from '../../../../dist/core.js';
import { compileHalfGrid, responseHalfGrid, LOGICAL_ID } from './grid.mjs';

const score = (maximum = 2) => ({ id: 'score', type: 'score',
  instructions: 'Award established points. Half credit is permitted only for the stated half-credit rule.',
  criteria: Array.from({ length: maximum + 1 }, (_, j) => `${j} points earned`) });
const request = (maximum = 2) => ({ model: 'research-only', state: 'Explicit TRAIN-style synthetic evidence.',
  questions: [score(maximum)], options: { template_version: 'v2', raw_logits: true } });
const rowFor = (plan, winners) => Object.fromEntries(plan.questions.map(branch => [branch.branch_id,
  Object.fromEntries(branch.output_labels.map((label, j) => [label, winners.includes(j) ? 0 : -1000]))]));
const near = (actual, expected) => assert.ok(Math.abs(actual - expected) < 1e-12, `${actual} versus ${expected}`);
const alphabet = [...'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwx'];
const promptSha = plan => createHash('sha256').update(JSON.stringify(plan.questions)).digest('hex');
const earnedKeys = maximum => Array.from({ length: 2 * maximum + 1 }, (_, j) => String(j / 2)).sort();

test('original request, criteria and maximum remain unchanged in state and chat research plans', () => {
  for (const context of [{ state: { evidence: 'partial', explicit: true } },
    { messages: [{ role: 'system', content: 'Original system bytes' }, { role: 'user', content: 'Original user bytes' }] }]) {
    const input = { ...request(), ...context }; if (context.messages) delete input.state;
    const snapshot = structuredClone(input), plan = compileHalfGrid(input);
    assert.deepEqual(input, snapshot); assert.deepEqual(plan.request, preparePrompt(input, 'v2').request);
    assert.equal(plan.request.questions[0].criteria.length, 3);
    assert.equal(plan.template_version, LOGICAL_ID);
    assert.equal(LOGICAL_ID, 'v2-earned-half-grid-alpha-research-1');
    assert.equal(plan.research_contract.logical_id, LOGICAL_ID);
    assert.deepEqual(plan.questions[0].answer_labels, ['0', '0.5', '1', '1.5', '2']);
    assert.match(plan.questions[0].instruction, /only when the selected question explicitly permits/);
  }
});

test('all score grids use canonical alphabet labels and a string JSON answer prefix', () => {
  for (const maximum of [1, 2, 4, 24]) {
    const plan = compileHalfGrid(request(maximum)), branch = plan.questions[0];
    assert.deepEqual(branch.output_labels, alphabet.slice(0, 2 * maximum + 1));
    assert.equal(branch.answer_prefix, '{"answer": "');
    assert.match(branch.instruction, /selected label as a string\.$/);
    assert.equal(branch.output_labels[0], 'A');
    assert.equal(branch.output_labels[1], 'B');
    assert.ok(branch.output_labels.every(label => /^[A-Za-z]$/.test(label)));
    assert.equal(new Set(branch.output_labels).size, 2 * maximum + 1);
    assert.equal(plan.logical_prompt_sha256, promptSha(plan));
  }
  const maximumPlan = compileHalfGrid(request(24));
  assert.equal(maximumPlan.questions[0].output_labels.length, 49);
  assert.equal(maximumPlan.questions[0].output_labels.at(-1), 'w');
  assert.equal(maximumPlan.research_contract.maximum_original_score, 24);
});

test('original-scale endpoints, integer levels and earned half points are exact with concentrated logits', () => {
  for (const maximum of [1, 2, 3, 4, 24]) {
    const plan = compileHalfGrid(request(maximum));
    for (let j = 0; j <= 2 * maximum; j++) {
      const returned = responseHalfGrid(plan, rowFor(plan, [j]), 15, true).answers.score;
      near(returned.score, j / 2); near(returned.variance, 0);
      assert.equal(returned.score_mapping, 'categorical_label_to_original_earned_points');
      assert.equal(returned.calibrated, false);
      assert.equal(returned.research_template, LOGICAL_ID);
      assert.equal(returned.output_label_to_earned_points[plan.questions[0].output_labels[j]], j / 2);
      assert.deepEqual(Object.keys(returned.probabilities).sort(), earnedKeys(maximum));
      assert.deepEqual(Object.keys(returned.logits).sort(), earnedKeys(maximum));
    }
  }
});

test('mixtures and variance use earned point units with truthful fractional probability/raw-logit keys', () => {
  const plan = compileHalfGrid(request());
  const response = responseHalfGrid(plan, rowFor(plan, [1, 2]), 9, true);
  const returned = response.answers.score;
  near(returned.score, 0.75); near(returned.variance, 0.0625);
  assert.deepEqual(Object.keys(returned.probabilities).sort(), earnedKeys(2));
  assert.deepEqual(Object.keys(returned.logits).sort(), earnedKeys(2));
  assert.ok(Object.hasOwn(returned.logits, '0.5'));
  assert.equal(returned.output_label_to_earned_points.B, 0.5);
  assert.equal(returned.output_label_to_earned_points.C, 1);
  assert.ok(!Object.hasOwn(returned.probabilities, 'B'));
  assert.equal(returned.legend['0.5'].requires_explicit_earned_half_credit, true);
  assert.equal(returned.original_rubric_legend['1'], '1 points earned');
  assert.equal(response.usage.output_tokens, 0);
  assert.equal(response.metadata.template_version, LOGICAL_ID);
  assert.equal(response.metadata.approval_effect, 'none');
  assert.equal(response.metadata.logical_prompt_sha256, plan.logical_prompt_sha256);
  assert.match(response.metadata.execution_attribution, /does not establish native execution/);
});

test('uniform distribution retains the original rubric midpoint and bounded range', () => {
  for (const maximum of [1, 2, 4, 24]) {
    const plan = compileHalfGrid(request(maximum));
    const returned = responseHalfGrid(plan, rowFor(plan, Array.from({ length: 2 * maximum + 1 }, (_, j) => j))).answers.score;
    near(returned.score, maximum / 2);
    assert.ok(returned.score >= 0 && returned.score <= maximum);
  }
});

test('actual production response validation rejects missing/extra branches, labels and nonfinite logits', () => {
  const plan = compileHalfGrid(request()), good = rowFor(plan, [1]);
  for (const bad of [{}, { ...good, extra: good['0'] }])
    assert.throws(() => responseHalfGrid(plan, bad), /Missing or unexpected branch logits/);
  assert.throws(() => responseHalfGrid(plan, { '0': { ...good['0'], extra: 0 } }), /Missing or unexpected label logits/);
  for (const value of [NaN, Infinity, -Infinity])
    assert.throws(() => responseHalfGrid(plan, { '0': { ...good['0'], A: value } }), /Missing or non-finite logit/);
  const missing = structuredClone(good); delete missing['0'].A;
  assert.throws(() => responseHalfGrid(plan, missing), /Missing or unexpected label logits/);
  const numericLabel = structuredClone(good); delete numericLabel['0'].A; numericLabel['0']['0'] = 0;
  assert.throws(() => responseHalfGrid(plan, numericLabel), /Missing or non-finite logit/);
});

test('research capacity, template and value mappings reject incompatible inputs without fallback', () => {
  assert.throws(() => compileHalfGrid(request(25)), /Unsupported half-grid/);
  assert.throws(() => compileHalfGrid({ ...request(), options: { template_version: 'v1' } }), /requires original v2/);
  const plan = compileHalfGrid(request()), bad = structuredClone(plan);
  bad.questions[0].research_score_values[1] = 0.25;
  assert.throws(() => responseHalfGrid(bad, rowFor(plan, [1])), /logical prompt changed/);
  bad.logical_prompt_sha256 = promptSha(bad);
  assert.throws(() => responseHalfGrid(bad, rowFor(plan, [1])), /value mapping changed/);
  const mutatedLabels = structuredClone(plan);
  [mutatedLabels.questions[0].output_labels[0], mutatedLabels.questions[0].output_labels[1]] = ['B', 'A'];
  assert.throws(() => responseHalfGrid(mutatedLabels, rowFor(mutatedLabels, [1])), /logical prompt changed/);
  mutatedLabels.logical_prompt_sha256 = promptSha(mutatedLabels);
  assert.throws(() => responseHalfGrid(mutatedLabels, rowFor(mutatedLabels, [1])), /categorical labels changed/);
});

test('choice and NOUL compilation and typed answers remain byte-for-byte production v2 in mixed requests', () => {
  const input = request();
  input.questions.unshift({ id: 'choice', type: 'choice', instructions: 'Select the evidence owner',
    criteria: [{ id: 'a', description: 'Owner A' }, { id: 'b', description: 'Owner B' }] });
  input.questions.push({ id: 'truth', type: 'noul', instructions: 'The outcome is established.' });
  for (const chat of [false, true]) {
    const current = structuredClone(input);
    if (chat) { delete current.state; current.messages = [{ role: 'assistant', content: 'Quoted evidence' }, { role: 'user', content: 'Unchanged context' }]; }
    const ordinary = preparePrompt(current, 'v2'), grid = compileHalfGrid(current);
    assert.deepEqual(grid.questions[0], ordinary.questions[0]); assert.deepEqual(grid.questions[2], ordinary.questions[2]);
    const logits = rowFor(grid, [1]), originalLogits = Object.fromEntries(ordinary.questions.map(branch => [branch.branch_id,
      Object.fromEntries(branch.output_labels.map((label, j) => [label, j === 1 ? 0 : -1000]))]));
    for (const advanced of [false, true]) {
      const altered = responseHalfGrid(grid, logits, 12, advanced), unchanged = buildResponse(ordinary, originalLogits, 12, advanced);
      assert.deepEqual(altered.answers.choice, unchanged.answers.choice);
      assert.deepEqual(altered.answers.truth, unchanged.answers.truth);
    }
  }
});

test('all permitted TRAIN240 plans preserve original evidence and rubric and have no approval side effect', async () => {
  const text = await readFile(new URL('../../../../fixtures/developer-evidence-train.jsonl', import.meta.url), 'utf8');
  assert.equal(createHash('sha256').update(text).digest('hex'), 'a2252720fc7da7ad2aa2bd2a71fe231ceed866ddc49d44429c241cfad01ba54b');
  const records = text.trim().split('\n').map(JSON.parse);
  assert.equal(records.length, 240);
  for (const record of records) {
    assert.equal(record.split, 'train');
    const input = { ...record.request, options: { ...record.request.options, template_version: 'v2' } };
    const plan = compileHalfGrid(input);
    assert.deepEqual(plan.request, preparePrompt(input, 'v2').request);
    assert.equal(plan.research_contract.approval_effect, 'none');
    assert.equal(plan.research_contract.actual_one_token_guard_required, true);
  }
});
