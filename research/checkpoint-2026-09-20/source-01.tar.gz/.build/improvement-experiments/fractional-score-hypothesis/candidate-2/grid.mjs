import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { canonical, preparePrompt, buildResponse } from '../../../../dist/core.js';

// Isolated research compiler, never installed as the production v2 template.
// No model, tokenizer, native process, HTTP, training, or artifact approval.
export const LOGICAL_ID = 'v2-earned-half-grid-alpha-research-1';
export const MAX_ORIGINAL_SCORE = 24;
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwx';
const sha = value => createHash('sha256').update(value).digest('hex');

export function compileHalfGrid(input) {
  const original = preparePrompt(input, 'v2');
  assert.equal(original.template_version, 'v2', 'Half-grid research requires original v2 context semantics');
  const request = original.request;
  const questions = original.questions.map((branch, index) => {
    const question = request.questions[index];
    if (question.type !== 'score') return branch;
    const maximum = question.criteria.length - 1;
    assert.ok(maximum <= MAX_ORIGINAL_SCORE, 'Unsupported half-grid research score maximum');
    const values = Array.from({ length: 2 * maximum + 1 }, (_, j) => j / 2);
    const labels = [...alphabet].slice(0, values.length);
    assert.equal(labels.length, values.length, 'Half-grid categorical vocabulary capacity');
    const detail = 'Return the actual earned point total on the ORIGINAL 0..' + maximum + ' rubric below. '
      + 'Output labels are categorical codes, not point values. Half points are earned credit, never confidence. '
      + 'Select a half point only when the selected question explicitly permits an earned half-credit rule and the context establishes it. '
      + 'Otherwise select an integer total. Apply the original instructions and original integer rubric anchors; do not invent partial credit.\n'
      + 'Original integer rubric anchors:\n'
      + question.criteria.map((entry, j) => j + ': ' + canonical(entry)).join('\n')
      + '\nCategorical output label to ORIGINAL earned point value:\n'
      + labels.map((label, j) => label + ': earned_points=' + values[j]
        + (Number.isInteger(values[j]) ? '; original integer anchor ' + values[j]
          : '; explicit earned half credit between original anchors ' + Math.floor(values[j]) + ' and ' + Math.ceil(values[j]))).join('\n');
    const instruction = 'Selected question:\n'
      + (typeof question.instructions === 'string' ? question.instructions : canonical(question.instructions))
      + '\n' + detail + '\nReturn only JSON with one answer field containing the selected label as '
      + 'a string.';
    const system = original.system_prompt_prefix + original.prefix_instruction;
    let messages;
    if (request.state != null) {
      messages = [{ role: 'system', content: system }, { role: 'user', content: 'Actual context:\n'
        + (typeof request.state === 'string' ? request.state : canonical(request.state))
        + '\n\n' + original.suffix_instruction + instruction }];
    } else {
      // Original v2 score chat semantics: preserve all supplied message bytes;
      // append a selected-question user turn; native normalization merges only
      // the final adjacent user turns, as in the original qualified profile.
      messages = structuredClone(request.messages);
      if (messages[0].role === 'system') messages[0].content = system + '\n' + messages[0].content;
      else messages.unshift({ role: 'system', content: system });
      messages.push({ role: 'user', content: original.suffix_instruction + instruction });
    }
    return { ...branch, instruction, answer_prefix: '{"answer": "',
      output_labels: labels, answer_labels: values.map(String), messages,
      research_score_values: values };
  });
  return { ...original, template_version: LOGICAL_ID, questions,
    research_contract: { logical_id: LOGICAL_ID, original_template: 'v2', increment: 0.5,
      maximum_original_score: MAX_ORIGINAL_SCORE, score_mapping: 'categorical_label_to_original_earned_points',
      probability_keys: 'original_earned_point_values', probability_calibration: 'not_calibrated',
      public_request_and_rubric_unchanged: true, zero_generation_required: true,
      actual_one_token_guard_required: true, fresh_complete_validation_required: true,
      approval_effect: 'none' }, logical_prompt_sha256: sha(JSON.stringify(questions)) };
}

export function responseHalfGrid(plan, logits, inputTokens = 0, advanced = false, extra = {}) {
  assert.equal(plan.template_version, LOGICAL_ID, 'Unsupported half-grid logical plan');
  assert.equal(plan.research_contract?.logical_id, LOGICAL_ID, 'Missing half-grid contract');
  assert.equal(plan.logical_prompt_sha256, sha(JSON.stringify(plan.questions)), 'Half-grid logical prompt changed');
  // The actual production function enforces exact branch/label keys and finite
  // logits and produces unchanged choice/NOUL answers. For score, j is the
  // internal half-grid index; convert both moments into original point units.
  const response = buildResponse(plan, logits, inputTokens, advanced, extra);
  plan.questions.forEach((branch, index) => {
    const question = plan.request.questions[index];
    if (question.type !== 'score') return;
    const maximum = question.criteria.length - 1;
    assert.ok(maximum <= MAX_ORIGINAL_SCORE, 'Unsupported half-grid score bound');
    const expected = Array.from({ length: 2 * maximum + 1 }, (_, j) => j / 2);
    assert.deepEqual(branch.research_score_values, expected, 'Half-grid value mapping changed');
    assert.deepEqual(branch.answer_labels, expected.map(String), 'Half-grid answer keys changed');
    assert.deepEqual(branch.output_labels, [...alphabet].slice(0, expected.length),
      'Half-grid categorical labels changed');
    const answer = response.answers[question.id];
    answer.score /= 2;
    answer.legend = Object.fromEntries(expected.map(value => [String(value), Number.isInteger(value)
      ? { earned_points: value, original_anchor: question.criteria[value] }
      : { earned_points: value, requires_explicit_earned_half_credit: true,
        original_lower_anchor: question.criteria[Math.floor(value)], original_upper_anchor: question.criteria[Math.ceil(value)] }]));
    answer.original_rubric_legend = Object.fromEntries(question.criteria.map((entry, j) => [String(j), entry]));
    answer.output_label_to_earned_points = Object.fromEntries(branch.output_labels.map((label, j) => [label, expected[j]]));
    answer.score_mapping = 'categorical_label_to_original_earned_points';
    answer.scoring = 'direct_half_grid_label_logits';
    answer.calibrated = false;
    answer.research_template = LOGICAL_ID;
    if (advanced) answer.variance /= 4;
  });
  response.metadata.template_version = LOGICAL_ID;
  response.metadata.logical_prompt_sha256 = plan.logical_prompt_sha256;
  response.metadata.research_contract = plan.research_contract;
  response.metadata.calibration = 'not_calibrated';
  response.metadata.approval_effect = 'none';
  response.metadata.execution_attribution = 'supplied_selected_logits; adapter alone does not establish native execution';
  return response;
}
