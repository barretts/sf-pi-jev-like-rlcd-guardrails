This is an isolated, prospective research compiler and response adapter. It is
uninstalled and unapproved. The currently running frozen original-profile
benchmark is unchanged. Source/CPU success establishes mapping behavior only.

Hypothesis: when a question explicitly permits earned half credit, an explicit
categorical label for that earned value may improve per-answer evidence scores
without requiring the particular mixture over integer labels that represents
the same expected value. Current integer-label output is already continuous;
this proposal is not a calibration or numeric quantization fix.

The successor logical ID is `v2-earned-half-grid-research-1`. Every original
request, integer rubric anchor, original maximum, and evaluator denominator is
preserved. Only score branches acquire a half-step internal categorical grid.
Their prompts state that half points require an explicit earned-credit rule;
other judgments use integer totals. The research capacity is maximum 24 points
(49 candidates). Unsupported larger rubrics fail instead of silently falling
back. Choice/NOUL branch messages and typed answers remain production v2.

Research score probability and raw-logit keys name original-scale grid values,
including fractional values. The response carries a categorical label/value
mapping, grid legend, and original integer rubric legend. Expectation and
variance use original point units. Selected-label probabilities remain
uncalibrated. This policy changes research score distributions and is not a
compatible replacement of production `direct_level_logits` metadata.

The root ran eight meaningful CPU checks successfully on 2026-09-20. Those
checks cover original request/context retention, endpoints, half points,
mixtures, variance, selected-logit validation, capacity, non-score differential
behavior, and all explicitly approved TRAIN240 plans. No model, tokenizer,
native, GPU, network, optimizer, VALIDATION or TEST was used by those checks.
The independent source review must finish before source release is frozen.

Future qualification remains separate and ordered:

1. Freeze reviewed source, logical prompt/value mapping, response policy,
   physical runtime, pinned raw model/templates, runtime identities and limits.
   No change enters the running original benchmark.
2. ROOT alone compiles/starts native work after the current native lane is
   closed and owned cleanup is known. Keep zero-generation selected-label
   evaluation and the unchanged real one-distinct-token label guard. Fresh
   synthetic vocabulary and original-Jinja/BOS probes must pass in actual
   answer-prefix contexts. Decimal values are meanings, not decimal output
   tokens.
3. Run the complete current 194-row VALIDATION protocol with unchanged legacy,
   developer and diagnosis targets and quality/uncertainty gates. Preserve all
   errors and complete coverage. Add a prospective per-developer-score
   correctness requirement of at least 90 percent using the unchanged original
   normalized error tolerance 0.1. This extra requirement is frozen before that
   run and does not redefine or excuse other quality gates.
4. Only a fully qualified candidate enters a separately frozen matched full
   direct-performance comparison. Retain rate nonregression, at least 90
   percent eligible clear completion, both reversed-order repetitions, all
   attempt work/time, and the existing twofold timing requirements.
5. No new TEST, permanent artifact approval, default activation, or actual pi
   developer-experience claim follows from source, arithmetic, synthetic probes
   or validation alone. The full correctly completed workflow gate remains.

Physical runtime changes are a distinct experiment. The separately prepared
F16/AUTO/batch2048/ubatch512 candidate requires its own identities and fresh
qualification; neither its quality nor its speed is presumed here.
