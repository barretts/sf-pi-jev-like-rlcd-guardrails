# Independently authored developer supervision supplement

Prepared on 2026-09-20T09:16:32.815Z as an experimental input for conditional review. Preparation is complete; adoption, training, model evaluation, reliability improvement, and speed/resource improvement are unproven. No supplement training or inference has been launched.

The new training file has **40 semantic groups / 160 choice-only rows**: 26 routing groups (two per each of 11 production Salesforce families, mixed, and general) and 14 diagnosis groups (two per each of seven production categories). Every class has exactly eight training rows. The independent diagnosis validation file has **14 groups / 56 choice-only rows**, two groups and eight rows per category. No final TEST file is created or modified. Existing validation/test scenarios and targets, including quality.jsonl and developer-workflows.jsonl, were not inspected.

## Production boundary and authored evidence

Routing uses the exact instruction and option descriptions extracted from src/automation.ts. Inventories are the unchanged availableRouteFamilies helper's output for synthetic representative active-tool IDs that match its production rules. Prefix-matched tool suffixes are synthetic inventory identifiers; this does not establish actual deployed tool names or availability. Each active family has one independently authored operation under the full 11-family inventory and a different operation with that family plus two plausible distractors. The two mixed operations independently require Flow plus browser, and explicitly authorized synthetic Slack reading plus SOQL. The two general operations request unavailable Flow or Data360 capability and expressly exclude all available substitute work.

Diagnosis is built through buildDeveloperRecipeRequest, then filtered to its diagnosis choice question without changing the instruction or default descriptions. Its state retains the production user_task/evidence shape. All contexts are synthetic. Blocking diagnostics, relevant contracts/source/specifications, unrelated warnings, and unsupported proposed fixes are explicit. Validation mechanisms were authored independently from the category definitions and differ from TRAIN mechanisms; its cases and labels are frozen before any supplement training, candidate evaluation, or label inspection for selection. The concurrent root training job uses the preexisting frozen 570-row corpus and does not use these new cases.

## Frozen transformations

1. An authored operation/evidence context is one semantic group, assigned wholly to TRAIN or diagnosis VALIDATION. No context is reused across these splits.
2. Each group expands to two deterministic option orders and two representations per order, giving four rows. State contains the production-shaped context object. Chat contains one user message with the canonical JSON of that exact object. State and chat use byte-equivalent canonical evidence, identical targets, and identical option order for each order index.
3. Option permutations are whole-list rotations of the production candidate list. The target is moved to a predefined answer position; no candidate ID or description changes. Positions and inventories are frozen per group in the ignored proof. Different order variants preserve exactly the same candidate set.
4. All representation/permutation variants remain under the same stable group_id. No counterfactual or transformation is split across training and validation. Target values are production candidate IDs; letters below are measured from preparePrompt(v2), never guessed from the target text.

For full routing inventories, the 22 order instances allocate G-M three times each and F once. The 22 reduced-family order instances allocate A/B five times each and C/D/E four times each. Mixed instances allocate F/A and F/C; general instances allocate B/C and D/E. Each instance is repeated exactly once for state and once for chat. This achieves the smallest feasible routing histogram range: the seven G-M positions can receive at most 22 instances, forcing at least one count at most three, while 26 reduced/general instances are restricted to A-E, forcing at least one count at least six. The achieved instance counts range from three to six. Both seven-option diagnosis corpora are exactly balanced at four order instances/eight rows per letter.

| Corpus | A | B | C | D | E | F | G | H | I | J | K | L | M |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| train | 20 | 20 | 20 | 18 | 18 | 14 | 14 | 6 | 6 | 6 | 6 | 6 | 6 |
| routing_train | 12 | 12 | 12 | 10 | 10 | 6 | 6 | 6 | 6 | 6 | 6 | 6 | 6 |
| diagnosis_train | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 0 | 0 | 0 | 0 | 0 | 0 |
| diagnosis_validation | 8 | 8 | 8 | 8 | 8 | 8 | 8 | 0 | 0 | 0 | 0 | 0 | 0 |

TRAIN representations: state 80 / chat 80; option order1 80 / order2 80. VALIDATION representations: state 28 / chat 28; option order1 28 / order2 28.

## Validation and frozen proof

The proof is under .build/improvement-experiments/supplement-preparation/ and ignored by the existing .build/ ignore rule. It contains authored definitions, frozen corpus copies, source snapshots, isolated public module projections, per-group inventories/positions/context hashes, per-row logical prompt hashes and measured letters, the preparation script, and the freeze manifest. The public schema validators and logical preparePrompt compiler passed for all 216 rows. Group/ID uniqueness, split integrity, four-variant grouping, identical paired evidence/options/targets, candidate-set preservation, exact counts, category/class balance, deterministic orders, and actual letter histograms passed. Only public schema/logical prompt code was transpiled to the ignored proof directory; no dist/native/worker/controller build or file edit occurred.

Zero model/inference/tokenizer/GPU/network/Git/auth/CI calls were made by this supplement preparation. This proves fixture validity and provenance only. It does not prove human-label accuracy on real developer failures, native tokenizer compatibility, model accuracy/calibration, generalization, latency, resource improvement, or release eligibility. Root must review the synthetic supervision and decide whether to adopt it after the frozen current-job results; this file does not authorize or launch that adoption.

The frozen 570-row TRAIN-only input was used only to inspect its first three rows for schema/style and to compute its unchanged whole-file hash: `26ccd13bad6b59c096d9d0ca774128e45ed929a16af1fbaca03ebef4aa8fb07b`. None of its scenarios was copied. It remains unchanged.

New corpus file hashes: TRAIN `ddac462e2f9e62ae5875597a1710fb54498290fcfa1b185456d435f523d113d7`; diagnosis VALIDATION `2e1ea3bb5316197f9f32edc22db2a59b038be74018283e726281eaa352d56f3b`. Whole-file byte hashes of the production/public sources and read guidance/context are:

| File | SHA-256 |
|---|---|
| src/automation.ts | `801815b6084cbcbc3280af68f64f32e99465fc7dd69831353958b22bdfc533e2` |
| src/recipes.ts | `c2d6a1ac5df49485c02f5b0fe4852a87a838b65244a898b6732c2ff1d3752364` |
| src/core.ts | `6c019fadb85344f0e1c7b42a1d5cb98bab9fb2d0c885fa137c939b558d2e2944` |
| src/evaluation.ts | `36a6d959b093498c5fa55bababd844c1deb7b6618a48302028f6c17c33470dcb` |
| README.md | `f6b170de8598c39de8ad2a883538825e6d50c7b66b1c43c770bf9877ffb2e7ef` |
| package.json | `a9ed3ee4e6f3009f7ccd151f77b82c80cc152095124f56556c6f41f875dd00b8` |
| .gitignore | `15ad6f36ebe49bf46d92ab19fb3cb8b556bb438db420c78bc4369112ea2a3139` |

Ownership is released to root for review after freeze verification. These are prepared experimental assets; they have not been committed, adopted, or used in a model run.
