import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import { wireCases, oneDistinctContinuation, completeMeasuredWork, approvalEffect } from './contract.mjs';

test('three literal host-gold cases preserve original max2 earned half credit without sending targets', async () => {
  const cases = JSON.parse(await readFile(new URL('./synthetic-requests.json', import.meta.url), 'utf8'));
  const golds = JSON.parse(await readFile(new URL('./host-golds.json', import.meta.url), 'utf8'));
  assert.deepEqual(cases.map(c => c.request.questions[0].type), ['choice','score','noul']);
  assert.deepEqual(cases[0].request.questions[0].criteria.map(c => c.id), ['red','blue']);
  assert.equal(cases[1].request.questions[0].criteria.length - 1, 2);
  assert.ok(cases[1].request.questions[0].instructions.includes('0.5 earned points'));
  assert.equal(golds.cases[1].target.answer, 0.5); assert.equal(golds.cases[2].target.answer, null);
  const wire = wireCases(cases.map((c, i) => ({ ...c, targets: golds.cases[i].target })));
  assert.ok(wire.every(c => !Object.hasOwn(c, 'targets') && !Object.hasOwn(c, 'golds')));
  assert.throws(() => wireCases(cases.slice(1)));
});

test('mock continuation guard rejects changed prefixes, duplicate label tokens and extra BOS', () => {
  const prefix = [2, 10, 20]; const valid = { A: [2,10,20,31], B: [2,10,20,32] };
  assert.equal(oneDistinctContinuation(prefix, valid, 2, 100), true);
  assert.throws(() => oneDistinctContinuation(prefix, { ...valid, B: [2,10,21,32] }, 2, 100));
  assert.throws(() => oneDistinctContinuation(prefix, { ...valid, B: valid.A }, 2, 100));
  assert.throws(() => oneDistinctContinuation([2,10,2], valid, 2, 100));
  assert.throws(() => oneDistinctContinuation(prefix, { A: [2,10,20,31,32] }, 2, 100));
});

test('mock measured-work guard retains public-call scope and rejects unknown/failed accounting; zero generation gives no approval', () => {
  const work = { successful_public_llama_decode_calls: 1, known_successful_submitted_prompt_tokens: 974,
    decode_calls_entered: 1, decode_calls_returned: 1, complete_accounting: true, internal_ubatch_forwards: null };
  const metrics = { prefill_strategy: 'full', prefix_tokens: 0, scored_positions: 1, branch_output_tokens: 0,
    branch_prompt_tokens: 974, computed_prompt_tokens: 974, suffix_batch_sizes: [1], engine_forwards: 1, partial_native_work: work };
  assert.equal(completeMeasuredWork(metrics, 974), true);
  assert.throws(() => completeMeasuredWork({ ...metrics, engine_forwards: 2 }, 974));
  assert.throws(() => completeMeasuredWork({ ...metrics, partial_native_work: { ...work, complete_accounting: false } }, 974));
  assert.throws(() => completeMeasuredWork({ ...metrics, partial_native_work: { ...work, decode_calls_entered: 2 } }, 974));
  assert.ok(Object.values(approvalEffect()).every(value => value === false));
});
