import assert from 'node:assert/strict';

// CPU contract assertions only; no tokenizer, template render or native caller.
export function wireCases(cases) {
  assert.equal(cases.length, 3);
  return cases.map(({ id, request }) => ({ id, request: structuredClone(request) }));
}

export function oneDistinctContinuation(prefix, continuations, bosId, vocabSize) {
  assert.ok(Number.isSafeInteger(bosId) && bosId >= 0);
  assert.ok(Number.isSafeInteger(vocabSize) && vocabSize > bosId);
  assert.ok(prefix.length > 0 && prefix[0] === bosId && prefix.filter(token => token === bosId).length === 1);
  const valid = tokens => tokens.every(token => Number.isSafeInteger(token) && token >= 0 && token < vocabSize);
  assert.ok(valid(prefix)); const selected = new Set();
  for (const tokens of Object.values(continuations)) {
    assert.equal(tokens.length, prefix.length + 1); assert.ok(valid(tokens));
    assert.deepEqual(tokens.slice(0, prefix.length), prefix);
    assert.ok(!selected.has(tokens.at(-1))); selected.add(tokens.at(-1));
  }
  assert.ok(selected.size > 0); return true;
}

export function completeMeasuredWork(metrics, promptTokens) {
  assert.equal(metrics.prefill_strategy, 'full'); assert.equal(metrics.prefix_tokens, 0);
  assert.equal(metrics.scored_positions, 1); assert.equal(metrics.branch_output_tokens, 0);
  assert.equal(metrics.branch_prompt_tokens, promptTokens); assert.equal(metrics.computed_prompt_tokens, promptTokens);
  assert.deepEqual(metrics.suffix_batch_sizes, [1]);
  assert.equal(metrics.engine_forwards, Math.ceil(promptTokens / 2048));
  const work = metrics.partial_native_work;
  assert.equal(work.complete_accounting, true);
  assert.equal(work.successful_public_llama_decode_calls, metrics.engine_forwards);
  assert.equal(work.known_successful_submitted_prompt_tokens, promptTokens);
  assert.equal(work.decode_calls_entered, work.decode_calls_returned);
  assert.equal(work.decode_calls_returned, metrics.engine_forwards);
  assert.equal(work.internal_ubatch_forwards, null);
  return true;
}

export const approvalEffect = () => ({ native_capability_proved: false, full_quality_approval: false,
  speed_improvement_claim_permitted: false, production_role_approval: false, automatic_model_selection: false });
