import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

// Source text only: no artifact probing, hashing, compilation or execution.
const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '../../..');
let source = await readFile(join(ROOT, '.build/improvement-experiments/gemma4-runtime-candidate-1/main.cpp'), 'utf8');
const once = (old, replacement) => {
  assert.equal(source.split(old).length, 2, 'Unexpected C091 source patch point');
  source = source.replace(old, replacement);
};
source = source.replaceAll('GEMMA4_PROTOTYPE_SOURCE_SHA256', 'GEMMA3_ALPHA_PROPOSAL_SOURCE_SHA256');
once('"gemma4-direct-label-raw-q4-runtime-candidate-1"', '"gemma3-4b-raw-f16-alpha-capability-candidate-1"');
once('"/Users/bsonntag/code/simple-jev-ts/models/gemma-4-31B_q4_0-it.gguf"', '"/Users/bsonntag/code/simple-jev-ts/models/gemma-3-4b-it-f16.gguf"');
once('"179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b"', '"29f4b518b636635613894282bda2a01bad964c8d474c4147343057b7ac442d50"');
once('17651001568ULL', '7767474336ULL');
const templateStart = source.indexOf('static constexpr const char *template_path =');
const templateEnd = source.indexOf('static constexpr int decode_chunk =', templateStart);
assert.ok(templateStart > 0 && templateEnd > templateStart);
source = source.slice(0, templateStart) + `// ROOT must first inspect/freeze the exact original embedded Gemma3 source.
// These compile blockers deliberately prevent reuse of Gemma4 template pins.
#if !defined(GEMMA3_ALPHA_RAW_TEMPLATE_PATH) || !defined(GEMMA3_ALPHA_RAW_TEMPLATE_SHA256) || !defined(GEMMA3_ALPHA_RAW_TEMPLATE_BYTES) || !defined(GEMMA3_ALPHA_PARSER_TEMPLATE_SHA256) || !defined(GEMMA3_ALPHA_PARSER_TEMPLATE_BYTES) || !defined(GEMMA3_ALPHA_PARSER_TRANSFORM) || !defined(GEMMA3_ALPHA_PARENT_C091_SOURCE_SHA256) || !defined(GEMMA3_ALPHA_TEMPLATE_REVISION)
#error "ROOT template/source identity freeze is required before compilation"
#endif
static constexpr const char *template_path = GEMMA3_ALPHA_RAW_TEMPLATE_PATH;
static constexpr const char *template_sha256 = GEMMA3_ALPHA_RAW_TEMPLATE_SHA256;
static constexpr size_t template_size = GEMMA3_ALPHA_RAW_TEMPLATE_BYTES;
static constexpr const char *parser_template_sha256 = GEMMA3_ALPHA_PARSER_TEMPLATE_SHA256;
static constexpr size_t parser_template_size = GEMMA3_ALPHA_PARSER_TEMPLATE_BYTES;
static constexpr const char *parser_source_transform = GEMMA3_ALPHA_PARSER_TRANSFORM;
// Prospective assertion only; permitted source does not establish actual suffix.
static constexpr const char *generation_boundary = "<start_of_turn>model\\n";
` + source.slice(templateEnd);
source = source.replaceAll('Gemma4', 'Gemma3').replaceAll('"gemma4"', '"gemma3"');
once('{"template_revision", "842da3794eaa0b77d5f08bae87a17459d91ff475"}', '{"template_revision", GEMMA3_ALPHA_TEMPLATE_REVISION}');
source = source.replaceAll('caller-supplied logical branches; no v2 instruction redefinition', 'caller-supplied earned-half-grid Alpha branches; no public v2 redefinition');
once('{"weight_conversion", "none; pinned raw GGUF"}', '{"weight_conversion", "none; pinned original raw F16 GGUF"},\n          {"logical_research_id", "v2-earned-half-grid-alpha-research-1"},\n          {"weight_file_type_declared", 1},\n          {"weight_dtype_attribution", "catalog/header declares mostly F16 with F32 tensors; ROOT full artifact/lineage proof required"}');
once('// Load the pinned raw quantized file directly; never create/expand weights.', '// Load the pinned original raw F16 file directly; never create/expand weights.');
const parserStart = source.indexOf('    // The pinned vendor lexer stores source');
const parserEnd = source.indexOf('    if (vocab_only)\n      return;', parserStart);
assert.ok(parserStart > 0 && parserEnd > parserStart);
source = source.slice(0, parserStart) + `    std::string expected_parser_source;
    const std::string transform = parser_source_transform;
    if (transform == "identity") {
      expected_parser_source = template_source;
    } else if (transform == "remove_exactly_one_terminal_lf") {
      if (template_source.empty() || template_source.back() != '\\n')
        throw std::runtime_error("ROOT-declared parser transform requires one terminal LF");
      expected_parser_source = template_source.substr(0, template_source.size() - 1);
    } else {
      throw std::runtime_error("Unsupported ROOT-declared Gemma3 parser transform");
    }
    const auto actual_parser_source = common_chat_templates_source(templates.get());
    if (template_source.size() != template_size || expected_parser_source.size() != parser_template_size ||
        sha256(expected_parser_source) != parser_template_sha256 || actual_parser_source != expected_parser_source ||
        actual_parser_source.size() != parser_template_size || sha256(actual_parser_source) != parser_template_sha256)
      throw std::runtime_error("Original Gemma3 template/parser source identity mismatch");
` + source.slice(parserEnd);
once('{"parent_prototype_source_sha256", "f2dc4e3457bb422219c24d6658757f3cd588ff3115d4e320c0c23e9582d332fb"}', '{"parent_c091_source_sha256", GEMMA3_ALPHA_PARENT_C091_SOURCE_SHA256}');
once('{"inherited_source_sha256", "ac0b5b0f1b8832bbbbc563e219bcbc621553e2297f456004955553560cadbcce"}', '{"source_ancestry_scope", "ROOT freezes current C091 source; no previous Gemma4 artifact or proof reused"}');
source = source.replaceAll('"quantized_cpu"', '"raw_f16_cpu"').replaceAll('"quantized_metal"', '"raw_f16_metal"');
once('  int forwards = 0, computed = 0;', `  int forwards = 0, computed = 0;
  int decode_calls_entered = 0, decode_calls_returned = 0;
  bool decode_work_complete = true;
  void reset_work() { forwards = computed = decode_calls_entered = decode_calls_returned = 0; decode_work_complete = true; }
  json partial_work() const {
    return {{"successful_public_llama_decode_calls", forwards}, {"known_successful_submitted_prompt_tokens", computed},
            {"decode_calls_entered", decode_calls_entered}, {"decode_calls_returned", decode_calls_returned},
            {"complete_accounting", decode_work_complete && decode_calls_entered == decode_calls_returned},
            {"failed_call_internal_work", decode_work_complete && decode_calls_entered == decode_calls_returned ? json(0) : json(nullptr)},
            {"internal_ubatch_forwards", nullptr}, {"generated_tokens", 0}};
  }
  int measured_decode(const llama_batch &batch) {
    ++decode_calls_entered;
    const int code = llama_decode(ctx, batch);
    ++decode_calls_returned;
    if (code == 0) { ++forwards; computed += batch.n_tokens; }
    else decode_work_complete = false;
    // Returned successful work is recorded before cancellation is observed.
    check_cancelled();
    return code;
  }`);
once('      int code = llama_decode(ctx, batch);', '      int code = measured_decode(batch);');
once('        int code = llama_decode(ctx, part);', '        int code = measured_decode(part);');
assert.equal(source.split('forwards++;\n      computed += n;').length, 2);
source = source.replace('      forwards++;\n      computed += n;\n', '');
assert.equal(source.split('forwards++;\n        computed += n;').length, 2);
source = source.replace('        forwards++;\n        computed += n;\n', '');
once('  json evaluate(const json &branches, bool full) {\n    check_cancelled();', `  json evaluate(const json &branches, bool full) {
    reset_work();
    check_cancelled();
    if (!full || !branches.is_array() || branches.size() != 1)
      throw std::invalid_argument("Gemma3 Alpha candidate requires full prefill of exactly one branch");`);
once('{"engine_forwards", forwards}', '{"engine_forwards", forwards},\n              {"engine_forwards_scope", "successful public llama_decode calls; internal ubatch forwards unobserved"},\n              {"partial_native_work", partial_work()}');
once('    json response = {{"v", 1}, {"id", r.value("id", "")}};', '    json response = {{"v", 1}, {"id", r.value("id", "")}};\n    engine.reset_work();');
once('    std::cout << response.dump() << std::endl;', '    if (response.contains("error") && r.value("op", "") == "evaluate")\n      response["partial_native_work"] = engine.partial_work();\n    std::cout << response.dump() << std::endl;');
assert.ok(!source.includes('"gemma4"') && !source.includes('"quantized_metal"'));
await writeFile(join(HERE, 'main.cpp.in'), '// UNCOMPILED PRIVATE SOURCE SCAFFOLD; NO NATIVE CLEARANCE.\n' + source, { flag: 'wx', mode: 0o600 });
console.log('Wrote one private uncompiled Gemma3 Alpha source scaffold; no artifact read or source-byte freeze.');
