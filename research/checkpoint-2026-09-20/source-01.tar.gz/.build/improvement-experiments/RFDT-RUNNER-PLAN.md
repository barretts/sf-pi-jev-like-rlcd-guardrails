# Private fresh-base RFDT experiment runner

This runner is prepared for the developer-improvement experiment. No model execution is authorized by this file. Root must explicitly freeze the complete developer corpus and clear GPU scheduling before each `run` invocation. The current partial developer corpus is not staged or hashed by preparation.

Files:

- `rfdt-runner.py`: data staging, one-candidate ownership, phase/PID/progress records, status and explicit cancellation.
- `evaluate-developer-candidate.mjs`: production API evaluation of exactly 78 frozen developer validation records using a verified disposable artifact registry.
- `rfdt-stage.json`: created only after an explicit final developer corpus SHA is supplied and complete counts validate.
- `rfdt-inputs/developer-corpus.jsonl`: complete frozen 546-row developer corpus, retained for validation attribution.
- `rfdt-inputs/combined-train-570.jsonl`: optimizer input containing legacy train180 and developer train390 only.
- `rfdt-round-N/`: distinct owned candidate, logs and proofs. `run/` contains production RFDT files, adapter, fused weights, GGUF, and fixed native validation report.

## CPU-only preparation and staging

From `/Users/bsonntag/code/simple-jev-ts`:

```sh
.build/rfdt-venv/bin/python .build/improvement-experiments/rfdt-runner.py plan

# Run only after developer_corpus/root explicitly freezes the FULL artifact.
# FINAL_SHA is the author's complete 546-row raw-file SHA, never the partial file hash.
.build/rfdt-venv/bin/python .build/improvement-experiments/rfdt-runner.py stage \
  --developer-corpus fixtures/developer-workflows.jsonl \
  --developer-sha256 "$FINAL_SHA"
```

Staging rejects counts other than546 total with390/78/78 train/validation/test and182 records per question type. The combined input must contain570 unique examples across285 groups,190 per question type, all explicitly `train`. Training groups and equivalent state/chat contexts must be disjoint from both corpora's validation/test data. No target is inferred or generated. The requests/targets are preserved while source-only extra metadata is excluded from the RFDT schema.

The legacy fixture is pinned to raw SHA `cd3de2d07db024aeb0f8d22be394ffa9024307680efbe2967569c325bc7af3c9`. C9 compiled core is pinned to SHA `2ee6c409a12b6a4f7b7a7d63c37d84923740e46f8732f625a65d0f39ef04bdf6`. Staging records immutable hashes for the earlier failed student's manifests, validation/test reports and permanent test reservation.

## One explicitly scheduled candidate

```sh
# Root must confirm paired evaluator56400 terminal and grant this exact GPU phase.
.build/rfdt-venv/bin/python .build/improvement-experiments/rfdt-runner.py run \
  --round 1 --steps 64 --root-gpu-cleared --blocker-pid 56400 --detach

.build/rfdt-venv/bin/python .build/improvement-experiments/rfdt-runner.py status --round 1

# Only if root explicitly cancels this owned candidate:
.build/rfdt-venv/bin/python .build/improvement-experiments/rfdt-runner.py cancel --round 1
```

The detached wrapper owns one global exclusive `rfdt-runner.lock`, its recorded owner PID/start identity, and a separate child process group for each phase. Status can reattach to observation without restarting training. Busy/abandoned locks are never taken over automatically. Cancellation verifies owner start identity, requests TERM, escalates the owned child group to KILL after5 seconds, and awaits cleanup. Output streams are limited to32MiB each. There is no wall-clock cutoff for legitimate training. Failed/cancelled candidates remain inspectable and are never implicitly resumed or replayed.

The idle Gemma4 server37914 can remain resident only under root's explicit scheduling clearance. The runner refuses any supplied live blocker PID and never stops that server or the paired evaluator. Parent/root serializes all GPU callers.

Planned candidates are round1/64, round2/128 and round3/256. Each starts from the SAME official cached base, never from an earlier adapter. Each requires a separate root grant; completion does not launch the next candidate.

## Production commands executed after clearance

The runner sets `HF_HUB_OFFLINE=1`, `TRANSFORMERS_OFFLINE=1`, `HF_DATASETS_OFFLINE=1`, `HF_HUB_DISABLE_PROGRESS_BARS=1` and `JEV_DEVICE=metal`. Token environment values are removed from the child environment; no credential file is read, login performed, download made, or environment dumped.

```sh
RUN="$PWD/.build/improvement-experiments/rfdt-round-1/run"
INPUT="$PWD/.build/improvement-experiments/rfdt-inputs/combined-train-570.jsonl"
MODEL="$PWD/.build/hf-session-1_s2hbhu/home/hub/models--google--gemma-3-1b-it/snapshots/dcc83ea841ab6100d6b47a070329e1ba4cf78752"

node dist/cli.js rfdt prepare --input "$INPUT" --output-dir "$RUN" \
  --template v2 --model google/gemma-3-1b-it \
  --model-file "$PWD/models/gemma-3-1b-it-f16.gguf" --device metal

node dist/cli.js rfdt train --run "$RUN" --steps 64 \
  --model-path "$MODEL" --python "$PWD/.build/rfdt-venv/bin/python"

node dist/cli.js rfdt export --run "$RUN" \
  --model-path "$MODEL" --python "$PWD/.build/rfdt-venv/bin/python"

node dist/cli.js rfdt evaluate --run "$RUN" --split validation

node .build/improvement-experiments/evaluate-developer-candidate.mjs \
  --artifact "$RUN/artifact.json" \
  --corpus "$PWD/.build/improvement-experiments/rfdt-inputs/developer-corpus.jsonl" \
  --corpus-sha256 "$FINAL_SHA" \
  --output "$PWD/.build/improvement-experiments/rfdt-round-1/developer-validation-report.json" \
  --progress "$PWD/.build/improvement-experiments/rfdt-round-1/developer-validation-progress.json"
```

Actual execution records exact commands and source/module/input hashes, base weight SHA, training loss/history, adapter/reload proofs, artifact hash/size/run identity, both native validation summaries, per-record metadata and developer progress. The pinned base weight SHA must equal `3d4ef8d71c14db7e448a09ebe891cfb6bf32c57a9b44499ae0d1c098e48516b6`. Production preparation/worker check all570 actual prompt token sequences and answer boundaries before training; no truncation or vocabulary padding is introduced.

The ordinary `eval --registry` CLI does not forward a scoped registry, so the developer wrapper uses `verifyTrainedArtifactExport` then `Classifier({artifactRegistryPath})` and `evaluateRecords`. Its registry is `{version:1, artifacts:[verifiedDescriptor]}`, removed after classifier disposal. This is an experimental execution descriptor, not permanent approval. Failing legacy validation still produces its report; developer validation runs to provide complete selection evidence.

Selection requires existing generic quality gates on legacy60 and developer78 plus uncertain Noul MAE≤0.10 on both. `completed_quality_pass` permits root's next evaluation decision; it does not select a final candidate, consume a test, or approve an artifact. No held-out tests, approval writes, default changes or next-candidate launch are in the runner. Future final selection/test authority remains with root.
