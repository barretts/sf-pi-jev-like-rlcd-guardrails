import { readFile } from "node:fs/promises";
import { preparePrompt } from "../../../dist/core.js";

// Pure logical compilation only: no backend/model import or native process.
let input = "";
for await (const chunk of process.stdin) input += chunk;
const { dataset_file, rows } = JSON.parse(input);
const examples = (await readFile(dataset_file, "utf8"))
  .split(/\r?\n/)
  .filter(Boolean)
  .map((line) => JSON.parse(line));
if (examples.some((row) => row.split !== "train"))
  throw new Error("Probe source must contain TRAIN records only");
const byId = new Map(examples.map((row) => [row.id, row]));
if (byId.size !== examples.length) throw new Error("Duplicate TRAIN IDs");
const branches = rows.map((row) => {
  const example = byId.get(row.source_id);
  if (!example || example.split !== "train")
    throw new Error(`Missing TRAIN source ${row.source_id}`);
  const plan = preparePrompt(example.request, row.template_version);
  const branch = plan.questions.find(
    (value) => value.question_id === row.question_id,
  );
  if (!branch) throw new Error(`Missing question ${row.id}`);
  if (
    JSON.stringify(branch.output_labels) !== JSON.stringify(row.output_labels)
  )
    throw new Error(`Output labels changed for ${row.id}`);
  if (
    JSON.stringify(branch.answer_labels) !== JSON.stringify(row.answer_labels)
  )
    throw new Error(`Answer labels changed for ${row.id}`);
  return { ...branch, branch_id: row.id };
});
process.stdout.write(JSON.stringify(branches));
