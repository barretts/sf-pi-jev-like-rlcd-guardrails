#!/usr/bin/env python3
"""Private TRAIN-only parity diagnostic. Preparation imports only stdlib.

Run preparation now; run inference only after the root grants a GPU slot.
All existing project sources and artifacts are read-only.
"""

from __future__ import annotations

import argparse
import collections
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import signal
import struct
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE_ID = "google/gemma-3-1b-it"
BASE_REV = "dcc83ea841ab6100d6b47a070329e1ba4cf78752"
MLX_REV = "9d1e356e7cc6549e7d1697adabe2ea01ff8e062c"
NATIVE_REV = "f072b103714dfa1eee531f80b24512faf38e3dd2"
COMPONENTS = ("mlx_adapter", "mlx_f32_adapter", "mlx_fused", "native")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_json(path):
    return json.loads(Path(path).read_text())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def bind(path, expected=None):
    path = Path(path).absolute()
    require(path.is_file(), f"Required file unavailable: {path}")
    observed = sha(path)
    require(expected is None or observed == expected, f"Identity mismatch: {path}")
    return {"path": str(path), "sha256": observed, "size": path.stat().st_size}


def tensor_dtypes(path):
    with Path(path).open("rb") as stream:
        size = struct.unpack("<Q", stream.read(8))[0]
        require(size <= 32 * 1024 * 1024, "Unexpected safetensors header size")
        header = json.loads(stream.read(size))
    return dict(collections.Counter(value["dtype"] for key, value in header.items() if key != "__metadata__"))


def gguf_metadata(path):
    with Path(path).open("rb") as stream:
        def unpack(fmt):
            size = struct.calcsize(fmt)
            data = stream.read(size)
            require(len(data) == size, "Truncated GGUF metadata")
            return struct.unpack(fmt, data)[0]

        def string():
            size = unpack("<Q")
            require(size <= 64 * 1024 * 1024, "Oversized GGUF string")
            return stream.read(size).decode("utf-8")

        formats = {0: "<B", 1: "<b", 2: "<H", 3: "<h", 4: "<I", 5: "<i", 6: "<f", 7: "<?", 10: "<Q", 11: "<q", 12: "<d"}

        def value(kind):
            if kind in formats:
                return unpack(formats[kind])
            if kind == 8:
                return string()
            if kind == 9:
                inner, count = unpack("<I"), unpack("<Q")
                require(count <= 1000000, "Oversized GGUF array")
                return [value(inner) for _ in range(count)]
            raise ValueError(f"Unsupported GGUF metadata type {kind}")

        require(stream.read(4) == b"GGUF", "Expected GGUF artifact")
        require(unpack("<I") == 3, "Expected GGUF v3")
        tensors, count = unpack("<Q"), unpack("<Q")
        selected = {}
        for _ in range(count):
            key = string()
            data = value(unpack("<I"))
            if key.startswith("gemma3.") or key in ("general.architecture", "general.file_type", "tokenizer.chat_template"):
                selected[key] = data
        selected["tensor_count"] = tensors
    require(selected["general.architecture"] == "gemma3", "Expected native Gemma3")
    require(selected["general.file_type"] == 1, "Expected F16 GGUF")
    require(selected["gemma3.block_count"] == 26, "Expected Gemma3 1B")
    require(selected["gemma3.attention.sliding_window"] == 512, "Native sliding window changed")
    require(isinstance(selected.get("tokenizer.chat_template"), str), "Missing native chat template")
    return selected


def select_rows(rows):
    require(all(row["split"] == "train" for row in rows), "Prepared input must contain TRAIN only")
    require(len({row["id"] for row in rows}) == len(rows), "Duplicate prepared TRAIN IDs")
    length = lambda row: len(row["prompt_token_ids"])
    choices = [row for row in rows if row["question_type"] == "choice"]
    scores = [row for row in rows if row["question_type"] == "score"]
    noul = [row for row in rows if row["question_type"] == "noul"]
    below = [row for row in choices if length(row) <= 512]
    above = [row for row in choices if length(row) > 512]
    require(below and above and scores and noul, "Required TRAIN length/type domains unavailable")
    specifications = [
        ("choice_closest_at_or_below_512", min(below, key=lambda row: (-length(row), row["id"]))),
        ("choice_closest_above_512", min(above, key=lambda row: (length(row), row["id"]))),
        ("choice_longest", min(choices, key=lambda row: (-length(row), row["id"]))),
        ("score_longest", min(scores, key=lambda row: (-length(row), row["id"]))),
        ("noul_shortest", min(noul, key=lambda row: (length(row), row["id"]))),
        ("noul_longest", min(noul, key=lambda row: (-length(row), row["id"]))),
    ]
    require(len({row["id"] for _, row in specifications}) == 6, "Selections must be six distinct existing rows")
    return [{"selection": name, "row_sha256": json_sha(row), "row": row} for name, row in specifications]


def prepare(args):
    run = Path(args.run_dir).resolve()
    job_path = Path(args.job).resolve() if args.job else run.parent / "job.json"
    job, manifest = load_json(job_path), load_json(run / "manifest.json")
    training, artifact = load_json(run / "training-report.json"), load_json(run / "artifact.json")
    fused_manifest = load_json(run / "fused/rfdt-fused-manifest.json")
    for identity in (manifest, artifact, training["provenance"], fused_manifest["provenance"]):
        require(identity["base_model"] == BASE_ID and identity["base_revision"] == BASE_REV, "Google base/revision mismatch")
    require(training["template_version"] == manifest["template_version"] == artifact["template_version"] == "v2", "Template mismatch")
    require(training["provenance"]["dependencies"]["mlx_lm_revision"] == MLX_REV, "MLX source revision mismatch")
    require(manifest["exports"]["converter_revision"] == NATIVE_REV, "Converter revision mismatch")
    require(fused_manifest["fusion_dtype"] == "float32" and fused_manifest["adapter_sha256"] == training["adapter_sha256"], "Fused adapter attribution mismatch")
    base = Path(job["base_model_path"]).absolute()
    fused = run / "fused"
    for path in (base, fused):
        config = load_json(path / "config.json")
        require(config["model_type"] == "gemma3_text" and config["hidden_size"] == 1152 and config["num_hidden_layers"] == 26 and config["vocab_size"] == 262144, "Checkpoint architecture mismatch")
        require(config["sliding_window"] == 512 and config["sliding_window_pattern"] == 6, "Checkpoint attention config mismatch")
        require(config.get("attn_logit_softcapping") is None and config.get("final_logit_softcapping") is None, "Softcap configuration changed")
    require(load_json(base / "config.json") == load_json(fused / "config.json"), "Base/fused configuration mismatch")
    bindings = {}
    def add(label, path, expected=None):
        bindings[label] = bind(path, expected)

    add("job", job_path)
    add("run_manifest", run / "manifest.json")
    add("training_report", run / "training-report.json")
    add("artifact_manifest", run / "artifact.json")
    add("prepared_train", run / "train.jsonl", training["training_data_sha256"])
    add("raw_train", manifest["prepared"]["dataset_file"], manifest["prepared"]["dataset_sha256"])
    require(manifest["prepared"]["branches"]["validation"] == manifest["prepared"]["branches"]["test"] == 0, "Prepared run is not TRAIN only")
    rows = [json.loads(line) for line in (run / "train.jsonl").read_text().splitlines() if line.strip()]
    require(len(rows) == manifest["prepared"]["branches"]["train"], "Prepared TRAIN count mismatch")
    selected = select_rows(rows)
    raw = [json.loads(line) for line in Path(bindings["raw_train"]["path"]).read_text().splitlines() if line.strip()]
    require(all(row["split"] == "train" for row in raw), "Raw source contains non-TRAIN records")
    add("adapter_weights", run / "adapter/adapters.safetensors", training["adapter_sha256"])
    add("adapter_config", run / "adapter/adapter_config.json")
    add("adapter_manifest", run / "adapter/rfdt-manifest.json")
    require(load_json(run / "adapter/rfdt-manifest.json") == training, "Training and adapter manifests differ")
    add("fused_manifest", fused / "rfdt-fused-manifest.json")
    for name, expected in fused_manifest["files"].items():
        add("fused:" + name, fused / name, expected)
    for path in sorted(base.iterdir()):
        if path.is_file() and (path.suffix in (".json", ".model", ".safetensors")):
            add("base:" + path.name, path, job.get("base_weight_sha256") if path.name == "model.safetensors" else None)
    add("gguf", artifact["file"], artifact["sha256"])
    require(bindings["gguf"]["size"] == artifact["size"], "GGUF size mismatch")
    require(manifest["exports"]["sha256"] == artifact["sha256"], "Export/manifest GGUF mismatch")
    add("worker", ROOT / "rfdt/worker.py", job["source_sha256"][str(ROOT / "rfdt/worker.py")])
    add("dist_core", ROOT / "dist/core.js", job["dist_sha256"]["core.js"])
    for name, expected in job["dist_sha256"].items():
        if name != "core.js":
            add("dist:" + name, ROOT / "dist" / name, expected)
    for name, expected in job["source_sha256"].items():
        if name != str(ROOT / "rfdt/worker.py"):
            add("run_source:" + name, name, expected)
    add("compiler_source", ROOT / "src/core.ts")
    add("native_binary", ROOT / ".build/jev-native")
    add("native_wrapper", ROOT / "native/main.cpp")
    add("native_build_script", ROOT / "scripts/build-native.sh")
    add("converter", ROOT / ".vendor/llama.cpp/convert_hf_to_gguf.py", manifest["exports"]["converter_sha256"])
    add("converter_gemma", ROOT / ".vendor/llama.cpp/conversion/gemma.py")
    add("converter_base", ROOT / ".vendor/llama.cpp/conversion/base.py")
    add("native_gemma", ROOT / ".vendor/llama.cpp/src/models/gemma3.cpp")
    add("native_window", ROOT / ".vendor/llama.cpp/src/llama-hparams.h")
    site = ROOT / ".build/rfdt-venv/lib/python3.13/site-packages"
    for name in ("gemma3_text", "base", "rope_utils", "cache"):
        add("mlx_model:" + name, site / f"mlx_lm/models/{name}.py")
    add("mlx_utils", site / "mlx_lm/utils.py")
    add("mlx_lora", site / "mlx_lm/tuner/lora.py")
    direct = list(site.glob("mlx_lm-*.dist-info/direct_url.json"))
    require(len(direct) == 1, "Ambiguous installed MLX-LM")
    add("mlx_direct_url", direct[0])
    require(load_json(direct[0])["vcs_info"]["commit_id"] == MLX_REV, "Installed MLX-LM revision mismatch")
    add("probe_script", HERE / "probe.py")
    add("branch_helper", HERE / "freeze-branches.mjs")
    node = shutil.which("node")
    require(node is not None, "Node is unavailable")
    add("node_binary", Path(node).resolve())
    add("python_binary", Path(sys.executable).resolve())
    frozen = subprocess.run([node, str(HERE / "freeze-branches.mjs")], input=json.dumps({"dataset_file": bindings["raw_train"]["path"], "rows": [item["row"] for item in selected]}), text=True, capture_output=True, check=True)
    branches = json.loads(frozen.stdout)
    require(len(branches) == 6 and all(branch["branch_id"] == item["row"]["id"] for branch, item in zip(branches, selected)), "Logical branch binding mismatch")
    metadata = gguf_metadata(bindings["gguf"]["path"])
    dtypes = {"base": tensor_dtypes(base / "model.safetensors"), "fused": tensor_dtypes(fused / "model.safetensors"), "adapter": tensor_dtypes(run / "adapter/adapters.safetensors")}
    require(set(dtypes["base"]) == {"BF16"}, "Expected actual BF16 Google base weights")
    require(set(dtypes["fused"]) == {"F32"}, "Expected saved F32 fused weights")
    protocol = {
        "schema_version": 1, "status": "prepared_only_no_inference", "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "run_id": manifest["id"], "artifact_id": artifact["id"], "base_model": BASE_ID, "base_revision": BASE_REV,
        "template_version": "v2", "mlx_revision": MLX_REV, "native_revision": NATIVE_REV,
        "run_directory": str(run), "base_directory": str(base), "fused_directory": str(fused), "adapter_directory": str(run / "adapter"),
        "bindings": bindings, "tensor_dtypes": dtypes, "native_metadata": metadata,
        "native_template_sha256": hashlib.sha256(metadata["tokenizer.chat_template"].encode()).hexdigest(),
        "selection_policy": "Existing TRAIN rows only; type and prompt length only; ID ascending breaks ties; no targets/predictions used for selection",
        "prepared_train_count": len(rows), "rows": selected, "logical_branches": branches,
        "native_limits": {"max_model_len": 2048, "max_batch_size": 6, "max_batch_tokens": 8192, "device": "metal"},
        "component_timeout_seconds": 600,
        "comparisons": {
            "native_cached_vs_full": {"paths": ["native_cached", "native_full"], "max_centered_logit_delta": 0.05, "max_total_variation": 0.01, "max_cross_entropy_delta": 0.05},
            "mlx_bf16_vs_f32_adapter": {"paths": ["mlx_adapter", "mlx_f32_adapter"], "max_centered_logit_delta": 0.5, "max_total_variation": 0.05, "max_cross_entropy_delta": 0.2},
            "mlx_f32_adapter_vs_fused": {"paths": ["mlx_f32_adapter", "mlx_fused"], "max_centered_logit_delta": 0.5, "max_total_variation": 0.05, "max_cross_entropy_delta": 0.2},
            "mlx_fused_vs_native_full": {"paths": ["mlx_fused", "native_full"], "max_centered_logit_delta": 0.5, "max_total_variation": 0.05, "max_cross_entropy_delta": 0.2},
        },
        "limits": ["Diagnostic thresholds are predeclared engineering flags, not corpus quality or adoption gates.", "Six existing TRAIN rows do not establish semantic generalization.", "Unavailable paths/results are unknown; no estimated or synthetic predictions.", "No TEST file, targets or inference are used.", "Inference must wait for the root GPU slot after round3 is terminal."]
    }
    model_modules = [name for name in sys.modules if name.split(".")[0] in ("mlx", "mlx_lm", "torch", "transformers", "huggingface_hub")]
    require(not model_modules, "Preparation unexpectedly imported a model package")
    write_new(args.protocol, protocol)
    digest = sha(args.protocol)
    write_new(str(args.protocol) + ".preparation.json", {"status": "prepared_only_no_inference", "protocol_sha256": digest, "model_modules_loaded": model_modules, "rows": [{"selection": item["selection"], "id": item["row"]["id"], "type": item["row"]["question_type"], "prompt_tokens": len(item["row"]["prompt_token_ids"])} for item in selected], "components": {name: "not_run" for name in COMPONENTS}, "invocation": [sys.executable, str(HERE / "probe.py"), "--run", "--protocol", str(Path(args.protocol).resolve()), "--protocol-sha256", digest, "--report", str(Path(args.protocol).with_name("report.json").resolve())]})
    print(json.dumps({"status": protocol["status"], "protocol": str(Path(args.protocol).resolve()), "protocol_sha256": digest, "rows": [{"id": item["row"]["id"], "tokens": len(item["row"]["prompt_token_ids"])} for item in selected]}))


def verify_protocol(args):
    require(args.protocol_sha256 is not None and sha(args.protocol) == args.protocol_sha256, "Frozen protocol digest mismatch")
    protocol = load_json(args.protocol)
    require(protocol["schema_version"] == 1 and len(protocol["rows"]) == 6, "Invalid probe protocol")
    require(protocol["base_model"] == BASE_ID and protocol["base_revision"] == BASE_REV, "Protocol Google lineage mismatch")
    for name, identity in protocol["bindings"].items():
        observed = bind(identity["path"], identity["sha256"])
        require(observed["size"] == identity["size"], f"Size mismatch for {name}")
    require(select_rows([json.loads(line) for line in Path(protocol["bindings"]["prepared_train"]["path"]).read_text().splitlines() if line.strip()]) == protocol["rows"], "Selected prepared rows changed")
    for item in protocol["rows"]:
        require(item["row"]["split"] == "train" and json_sha(item["row"]) == item["row_sha256"], "Frozen TRAIN row mismatch")
    return protocol


def numeric_result(row, logits):
    require(len(logits) == len(row["allowed_token_ids"]) and all(math.isfinite(value) for value in logits), "Invalid actual selected logits")
    maximum = max(logits)
    weights = [math.exp(value - maximum) for value in logits]
    total = sum(weights)
    probabilities = [value / total for value in weights]
    log_partition = maximum + math.log(total)
    cross_entropy = -sum(target * (value - log_partition) for target, value in zip(row["target_probabilities"], logits))
    winner = max(range(len(logits)), key=logits.__getitem__)
    return {"status": "observed", "selected_logits": logits, "probabilities": probabilities, "cross_entropy": cross_entropy, "winner_index": winner, "winner_label": row["output_labels"][winner], "winner_token_id": row["allowed_token_ids"][winner]}


def mlx_component(protocol, kind):
    # Deliberately lazy: --prepare-only and protocol checks never import MLX/HF.
    spec = importlib.util.spec_from_file_location("frozen_jev_rfdt_worker", protocol["bindings"]["worker"]["path"])
    worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(worker)
    worker.dependencies()
    import mlx.core as mx
    from mlx.utils import tree_flatten, tree_map
    mx.set_cache_limit(worker.FREE_CACHE_LIMIT_BYTES)
    directory = protocol["base_directory"] if kind in ("mlx_adapter", "mlx_f32_adapter") else protocol["fused_directory"]
    adapter = Path(protocol["adapter_directory"])
    model, _, config = worker.load_model(Path(directory), adapter if kind == "mlx_adapter" else None)
    if kind == "mlx_f32_adapter":
        from mlx_lm.tuner.utils import load_adapters
        worker.validate_adapter(adapter)
        # Exact production ordering: cast base parameters, then load adapters.
        # Keep LoRA modules unfused to isolate dtype change from fusion math.
        model.update(tree_map(lambda parameter: parameter.astype(mx.float32) if mx.issubdtype(parameter.dtype, mx.floating) else parameter, model.parameters()))
        load_adapters(model, str(adapter))
    model.eval()
    rows = [item["row"] for item in protocol["rows"]]
    parity = worker.verify_prompt_parity(worker.load_tokenizer(Path(directory)), rows)
    observed = {}
    parameter_dtypes = dict(collections.Counter(str(value.dtype) for _, value in tree_flatten(model.parameters())))
    for row in rows:
        tokens, allowed, targets = worker.row_arrays(row)
        raw = mx.take(worker.final_logits(model, tokens)[0], allowed).astype(mx.float32)
        mx.eval(raw)
        observed[row["id"]] = numeric_result(row, raw.tolist())
        del raw, tokens, allowed, targets
        mx.clear_cache()
    return {"status": "observed", "kind": kind, "device": str(mx.default_device()), "model_config": config, "parameter_dtypes": parameter_dtypes, "prompt_parity": parity, "rows": observed}


def native_component(protocol, stderr_path):
    with Path(stderr_path).open("x") as log:
        process = subprocess.Popen([protocol["bindings"]["native_binary"]["path"]], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log, text=True, env=offline_env())
        serial = 0
        def rpc(op, **fields):
            nonlocal serial
            serial += 1
            request_id = f"parity-{serial}"
            process.stdin.write(json.dumps({"v": 1, "id": request_id, "op": op, **fields}, allow_nan=False) + "\n")
            process.stdin.flush()
            line = process.stdout.readline()
            require(line, "Native exited without a protocol reply")
            reply = json.loads(line)
            require(reply.get("v") == 1 and reply.get("id") == request_id, "Native reply envelope mismatch")
            if "error" in reply:
                raise RuntimeError(f"Actual native path failed: {reply['error']}")
            return reply["result"]
        try:
            status = rpc("init", model_file=protocol["bindings"]["gguf"]["path"], **protocol["native_limits"])
            require(status["architecture"] == "gemma3" and status["device"] == "metal", "Wrong native architecture/device")
            commit = status["native_build"]["commit"]
            require(len(commit) >= 7 and protocol["native_revision"].startswith(commit), "Wrong native build revision")
            require(hashlib.sha256(status["template"].encode()).hexdigest() == protocol["native_template_sha256"], "Native template identity mismatch")
            compiled = rpc("compile", branches=protocol["logical_branches"])
            require(len(compiled) == 6, "Native compiled branch count mismatch")
            for branch, item in zip(compiled, protocol["rows"]):
                row = item["row"]
                require(branch["branch_id"] == row["id"] and branch["tokens"] == row["prompt_token_ids"] and branch["rendered"] == row["prompt"], f"Native exact prompt mismatch: {row['id']}")
                require([branch["token_ids"][label] for label in row["output_labels"]] == row["allowed_token_ids"], f"Native allowed token mismatch: {row['id']}")
                require(set(branch["token_ids"]) == set(row["output_labels"]), f"Native label domain mismatch: {row['id']}")
            results = {}
            for name, full in (("native_cached", False), ("native_full", True)):
                # Evaluate each real branch separately so cache prefix reuse runs
                # through its entire prompt, including the >512 boundary.
                observed, metrics = {}, {}
                for branch, item in zip(compiled, protocol["rows"]):
                    row = item["row"]
                    evaluation = rpc("evaluate", branches=[branch], full=full)
                    observed[row["id"]] = numeric_result(row, [evaluation["logits"][row["id"]][label] for label in row["output_labels"]])
                    metrics[row["id"]] = evaluation["metrics"]
                    require(evaluation["metrics"]["prefill_strategy"] == ("full" if full else "shared_prefix"), "Native full flag ignored")
                results[name] = {"status": "observed", "rows": observed, "metrics": metrics}
            return {"status": "observed", "native_status": status, "exact_compile_verified": True, "paths": results}
        finally:
            try:
                process.stdin.close()
            except OSError:
                pass
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)


def offline_env():
    return {**os.environ, "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "HF_DATASETS_OFFLINE": "1", "HF_HUB_DISABLE_TELEMETRY": "1", "WANDB_DISABLED": "true"}


def comparison(left, right, limits):
    if left.get("status") != "observed" or right.get("status") != "observed":
        return {"status": "unknown", "reason": "One or both actual paths unavailable"}
    ll, rr = left["selected_logits"], right["selected_logits"]
    lp, rp = left["probabilities"], right["probabilities"]
    lm, rm = sum(ll) / len(ll), sum(rr) / len(rr)
    centered = max(abs((a - lm) - (b - rm)) for a, b in zip(ll, rr))
    tv = sum(abs(a - b) for a, b in zip(lp, rp)) / 2
    ce = abs(left["cross_entropy"] - right["cross_entropy"])
    winner = left["winner_token_id"] == right["winner_token_id"]
    return {"status": "observed", "max_centered_logit_delta": centered, "max_probability_delta": max(abs(a - b) for a, b in zip(lp, rp)), "total_variation": tv, "cross_entropy_delta": ce, "winner_agreement": winner, "within_predeclared_numeric_limits": centered <= limits["max_centered_logit_delta"] and tv <= limits["max_total_variation"] and ce <= limits["max_cross_entropy_delta"], "limits": limits}


def run(args, protocol):
    require(args.report and not Path(args.report).exists(), "Use a fresh --report path")
    results = {}
    execution_dir = Path(str(args.report) + ".components")
    execution_dir.mkdir(parents=True, exist_ok=False)
    for kind in COMPONENTS:
        component_file = execution_dir / (kind + ".json")
        command = [sys.executable, str(HERE / "probe.py"), "--component", kind, "--protocol", args.protocol, "--protocol-sha256", args.protocol_sha256, "--component-output", str(component_file)]
        try:
            process = subprocess.Popen(command, env=offline_env(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
            try:
                stdout, stderr = process.communicate(timeout=protocol["component_timeout_seconds"])
            except subprocess.TimeoutExpired:
                # Terminate the whole private component group, including its
                # native child, before moving on or returning the GPU slot.
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.communicate(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.communicate(timeout=15)
                raise
            except BaseException:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.communicate(timeout=15)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.communicate(timeout=15)
                raise
            completed = subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
            (execution_dir / (kind + ".stdout.log")).write_text(completed.stdout)
            (execution_dir / (kind + ".stderr.log")).write_text(completed.stderr)
            require(completed.returncode == 0, f"Component {kind} failed: {completed.stderr[-2000:]}")
            results[kind] = load_json(component_file)
        except subprocess.TimeoutExpired:
            results[kind] = {"status": "unknown", "reason": "Actual component timed out", "rows": {}}
    paths = {name: results[name] for name in ("mlx_adapter", "mlx_f32_adapter", "mlx_fused")}
    if results["native"].get("status") == "observed":
        paths.update(results["native"]["paths"])
    else:
        paths.update({name: {"status": "unknown", "reason": results["native"].get("reason"), "rows": {}} for name in ("native_cached", "native_full")})
    comparisons = {}
    for name, policy in protocol["comparisons"].items():
        left, right = policy["paths"]
        comparisons[name] = {item["row"]["id"]: comparison(paths[left].get("rows", {}).get(item["row"]["id"], {}), paths[right].get("rows", {}).get(item["row"]["id"], {}), {key: value for key, value in policy.items() if key != "paths"}) for item in protocol["rows"]}
    observed = all(result.get("status") == "observed" for result in results.values())
    write_new(args.report, {"schema_version": 1, "status": "observed" if observed else "partial_unknown", "protocol_sha256": args.protocol_sha256, "artifact_id": protocol["artifact_id"], "gguf_sha256": protocol["bindings"]["gguf"]["sha256"], "components": results, "comparisons": comparisons, "limits": protocol["limits"], "test_inference": 0})
    print(json.dumps({"status": "observed" if observed else "partial_unknown", "report": args.report}))


def main():
    def cancelled(signum, frame):
        raise KeyboardInterrupt("Private parity probe cancelled")
    signal.signal(signal.SIGTERM, cancelled)
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare-only", action="store_true")
    mode.add_argument("--verify-only", action="store_true")
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--component", choices=COMPONENTS)
    parser.add_argument("--run-dir", default=str(ROOT / ".build/improvement-experiments/rfdt-round-2/run"))
    parser.add_argument("--job")
    parser.add_argument("--protocol", required=True)
    parser.add_argument("--protocol-sha256")
    parser.add_argument("--report")
    parser.add_argument("--component-output")
    args = parser.parse_args()
    if args.prepare_only:
        prepare(args)
        return
    protocol = verify_protocol(args)
    if args.verify_only:
        require(not any(name.split(".")[0] in ("mlx", "mlx_lm", "torch", "transformers", "huggingface_hub") for name in sys.modules), "Verification imported a model package")
        print(json.dumps({"status": "verified_only_no_inference", "protocol_sha256": args.protocol_sha256, "binding_count": len(protocol["bindings"]), "selected_rows": len(protocol["rows"])}))
        return
    os.environ.update(offline_env())
    if args.component:
        require(args.component_output, "Missing component output")
        try:
            result = native_component(protocol, args.component_output + ".native.stderr.log") if args.component == "native" else mlx_component(protocol, args.component)
        except (ImportError, OSError, RuntimeError) as error:
            result = {"status": "unknown", "reason": f"Actual path unavailable: {type(error).__name__}: {error}", "rows": {}}
        write_new(args.component_output, result)
    else:
        run(args, protocol)


if __name__ == "__main__":
    main()
