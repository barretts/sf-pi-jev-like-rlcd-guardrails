This is a CPU-authored TRAIN proposal. It is not adopted into an evaluation corpus, frozen for optimization, used for inference, or evidence of a model-quality improvement. A later hypothesis justified by the current paired experiment and a separate adoption decision are required before use.

All authored files are confined to `.build/improvement-experiments/evidence-supervision-proposal/`. The only supplied data read was `train-style-12.jsonl`, which contains TRAIN records. Public production `src/core.ts`, `src/evaluation.ts`, and `src/recipes.ts` provided the request/target/prompt and recipe contracts. At the root agent's direction, validation imported the existing unchanged `dist/core.js` and `dist/evaluation.js` pure CPU exports. Source and artifact hashes are recorded in `cpu-validation.json`.

No validation/test context, target, prediction or report files were read. The original mixed developer-workflow corpus, oldquality corpus, protected repair tasks, RFDT jobs, model files, memory, and gateway configuration were not used. No network/auth, project build, Git, native backend, tokenizer, GPU, or classifier/model inference operation was performed. The record contexts describe trusted **synthetic** execution evidence inside their own scenarios; they are not claims that these systems were executed in the workspace.

Scope audit: after the final corpus hashes and CPU checks were fixed, an unfiltered collaboration agent inventory returned unrelated teams' completion summaries while checking whether the semantic reviewer was still running. Their files were not opened and those summaries were not used to author or revise this proposal. The root agent was informed immediately. The allowed input provenance above describes the data-authoring and validation inputs.

`proposed-train.jsonl` preserves the production QualityRecord schema and supplied TRAIN style: unique `id`, unique context `group_id`, `split: "train"`, model `google/gemma-3-1b-it`, one question `q`, exactly one context carrier, and a literal `targets.q.answer`. There is no added production request field. Noul targets are booleans or null. Score targets are finite numeric earned-point totals. Because production targets require a single `answer` or `probabilities` field, per-condition credits are supplied in `source-contexts.json` and the explicit 120-entry `score-targets.json` sidecar, each including the total, maximum and normalized score. Internal credit keys never appear in the model-visible rubric.

There are 90 independently authored source contexts and 240 TRAIN records:

| Quantity | Source contexts | Records |
| --- | ---: | ---: |
| Noul | 60 | 120 |
| Noul established true | 20 | 40 |
| Noul established false | 20 | 40 |
| Noul unknown | 20 | 40 |
| Score | 30 | 120 |
| State representation | 90 | 120 |
| Equivalent chat representation | 90 | 120 |

Each Noul group has one state and one byte-identical user-message carrier. Each score group has forward and reverse condition orders, each with state and chat carriers, giving four records per group. The two condition orders differ for every score source. Ordinal score anchors remain ordered from zero to the maximum; only the textual condition order changes. The score contexts have 2, 3 or 4 independent full-point conditions. The root agent amended the initial max1 request to avoid a trivial identical condition-order variant or a weighted max1 override.

| Score maximum | Source contexts | Records |
| --- | ---: | ---: |
| 2 | 12 | 48 |
| 3 | 6 | 24 |
| 4 | 12 | 48 |

Each of normalized earned levels 0, 0.25, 0.5, 0.75 and 1 has exactly six score contexts and 24 records. The 90 source-condition credits comprise 41 zeroes, 8 explicitly permitted half points and 41 full points; expanded across the four variants, those counts are 164, 32 and 164. Raw score totals comprise 0:6, 0.5:3, 1:5, 1.5:5, 2:4, 3:5, 4:2 source contexts. There are no raw quarter-point credits. Normalized quarter levels arise from integer points on max4 rubrics or half points on max2 rubrics.

The evidence mechanisms vary across Unicode/encoding, JSON/CSV/TOML/INI parsing, modulo/search/GCD/vector arithmetic, database constraints and rollback, filesystem bytes/types/modes/ownership, Git revision and diff identity, installed package versions/peer bindings/exports, pagination/cursors/order/retries, structured errors, compiler constants, dates, transport checksums and compression. The four repair themes excluded by the assignment are absent. Independent groups do not reuse a source context with another gold; intended representation/order twins share a group. A first-page pagination scenario that resembled another partial-pagination source was replaced with a localized error-report scenario before the final review.

Noul instructions use one consistent source-only truth semantics: established proposition is true, established contradiction is false, and neither established is unknown. False contexts contain a complete source consequence or a trusted contradictory result; unknown contexts concern missing later outcomes, missing effective source/configuration, different-scope observations, or unexecuted plans/examples. Score instructions award no points for missing evidence, contradicted outcomes, plans, examples or another candidate/scope. A 0.5 credit is permitted only in a particular condition's explicit rule, and represents a specified verified subset rather than confidence.

Two wording issues found in independent review were repaired: the CSV input is now shown as both an unambiguous literal record and ASCII bytes; the compiler rubric now names flag value `0x2` instead of ambiguous `bit2`. Visible internal condition keys were removed to avoid a shortcut from original key order. Nine score sources were re-derived after the final max2/max3/max4 revision.

CPU validation command, run from `/Users/bsonntag/code/simple-jev-ts`:

```sh
node .build/improvement-experiments/evidence-supervision-proposal/validate-cpu.mjs
```

Validation uses production `validateQualityRecords` for all 240 records and production `preparePrompt` for both v1 and v2, yielding 480 successful one-question logical plans. It also checks one question per record, TRAIN-only splits, the required group prefix, context and target equality within groups, unique independent context strings, all condition-credit sums, schema score maxima, the explicit score-target sidecar, explicit half-credit permissions, balanced normalized score levels and nontrivial condition reversal. `logical-prompts-manifest.json` records branch hashes and message byte lengths; no prediction or quality report is generated.

The maximum source context is 327 UTF-8 bytes. The largest compiled messages are 5,202 bytes for v1 and 2,624 bytes for v2. These compact byte bounds leave room for later frozen-tokenizer verification, but do not prove a 2,048-token limit. No actual tokenizer was called, so token fit remains unverified.

Final raw `proposed-train.jsonl` SHA-256: `a2252720fc7da7ad2aa2bd2a71fe231ceed866ddc49d44429c241cfad01ba54b`.

Independent semantic review is supplied as `review.json` and `semantic-review.md`. The reviewer independently reasoned through all 90 source answers and all 90 score-condition credits, then compared all 240 record targets at the final corpus/source hashes; all agreed. Target fields were suppressed during derivation, but the parent agent had disclosed one replacement context's gold in a progress message, and aggregate balancing requirements were known. This was an independent semantic review, not a fully blinded 90-source experiment. The root agent will separately review all 90 sources before any adoption decision.

CPU schema and logical prompt checks prove parse/compilation and structural invariants. Semantic review supports the authored golds within each synthetic scenario. Neither lane establishes training benefit or model performance.
