import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { loadQualityRecords, validateQualityRecords } from '../../../dist/evaluation.js';
import { preparePrompt, canonical } from '../../../dist/core.js';
const root=resolve(import.meta.dirname,'../../..'), folder=import.meta.dirname;
const sha=b=>createHash('sha256').update(b).digest('hex');
const raw=await readFile(join(folder,'proposed-train.jsonl'));
assert.equal(sha(raw),'a2252720fc7da7ad2aa2bd2a71fe231ceed866ddc49d44429c241cfad01ba54b');
const records=validateQualityRecords(raw.toString().trimEnd().split('\n').map(JSON.parse));
const sources=JSON.parse(await readFile(join(folder,'source-contexts.json'),'utf8'));
const credits=JSON.parse(await readFile(join(folder,'score-targets.json'),'utf8'));
assert.equal(records.length,240); assert.equal(sources.length,90); assert.equal(credits.length,120);
const groups=new Map(), ids=new Set(), payloads=new Set();
const context=r=>canonical(r.request.state??r.request.messages.map(m=>({role:m.role,content:m.content})));
const simpleContext=r=>r.request.state??(r.request.messages.length===1&&r.request.messages[0].role==='user'?r.request.messages[0].content:r.request.messages);
const contexts=new Set(sources.map(s=>canonical(s.context)));
assert.equal(contexts.size,90);
const sourceMap=new Map(sources.map(s=>['evidence-supplement-train-'+s.source_id,s]));
const creditMap=new Map(credits.map(c=>[c.record_id,c]));
let compilations=0, maxV2Bytes=0;
for(const r of records){
 assert.equal(r.split,'train');assert.ok(!ids.has(r.id));ids.add(r.id);
 assert.equal(r.request.questions.length,1);assert.deepEqual(Object.keys(r.targets),['q']);assert.deepEqual(Object.keys(r.targets.q),['answer']);
 const s=sourceMap.get(r.group_id),q=r.request.questions[0];assert.ok(s);assert.equal(q.type,s.type);assert.equal(simpleContext(r),s.context);assert.equal(r.targets.q.answer,s.expected_answer);
 const g=groups.get(r.group_id)??[];g.push(r);groups.set(r.group_id,g);
 const payload=canonical(JSON.parse(JSON.stringify(r.request)));assert.ok(!payloads.has(payload));payloads.add(payload);
 if(q.type==='score'){
  assert.equal(q.criteria.length-1,s.max_score);assert.equal(s.conditions.length,s.max_score);
  assert.equal(s.conditions.reduce((n,c)=>n+c.expected_credit,0),s.expected_answer);
  for(const c of s.conditions){assert.ok([0,.5,1].includes(c.expected_credit));if(c.expected_credit===.5)assert.ok(c.text.includes('explicitly allow 0.5 point'));assert.ok(!q.instructions.includes('['+c.key+']'));}
  const ordered=r.id.includes('-forward-')?s.conditions:[...s.conditions].reverse();
  const positions=ordered.map(c=>q.instructions.indexOf(c.text));assert.ok(positions.every(n=>n>=0));assert.ok(positions.every((n,i)=>i===0||n>positions[i-1]));
  const c=creditMap.get(r.id);assert.ok(c);assert.equal(c.sum,s.expected_answer);assert.equal(c.max_score,s.max_score);assert.deepEqual(c.ordered_rubric_credits,ordered.map(x=>({criterion_key:x.key,credit:x.expected_credit})));
 }else assert.ok(q.instructions.includes(s.proposition));
 for(const version of ['v1','v2']){const p=preparePrompt(r.request,version);assert.equal(p.questions.length,1);if(version==='v2')maxV2Bytes=Math.max(maxV2Bytes,Buffer.byteLength(canonical(p.questions[0].messages)));compilations++;}
}
assert.equal(groups.size,90);
for(const [id,g]of groups){const s=sourceMap.get(id);assert.equal(g.length,s.type==='noul'?2:4);assert.equal(g.filter(r=>r.request.state!==undefined).length,g.length/2);if(s.type==='score'){const forward=g.find(r=>r.id.endsWith('-forward-state')),reverse=g.find(r=>r.id.endsWith('-reverse-state'));assert.notEqual(forward.request.questions[0].instructions,reverse.request.questions[0].instructions);assert.deepEqual(forward.request.questions[0].criteria,reverse.request.questions[0].criteria);}}
const separation=[];
for(const name of ['quality.jsonl','developer-workflows.jsonl','developer-supplement-train.jsonl','developer-diagnosis-validation.jsonl']){
 const path=join(root,'fixtures',name), rows=await loadQualityRecords(path);
 for(const r of rows){assert.ok(!ids.has(r.id));assert.ok(!groups.has(r.group_id));assert.ok(!contexts.has(canonical(simpleContext(r))));}
 separation.push({file:name,raw_sha256:sha(await readFile(path)),compared_records:rows.length,ids_groups_exact_contexts_disjoint:true});
}
const noul=sources.filter(s=>s.type==='noul'),scores=sources.filter(s=>s.type==='score');
assert.equal(noul.length,60);assert.equal(scores.length,30);
for(const label of [true,false,null])assert.equal(noul.filter(s=>s.expected_answer===label).length,20);
for(const level of [0,.25,.5,.75,1])assert.equal(scores.filter(s=>s.expected_answer/s.max_score===level).length,6);
const proof={kind:'jev_root_train_proposal_review',observed_at:new Date().toISOString(),status:'reviewed_proposal_not_adopted',raw_sha256:sha(raw),records:240,source_groups:90,production_cpu_compilations:compilations,max_v2_message_bytes:maxV2Bytes,all_train:true,all_source_targets_and_condition_sums_match:true,manual_root_semantic_review:{source_contexts:90,noul_propositions:60,score_contexts:30,condition_credits:90,material_gold_contradictions:0,note:'ROOT inspected all 90 complete contexts and their propositions or condition rubrics; synthetic stated trusted traces, not live developer observations.'},mechanical_separation:separation,sidecar_sha256:Object.fromEntries(await Promise.all(['source-contexts.json','score-targets.json','review.json','cpu-validation.json'].map(async n=>[n,sha(await readFile(join(folder,n)))]))),token_fit_verified:false,model_calls:0,native_calls:0,network_calls:0,training_selected:false,protected_targets_used_for_training_or_proposal_design:false,separation_limit:'Exact normalized contexts and IDs/groups; semantic independence additionally reviewed against bounded existing VAL source audits. No protected TEST scenarios emitted or retained in proposal review.'};
await writeFile(join(folder,'root-review-proof.json'),JSON.stringify(proof,null,2)+'\n',{flag:'wx',mode:0o600});console.log(JSON.stringify(proof,null,2));
