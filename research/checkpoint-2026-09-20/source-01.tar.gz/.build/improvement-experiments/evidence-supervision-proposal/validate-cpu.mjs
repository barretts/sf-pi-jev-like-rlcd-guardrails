import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';

const directory = new URL('./', import.meta.url);
const production = new URL('../../../src/', import.meta.url);
const frozenDist = new URL('../../../dist/', import.meta.url);
const { validateQualityRecords } = await import(new URL('evaluation.js', frozenDist));
const { preparePrompt, canonical } = await import(new URL('core.js', frozenDist));
const raw = await readFile(new URL('proposed-train.jsonl', directory));
const authored = JSON.parse(await readFile(new URL('source-contexts.json', directory), 'utf8'));
const scoreTargets = JSON.parse(await readFile(new URL('score-targets.json', directory), 'utf8'));
const scoreTargetsById = new Map(scoreTargets.map(g=>[g.record_id,g]));
const values = raw.toString('utf8').trimEnd().split('\n').map(JSON.parse);
const records = validateQualityRecords(values);
const groups = new Map();
const count = (items, key) => Object.fromEntries([...new Set(items.map(key))].sort().map(k => [k,items.filter(i=>key(i)===k).length]));
let maxPromptBytes = 0;
let maxBranchCount = 0;
const maxPromptBytesByVersion = {v1:0,v2:0};
const compiled = [];
for (const r of records) {
  if (r.split !== 'train') throw new Error('non-train record');
  if (!r.group_id.startsWith('evidence-supplement-train-')) throw new Error('unexpected group prefix');
  if (r.request.questions.length !== 1) throw new Error('record must have one question');
  const context = r.request.state ?? r.request.messages[0].content;
  if (Buffer.byteLength(context)>2048) throw new Error('context byte cap exceeded');
  const members = groups.get(r.group_id) ?? [];
  members.push(r); groups.set(r.group_id, members);
  for (const version of ['v1','v2']) {
    const plan = preparePrompt(r.request, version);
    if (plan.template_version !== version || plan.questions.length !== 1) throw new Error('invalid logical plan');
    const branch = plan.questions[0];
    const bytes = Buffer.byteLength(canonical(branch.messages));
    maxPromptBytes = Math.max(maxPromptBytes, bytes);
    maxPromptBytesByVersion[version] = Math.max(maxPromptBytesByVersion[version],bytes);
    maxBranchCount = Math.max(maxBranchCount, plan.questions.length);
    compiled.push({record_id:r.id, version, branch_sha256:createHash('sha256').update(canonical(branch)).digest('hex'), logical_prompt_bytes:bytes});
  }
}
const sourceByGroup = new Map(authored.map(s=>['evidence-supplement-train-'+s.source_id,s]));
let halfCreditConditions = 0;
for (const [group, members] of groups) {
  const source = sourceByGroup.get(group);
  if (!source) throw new Error('missing authored source');
  if (members.length !== (source.type==='noul'?2:4)) throw new Error('wrong group size');
  if (new Set(members.map(r=>JSON.stringify(r.targets))).size!==1) throw new Error('targets vary within group');
  if (new Set(members.map(r=>r.request.state??r.request.messages[0].content)).size!==1) throw new Error('context varies within group');
  if (source.type==='score') {
    if (source.conditions.length !== source.max_score) throw new Error('bad maximum');
    if (source.conditions.reduce((sum,c)=>sum+c.expected_credit,0)!==source.expected_answer) throw new Error('credit sum differs');
    if (![0,.25,.5,.75,1].includes(source.expected_answer/source.max_score)) throw new Error('unexpected normalized level');
    for (const c of source.conditions) {
      if (![0,.5,1].includes(c.expected_credit)) throw new Error('unexpected raw credit');
      if (c.expected_credit===.5) {
        if (!c.text.includes('explicitly allow 0.5 point')) throw new Error('half credit not explicitly allowed');
        halfCreditConditions++;
      }
    }
    const forward=members.find(r=>r.id.endsWith('forward-state')).request.questions[0];
    const reverse=members.find(r=>r.id.endsWith('reverse-state')).request.questions[0];
    if (canonical(forward.criteria)!==canonical(reverse.criteria)) throw new Error('ordinal anchors were permuted');
    if (forward.instructions===reverse.instructions) throw new Error('condition order did not change');
    if (forward.instructions.includes('[c1]')) throw new Error('internal gold keys are model-visible');
    for (const record of members) {
      const gold = scoreTargetsById.get(record.id);
      if (!gold || gold.sum!==record.targets.q.answer || gold.max_score!==record.request.questions[0].criteria.length-1)
        throw new Error('score target sidecar differs from production target/range');
      if (gold.ordered_rubric_credits.reduce((sum,c)=>sum+c.credit,0)!==gold.sum)
        throw new Error('ordered credits do not sum');
      const ordered = record.id.includes('-forward-')?source.conditions:[...source.conditions].reverse();
      if (JSON.stringify(gold.ordered_rubric_credits)!==JSON.stringify(ordered.map(c=>({criterion_key:c.key,credit:c.expected_credit}))))
        throw new Error('ordered credits do not match variant');
    }
  }
}
if (new Set(authored.map(s=>s.context)).size!==90) throw new Error('duplicate independent contexts');
const noulSources=authored.filter(s=>s.type==='noul');
const scoreSources=authored.filter(s=>s.type==='score');
const proof = {
  status:'CPU validation passed; proposal only, not adopted or frozen',
  validation_method:'existing unchanged production dist/evaluation.js validateQualityRecords; production dist/core.js preparePrompt v1 and v2; CPU-only Node imports, no source transpilation or project build',
  record_count:records.length, source_context_count:authored.length, group_count:groups.size,
  record_type_counts:count(records,r=>r.request.questions[0].type),
  source_type_counts:count(authored,s=>s.type),
  representation_record_counts:count(records,r=>r.request.state!==undefined?'state':'chat'),
  noul_source_label_counts:count(noulSources,s=>s.expected_answer===null?'unknown':String(s.expected_answer)),
  noul_record_label_counts:count(records.filter(r=>r.request.questions[0].type==='noul'),r=>r.targets.q.answer===null?'unknown':String(r.targets.q.answer)),
  score_source_maximum_counts:count(scoreSources,s=>String(s.max_score)),
  score_record_maximum_counts:count(records.filter(r=>r.request.questions[0].type==='score'),r=>String(r.request.questions[0].criteria.length-1)),
  score_source_normalized_level_counts:count(scoreSources,s=>String(s.expected_answer/s.max_score)),
  score_record_normalized_level_counts:count(records.filter(r=>r.request.questions[0].type==='score'),r=>String(r.targets.q.answer/(r.request.questions[0].criteria.length-1))),
  score_source_raw_sum_counts:count(scoreSources,s=>String(s.expected_answer)),
  score_source_condition_credit_counts:count(scoreSources.flatMap(s=>s.conditions),c=>String(c.expected_credit)),
  score_record_condition_credit_counts:count(scoreSources.flatMap(s=>s.conditions.flatMap(c=>[c,c,c,c])),c=>String(c.expected_credit)),
  earned_half_credit_source_conditions:halfCreditConditions,
  score_condition_order_variant_records:120,
  score_condition_order_carrier_counts:count(records.filter(r=>r.request.questions[0].type==='score'),r=>(r.id.includes('-forward-')?'forward':'reverse')+'-'+(r.request.state!==undefined?'state':'chat')),
  score_condition_order_pairs:60,
  model_visible_internal_credit_keys:false,
  score_target_sidecar_count:scoreTargets.length,
  logical_prompt_compilation_count:compiled.length, max_logical_plan_branches:maxBranchCount,
  maximum_context_utf8_bytes:Math.max(...authored.map(s=>Buffer.byteLength(s.context))),
  maximum_compiled_messages_utf8_bytes:maxPromptBytes,
  maximum_compiled_messages_utf8_bytes_by_version:maxPromptBytesByVersion,
  raw_sha256:createHash('sha256').update(raw).digest('hex'),
  source_contexts_sha256:createHash('sha256').update(await readFile(new URL('source-contexts.json',directory))).digest('hex'),
  score_targets_sha256:createHash('sha256').update(await readFile(new URL('score-targets.json',directory))).digest('hex'),
  public_source_sha256:Object.fromEntries(await Promise.all(['core.ts','evaluation.ts','recipes.ts'].map(async name=>[name,createHash('sha256').update(await readFile(new URL(name,production))).digest('hex')]))),
  frozen_dist_sha256:Object.fromEntries(await Promise.all(['core.js','evaluation.js'].map(async name=>[name,createHash('sha256').update(await readFile(new URL(name,frozenDist))).digest('hex')]))),
  input_sample_sha256:createHash('sha256').update(await readFile(new URL('train-style-12.jsonl',directory))).digest('hex'),
  no_network_or_auth:true, no_native_or_gpu_calls:true, no_model_calls:true, no_project_build:true,
  tokenization_performed:false, token_fit_proven:false,
  constraints:'Only supplied TRAIN style sample and public core/evaluation/recipe schemas used; all 240 proposal records remain train; source credit sidecar preserves production target schema {answer}; logical byte bounds do not prove a frozen 2048-token fit.',
};
await writeFile(new URL('cpu-validation.json',directory),JSON.stringify(proof,null,2)+'\n');
await writeFile(new URL('logical-prompts-manifest.json',directory),JSON.stringify(compiled,null,2)+'\n');
console.log(JSON.stringify(proof,null,2));
