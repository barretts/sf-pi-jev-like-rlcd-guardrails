import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { PINS, sha, jsonBytes, strictJson } from './contracts.mjs';

// Explicit source-release preparation only. It never launches the tests or any
// renderer/native/model. Caller first observes the focused CPU command CLOSED0.
const here = new URL('./', import.meta.url);
const root = new URL('../../../', here);
const own = ['attest.mjs', 'contracts.mjs', 'fixtures.cpu.mjs', 'attest.cpu.test.mjs', 'render-reference.py',
  'source-contract-check.mjs', 'README.md', 'freeze-source.mjs'];
const source = ['dist/core.js', 'dist/evaluation.js', 'dist/rfdt.js', 'dist/backend.js', 'dist/models.js',
  'scripts/developer-decision-eval.mjs', '.build/improvement-experiments/fractional-score-hypothesis/candidate-2/grid.mjs',
  '.build/improvement-experiments/gemma4-successor-quality/grade.mjs',
  ...['protocol.mjs', 'harness.mjs', 'capability.mjs', 'runner.mjs', 'root-entry.mjs'].map(name => '.build/improvement-experiments/gemma4-successor-direct-proposal/' + name),
  ...['protocol.mjs', 'classifier.mjs', 'runner.mjs'].map(name => '.build/improvement-experiments/gemma4-runtime-candidate-1/quality-run/' + name),
  '.build/improvement-experiments/gemma4-label-prototype/research-quality/render-reference.py',
  '.build/improvement-experiments/gemma4-label-prototype/research-quality/quality.mjs',
  '.build/improvement-experiments/gemma4-direct-result-audit/attest.mjs',
  'models/gemma-4-31B-it.chat_template.jinja'];
const metadata = [
  '.build/improvement-experiments/gemma4-successor-direct-proposal/prospective-protocol-root-1.json',
  '.build/improvement-experiments/gemma4-successor-direct-proposal/root-original-server-profile-metadata-1.json',
  '.build/improvement-experiments/gemma4-runtime-candidate-1/root-qualification-metadata-1.json',
  '.build/improvement-experiments/gemma4-successor-direct-proposal/source-release-revision-2.json',
];
async function identity(url) { const bytes = await readFile(url); return { path: fileURLToPath(url), bytes: bytes.length, sha256: sha(bytes) }; }
export async function freezeSourcePreparation({ observedCpuExitCode, observedCpuSessionClosed, expectedTests }) {
  assert.equal(observedCpuExitCode, 0); assert.equal(observedCpuSessionClosed, true); assert.equal(expectedTests, 17);
  const output = await readFile(new URL('cpu-tap.txt', here)); const text = output.toString('utf8');
  for (const [name, value] of Object.entries({ tests: expectedTests, pass: expectedTests, fail: 0, cancelled: 0, skipped: 0, todo: 0 }))
    assert.match(text, new RegExp('^# ' + name + ' ' + value + '$', 'm'), 'Focused CPU observed ' + name);
  const duration = Number(text.match(/^# duration_ms ([0-9.]+)$/m)?.[1]); assert.ok(Number.isFinite(duration) && duration > 0);
  const proof = { kind: 'successor312_invented_injected_CPU_proof_ONLY', observed_at: new Date().toISOString(),
    command: 'node --test --test-reporter=tap .build/improvement-experiments/gemma4-successor-direct-result-audit/attest.cpu.test.mjs',
    tests: expectedTests, passed: expectedTests, failed: 0, observed_exit_code: observedCpuExitCode, observed_session_closed: true,
    duration_ms: duration, raw_CPU_output: await identity(new URL('cpu-tap.txt', here)),
    tests_are_entirely_invented: true, no_actual_model_response_or_qualification_output_read: true,
    model_tokenizer_native_GPU_training_network_auth_executed: false, no_actual_quality_or_gain_proven: true, approval_effect: 'none' };
  strictJson(proof); await writeFile(new URL('cpu-proof.json', here), jsonBytes(proof), { flag: 'wx', mode: 0o600 });
  const urls = [...own.map(name => new URL(name, here)), ...source.map(name => new URL(name, root)), ...metadata.map(name => new URL(name, root))];
  const sources = await Promise.all(urls.map(identity));
  const expected = new Map([
    ['/candidate-2/grid.mjs', PINS.grid], ['/dist/core.js', PINS.core], ['/dist/evaluation.js', PINS.evaluation], ['/dist/rfdt.js', PINS.rfdt],
    ['/scripts/developer-decision-eval.mjs', PINS.decision], ['/gemma4-successor-quality/grade.mjs', '0821757efa2dd445e645a2f6d22751d455895d30543aadcc32901a2c6fda794b'],
    ['/gemma4-successor-direct-proposal/runner.mjs', PINS.benchmarkRunner], ['/gemma4-successor-direct-proposal/source-release-revision-2.json', PINS.benchmarkRelease],
    ['/prospective-protocol-root-1.json', PINS.prospective], ['/root-original-server-profile-metadata-1.json', PINS.baselineMetadata],
    ['/root-qualification-metadata-1.json', PINS.qualificationMetadata], ['/models/gemma-4-31B-it.chat_template.jinja', PINS.template],
  ]);
  for (const [suffix, hash] of expected) assert.equal(sources.find(row => row.path.endsWith(suffix))?.sha256, hash, 'Frozen permitted source/metadata identity: ' + suffix);
  const release = { kind: 'successor312_independent_result_attester_source_release', release_revision: 1, released_at: new Date().toISOString(),
    research_schema: 'independent-successor-312-result-attestation-1', source_and_CPU_only: true,
    source_identities: sources.sort((a, b) => a.path.localeCompare(b.path)), cpu_proof: await identity(new URL('cpu-proof.json', here)),
    source_manifest_metadata: await identity(new URL('manifest-contract-metadata.json', here)),
    benchmark_source_release_sha256: PINS.benchmarkRelease, benchmark_runner_sha256: PINS.benchmarkRunner,
    benchmark_final_source_revision: 2, existing_successor_grade_sha256_unchanged: '0821757efa2dd445e645a2f6d22751d455895d30543aadcc32901a2c6fda794b',
    bounded_source_review: { reproduced_false_positives: ['RPC PID not bound to owned block', 'classifier envelope duration not enclosed', 'extra init receipt ignored'],
      all_three_closed_and_regression_verified: true, explicit_null_unknown_population_preserved: true,
      teacher_contract_review: 'no request/schema/instruction/normalization mismatch found', review_stopped: true },
    raw_weight_or_native_artifact_full_SHA_verification_by_source_agent: false,
    actual_model_quality_performance_or_gain_proven: false, actual_run_outputs_read: false,
    original_frozen_sources_edited: false, held_out_TEST_read: false, native_execution_authorized: false,
    production_role_approval: false, approval_effect: 'none', source_ownership_released_to_ROOT: true };
  strictJson(release); await writeFile(new URL('source-freeze.json', here), jsonBytes(release), { flag: 'wx', mode: 0o600 });
  return { release: await identity(new URL('source-freeze.json', here)), cpu_proof: release.cpu_proof,
    attester: sources.find(row => row.path.endsWith('/gemma4-successor-direct-result-audit/attest.mjs')),
    sources: sources.length };
}
