import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { COMPILER_SHA256, ORIGINAL_PLAN_SHA256, RESEARCH_SCHEMA, SUCCESSOR_PHYSICAL_IDENTITY } from './grade.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const insist = (condition, message) => { if (!condition) throw new Error(message); };
const priorReleaseBytes = await readFile(join(here, 'release.json'));
insist(sha(priorReleaseBytes) === 'f00e5ba3e192153ed8ce3c327f28ab48611568c0ecc0d195243771220efd5417', 'Preserved original release changed');
const priorRelease = JSON.parse(priorReleaseBytes);
const priorProofBytes = await readFile(join(here, 'cpu-proof.json'));
insist(sha(priorProofBytes) === priorRelease.cpu_proof.sha256, 'Preserved original CPU proof changed');
const preservedSources = await Promise.all(['grade.mjs', 'grade.cpu.test.mjs', 'README.md', 'release.mjs'].map(async name => {
  const path = join(here, 'release-1-source', name), bytes = await readFile(path), original = priorRelease.sources.find(source => source.name === name);
  insist(sha(bytes) === original.sha256 && bytes.length === original.bytes, 'Preserved original source changed: ' + name);
  return { name: 'release-1-source/' + name, path, bytes: bytes.length, sha256: sha(bytes) };
}));
const pinnedDependencies = new Map([
  ['../fractional-score-hypothesis/candidate-2/grid.mjs', COMPILER_SHA256],
  ['../gemma4-label-prototype/research-quality/quality.mjs', '0e78e1edd104cc9392d67aa27a3d912b8cce5c33b062825aad7c1c6347b75795'],
  ['../gemma4-label-prototype/research-quality/protocol.mjs', 'eb3a31aa82854014e1afed1e60d2f4e4128362efac2c5ccdc1a047fd4462ea83'],
  ['../../../dist/core.js', '2ee6c409a12b6a4f7b7a7d63c37d84923740e46f8732f625a65d0f39ef04bdf6'],
]);
const paths = ['grade.mjs', 'grade.cpu.test.mjs', 'README.md', 'release.mjs', ...pinnedDependencies.keys(), '../../../dist/evaluation.js'];
const sources = await Promise.all(paths.map(async name => {
  const path = resolve(here, name), bytes = await readFile(path), sha256 = sha(bytes);
  if (pinnedDependencies.has(name)) insist(sha256 === pinnedDependencies.get(name), 'Reviewed dependency changed: ' + name);
  return { name, path, bytes: bytes.length, sha256 };
}));
const tested = await promisify(execFile)(process.execPath, ['--test', '--test-reporter=tap', join(here, 'grade.cpu.test.mjs')],
  { cwd: here, timeout: 30000, maxBuffer: 1024 * 1024, encoding: 'utf8' });
insist(/^# tests 14$/m.test(tested.stdout) && /^# pass 14$/m.test(tested.stdout)
  && /^# fail 0$/m.test(tested.stdout) && /^# skipped 0$/m.test(tested.stdout), 'Complete expected 14-test CPU proof required');
// Protect the source freeze against edits occurring during CPU verification.
for (const source of sources) insist(sha(await readFile(source.path)) === source.sha256, 'Source changed during CPU verification: ' + source.name);
const proof = { research_schema: 'jev.gemma4.successor.cpu-proof.v1', release_revision: 2, frozen_at: new Date().toISOString(),
  scope: 'injected_cpu_only_no_actual_validation_data_no_inference', execution: { command: 'node --test --test-reporter=tap grade.cpu.test.mjs',
    node_version: process.version, exit_code: 0, stdout: tested.stdout, stderr: tested.stderr },
  tests: 14, passed: 14, failed: 0, skipped: 0, source_sha256: sources.find(source => source.name === 'grade.mjs').sha256,
  tests_source_sha256: sources.find(source => source.name === 'grade.cpu.test.mjs').sha256,
  claims: { native_execution: false, actual_model_quality: false, benchmark_gain: false, production_approval: false }, approval_effect: 'none' };
const proofBytes = jsonBytes(proof);
await writeFile(join(here, 'cpu-proof-revision-2.json'), proofBytes, { flag: 'wx', mode: 0o600 });
const release = { research_schema: 'jev.gemma4.successor.grader-release.v1', release_revision: 2, frozen_at: proof.frozen_at,
  report_schema: RESEARCH_SCHEMA, logical_id: 'v2-earned-half-grid-alpha-research-1',
  original_plan_sha256: ORIGINAL_PLAN_SHA256, successor_physical_identity: SUCCESSOR_PHYSICAL_IDENTITY,
  successor_identity_attribution: 'ROOT-supplied new candidate id, emitted ordered profile digest, distinct profile-file digest, and same raw-model pins; no native profile/model/binary reads performed by grader preparation.',
  sources, cpu_proof: { name: 'cpu-proof-revision-2.json', bytes: proofBytes.length, sha256: sha(proofBytes) },
  supersedes: { name: 'release.json', bytes: priorReleaseBytes.length, sha256: sha(priorReleaseBytes),
    reason: 'Original physical profile was inherited incorrectly. Revision 2 requires separately explicit pinned new physical identity while retaining original plan data/scoring unchanged.',
    prior_cpu_proof: { name: 'cpu-proof.json', bytes: priorProofBytes.length, sha256: sha(priorProofBytes) }, preserved_sources: preservedSources },
  original_evaluation_note: 'Current dist/evaluation.js newly exports original unchanged scorePrediction; export-only change is ROOT-attributed. This release binds the current actual exports and tests their behavior, not an unobserved prior native run.',
  approval_effect: 'none', scope: 'source_only_no_inference_or_promotion' };
const releaseBytes = jsonBytes(release);
await writeFile(join(here, 'release-revision-2.json'), releaseBytes, { flag: 'wx', mode: 0o600 });
process.stdout.write(JSON.stringify({ grade_source_sha256: proof.source_sha256, cpu_proof_sha256: sha(proofBytes),
  release_name: 'release-revision-2.json', release_sha256: sha(releaseBytes), tests: proof.tests, passed: proof.passed, approval_effect: 'none' }, null, 2) + '\n');
