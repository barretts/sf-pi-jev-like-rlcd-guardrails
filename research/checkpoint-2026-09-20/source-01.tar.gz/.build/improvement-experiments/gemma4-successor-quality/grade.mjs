import { createHash } from 'node:crypto';
import { canonical, preparePrompt } from '../../../dist/core.js';
import { scorePrediction, validateQualityRecords, qualityDatasetDigest, summarizeQuality, QUALITY_GATES } from '../../../dist/evaluation.js';
import { compileHalfGrid, LOGICAL_ID } from '../fractional-score-hypothesis/candidate-2/grid.mjs';
import { attachValidationCoverage } from '../gemma4-label-prototype/research-quality/quality.mjs';
import { diagnosisGrid } from '../gemma4-label-prototype/research-quality/protocol.mjs';

// This pure, source-only grader does not load files or run inference.
export const ORIGINAL_PLAN_SHA256 = '367ec2f18be9514bb6319211be3f68cdfe5d076c8bd01811851de25680395a2b';
export const COMPILER_SHA256 = '92176c96d6a49a600c281c43578eb55aea20082b0847019bfef64282f7b40872';
export const RESEARCH_SCHEMA = 'jev.gemma4.successor.quality-report.v1';
export const MANIFEST_SCHEMA = 'jev.gemma4.successor.quality-manifest.v1';
export const SUCCESSOR_PHYSICAL_IDENTITY = Object.freeze({
  research_profile: 'gemma4-direct-label-raw-q4-runtime-candidate-1',
  physical_profile_sha256: '48dda5a0b1630b607f0e5c691366ced92843ea43f0d5d4aab9bc62cc2a7416fc',
  physical_profile_file_sha256: 'd0e4f0aa97661a9fffbbf80a649b6e8b1add435d76366e3f775504d00b5058c7',
  raw_model_sha256: '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b',
  raw_model_bytes: 17651001568,
});
export const SET_SPECS = Object.freeze([
  Object.freeze({ name: 'legacy-validation-60', records: 60, groups: 30 }),
  Object.freeze({ name: 'developer-validation-78', records: 78, groups: 39 }),
  Object.freeze({ name: 'diagnosis-validation-56', records: 56, groups: 14 }),
]);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const insist = (condition, message) => { if (!condition) throw new Error(message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const same = (actual, expected, label) => insist(canonical(actual) === canonical(expected), label + ' mismatch');
const digest = value => sha(canonical(JSON.parse(JSON.stringify(value))));
const byteBuffer = value => {
  insist(typeof value === 'string' || Buffer.isBuffer(value), 'Expected immutable UTF-8 bytes or string');
  return Buffer.isBuffer(value) ? Buffer.from(value) : Buffer.from(value, 'utf8');
};
const hex = value => typeof value === 'string' && /^[0-9a-f]{64}$/.test(value);

// Enforce the parsed-JSON boundary without cloning or invoking getters/toJSON.
// Otherwise inherited attribution could qualify in memory and vanish from the retained report.
function requireRetainableJson(value, ancestors = new Set(), depth = 0) {
  insist(depth <= 128, 'Raw run envelopes exceed JSON nesting limit');
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number') { insist(Number.isFinite(value), 'Raw run envelopes require finite JSON numbers'); return; }
  insist(typeof value === 'object' && value !== null, 'Raw run envelopes require plain JSON values');
  insist(!ancestors.has(value), 'Raw run envelopes must be acyclic JSON');
  const array = Array.isArray(value), prototype = Object.getPrototypeOf(value);
  insist(array ? prototype === Array.prototype : prototype === Object.prototype || prototype === null, 'Raw run envelopes require plain own-property JSON objects');
  insist(Object.getOwnPropertySymbols(value).length === 0, 'Raw run envelopes require string JSON keys');
  const descriptors = Object.getOwnPropertyDescriptors(value);
  ancestors.add(value);
  if (array) {
    insist(Object.keys(descriptors).length === value.length + 1, 'Raw run envelopes require dense JSON arrays without extra properties');
    for (let i = 0; i < value.length; i++) {
      const descriptor = descriptors[String(i)];
      insist(descriptor && 'value' in descriptor && descriptor.enumerable, 'Raw run envelopes forbid sparse arrays and JSON accessors');
      requireRetainableJson(descriptor.value, ancestors, depth + 1);
    }
  } else {
    for (const descriptor of Object.values(descriptors)) {
      insist('value' in descriptor && descriptor.enumerable, 'Raw run envelopes forbid JSON accessors and hidden properties');
      requireRetainableJson(descriptor.value, ancestors, depth + 1);
    }
  }
  ancestors.delete(value);
}

function prepareInputs({ originalFrozenPlanBytes, inputSets, successorPhysicalIdentity }, expectedPlanSha256, evidenceScope) {
  insist(object(successorPhysicalIdentity), 'Explicit successor physical identity required');
  requireRetainableJson(successorPhysicalIdentity);
  same(successorPhysicalIdentity, SUCCESSOR_PHYSICAL_IDENTITY, 'Explicit successor physical identity');
  insist(hex(expectedPlanSha256), 'Expected frozen plan SHA must be lowercase SHA-256');
  const bytes = byteBuffer(originalFrozenPlanBytes);
  insist(sha(bytes) === expectedPlanSha256, 'Original frozen run-plan bytes mismatch');
  const plan = JSON.parse(bytes.toString('utf8'));
  insist(plan.kind === 'gemma4_validation_research_frozen_run_plan' && plan.template_version === 'v2'
    && plan.scope === 'validation_only_research_no_role_promotion' && plan.expected_records === 194, 'Unsupported original frozen run plan');
  same(plan.quality_gates, QUALITY_GATES, 'Original quality gates');
  insist(plan.additional_gates?.unknown_noul_mae === 0.1 && plan.additional_gates.diagnosis_choice_accuracy === 0.95
    && plan.additional_gates.exact_194_record_coverage === true
    && plan.additional_gates.all_14_diagnosis_groups_and_56_representations === true, 'Original external gates changed');
  insist(Array.isArray(plan.inputs) && plan.inputs.length === 3 && Array.isArray(inputSets) && inputSets.length === 3, 'Exactly three original input sets required');
  insist(object(plan.physical_profile) && plan.research_profile === plan.physical_profile.id
    && hex(plan.physical_profile_sha256) && sha(JSON.stringify(plan.physical_profile)) === plan.physical_profile_sha256, 'Frozen physical profile identity mismatch');
  insist(hex(plan.artifacts?.model?.sha256) && Number.isSafeInteger(plan.artifacts.model.bytes) && plan.artifacts.model.bytes > 0
    && plan.physical_profile.model_expected_sha256 === plan.artifacts.model.sha256
    && plan.physical_profile.model_expected_size === plan.artifacts.model.bytes, 'Frozen model identity mismatch');
  const allIds = new Set(), allGroups = new Set();
  const sets = SET_SPECS.map((spec, index) => {
    const frozen = plan.inputs[index], input = inputSets[index];
    insist(frozen.name === spec.name && input.name === spec.name && frozen.records === spec.records && frozen.groups === spec.groups, 'Frozen set identity/count/order mismatch');
    const raw = byteBuffer(input.bytes);
    insist(hex(frozen.input_sha256) && sha(raw) === frozen.input_sha256 && raw.length === frozen.input_bytes, spec.name + ': original input bytes changed');
    const values = raw.toString('utf8').split(/\r?\n/).filter(line => line.trim()).map(line => JSON.parse(line));
    const records = validateQualityRecords(values);
    insist(records.length === spec.records && records.every(record => record.split === 'validation'), spec.name + ': expected complete validation-only records');
    same(records.map(record => record.id), frozen.expected_ids, spec.name + ': original record IDs/order');
    insist(new Set(records.map(record => record.group_id)).size === spec.groups, spec.name + ': original group coverage mismatch');
    const originalPrompts = records.map(record => [record.id, sha(JSON.stringify(preparePrompt({
      ...record.request, options: { ...record.request.options, template_version: 'v2' },
    }, 'v2').questions))]);
    same(originalPrompts, frozen.logical_prompt_sha256, spec.name + ': original compiled prompts');
    for (const record of records) {
      insist(!allIds.has(record.id), 'Duplicate original record ID across sets: ' + record.id);
      allIds.add(record.id);
    }
    for (const group of new Set(records.map(record => record.group_id))) {
      insist(!allGroups.has(group), 'Original groups overlap across sets: ' + group);
      allGroups.add(group);
    }
    if (index === 2) {
      insist(records.every(record => record.request.questions.length === 1 && record.request.questions[0].type === 'choice'), 'Diagnosis requires exactly one original choice per row');
      for (const group of new Set(records.map(record => record.group_id)))
        insist(diagnosisGrid(records.filter(record => record.group_id === group)).complete, 'Diagnosis group lacks original state/chat/order cells: ' + group);
    }
    return { ...spec, records, expected_ids: records.map(record => record.id), input_sha256: sha(raw), input_bytes: raw.length };
  });
  insist(allIds.size === 194 && allGroups.size === 83, 'Exactly 194 unique records and 83 independent groups required');
  same(sets.flatMap(set => set.expected_ids), plan.execution_order, 'Original frozen execution order');
  return { plan, sets, expectedPlanSha256, evidenceScope, successorPhysicalIdentity: structuredClone(successorPhysicalIdentity) };
}

function successorManifest(prepared) {
  const { plan, sets, expectedPlanSha256, evidenceScope, successorPhysicalIdentity } = prepared;
  return {
    research_schema: MANIFEST_SCHEMA, evidence_scope: evidenceScope, logical_id: LOGICAL_ID,
    original_frozen_plan_sha256: expectedPlanSha256, required_compiler_source_sha256: COMPILER_SHA256,
    expected_records: 194, expected_groups: 83,
    ...successorPhysicalIdentity,
    original_physical_identity: { research_profile: plan.research_profile, physical_profile_sha256: plan.physical_profile_sha256,
      raw_model_sha256: plan.artifacts.model.sha256, raw_model_bytes: plan.artifacts.model.bytes },
    inputs: sets.map(set => ({ name: set.name, records: set.records.length, groups: set.groups,
      input_sha256: set.input_sha256, input_bytes: set.input_bytes, dataset_sha256: qualityDatasetDigest(set.records) })),
    records: sets.flatMap(set => set.records.map(record => {
      const compiled = compileHalfGrid({ ...record.request, options: { ...record.request.options, template_version: 'v2' } });
      insist(compiled.template_version === LOGICAL_ID && compiled.research_contract?.logical_id === LOGICAL_ID, 'Successor compiler logical identity mismatch');
      return { record_id: record.id, group_id: record.group_id, set: set.name, split: 'validation',
        logical_prompt_sha256: compiled.logical_prompt_sha256, original_record_sha256: digest(record),
        expected_model: record.request.model, expected_questions: record.request.questions.length };
    })),
    approval_effect: 'none',
  };
}

export function buildSuccessorManifest(input) {
  return successorManifest(prepareInputs(input, ORIGINAL_PLAN_SHA256, 'submitted_runs'));
}

function checkAttribution(envelope, expected, manifest) {
  insist(object(envelope), 'Expected run envelope object');
  insist(envelope.record_id === expected.record_id, 'Run envelope record order/identity mismatch');
  for (const field of ['logical_id', 'research_profile', 'physical_profile_sha256', 'raw_model_sha256', 'raw_model_bytes'])
    insist(envelope[field] === manifest[field], 'Run envelope attribution mismatch: ' + field);
  insist(envelope.logical_prompt_sha256 === expected.logical_prompt_sha256, 'Run envelope compiled prompt SHA mismatch');
  insist(envelope.model === expected.expected_model, 'Run envelope response model identity mismatch');
  insist(Number.isFinite(envelope.elapsed_ms) && envelope.elapsed_ms >= 0, 'Invalid run envelope elapsed_ms');
  insist(envelope.error === undefined || (typeof envelope.error === 'string' && envelope.error.length > 0), 'Malformed retained run error');
  insist(envelope.response !== undefined || envelope.error !== undefined, 'Every run must retain a response or explicit failure');
  if (envelope.response !== undefined) {
    const response = envelope.response;
    insist(object(response) && response.model === expected.expected_model && object(response.metadata), 'Malformed raw response/model metadata');
    const metadata = response.metadata;
    insist(metadata.template_version === LOGICAL_ID && metadata.logical_prompt_sha256 === expected.logical_prompt_sha256, 'Raw response logical attribution mismatch');
    for (const field of ['research_profile', 'physical_profile_sha256', 'raw_model_sha256', 'raw_model_bytes'])
      insist(metadata[field] === manifest[field], 'Raw response physical attribution mismatch: ' + field);
  }
}

function gradingView(record, envelope) {
  const view = { id: record.id, group_id: record.group_id, split: record.split,
    regression: record.regression === true, answers: [], elapsed_ms: envelope.elapsed_ms };
  if (envelope.error !== undefined) return { ...view, error: envelope.error };
  try {
    const predictions = envelope.response.answers;
    insist(object(predictions), 'Malformed raw answers');
    same(Object.keys(predictions).sort(), record.request.questions.map(question => question.id).sort(), 'Original question answer coverage');
    view.answers = record.request.questions.map(question => {
      const prediction = predictions[question.id];
      insist(object(prediction), 'Malformed answer: ' + question.id);
      if (question.type === 'score') insist(Number.isFinite(prediction.score) && prediction.score >= 0
        && prediction.score <= question.criteria.length - 1, 'Score outside original rubric: ' + question.id);
      if (question.type === 'choice') insist(question.criteria.some(candidate => candidate.id === prediction.choice), 'Choice outside original candidates: ' + question.id);
      // Metadata is neither copied into views nor relabelled to v2. The actual unchanged export grades original units.
      return scorePrediction(question, record.targets[question.id], structuredClone(prediction));
    });
  } catch (error) {
    view.answers = [];
    view.error = error instanceof Error ? error.message : String(error);
  }
  return view;
}

function grade(input, expectedPlanSha256, evidenceScope) {
  const prepared = prepareInputs(input, expectedPlanSha256, evidenceScope);
  const expectedManifest = successorManifest(prepared);
  same(input.successorManifest, expectedManifest, 'Frozen successor grading manifest');
  const { runEnvelopes } = input;
  insist(Array.isArray(runEnvelopes) && runEnvelopes.length === 194, 'Exactly 194 retained run envelopes required; missing/extras are rejected');
  requireRetainableJson(runEnvelopes);
  const records = prepared.sets.flatMap(set => set.records);
  runEnvelopes.forEach((envelope, index) => checkAttribution(envelope, expectedManifest.records[index], expectedManifest));
  const views = records.map((record, index) => gradingView(record, runEnvelopes[index]));
  const summary = summarizeQuality(views);
  const coverageReport = attachValidationCoverage({ summary, results: views }, prepared.sets);
  // The original helper's render predicate reads result.metadata. Views have no metadata;
  // the same predicate is therefore applied directly to unchanged raw envelopes instead.
  const originalAdditional = { ...coverageReport.gates.additional,
    independent_render_all_records: runEnvelopes.every(envelope => !envelope.error && envelope.response?.metadata.independent_render_match === true)
      && views.every(view => !view.error) };
  const developer = prepared.sets[1].records;
  const expectedScores = developer.reduce((sum, record) => sum + record.request.questions.filter(question => question.type === 'score').length, 0);
  const developerIds = new Set(developer.map(record => record.id));
  const developerScores = views.filter(view => developerIds.has(view.id)).flatMap(view => view.answers).filter(answer => answer.type === 'score');
  const correctScores = developerScores.filter(answer => answer.correct === true).length;
  const accuracy = expectedScores ? correctScores / expectedScores : null;
  const prospective = { expected_count: expectedScores, scored_count: developerScores.length, correct_count: correctScores,
    accuracy, threshold: 0.9, passed: expectedScores > 0 && developerScores.length === expectedScores && accuracy >= 0.9,
    rule: 'original scorePrediction.correct; original criteria.length-1 denominator; missing/failing records remain unscored failures' };
  const originalPassed = originalAdditional.original_quality_gates_independently_on_legacy60_and_developer78 && Object.values(originalAdditional).every(Boolean);
  return {
    research_schema: RESEARCH_SCHEMA, evidence_scope: evidenceScope, logical_id: LOGICAL_ID,
    created_at: input.createdAt ?? new Date().toISOString(), approval_effect: 'none',
    original_frozen_plan_sha256: expectedPlanSha256, successor_manifest_sha256: digest(expectedManifest),
    successor_physical_identity: prepared.successorPhysicalIdentity,
    original_physical_identity: expectedManifest.original_physical_identity,
    dataset_sha256: qualityDatasetDigest(records), summary, grade_views: views,
    run_envelopes: runEnvelopes, coverage: coverageReport.coverage, unknown_noul: coverageReport.unknown_noul,
    diagnosis: coverageReport.diagnosis, prospective_developer_score_correctness: prospective,
    gates: { original_production_by_set: coverageReport.gates.production_by_set,
      original_additional: originalAdditional, original_contract_passed: originalPassed,
      prospective_developer_score_correctness: prospective.passed, passed: originalPassed && prospective.passed },
    claims: { production_quality_report: false, native_contracts_verified: false, native_model_quality_established: false,
      benchmark_gain_established: false, production_role_approval: false },
    limits: 'Research grading only. Submitted attribution is checked, not independently proved. CPU mocks prove host grading/coverage, not native execution, model quality, gain, or approval. No evaluateRecords or production template-version relabelling is used.',
  };
}

export function gradeValidationResearch(input) { return grade(input, ORIGINAL_PLAN_SHA256, 'submitted_runs'); }

// Injection is explicitly segregated: these APIs always report injected_cpu and cannot establish a native claim.
export function buildInjectedCpuSuccessorManifest(input, expectedSyntheticPlanSha256) {
  return successorManifest(prepareInputs(input, expectedSyntheticPlanSha256, 'injected_cpu'));
}
export function gradeInjectedCpuValidationResearch(input, expectedSyntheticPlanSha256) {
  return grade(input, expectedSyntheticPlanSha256, 'injected_cpu');
}
