import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { COMPILER_SHA256, ORIGINAL_PLAN_SHA256, RESEARCH_SCHEMA } from './grade.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const insist = (condition, message) => { if (!condition) throw new Error(message); };
const pinnedDependencies = new Map([
  ['../fractional-score-hypothesis/candidate-2/grid.mjs', COMPILER_SHA256],
  ['../gemma4-label-prototype/research-quality/quality.mjs', '0e78e1edd104cc9392d67aa27a3d912b8cce5c33b062825aad7c1c6347b75795'],
  ['../gemma4-label-prototype/research-quality/protocol.mjs', 'eb3a31aa82854014e1afed1e60d2f4e4128362efac2c5ccdc1a047fd4462ea83'],
  ['../../../dist/core.js', '2ee6c409a12b6a4f7b7a7d63c37d84923740e46f8732f625a65d0f39ef04bdf6'],
]);
const paths = ['grade.mjs', 'grade.cpu.test.mjs', 'README.md', 'release.mjs', ...pinnedDependencies.keys(), '../../../dist/evaluation.js'];
const sources = await Promise.all(paths.map(async name => {
  const path = resolve(here, name), bytes = await readFile(path), sha256 = sha(bytes);
  if (pinnedDependencies.has(name)) insist(sha256 === pinnedDependencies.get(name), 'Reviewed dependency changed: ' + name);
  return { name, path, bytes: bytes.length, sha256 };
}));
const tested = await promisify(execFile)(process.execPath, ['--test', '--test-reporter=tap', join(here, 'grade.cpu.test.mjs')],
  { cwd: here, timeout: 30000, maxBuffer: 1024 * 1024, encoding: 'utf8' });
insist(/^# tests 13$/m.test(tested.stdout) && /^# pass 13$/m.test(tested.stdout)
  && /^# fail 0$/m.test(tested.stdout) && /^# skipped 0$/m.test(tested.stdout), 'Complete expected 13-test CPU proof required');
// Protect the source freeze against edits occurring during CPU verification.
for (const source of sources) insist(sha(await readFile(source.path)) === source.sha256, 'Source changed during CPU verification: ' + source.name);
const proof = { research_schema: 'jev.gemma4.successor.cpu-proof.v1', frozen_at: new Date().toISOString(),
  scope: 'injected_cpu_only_no_actual_validation_data_no_inference', execution: { command: 'node --test --test-reporter=tap grade.cpu.test.mjs',
    node_version: process.version, exit_code: 0, stdout: tested.stdout, stderr: tested.stderr },
  tests: 13, passed: 13, failed: 0, skipped: 0, source_sha256: sources.find(source => source.name === 'grade.mjs').sha256,
  tests_source_sha256: sources.find(source => source.name === 'grade.cpu.test.mjs').sha256,
  claims: { native_execution: false, actual_model_quality: false, benchmark_gain: false, production_approval: false }, approval_effect: 'none' };
const proofBytes = jsonBytes(proof);
await writeFile(join(here, 'cpu-proof.json'), proofBytes, { flag: 'wx', mode: 0o600 });
const release = { research_schema: 'jev.gemma4.successor.grader-release.v1', frozen_at: proof.frozen_at,
  report_schema: RESEARCH_SCHEMA, logical_id: 'v2-earned-half-grid-alpha-research-1',
  original_plan_sha256: ORIGINAL_PLAN_SHA256, sources, cpu_proof: { name: 'cpu-proof.json', bytes: proofBytes.length, sha256: sha(proofBytes) },
  original_evaluation_note: 'Current dist/evaluation.js newly exports original unchanged scorePrediction; export-only change is ROOT-attributed. This release binds the current actual exports and tests their behavior, not an unobserved prior native run.',
  approval_effect: 'none', scope: 'source_only_no_inference_or_promotion' };
const releaseBytes = jsonBytes(release);
await writeFile(join(here, 'release.json'), releaseBytes, { flag: 'wx', mode: 0o600 });
process.stdout.write(JSON.stringify({ grade_source_sha256: proof.source_sha256, cpu_proof_sha256: sha(proofBytes),
  release_sha256: sha(releaseBytes), tests: proof.tests, passed: proof.passed, approval_effect: 'none' }, null, 2) + '\n');
