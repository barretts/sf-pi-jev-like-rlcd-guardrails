# Successor research quality grader

This source-only module grades supplied validation research envelopes for `v2-earned-half-grid-alpha-research-1`. It does not launch inference, load data from disk, read a model or tokenizer, train, access the network, promote a source, or approve a production role. The report uses `research_schema: "jev.gemma4.successor.quality-report.v1"`; it is not a production `QualityReport`, does not use `evaluateRecords`, and has no report `template_version` or production `schema_version` field.

The default APIs pin the original immutable run-plan bytes to SHA-256 `367ec2f18be9514bb6319211be3f68cdfe5d076c8bd01811851de25680395a2b`. The original manifest describes exactly 194 validation records in order: `legacy-validation-60` with 30 groups, `developer-validation-78` with 39 groups, and `diagnosis-validation-56` with 14 groups. All 83 groups are distinct across sets. Preparing this source read the original run-plan metadata only; no actual validation inputs, reports, logits, proofs, results, model weights, or tokenizer assets were read or evaluated.

## API

The caller supplies authorized immutable snapshots. The grader has no filesystem I/O.

```js
import { buildSuccessorManifest, gradeValidationResearch } from './grade.mjs';

const input = {
  originalFrozenPlanBytes, // Buffer or UTF-8 string; caller obtains it under its own authorization
  inputSets: [
    { name: 'legacy-validation-60', bytes: legacySnapshotBytes },
    { name: 'developer-validation-78', bytes: developerSnapshotBytes },
    { name: 'diagnosis-validation-56', bytes: diagnosisSnapshotBytes },
  ],
};
const successorManifest = buildSuccessorManifest(input);
// Freeze successorManifest before a future run. Preserve its serialized bytes and digest externally.
const report = gradeValidationResearch({
  ...input, successorManifest, runEnvelopes,
  createdAt: '2030-01-01T00:00:00.000Z', // optional deterministic report timestamp
});
```

Each original input must match the frozen byte hash and length before parsing with the actual exported `validateQualityRecords`. Original record IDs/order, compiled original `preparePrompt(..., 'v2')` hashes, group counts, validation split, and original diagnosis structure must all match. Byte binding preserves original requests, instructions, rubrics, targets, and denominators. The actual exported `qualityDatasetDigest` binds normalized records. The successor manifest is independently rebuilt using the reviewed categorical half-grid compiler and must match exactly. It freezes every record's new compiled logical prompt SHA and original record digest, along with the expected model alias and raw model/profile identity. The original integer rubric maximum remains the scoring denominator; half-grid label count never becomes a new denominator.

Every run envelope must occur once in the exact original order. Required fields are:

```js
{
  record_id,
  logical_id: 'v2-earned-half-grid-alpha-research-1',
  logical_prompt_sha256, // equals this record's successor manifest compiled hash
  research_profile, physical_profile_sha256,
  raw_model_sha256, raw_model_bytes,
  model, // equals this record's unchanged original request.model
  elapsed_ms, // finite, nonnegative
  response, // unchanged original response, when available
  error, // nonempty original failure string, when available
  // additional evidence fields are preserved unchanged
}
```

At least `response` or `error` is required. An error may coexist with a retained response and still grades as a failure. A response must independently preserve its expected `model` and raw metadata: `template_version` must be the distinct successor logical ID, `logical_prompt_sha256` must be the expected compiled SHA, and `research_profile`, `physical_profile_sha256`, `raw_model_sha256`, and `raw_model_bytes` must agree with the frozen manifest. Malformed attribution rejects the entire report rather than converting it into a successful result. The module never rewrites raw response metadata or changes it to `v2`.

Raw envelopes must be finite, acyclic own-property JSON values, as produced by an ordinary JSON parser. Custom prototypes, inherited attribution, getters, `toJSON` functions, hidden properties, sparse arrays, symbols, undefined values, nonfinite numbers, and nesting over 128 levels reject the report before grading. This boundary ensures fields used to qualify a report survive unchanged JSON serialization. A malformed native transport should retain its original failure string without inventing a parsed response. Finite but invalid predictions still become retained record failures.

`run_envelopes` in the report is the exact submitted array; no fields are changed, deleted, or synthesized. Separate `grade_views` contain the metadata-free `QualityRecordResult` fields and cloned answer predictions scored by the actual exported `scorePrediction` against each original question and target. Their top level has no `metadata`, `model`, `usage`, or logical-prompt attribution fields. Missing/extra answers, answers outside original bounds, scoring errors, and retained run errors produce complete record failures with empty scored answers. Failed questions are never filled with successful synthetic answers.

## Gates and attribution limits

The actual original `attachValidationCoverage` helper supplies the original external coverage, unknown-NOUL, diagnosis, and per-set quality rules; the actual `diagnosisGrid` helper validates original cells. `summarizeQuality` is called through the actual evaluation export.

- Legacy and developer sets each independently require the original production quality gates, complete question coverage, and unknown NOUL MAE `<= 0.1` with exact expected unknown coverage. Aggregate metrics cannot compensate for a failing set.
- Unknown NOULs are specifically original `noul` targets with `answer === null`. Their mean absolute error and complete coverage remain unchanged; the report also preserves the original aggregate unknown gate.
- Diagnosis requires all 14 independent groups, all 56 rows, exactly one state/order1, chat/order1, state/order2, and chat/order2 cell per group, no failures, and choice accuracy `>= 0.95`. Thus 54/56 passes the diagnosis accuracy gate and 53/56 fails. The original informational `all_correct` group field is reported; it is not converted into an extra all-correct gate.
- The original helper reads render evidence from `result.metadata`. Because grading views deliberately have no metadata, this one predicate is applied directly to unchanged raw `response.metadata.independent_render_match === true`, also requiring no envelope or grading error. The raw assertion is checked, not independently proved by the grader.
- A prospective additional gate requires developer score correctness `>= 0.9`, complete expected score coverage, and a nonempty original score denominator. Correctness comes directly from original `scorePrediction.correct`, including its original normalized-error `<= 0.1` threshold. The accuracy denominator is the full expected original developer score count, including unscored failures. A passing mean score MAE cannot replace this per-score gate.

Every report declares `approval_effect: "none"`. Its explicit claims for production `QualityReport`, native contracts, native model quality, benchmark gain, and production role approval are false. A passing report establishes only that submitted grading and attribution satisfy this host contract. The manifest's `required_compiler_source_sha256` is a required source pin; a pure function cannot independently inspect the loaded module's source bytes. `release.mjs` checks the actual dependency hash during freeze, and a runtime consumer must check the entire frozen release again before importing/using these sources. The caller must independently establish native compile/render/BOS/label/token/accounting/source/model/process contracts and any actual quality or improvement claim.

## CPU proof and release

`grade.cpu.test.mjs` constructs invented CPU-only contexts and supplied selected logits. The `buildInjectedCpuSuccessorManifest` and `gradeInjectedCpuValidationResearch` APIs accept an injected synthetic original-plan hash and always label their outputs `evidence_scope: "injected_cpu"`. The default actual-run API always requires the literal original run-plan hash and rejects these synthetic plans. CPU injection is not an actual manifest escape route and does not establish native execution or quality.

The 13 tests cover real scorer/summary correspondence, unchanged raw envelopes, original half-credit units, frozen input mutation, exact run coverage, distinct logical attribution, physical/model attribution, retained errors, malformed answer coverage, the plain-JSON serialization boundary, per-set unknown dilution, missing unknown answers, diagnosis threshold/cells/groups, original per-score correctness, and missing render evidence. No actual benchmark or validation record is used.

Run `node --test grade.cpu.test.mjs` for CPU verification. Run `node release.mjs` once to write new, exclusively created `cpu-proof.json` and `release.json`. Release hashes bind the grading module, CPU test source, usage documentation, release script, reviewed compiler, original pure helpers, and current actual core/evaluation exports. The release script executes only these synthetic CPU tests. Existing release files are preserved rather than overwritten. Consumers must verify the released source and dependency hashes before use. Source freeze is not an inference launch or source promotion.
