import assert from 'node:assert/strict';
import test from 'node:test';
import { createHash } from 'node:crypto';
import { preparePrompt } from '../../../dist/core.js';
import { scorePrediction, summarizeQuality, validateQualityRecords, qualityDatasetDigest, QUALITY_GATES } from '../../../dist/evaluation.js';
import { compileHalfGrid, responseHalfGrid, LOGICAL_ID } from '../fractional-score-hypothesis/candidate-2/grid.mjs';
import { buildInjectedCpuSuccessorManifest, gradeInjectedCpuValidationResearch, gradeValidationResearch,
  SET_SPECS, RESEARCH_SCHEMA, ORIGINAL_PLAN_SHA256, SUCCESSOR_PHYSICAL_IDENTITY } from './grade.mjs';

const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const clone = value => structuredClone(value);
const jsonClone = value => JSON.parse(JSON.stringify(value));

// Synthetic invented contexts only. No file loading, model/tokenizer/native process, or VAL/TEST data.
function cpuFixture() {
  const sets = SET_SPECS.map((spec, setIndex) => {
    const records = [];
    for (let group = 0; group < spec.groups; group++) {
      const groupId = 'cpu-set' + setIndex + '-group' + group;
      const cells = setIndex === 2 ? [['order1', 'state'], ['order1', 'chat'], ['order2', 'state'], ['order2', 'chat']]
        : [[null, 'state'], [null, 'chat']];
      const type = setIndex === 2 ? 'choice' : group < spec.groups / 3 ? 'choice' : group < 2 * spec.groups / 3 ? 'score' : 'noul';
      for (const [order, representation] of cells) {
        const question = { id: 'q', type, instructions: type === 'score'
          ? 'Earn one point for each of five completed items; an explicitly recorded half completion earns 0.5 point.'
          : 'Read this invented CPU test statement.' };
        if (type === 'choice') question.criteria = [{ id: 'yes', description: 'invented observed fact' }, { id: 'no', description: 'invented alternative' }];
        if (type === 'score') question.criteria = ['0 complete', '1 complete', '2 complete', '3 complete', '4 complete', '5 complete'];
        if (type === 'noul') question.criteria = { true: 'established', false: 'contradicted' };
        const context = 'Invented CPU-only statement, set ' + setIndex + ', group ' + group + '.';
        const request = { model: 'cpu-injected-model-alias', questions: [question],
          ...(representation === 'state' ? { state: context } : { messages: [{ role: 'user', content: context }] }) };
        const answer = type === 'choice' ? 'yes' : type === 'score' ? 2.5 : group === spec.groups - 1 ? null : group % 2 === 0;
        records.push({ id: groupId + (order ? '-' + order : '') + '-' + representation, group_id: groupId,
          split: 'validation', request, targets: { q: { answer } }, ...(setIndex === 0 && group === 0 ? { regression: true } : {}) });
      }
    }
    return { ...spec, records, bytes: Buffer.from(records.map(record => JSON.stringify(record)).join('\n') + '\n') };
  });
  const physical = { id: 'gemma4-direct-label-raw-q4-research-v0',
    model_expected_sha256: '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b', model_expected_size: 17651001568 };
  const original = { schema_version: 1, kind: 'gemma4_validation_research_frozen_run_plan', template_version: 'v2',
    scope: 'validation_only_research_no_role_promotion', expected_records: 194,
    research_profile: physical.id, physical_profile: physical, physical_profile_sha256: sha(JSON.stringify(physical)),
    artifacts: { model: { sha256: physical.model_expected_sha256, bytes: physical.model_expected_size } },
    quality_gates: QUALITY_GATES, additional_gates: { unknown_noul_mae: 0.1, diagnosis_choice_accuracy: 0.95,
      exact_194_record_coverage: true, all_14_diagnosis_groups_and_56_representations: true },
    inputs: sets.map(set => ({ name: set.name, records: set.records.length, groups: set.groups,
      input_sha256: sha(set.bytes), input_bytes: set.bytes.length, expected_ids: set.records.map(record => record.id),
      logical_prompt_sha256: set.records.map(record => [record.id, sha(JSON.stringify(preparePrompt({
        ...record.request, options: { template_version: 'v2' },
      }, 'v2').questions))]) })), execution_order: sets.flatMap(set => set.records.map(record => record.id)) };
  const originalFrozenPlanBytes = Buffer.from(JSON.stringify(original));
  const expectedSyntheticPlanSha256 = sha(originalFrozenPlanBytes);
  const input = { originalFrozenPlanBytes, inputSets: sets.map(({ name, bytes }) => ({ name, bytes })),
    successorPhysicalIdentity: clone(SUCCESSOR_PHYSICAL_IDENTITY) };
  const successorManifest = buildInjectedCpuSuccessorManifest(input, expectedSyntheticPlanSha256);
  const records = sets.flatMap(set => set.records);
  const runEnvelopes = records.map((record, index) => {
    const plan = compileHalfGrid({ ...record.request, options: { template_version: 'v2' } });
    const branch = plan.questions[0], target = record.targets.q.answer;
    const chosen = record.request.questions[0].type === 'score' ? branch.research_score_values.indexOf(target)
      : record.request.questions[0].type === 'choice' ? 0 : target === null ? 4 : target ? 8 : 0;
    const logits = { [branch.branch_id]: Object.fromEntries(branch.output_labels.map((label, i) => [label, i === chosen ? 100 : 0])) };
    const metadata = { research_profile: successorManifest.research_profile,
      physical_profile_sha256: successorManifest.physical_profile_sha256,
      raw_model_sha256: successorManifest.raw_model_sha256, raw_model_bytes: successorManifest.raw_model_bytes,
      independent_render_match: true, cpu_mock: true, nested_unchanged_marker: { letters: ['a', 'b'], count: 17 } };
    const response = responseHalfGrid(plan, logits, 17, true, { metadata });
    return { record_id: record.id, logical_id: LOGICAL_ID, logical_prompt_sha256: successorManifest.records[index].logical_prompt_sha256,
      research_profile: successorManifest.research_profile, physical_profile_sha256: successorManifest.physical_profile_sha256,
      raw_model_sha256: successorManifest.raw_model_sha256, raw_model_bytes: successorManifest.raw_model_bytes,
      model: record.request.model, elapsed_ms: index + 0.25, response, injected_source: 'synthetic_selected_logits_no_native_execution' };
  });
  return { input: { ...input, successorManifest, runEnvelopes, createdAt: '2030-01-01T00:00:00.000Z' }, expectedSyntheticPlanSha256, records, original };
}
const evaluate = fixture => gradeInjectedCpuValidationResearch(fixture.input, fixture.expectedSyntheticPlanSha256);
const mutatePlan = (fixture, change) => {
  const plan = clone(fixture.original);
  const values = fixture.input.inputSets.map(set => set.bytes.toString('utf8').trim().split('\n').map(line => JSON.parse(line)));
  change(plan, values);
  fixture.input.inputSets = fixture.input.inputSets.map((set, index) => {
    const bytes = Buffer.from(values[index].map(record => JSON.stringify(record)).join('\n') + '\n');
    const frozen = plan.inputs[index];
    frozen.input_sha256 = sha(bytes); frozen.input_bytes = bytes.length;
    frozen.expected_ids = values[index].map(record => record.id);
    frozen.logical_prompt_sha256 = values[index].map(record => [record.id, sha(JSON.stringify(preparePrompt({
      ...record.request, options: { template_version: 'v2' },
    }, 'v2').questions))]);
    return { name: set.name, bytes };
  });
  plan.execution_order = values.flatMap(set => set.map(record => record.id));
  fixture.input.originalFrozenPlanBytes = Buffer.from(JSON.stringify(plan));
  fixture.expectedSyntheticPlanSha256 = sha(fixture.input.originalFrozenPlanBytes);
};

test('actual scorer and summaries grade original half-point rubric while raw envelopes/metadata stay unchanged', () => {
  const fixture = cpuFixture(), before = jsonClone(fixture.input.runEnvelopes), report = evaluate(fixture);
  assert.equal(report.research_schema, RESEARCH_SCHEMA);
  assert.equal(report.evidence_scope, 'injected_cpu');
  assert.equal(report.logical_id, LOGICAL_ID);
  assert.equal('template_version' in report, false);
  assert.equal('schema_version' in report, false);
  assert.equal(report.run_envelopes, fixture.input.runEnvelopes);
  assert.deepEqual(jsonClone(report.run_envelopes), before);
  assert.equal(report.grade_views.length, 194);
  assert.equal(report.coverage.exact_order, true);
  assert.equal(report.diagnosis.groups.length, 14);
  assert.ok(report.diagnosis.groups.every(group => group.complete));
  assert.equal(report.gates.passed, true);
  assert.equal(report.approval_effect, 'none');
  assert.ok(Object.values(report.claims).every(value => value === false));
  assert.deepEqual(report.summary, summarizeQuality(report.grade_views));
  assert.equal(report.dataset_sha256, qualityDatasetDigest(validateQualityRecords(fixture.records)));
  for (let i = 0; i < report.grade_views.length; i++) {
    const view = report.grade_views[i], record = fixture.records[i];
    assert.equal('metadata' in view, false); assert.equal('model' in view, false); assert.equal('usage' in view, false);
    assert.equal('logical_prompt_sha256' in view, false);
    assert.deepEqual(view.answers[0], scorePrediction(record.request.questions[0], record.targets.q, fixture.input.runEnvelopes[i].response.answers.q));
  }
  assert.equal(report.prospective_developer_score_correctness.expected_count, 26);
  assert.equal(report.prospective_developer_score_correctness.correct_count, 26);
  assert.deepEqual(report.successor_physical_identity, SUCCESSOR_PHYSICAL_IDENTITY);
  assert.equal(report.original_physical_identity.research_profile, fixture.original.research_profile);
  assert.notEqual(report.successor_physical_identity.research_profile, report.original_physical_identity.research_profile);
  assert.equal(fixture.original.research_profile, 'gemma4-direct-label-raw-q4-research-v0');
});

test('explicit new physical identity is required and independently pinned; original profile cannot qualify successor envelopes', () => {
  for (const change of [identity => { identity.research_profile = 'gemma4-direct-label-raw-q4-research-v0'; },
    identity => { identity.physical_profile_sha256 = '0'.repeat(64); },
    identity => { identity.physical_profile_file_sha256 = '0'.repeat(64); },
    identity => { identity.raw_model_sha256 = '0'.repeat(64); },
    identity => { identity.raw_model_bytes -= 1; }]) {
    const fixture = cpuFixture(); change(fixture.input.successorPhysicalIdentity);
    assert.throws(() => buildInjectedCpuSuccessorManifest(fixture.input, fixture.expectedSyntheticPlanSha256), /Explicit successor physical identity mismatch/);
  }
  const missing = cpuFixture(); delete missing.input.successorPhysicalIdentity;
  assert.throws(() => evaluate(missing), /Explicit successor physical identity required/);
  const oldRun = cpuFixture(), row = oldRun.input.runEnvelopes[0];
  row.research_profile = oldRun.original.research_profile;
  row.physical_profile_sha256 = oldRun.original.physical_profile_sha256;
  row.response.metadata.research_profile = oldRun.original.research_profile;
  row.response.metadata.physical_profile_sha256 = oldRun.original.physical_profile_sha256;
  assert.throws(() => evaluate(oldRun), /Run envelope attribution mismatch/);
  const oldRaw = cpuFixture();
  oldRaw.input.runEnvelopes[0].response.metadata.research_profile = oldRaw.original.research_profile;
  oldRaw.input.runEnvelopes[0].response.metadata.physical_profile_sha256 = oldRaw.original.physical_profile_sha256;
  assert.throws(() => evaluate(oldRaw), /Raw response physical attribution mismatch/);
  const accepted = cpuFixture(), before = accepted.input.originalFrozenPlanBytes.toString('utf8');
  const report = evaluate(accepted);
  assert.equal(report.gates.passed, true);
  assert.equal(accepted.input.originalFrozenPlanBytes.toString('utf8'), before);
  assert.equal(report.successor_physical_identity.physical_profile_sha256, '48dda5a0b1630b607f0e5c691366ced92843ea43f0d5d4aab9bc62cc2a7416fc');
});

test('default actual manifest pin rejects synthetic CPU plan and byte mutation', () => {
  const fixture = cpuFixture();
  assert.notEqual(fixture.expectedSyntheticPlanSha256, ORIGINAL_PLAN_SHA256);
  assert.throws(() => gradeValidationResearch(fixture.input), /Original frozen run-plan bytes mismatch/);
  fixture.input.originalFrozenPlanBytes = Buffer.concat([fixture.input.originalFrozenPlanBytes, Buffer.from(' ')]);
  assert.throws(() => evaluate(fixture), /Original frozen run-plan bytes mismatch/);
});

test('changing context, original instructions, rubric or target bytes is rejected against frozen manifest', () => {
  for (const field of ['context', 'instructions', 'rubric', 'target']) {
    const fixture = cpuFixture();
    const values = fixture.input.inputSets[0].bytes.toString('utf8').trim().split('\n').map(line => JSON.parse(line));
    const row = values.find(record => record.request.questions[0].type === 'score');
    if (field === 'context') row.request.state = 'changed context';
    if (field === 'instructions') row.request.questions[0].instructions += ' changed';
    if (field === 'rubric') row.request.questions[0].criteria[3] = 'changed rubric';
    if (field === 'target') row.targets.q.answer = 3;
    fixture.input.inputSets[0].bytes = Buffer.from(values.map(record => JSON.stringify(record)).join('\n') + '\n');
    assert.throws(() => evaluate(fixture), /original input bytes changed/);
  }
});

test('unique full 194 run coverage rejects missing, extra, duplicate and reordered envelopes', () => {
  for (const change of [rows => rows.pop(), rows => rows.push(clone(rows[0])), rows => { rows[1] = clone(rows[0]); },
    rows => { [rows[0], rows[1]] = [rows[1], rows[0]]; }]) {
    const fixture = cpuFixture(); change(fixture.input.runEnvelopes);
    assert.throws(() => evaluate(fixture), /194 retained|record order\/identity/);
  }
});

test('frozen successor record SHA/model identity and raw metadata cannot be relabelled to v2', () => {
  for (const change of [f => { f.input.successorManifest.records[0].logical_prompt_sha256 = '0'.repeat(64); },
    f => { f.input.runEnvelopes[0].logical_id = 'v2'; },
    f => { f.input.runEnvelopes[0].response.metadata.template_version = 'v2'; },
    f => { f.input.runEnvelopes[0].response.metadata.logical_prompt_sha256 = '0'.repeat(64); },
    f => { f.input.runEnvelopes[0].response.metadata.raw_model_sha256 = '0'.repeat(64); },
    f => { f.input.runEnvelopes[0].physical_profile_sha256 = '0'.repeat(64); },
    f => { f.input.runEnvelopes[0].response.model = 'different-model'; }]) {
    const fixture = cpuFixture(); change(fixture);
    assert.throws(() => evaluate(fixture), /mismatch|Malformed raw response/);
  }
});

test('errors including retained responses stay failures; no dropped or imputed answers', () => {
  const fixture = cpuFixture();
  fixture.input.runEnvelopes[0].error = 'injected full-prefill failure';
  const second = fixture.input.runEnvelopes[1]; second.error = 'injected transport terminal'; delete second.response;
  const report = evaluate(fixture);
  assert.equal(report.grade_views.length, 194); assert.equal(report.summary.failures, 2);
  assert.deepEqual(report.grade_views.slice(0, 2).map(row => row.answers), [[], []]);
  assert.equal(report.grade_views[0].error, 'injected full-prefill failure');
  assert.ok(report.run_envelopes[0].response);
  assert.equal(report.gates.passed, false);
  assert.equal(report.coverage.sets[0].complete_question_coverage, false);
});

test('missing/extra answers and invalid score become complete retained record failures', () => {
  for (const change of [response => { delete response.answers.q; }, response => { response.answers.extra = clone(response.answers.q); },
    response => { response.answers.q.score = -0.01; }, response => { response.answers.q.score = 5.01; }]) {
    const fixture = cpuFixture();
    const index = fixture.records.findIndex(record => record.request.questions[0].type === 'score');
    change(fixture.input.runEnvelopes[index].response);
    const report = evaluate(fixture);
    assert.equal(report.summary.failures, 1); assert.equal(report.grade_views.length, 194);
    assert.deepEqual(report.grade_views[index].answers, []); assert.equal(report.gates.passed, false);
  }
});

test('raw envelope JSON boundary rejects inherited attribution, getters, toJSON and nonfinite values without mutation', () => {
  for (const change of [metadata => {
    const inherited = { template_version: metadata.template_version, logical_prompt_sha256: metadata.logical_prompt_sha256,
      research_profile: metadata.research_profile, physical_profile_sha256: metadata.physical_profile_sha256,
      raw_model_sha256: metadata.raw_model_sha256, raw_model_bytes: metadata.raw_model_bytes, independent_render_match: true };
    Object.setPrototypeOf(metadata, inherited);
    for (const key of Object.keys(inherited)) delete metadata[key];
  }, metadata => {
    Object.defineProperty(metadata, 'untrusted_getter', { enumerable: true, get() { throw new Error('Getter must never run'); } });
  }, metadata => { metadata.toJSON = () => ({}); }, metadata => { metadata.nonfinite_unserializable = NaN; }]) {
    const fixture = cpuFixture(); change(fixture.input.runEnvelopes[0].response.metadata);
    assert.throws(() => evaluate(fixture), /plain own-property JSON|JSON accessors|plain JSON values|finite JSON numbers/);
    assert.equal(fixture.input.runEnvelopes[0].response.metadata.cpu_mock, true);
  }
});

test('per-set unknown MAE cannot be diluted by aggregate unknowns and complete unknown coverage is mandatory', () => {
  const fixture = cpuFixture();
  const legacyUnknown = fixture.records.findIndex(record => record.id.startsWith('cpu-set0') && record.targets.q.answer === null);
  fixture.input.runEnvelopes[legacyUnknown].response.answers.q.noul = 0.72;
  const report = evaluate(fixture);
  assert.ok(report.unknown_noul.mae <= 0.1);
  assert.equal(report.coverage.sets[0].unknown_noul.passed, false);
  assert.equal(report.coverage.sets[1].unknown_noul.passed, true);
  assert.equal(report.gates.passed, false);
  fixture.input.runEnvelopes[legacyUnknown].error = 'injected unknown failure';
  const missing = evaluate(fixture);
  assert.equal(missing.coverage.sets[0].unknown_noul.scored_count, 1);
  assert.equal(missing.coverage.sets[0].unknown_noul.expected_count, 2);
  assert.equal(missing.coverage.sets[0].unknown_noul.passed, false);
});

test('diagnosis preserves 95 percent threshold: 54/56 passes and 53/56 fails without requiring every group all-correct', () => {
  const fixture = cpuFixture(), indices = fixture.records.flatMap((record, index) => record.id.startsWith('cpu-set2') ? [index] : []);
  for (const index of indices.slice(0, 2)) fixture.input.runEnvelopes[index].response.answers.q.choice = 'no';
  const passing = evaluate(fixture);
  assert.equal(passing.diagnosis.summary.choice.correct, 54);
  assert.equal(passing.gates.original_additional.diagnosis_choice_accuracy, true);
  assert.equal(passing.diagnosis.groups[0].all_correct, false);
  assert.equal(passing.gates.passed, true);
  fixture.input.runEnvelopes[indices[2]].response.answers.q.choice = 'no';
  const failing = evaluate(fixture);
  assert.equal(failing.diagnosis.summary.choice.correct, 53);
  assert.equal(failing.gates.original_additional.diagnosis_choice_accuracy, false);
  assert.equal(failing.gates.passed, false);
});

test('original diagnosis group four-cell structure and 83 independent groups reject synthetic malformed manifests', () => {
  const grid = cpuFixture();
  mutatePlan(grid, (_plan, values) => { values[2][3].id = 'cpu-set2-group0-order2-state-duplicate'; });
  assert.throws(() => buildInjectedCpuSuccessorManifest(grid.input, grid.expectedSyntheticPlanSha256), /state\/chat\/order cells/);
  const overlapping = cpuFixture();
  mutatePlan(overlapping, (_plan, values) => { values[1][0].group_id = 'cpu-set0-group0'; values[1][1].group_id = 'cpu-set0-group0'; });
  assert.throws(() => buildInjectedCpuSuccessorManifest(overlapping.input, overlapping.expectedSyntheticPlanSha256), /groups overlap across sets/);
  const nonValidation = cpuFixture();
  mutatePlan(nonValidation, (_plan, values) => { values[0][0].split = 'test'; values[0][1].split = 'test'; });
  assert.throws(() => buildInjectedCpuSuccessorManifest(nonValidation.input, nonValidation.expectedSyntheticPlanSha256), /validation-only/);
});

test('prospective developer correctness uses actual scorer per-score threshold despite passing mean MAE', () => {
  const fixture = cpuFixture(), indices = fixture.records.flatMap((record, index) =>
    record.id.startsWith('cpu-set1') && record.request.questions[0].type === 'score' ? [index] : []);
  for (const index of indices.slice(0, 3)) fixture.input.runEnvelopes[index].response.answers.q.score = 3.5;
  const report = evaluate(fixture);
  assert.ok(report.coverage.sets[1].summary.score.normalized_mae <= 0.1);
  assert.equal(report.coverage.sets[1].passed, true);
  assert.equal(report.prospective_developer_score_correctness.correct_count, 23);
  assert.equal(report.prospective_developer_score_correctness.accuracy, 23 / 26);
  assert.equal(report.prospective_developer_score_correctness.passed, false);
  assert.equal(report.gates.passed, false);
  const boundary = cpuFixture();
  boundary.input.runEnvelopes[indices[0]].response.answers.q.score = 3;
  const boundaryReport = evaluate(boundary);
  assert.equal(boundaryReport.grade_views[indices[0]].answers[0].normalized_absolute_error, 0.1);
  assert.equal(boundaryReport.grade_views[indices[0]].answers[0].correct, true);
});

test('independent render predicate reads only original raw metadata; absent render evidence fails', () => {
  const fixture = cpuFixture(); delete fixture.input.runEnvelopes[0].response.metadata.independent_render_match;
  const report = evaluate(fixture);
  assert.equal(report.summary.failures, 0);
  assert.equal(report.gates.original_additional.independent_render_all_records, false);
  assert.equal(report.gates.passed, false);
  assert.equal('metadata' in report.grade_views[0], false);
});
