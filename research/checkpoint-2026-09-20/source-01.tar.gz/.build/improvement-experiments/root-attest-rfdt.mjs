import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { readFile, stat, readdir, writeFile, chmod } from "node:fs/promises";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { resolve, join } from "node:path";
import { loadQualityRecords, summarizeQuality, qualityDatasetDigest } from "../../dist/evaluation.js";

const root = resolve(import.meta.dirname, "../..");
const round = Number(process.argv[2]);
assert.ok(Number.isInteger(round) && round >= 5);
const folder = join(root, ".build/improvement-experiments", `rfdt-round-${round}`);
const json = async (p) => JSON.parse(await readFile(p, "utf8"));
const digest = async (p) => {
  const h = createHash("sha256");
  for await (const bytes of createReadStream(p)) h.update(bytes);
  return h.digest("hex");
};
const absent = async (p) => stat(p).then(() => false, e => { if (e.code === "ENOENT") return true; throw e; });
const j = await json(join(folder, "job.json"));
assert.ok(["completed_quality_fail", "completed_quality_pass"].includes(j.status));
assert.equal(j.phase, "terminal");
assert.equal(j.heldout_invocations, 0);
assert.equal(j.approval_invocations, 0);
assert.equal(j.fresh_base, true);
assert.equal(j.old_adapter_used, false);
assert.equal(j.offline, true);
assert.deepEqual(j.phase_history.map(p => p.phase), ["prepare", "train", "export", "legacy_validation", "developer_validation", "diagnosis_validation"]);
for (const p of j.phase_history) assert.ok([0, 1].includes(p.exit_code));
for (const p of j.phase_history.slice(0, 3)) assert.equal(p.exit_code, 0);
const checks = {}, hashes = {};
const bind = async (p, expected) => {
  const actual = await digest(p);
  assert.equal(actual, expected, `Hash changed: ${p}`);
  checks[p] = true;
  hashes[p] = actual;
};
for (const [p, expected] of Object.entries(j.source_sha256)) await bind(p, expected);
for (const [p, expected] of Object.entries(j.dist_sha256)) await bind(join(root, "dist", p), expected);
for (const [p, expected] of Object.entries(j.staged.old_evidence_hashes)) await bind(p, expected);
await bind(j.stage_binding.path, j.stage_binding.sha256);
const stage = await json(j.stage_binding.path);
assert.deepEqual(stage, j.staged);
await bind(stage.training_input, stage.training_input_sha256);
await bind(stage.developer_source, stage.developer_sha256);
await bind(stage.developer_frozen, stage.developer_sha256);
await bind(stage.legacy_source, stage.legacy_sha256);
await bind(stage.diagnosis_validation.path, stage.diagnosis_validation.sha256);
const rawTrain = (await readFile(stage.training_input, "utf8")).trim().split("\n").map(JSON.parse);
assert.equal(rawTrain.length, stage.optimizer_rows);
assert.ok(rawTrain.every(r => r.split === "train"));
assert.equal(new Set(rawTrain.map(r => r.group_id)).size, stage.optimizer_groups);
const manifest = await json(join(folder, "run/manifest.json"));
assert.equal(manifest.source.sha256, stage.training_input_sha256);
assert.deepEqual(manifest.prepared.branches, { train: stage.optimizer_rows, validation: 0, test: 0 });
assert.equal((await stat(manifest.prepared.files.validation)).size, 0);
assert.equal((await stat(manifest.prepared.files.test)).size, 0);
const training = await json(join(folder, "run/training-report.json"));
assert.equal(training.steps, j.steps);
assert.equal(training.reload_verified, true);
assert.equal(training.reload_max_probability_delta, 0);
assert.equal(training.adapter_changed, true);
assert.equal(training.hyperparameters.truncation, false);
await bind(manifest.prepared.files.train, training.training_data_sha256);
await bind(j.artifact.file, j.artifact.sha256);
assert.equal((await stat(j.artifact.file)).size, j.artifact.size);
assert.equal(manifest.exports.sha256, j.artifact.sha256);
const reports = {};
for (const [name, path, input, count, groups] of [
  ["legacy", "run/native-validation-report.json", stage.legacy_source, 60, 30],
  ["developer", "developer-validation-report.json", stage.developer_frozen, 78, 39],
  ["diagnosis", "diagnosis-validation-report.json", stage.diagnosis_validation.path, 56, 14],
]) {
  const p = join(folder, path), r = await json(p);
  const expected = (await loadQualityRecords(input)).filter(v => v.split === "validation");
  assert.equal(expected.length, count);
  assert.equal(r.results.length, count);
  assert.deepEqual(r.results.map(v => v.id), expected.map(v => v.id));
  assert.equal(new Set(r.results.map(v => v.id)).size, count);
  assert.equal(new Set(r.results.map(v => v.group_id)).size, groups);
  assert.ok(r.results.every(v => v.split === "validation" && v.model === j.artifact.id && !v.error && v.metadata.artifact.sha256 === j.artifact.sha256 && v.metadata.artifact.size === j.artifact.size));
  for (let i = 0; i < count; i++) {
    assert.equal(r.results[i].group_id, expected[i].group_id);
    for (const answer of r.results[i].answers) assert.deepEqual(answer.target, expected[i].targets[answer.question_id]);
  }
  assert.deepEqual(summarizeQuality(r.results), r.summary);
  assert.equal(r.summary.failures, 0);
  assert.deepEqual(r.splits, ["validation"]);
  if (name !== "diagnosis") assert.equal(r.dataset_sha256, qualityDatasetDigest(expected));
  if (name === "legacy") assert.equal(r.rfdt.artifact_sha256, j.artifact.sha256);
  else {
    assert.equal(r.experiment.artifact_sha256, j.artifact.sha256);
    assert.equal(r.experiment.corpus_raw_sha256, name === "diagnosis" ? stage.diagnosis_validation.sha256 : stage.developer_sha256);
    assert.equal(r.experiment.scoped_registry_removed, true);
  }
  hashes[p] = await digest(p);
  reports[name] = { summary: r.summary, coverage: r.coverage ?? null, experiment_gates: r.experiment_gates ?? null, sha256: hashes[p] };
}
assert.equal(reports.diagnosis.experiment_gates.execution_completed, true);
assert.equal(reports.diagnosis.experiment_gates.choice_accuracy_threshold, 0.95);
for (const k of ["complete_expected_ids", "zero_errors", "group_coverage", "representation_coverage", "each_group_representation_coverage", "native_candidate_identity"]) assert.equal(reports.diagnosis.experiment_gates[k], true);
const ownedPids = new Set([j.owner_pid, ...j.phase_history.map(p => p.child_pid), ...process.argv.slice(3).map(Number)]);
const ownedGroups = new Set([j.owner_pid, ...j.phase_history.map(p => p.child_pgid)]);
const ps = await promisify(execFile)("ps", ["-axo", "pid=,ppid=,pgid=,lstart=,stat=,comm="]);
const active = ps.stdout.split("\n").filter(line => {
  const numbers = line.trim().split(/\s+/).slice(0, 3).map(Number);
  return ownedPids.has(numbers[0]) || ownedGroups.has(numbers[2]);
});
assert.deepEqual(active, [], "Owned process/group remains live");
assert.ok(await absent(join(root, ".build/improvement-experiments/rfdt-runner.lock")));
assert.ok(await absent(join(root, ".jev/artifacts.json")));
assert.ok(!(await readdir(join(folder, "run"))).some(name => name.startsWith("native-test") || name.includes("reservation")));
hashes[j.artifact.run_manifest] = await digest(j.artifact.run_manifest);
const proof = { kind: "jev_rfdt_root_complete_selection_attestation", round, observed_at: new Date().toISOString(), status: j.status, artifact: j.artifact, training: { initial_loss: training.initial_loss, final_loss: training.final_loss, steps: training.steps, reload_delta: training.reload_max_probability_delta, memory: training.memory }, reports, selection_gates: j.selection_gates, actual_file_hash_checks: checks, file_sha256: hashes, execution_source_bindings: j.source_sha256, all_owned_pids_and_groups_missing: true, observed_owned_pids: [...ownedPids], observed_owned_groups: [...ownedGroups], lock_absent: true, final_test_unused_for_this_candidate: true, permanent_approval_absent: true, model_approved: false };
const output = join(folder, "complete-selection-proof.json");
assert.ok(await absent(output), "Existing root attestation must remain unchanged");
await writeFile(output, JSON.stringify(proof, null, 2) + "\n", { mode: 0o600 });
await chmod(output, 0o600);
console.log(JSON.stringify({ round, status: proof.status, root_attestation: output, artifact_sha256: j.artifact.sha256, actual_hash_checks: Object.keys(checks).length, quality: Object.fromEntries(Object.entries(reports).map(([k, v]) => [k, v.summary])), all_owned_groups_missing: true }));
