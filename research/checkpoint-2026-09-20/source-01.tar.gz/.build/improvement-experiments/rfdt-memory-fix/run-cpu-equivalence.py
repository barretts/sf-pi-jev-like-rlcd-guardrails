#!/usr/bin/env python3
"""Compare tiny random CPU fixtures; never load checkpoint weights."""

import hashlib
import json
import os
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[3]
proof_dir = Path(__file__).resolve().parent
baseline = proof_dir / "worker-d7c9f2e.py"
baseline_sha = "f046f8bd1e87051873fecc2e8e89647d31a210de7bad3bbb46efb6efd5810616"
assert hashlib.sha256(baseline.read_bytes()).hexdigest() == baseline_sha
baseline.chmod(0o400)
workers = {"baseline": baseline, "fixed": root / "rfdt" / "worker.py"}
hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in workers.items()}
environment = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1")
results = {}
for name, worker in workers.items():
    completed = subprocess.run(
        [str(root / ".build" / "rfdt-venv" / "bin" / "python"), str(worker), "self-test"],
        cwd=root,
        env=environment,
        capture_output=True,
        text=True,
        timeout=120,
    )
    (proof_dir / f"selftest-{name}.stdout.json").write_text(completed.stdout)
    (proof_dir / f"selftest-{name}.stderr.log").write_text(completed.stderr)
    assert completed.returncode == 0, completed.stderr + completed.stdout
    results[name] = json.loads(completed.stdout)
fields = [
    "initial_loss", "final_loss", "reload_max_probability_delta", "fusion_max_probability_delta",
    "adapter_changed", "full_context_gradient_verified", "reload_verified", "fusion_verified",
]
comparison = {
    field: {"baseline": results["baseline"][field], "fixed": results["fixed"][field],
            "equal": results["baseline"][field] == results["fixed"][field]}
    for field in fields
}
assert all(value["equal"] for value in comparison.values()), comparison
assert hashes == {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in workers.items()}
proof = {
    "proof": "tiny_random_gemma_cpu_only_no_checkpoint_weights",
    "baseline_commit": "d7c9f2ef34cbcc89c43152da235e893346d8d2b3",
    "worker_sha256": hashes,
    "comparison": comparison,
    "passed": True,
    "fixed_evaluation_probability_delta": results["fixed"]["evaluation_max_probability_delta"],
    "fixed_memory": results["fixed"]["memory"],
    "baseline_copy_read_only": baseline.stat().st_mode & 0o777 == 0o400,
}
(proof_dir / "cpu-equivalence-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps(proof))
