#include "build-info.h"
#include "chat.h"
#include "ggml-backend.h"
#include "llama.h"
#include "nlohmann/json.hpp"
#include <CommonCrypto/CommonDigest.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <condition_variable>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <mutex>
#include <queue>
#include <set>
#include <sstream>
#include <thread>
using json = nlohmann::ordered_json;
static std::atomic<bool> cancelled{false};
static constexpr size_t max_protocol_line = 64 * 1024 * 1024;
static void check_cancelled() {
  if (cancelled.load())
    throw std::runtime_error("Cancelled");
}
static int integer(const json &value, int low, int high,
                   const char *description) {
  if (!value.is_number_integer())
    throw std::invalid_argument(description);
  if (value.is_number_unsigned()) {
    const auto n = value.get<std::uint64_t>();
    if (n > std::uint64_t(high) || n < std::uint64_t(low))
      throw std::invalid_argument(description);
    return int(n);
  }
  const auto n = value.get<std::int64_t>();
  if (n < low || n > high)
    throw std::invalid_argument(description);
  return int(n);
}
static int limit(const json &request, const char *key, int fallback, int high) {
  return request.contains(key)
             ? integer(request.at(key), 1, high, "Invalid native limits")
             : fallback;
}
struct NativeBatch {
  llama_batch value;
  explicit NativeBatch(int size) : value(llama_batch_init(size, 0, 1)) {}
  ~NativeBatch() { llama_batch_free(value); }
  NativeBatch(const NativeBatch &) = delete;
  NativeBatch &operator=(const NativeBatch &) = delete;
};
static void log_callback(ggml_log_level, const char *text, void *) {
  std::cerr << text;
}

// Research-only physical compiler. This source is deliberately outside the
// production tree and does not authorize a model role or a held-out evaluation.
#ifndef GEMMA4_PROTOTYPE_SOURCE_SHA256
#error "Compile with the SHA-256 of this prototype source"
#endif
static constexpr const char *research_profile =
    "gemma4-direct-label-raw-q4-runtime-candidate-1";
static constexpr const char *model_path =
    "/Users/bsonntag/code/simple-jev-ts/models/gemma-4-31B_q4_0-it.gguf";
static constexpr const char *model_sha256 =
    "179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b";
static constexpr std::uintmax_t model_size = 17651001568ULL;
static constexpr const char *template_path =
    "/Users/bsonntag/code/simple-jev-ts/models/gemma-4-31B-it.chat_template.jinja";
static constexpr const char *template_sha256 =
    "ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4";
static constexpr size_t template_size = 18683;
static constexpr const char *parser_template_sha256 =
    "6a1015c47ccfcfa67c3b772385bccee357a4d37c3cda37bd202e9047f391ab82";
static constexpr size_t parser_template_size = 18682;
static constexpr const char *parser_source_transform =
    "pinned raw bytes minus exactly one terminal LF (0x0A); all preceding bytes unchanged";
static constexpr const char *generation_boundary =
    "<|turn>model\n<|channel>thought\n<channel|>";
static constexpr int decode_chunk = 2048;

static std::string sha256(const std::string &text) {
  unsigned char digest[CC_SHA256_DIGEST_LENGTH];
  CC_SHA256(text.data(), static_cast<CC_LONG>(text.size()), digest);
  std::ostringstream out;
  out << std::hex << std::setfill('0');
  for (auto byte : digest)
    out << std::setw(2) << static_cast<unsigned>(byte);
  return out.str();
}
static void pinned_path(const json &request, const char *key,
                        const char *expected, std::uintmax_t expected_size) {
  if (!request.contains(key) || !request.at(key).is_string() ||
      request.at(key).get<std::string>() != expected)
    throw std::invalid_argument(std::string("Research profile requires pinned ") + key);
  if (!std::filesystem::is_regular_file(expected) ||
      std::filesystem::file_size(expected) != expected_size)
    throw std::invalid_argument(std::string("Pinned file type/size mismatch: ") + key);
}
static std::string verified_template(const json &request) {
  pinned_path(request, "chat_template_file", template_path, template_size);
  std::ifstream file(template_path, std::ios::binary);
  std::string source(template_size, '\0');
  if (!file.read(source.data(), source.size()) || file.peek() != EOF ||
      sha256(source) != template_sha256)
    throw std::invalid_argument("Pinned corrected Gemma4 template SHA-256 mismatch");
  return source;
}
static json physical_profile() {
  return {{"id", research_profile},
          {"architecture_allowlist", {"gemma4"}},
          {"wire_protocol", 1},
          {"logical_template", "caller-supplied logical branches; no v2 instruction redefinition"},
          {"model_expected_sha256", model_sha256},
          {"model_expected_size", model_size},
          {"template_sha256", template_sha256},
          {"template_raw_bytes", template_size},
          {"parser_template_sha256", parser_template_sha256},
          {"parser_template_bytes", parser_template_size},
          {"parser_source_transform", parser_source_transform},
          {"template_revision", "842da3794eaa0b77d5f08bae87a17459d91ff475"},
          {"enable_thinking", false},
          {"generation_boundary", generation_boundary},
          {"label_rule", "one_distinct_token_preserving_entire_rendered_prefix"},
          {"weight_conversion", "none; pinned raw GGUF"},
          {"max_model_len", 2048},
          {"max_batch_size", 1},
          {"max_batch_tokens", 2048},
          {"decode_chunk", decode_chunk},
          {"threads", 2},
          {"kv_dtype", "f16"},
          {"kv_type_k_requested", {{"name", "f16"}, {"enum", static_cast<int>(GGML_TYPE_F16)}}},
          {"kv_type_v_requested", {{"name", "f16"}, {"enum", static_cast<int>(GGML_TYPE_F16)}}},
          {"flash_attn_requested", {{"name", "auto"}, {"enum", static_cast<int>(LLAMA_FLASH_ATTN_TYPE_AUTO)}}},
          {"n_batch_requested", decode_chunk},
          {"n_ubatch_requested", 512},
          {"context_capacity_default", 4096},
          {"n_seq_max_default", 2},
          {"kv_unified", true},
          {"swa_full_inherited_default", true},
          {"reused_library_backends", "CPU and Metal; CPU selection does not prove no Metal registration"}};
}
struct Engine {
  llama_model *model = nullptr;
  llama_context *ctx = nullptr;
  const llama_vocab *vocab = nullptr;
  common_chat_templates_ptr templates;
  std::string device, device_name, architecture;
  std::string bos_piece;
  llama_token bos_id = -1;
  bool vocab_only = true;
  int gpu_layers_requested = 0;
  int max_len = 2048, max_batch = 1, max_tokens = 2048;
  int forwards = 0, computed = 0;
  ~Engine() {
    if (ctx)
      llama_free(ctx);
    if (model)
      llama_model_free(model);
  }
  std::vector<llama_token> tokenize(const std::string &s) {
    check_cancelled();
    int n = llama_tokenize(vocab, s.data(), s.size(), nullptr, 0, false, true);
    check_cancelled();
    if (n == 0)
      return {};
    std::vector<llama_token> t(-n);
    n = llama_tokenize(vocab, s.data(), s.size(), t.data(), t.size(), false,
                       true);
    check_cancelled();
    if (n < 0)
      throw std::runtime_error("Tokenization failed");
    t.resize(n);
    return t;
  }
  void init(const json &r) {
    check_cancelled();
    if (model)
      throw std::runtime_error("Already initialized");
    if (r.value("research_profile", std::string()) != research_profile)
      throw std::invalid_argument("Explicit Gemma4 research physical profile is required");
    pinned_path(r, "model_file", model_path, model_size);
    const auto template_source = verified_template(r);
    if (r.contains("vocab_only") && !r.at("vocab_only").is_boolean())
      throw std::invalid_argument("vocab_only must be boolean");
    vocab_only = r.value("vocab_only", true);
    max_len = limit(r, "max_model_len", 2048, 2048);
    max_batch = limit(r, "max_batch_size", 1, 1);
    max_tokens = limit(r, "max_batch_tokens", 2048, 2048);
    auto mp = llama_model_default_params();
    const auto requested_device = r.value("device", std::string("cpu"));
    if (requested_device != "cpu" && requested_device != "metal")
      throw std::invalid_argument("Unsupported device");
    if (vocab_only && requested_device != "cpu")
      throw std::invalid_argument("Vocabulary-only mode is CPU-only");
    mp.vocab_only = vocab_only;
    mp.use_extra_bufts = false;
    mp.load_mode = LLAMA_LOAD_MODE_MMAP;
    // No explicit backend load/init/enumeration is needed for vocabulary-only
    // compilation. The reused library may still register Metal internally.
    ggml_backend_dev_t metal = nullptr;
    ggml_backend_dev_t host = nullptr;
    if (!vocab_only) {
      ggml_backend_load_all();
      llama_backend_init();
      for (size_t i = 0; i < ggml_backend_dev_count(); i++) {
        auto dev = ggml_backend_dev_get(i);
        if (ggml_backend_dev_type(dev) == GGML_BACKEND_DEVICE_TYPE_CPU)
          host = dev;
        if (std::string(ggml_backend_reg_name(
                ggml_backend_dev_backend_reg(dev))) == "MTL")
          metal = dev;
      }
    }
    if (requested_device == "metal" && !metal)
      throw std::runtime_error("Metal device unavailable");
    const bool cpu = requested_device == "cpu";
    if (!vocab_only && cpu && !host)
      throw std::runtime_error("CPU device unavailable");
    device = cpu ? "cpu" : "metal";
    auto selected_device = cpu ? host : metal;
    device_name = selected_device ? ggml_backend_dev_name(selected_device)
                                  : "not_initialized_vocabulary_only";
    gpu_layers_requested = cpu ? 0 : 99;
    mp.n_gpu_layers = gpu_layers_requested;
    ggml_backend_dev_t devices[] = {selected_device, nullptr};
    mp.devices = devices;
    // Load the pinned raw quantized file directly; never create/expand weights.
    model = llama_model_load_from_file(model_path, mp);
    check_cancelled();
    if (!model)
      throw std::runtime_error("Model load failed");
    char arch[128]{};
    llama_model_meta_val_str(model, "general.architecture", arch, sizeof(arch));
    architecture = arch;
    if (architecture != "gemma4")
      throw std::runtime_error("Research profile requires Gemma4 architecture");
    // The vendor intentionally leaves n_ctx_train uninitialized (zero) when
    // vocab_only skips non-vocabulary hparams. Keep the independent 2048-token
    // research hard cap, and enforce the model's train limit for weight mode.
    if (!vocab_only && max_len > llama_model_n_ctx_train(model))
      throw std::runtime_error("Context exceeds model limit");
    vocab = llama_model_get_vocab(model);
    bos_id = llama_vocab_bos(vocab);
    if (bos_id < 0)
      throw std::runtime_error("Missing vocabulary BOS token");
    char bos_buffer[128];
    const int bos_length = llama_token_to_piece(vocab, bos_id, bos_buffer,
                                               sizeof(bos_buffer), 0, true);
    if (bos_length <= 0 || bos_length > int(sizeof(bos_buffer)))
      throw std::runtime_error("Cannot resolve vocabulary BOS token piece");
    bos_piece.assign(bos_buffer, bos_length);
    templates = common_chat_templates_init(model, template_source);
    // The pinned vendor lexer stores source after removing one terminal LF.
    // Keep the raw file identity and require only this specific byte transform.
    if (template_source.size() != template_size ||
        template_source.back() != '\n' || template_source.find('\r') != std::string::npos)
      throw std::runtime_error("Pinned template violates the known single-LF parser transform");
    const auto expected_parser_source = template_source.substr(0, template_source.size() - 1);
    const auto actual_parser_source = common_chat_templates_source(templates.get());
    if (expected_parser_source.size() != parser_template_size ||
        sha256(expected_parser_source) != parser_template_sha256 ||
        actual_parser_source != expected_parser_source ||
        actual_parser_source.size() != parser_template_size ||
        sha256(actual_parser_source) != parser_template_sha256)
      throw std::runtime_error("Corrected template parser source mismatches pinned single-LF identity");
    if (vocab_only)
      return;
    auto cp = llama_context_default_params();
    cp.n_ctx = max_len + max_tokens;
    cp.n_batch = decode_chunk;
    cp.n_ubatch = 512;
    cp.n_seq_max = max_batch + 1;
    cp.kv_unified = true;
    cp.type_k = GGML_TYPE_F16;
    cp.type_v = GGML_TYPE_F16;
    cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_AUTO;
    cp.n_threads = 2;
    cp.n_threads_batch = 2;
    cp.offload_kqv = !cpu;
    cp.op_offload = !cpu;
    ctx = llama_init_from_model(model, cp);
    check_cancelled();
    if (!ctx)
      throw std::runtime_error("Context initialization failed");
  }
  json provenance() const {
    const auto profile = physical_profile();
    return {{"physical_profile", profile},
            {"physical_profile_sha256", sha256(profile.dump())},
            {"prototype_source_sha256", GEMMA4_PROTOTYPE_SOURCE_SHA256},
            {"parent_prototype_source_sha256", "f2dc4e3457bb422219c24d6658757f3cd588ff3115d4e320c0c23e9582d332fb"},
            {"flash_attn_effective", nullptr},
            {"flash_attn_effective_status", "unobserved; AUTO is a request and may resolve enabled or disabled"},
            {"inherited_source_sha256", "ac0b5b0f1b8832bbbbc563e219bcbc621553e2297f456004955553560cadbcce"},
            {"model_expected_sha256", model_sha256},
            {"model_sha256_checked_by_prototype", false},
            {"model_identity_check", "pinned literal path and size; ROOT must verify frozen SHA-256 before execution"},
            {"template_sha256", template_sha256},
            {"template_sha256_checked_by_prototype", true},
            {"template_raw_identity", {{"sha256", template_sha256},
                                       {"bytes", template_size}, {"verified", true}}},
            {"template_parser_identity", {{"sha256", sha256(common_chat_templates_source(templates.get()))},
                                          {"bytes", common_chat_templates_source(templates.get()).size()},
                                          {"expected_sha256", parser_template_sha256},
                                          {"expected_bytes", parser_template_size},
                                          {"verified", true}, {"transform", parser_source_transform}}},
            {"vocab_only", vocab_only},
            {"context_train_metadata_status", vocab_only ? "uninitialized_in_vocabulary_only_mode" : "loaded"},
            {"context_train_limit_checked", !vocab_only},
            {"context_train_check_scope", "max_model_len; independent 2048-token hard cap always enforced"},
            {"context_train_tokens", vocab_only ? json(nullptr) : json(llama_model_n_ctx_train(model))},
            {"weights_loaded", !vocab_only && model != nullptr},
            {"context_created", ctx != nullptr},
            {"explicit_backend_init", !vocab_only},
            {"actual_mode", vocab_only ? "cpu_vocabulary_only_no_context" :
                            device == "cpu" ? "quantized_cpu" : "quantized_metal"},
            {"device", device},
            {"device_name", device_name},
            {"gpu_layers_requested", gpu_layers_requested},
            {"offload_kqv", !vocab_only && device == "metal"},
            {"op_offload", !vocab_only && device == "metal"},
            {"actual_offloaded_layers", nullptr},
            {"bos_piece", bos_piece},
            {"bos_token_id", bos_id},
            {"effective_limits", {{"max_model_len", max_len},
                                  {"max_batch_size", max_batch},
                                  {"max_batch_tokens", max_tokens},
                                  {"context_capacity", vocab_only ? 0 : max_len + max_tokens}}}};
  }
  json status() const {
    return {{"ready", true},
            {"template", common_chat_templates_source(templates.get())},
            {"device", device},
            {"device_name", device_name},
            {"architecture", architecture},
            {"provenance", provenance()},
            {"native_build",
             {{"commit", llama_commit()},
              {"target", llama_build_target()},
              {"number", llama_build_number()},
              {"compiler", llama_compiler()}}},
            {"limits",
             {{"max_model_len", max_len},
              {"max_batch_size", max_batch},
              {"max_batch_tokens", max_tokens}}}};
  }
  json compile(const json &branches) {
    check_cancelled();
    if (!branches.is_array() || branches.empty() || branches.size() > 256)
      throw std::invalid_argument("Expected 1–256 branches");
    json result = json::array();
    std::set<std::string> branch_ids;
    for (const auto &b : branches) {
      check_cancelled();
      const auto branch_id = b.at("branch_id").get<std::string>();
      if (branch_id.empty() || !branch_ids.insert(branch_id).second)
        throw std::invalid_argument("Empty or duplicate branch ID");
      if (!b.at("messages").is_array() || b.at("messages").empty() ||
          !b.at("output_labels").is_array() ||
          b.at("output_labels").empty() || b.at("output_labels").size() > 50)
        throw std::invalid_argument("Invalid messages or output labels");
      common_chat_templates_inputs input;
      input.enable_thinking = false;
      input.add_generation_prompt = true;
      input.add_bos = true;
      input.add_eos = false;
      const auto &messages = b.at("messages");
      for (size_t message_index = 0; message_index < messages.size();
           message_index++) {
        check_cancelled();
        const auto &m = messages[message_index];
        common_chat_msg msg;
        msg.role = m.at("role");
        msg.content = m.at("content");
        if (msg.role != "user" && msg.role != "assistant" &&
            msg.role != "system")
          throw std::invalid_argument("Gemma does not support this role");
        // The logical compiler appends the selected question as a user
        // message. Render it in the existing final user turn when necessary;
        // earlier history keeps its roles so unsupported sequences still fail.
        if (message_index + 1 == messages.size() && msg.role == "user" &&
            !input.messages.empty() && input.messages.back().role == "user")
          input.messages.back().content += "\n\n" + msg.content;
        else
          input.messages.push_back(msg);
      }
      std::string prompt;
      check_cancelled();
      try {
        prompt = common_chat_templates_apply(templates.get(), input).prompt;
        const std::string boundary = generation_boundary;
        if (prompt.size() < boundary.size() ||
            prompt.compare(prompt.size() - boundary.size(), boundary.size(), boundary) != 0)
          throw std::invalid_argument("Rendered Gemma4 disabled-thinking boundary mismatch");
        const auto answer_prefix = b.at("answer_prefix").get<std::string>();
        if (answer_prefix != "{\"answer\": \"" && answer_prefix != "{\"answer\": ")
          throw std::invalid_argument("Research profile requires the existing JSON answer prefix");
        prompt += answer_prefix;
      } catch (const std::exception &e) {
        throw std::invalid_argument(std::string("Unsupported chat history: ") +
                                    e.what());
      }
      if (prompt.rfind(bos_piece, 0) != 0)
        prompt = bos_piece + prompt;
      auto tokens = tokenize(prompt);
      if (tokens.empty() || tokens.size() > size_t(max_len))
        throw std::invalid_argument("Branch exceeds context limit");
      if (tokens.front() != bos_id || std::count(tokens.begin(), tokens.end(), bos_id) != 1)
        throw std::invalid_argument("Rendered branch must contain exactly one vocabulary BOS token");
      json ids = json::object();
      std::set<llama_token> distinct;
      for (const auto &label : b.at("output_labels")) {
        check_cancelled();
        auto with = tokenize(prompt + label.get<std::string>());
        if (with.size() != tokens.size() + 1 ||
            !std::equal(tokens.begin(), tokens.end(), with.begin()) ||
            !distinct.insert(with.back()).second)
          throw std::invalid_argument(
              "Answer label is not one distinct token at rendered boundary");
        ids[label.get<std::string>()] = with.back();
      }
      result.push_back({{"branch_id", b.at("branch_id")},
                        {"tokens", tokens},
                        {"token_ids", ids},
                        {"provenance", provenance()},
                        {"rendered_generation_boundary", std::string(generation_boundary) + b.at("answer_prefix").get<std::string>()},
                        {"rendered", prompt}});
    }
    check_cancelled();
    return result;
  }
  void decode(const std::vector<llama_token> &tokens, int seq, int offset,
              bool output) {
    for (size_t start = 0; start < tokens.size(); start += decode_chunk) {
      check_cancelled();
      const size_t n = std::min(size_t(decode_chunk), tokens.size() - start);
      NativeBatch owner(n);
      auto &batch = owner.value;
      for (size_t i = 0; i < n; i++) {
        check_cancelled();
        batch.token[i] = tokens[start + i];
        batch.pos[i] = offset + start + i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = seq;
        batch.logits[i] = output && start + i + 1 == tokens.size();
      }
      batch.n_tokens = n;
      check_cancelled();
      int code = llama_decode(ctx, batch);
      check_cancelled();
      if (code)
        throw std::runtime_error("Native forward failed: " +
                                 std::to_string(code));
      forwards++;
      computed += n;
    }
  }
  json evaluate(const json &branches, bool full) {
    check_cancelled();
    if (vocab_only)
      throw std::invalid_argument("Evaluation is forbidden in vocabulary-only mode: no weights/context loaded");
    if (!ctx)
      throw std::runtime_error("Evaluation context is not initialized");
    if (!branches.is_array() || branches.empty() || branches.size() > 256)
      throw std::invalid_argument("Expected 1–256 compiled branches");
    std::set<std::string> branch_ids;
    std::vector<std::vector<llama_token>> tokens;
    for (const auto &b : branches) {
      check_cancelled();
      const auto branch_id = b.at("branch_id").get<std::string>();
      if (branch_id.empty() || !branch_ids.insert(branch_id).second)
        throw std::invalid_argument("Empty or duplicate branch ID");
      const auto &raw = b.at("tokens");
      if (!raw.is_array() || raw.empty() || raw.size() > size_t(max_len))
        throw std::invalid_argument("Invalid compiled token length");
      std::vector<llama_token> t;
      t.reserve(raw.size());
      for (const auto &token : raw) {
        check_cancelled();
        t.push_back(integer(token, 0, llama_vocab_n_tokens(vocab) - 1,
                            "Invalid compiled token ID"));
      }
      tokens.push_back(std::move(t));
      if (!b.at("token_ids").is_object() || b.at("token_ids").empty() ||
          b.at("token_ids").size() > 50)
        throw std::invalid_argument("Missing answer token IDs");
      for (auto it = b.at("token_ids").begin(); it != b.at("token_ids").end();
           it++) {
        check_cancelled();
        integer(it.value(), 0, llama_vocab_n_tokens(vocab) - 1,
                "Invalid answer token ID");
      }
    }
    check_cancelled();
    llama_memory_clear(llama_get_memory(ctx), true);
    forwards = 0;
    computed = 0;
    size_t prefix = 0;
    if (!full) {
      size_t cap = tokens[0].size() - 1;
      for (auto &t : tokens) {
        check_cancelled();
        cap = std::min(cap, t.size() - 1);
      }
      while (prefix < cap) {
        check_cancelled();
        bool same = true;
        for (auto &t : tokens) {
          check_cancelled();
          if (t[prefix] != tokens[0][prefix])
            same = false;
        }
        if (!same)
          break;
        prefix++;
      }
    }
    if (prefix)
      decode({tokens[0].begin(), tokens[0].begin() + prefix}, 0, 0, false);
    std::vector<size_t> order;
    for (size_t i = 0; i < tokens.size(); i++)
      order.push_back(i);
    std::stable_sort(order.begin(), order.end(), [&](auto a, auto b) {
      return tokens[a].size() < tokens[b].size();
    });
    check_cancelled();
    json logits = json::object(), sizes = json::array();
    for (size_t cursor = 0; cursor < order.size();) {
      check_cancelled();
      size_t end = cursor;
      while (end < order.size() &&
             end - cursor < size_t(full ? 1 : max_batch) &&
             (end - cursor + 1) * (tokens[order[end]].size() - prefix) <=
                 size_t(max_tokens)) {
        check_cancelled();
        end++;
      }
      if (end == cursor)
        throw std::invalid_argument("Suffix exceeds batch token budget");
      sizes.push_back(end - cursor);
      NativeBatch owner(max_tokens);
      auto &batch = owner.value;
      std::vector<int> last;
      for (size_t j = cursor; j < end; j++) {
        check_cancelled();
        int seq = j - cursor + 1;
        auto i = order[j];
        if (prefix)
          llama_memory_seq_cp(llama_get_memory(ctx), 0, seq, 0, prefix);
        for (size_t k = prefix; k < tokens[i].size(); k++) {
          check_cancelled();
          int n = batch.n_tokens++;
          batch.token[n] = tokens[i][k];
          batch.pos[n] = k;
          batch.n_seq_id[n] = 1;
          batch.seq_id[n][0] = seq;
          batch.logits[n] = k + 1 == tokens[i].size();
        }
        last.push_back(batch.n_tokens - 1);
      }
      // Split large suffix batches into native calls while preserving scoring
      // positions.
      for (int start = 0; start < batch.n_tokens; start += decode_chunk) {
        check_cancelled();
        int n = std::min(decode_chunk, batch.n_tokens - start);
        llama_batch part = batch;
        part.n_tokens = n;
        part.token += start;
        part.pos += start;
        part.n_seq_id += start;
        part.seq_id += start;
        part.logits += start;
        int code = llama_decode(ctx, part);
        check_cancelled();
        if (code) {
          throw std::runtime_error("Native suffix forward failed: " +
                                   std::to_string(code));
        }
        forwards++;
        computed += n;
        for (size_t j = 0; j < last.size(); j++) {
          check_cancelled();
          if (last[j] >= start && last[j] < start + n) {
            auto i = order[cursor + j];
            auto row = llama_get_logits_ith(ctx, last[j] - start);
            if (!row) {
              throw std::runtime_error("Missing scoring logits");
            }
            json selected = json::object();
            for (auto it = branches[i].at("token_ids").begin();
                 it != branches[i].at("token_ids").end(); it++) {
              check_cancelled();
              float v = row[it.value().get<int>()];
              if (!std::isfinite(v)) {
                throw std::runtime_error("Non-finite selected logit");
              }
              selected[it.key()] = v;
            }
            logits[branches[i].at("branch_id").get<std::string>()] = selected;
          }
        }
      }
      for (size_t j = cursor; j < end; j++) {
        check_cancelled();
        llama_memory_seq_rm(llama_get_memory(ctx), j - cursor + 1, -1, -1);
      }
      cursor = end;
    }
    // Logical unique-prefix accounting is independent of executed batches.
    std::map<std::pair<int, llama_token>, int> trie;
    int lengths = 0;
    for (auto &t : tokens) {
      check_cancelled();
      lengths += t.size();
      int node = 0;
      for (auto token : t) {
        check_cancelled();
        auto key = std::make_pair(node, token);
        auto found = trie.find(key);
        if (found == trie.end())
          found = trie.emplace(key, trie.size() + 1).first;
        node = found->second;
      }
    }
    check_cancelled();
    llama_memory_clear(llama_get_memory(ctx), true);
    return {{"logits", logits},
            {"input_tokens", trie.size()},
            {"metrics",
             {{"backend", "llama.cpp"},
              {"provenance", provenance()},
              {"prefill_strategy", full ? "full" : "shared_prefix"},
              {"prefix_tokens", prefix},
              {"suffix_batch_sizes", sizes},
              {"engine_forwards", forwards},
              {"branch_prompt_tokens", lengths},
              {"computed_prompt_tokens", computed},
              {"logical_prefill_tokens", computed},
              {"padded_suffix_tokens", 0},
              {"branch_output_tokens", 0},
              {"scored_positions", tokens.size()}}}};
  }
};
int main() {
  llama_log_set(log_callback, nullptr);
  Engine engine;
  std::mutex mutex;
  std::condition_variable cv;
  std::queue<json> requests;
  bool eof = false;
  bool protocol_failed = false;
  std::string active;
  std::set<std::string> cancelled_requests;
  std::string pending_cancel;
  std::thread reader([&] {
    try {
      while (true) {
        std::string line;
        auto *input = std::cin.rdbuf();
        bool reached_eof = false;
        while (true) {
          const auto next = input->sbumpc();
          if (next == std::char_traits<char>::eof()) {
            reached_eof = true;
            break;
          }
          if (next == '\n')
            break;
          if (line.size() == max_protocol_line)
            throw std::invalid_argument("Native protocol line exceeds 64 MiB");
          line.push_back(char(next));
        }
        if (line.empty() && reached_eof)
          break;
        auto r = json::parse(
            line, [](int depth, json::parse_event_t, json &) {
              if (depth > 32)
                throw std::invalid_argument("Native protocol nesting exceeds 32");
              return true;
            });
        if (!r.is_object() || !r.contains("op") ||
            !r.at("op").is_string())
          throw std::invalid_argument("Invalid native protocol envelope");
        std::lock_guard<std::mutex> lock(mutex);
        if (r.at("op") == "cancel") {
          if (!r.contains("v") ||
              integer(r.at("v"), 1, 1, "Unsupported protocol") != 1 ||
              !r.contains("target") || !r.at("target").is_string())
            throw std::invalid_argument("Invalid native cancellation envelope");
          const auto target = r.at("target").get<std::string>();
          if (target.empty() || target.size() > 128)
            throw std::invalid_argument("Invalid native cancellation ID");
          if (target == active)
            cancelled = true;
          else if (!requests.empty() && requests.front().at("id") == target)
            cancelled_requests.insert(target);
          else
            // One RPC is submitted at a time. Keep at most one cancellation
            // that arrived before its request; late replies cannot accumulate
            // completed IDs or displace cancellation of a queued request.
            pending_cancel = target;
        } else {
          if (!r.contains("id") || !r.at("id").is_string() ||
              r.at("id").get_ref<const std::string &>().empty() ||
              r.at("id").get_ref<const std::string &>().size() > 128)
            throw std::invalid_argument("Invalid native request ID");
          if (!requests.empty())
            throw std::invalid_argument("Native protocol request queue is full");
          requests.push(std::move(r));
        }
        cv.notify_one();
      }
    } catch (const json::exception &) {
      std::cerr << "Native protocol rejected malformed JSON\n";
      std::lock_guard<std::mutex> lock(mutex);
      protocol_failed = true;
      cancelled = true;
    } catch (const std::exception &e) {
      std::cerr << "Native protocol rejected input: " << e.what() << '\n';
      std::lock_guard<std::mutex> lock(mutex);
      protocol_failed = true;
      cancelled = true;
    }
    {
      std::lock_guard<std::mutex> lock(mutex);
      eof = true;
    }
    cv.notify_one();
  });
  while (true) {
    json r;
    {
      std::unique_lock<std::mutex> lock(mutex);
      cv.wait(lock, [&] { return eof || !requests.empty(); });
      if (protocol_failed || requests.empty())
        break;
      r = requests.front();
      requests.pop();
      active = r.value("id", "");
      cancelled = cancelled_requests.erase(active) > 0 || active == pending_cancel;
      if (active == pending_cancel)
        pending_cancel.clear();
    }
    json response = {{"v", 1}, {"id", r.value("id", "")}};
    try {
      if (!r.contains("v") ||
          integer(r.at("v"), 1, 1, "Unsupported protocol") != 1)
        throw std::invalid_argument("Unsupported protocol");
      check_cancelled();
      const auto op = r.value("op", "");
      if (op == "init") {
        engine.init(r);
        response["result"] = engine.status();
      } else {
        if (!engine.model || !engine.templates)
          throw std::runtime_error("Not initialized");
        if (op == "compile")
          response["result"] = engine.compile(r.at("branches"));
        else if (op == "evaluate")
          response["result"] =
              engine.evaluate(r.at("branches"), r.value("full", false));
        else
          throw std::invalid_argument("Unknown operation");
      }
    } catch (const json::exception &) {
      if (engine.ctx)
        llama_memory_clear(llama_get_memory(engine.ctx), true);
      response["error"] = {{"message", "Malformed native request fields"},
                           {"kind", "invalid_request"}};
    } catch (const std::invalid_argument &e) {
      if (engine.ctx)
        llama_memory_clear(llama_get_memory(engine.ctx), true);
      response["error"] = {{"message", e.what()}, {"kind", "invalid_request"}};
    } catch (const std::exception &e) {
      if (engine.ctx)
        llama_memory_clear(llama_get_memory(engine.ctx), true);
      response["error"] = {{"message", e.what()},
                           {"kind", cancelled ? "cancelled" : "runtime"}};
    }
    std::cout << response.dump() << std::endl;
    {
      std::lock_guard<std::mutex> lock(mutex);
      active.clear();
    }
  }
  reader.join();
  return protocol_failed ? 2 : 0;
}
