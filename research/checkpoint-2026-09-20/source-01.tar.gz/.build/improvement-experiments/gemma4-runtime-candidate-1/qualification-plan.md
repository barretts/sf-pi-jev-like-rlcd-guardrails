Candidate 1 is source preparation only. No compilation, native/tokenizer/model/GPU execution, live benchmark/result read, TEST access, training, role promotion, production activation, or change to the original benchmark has occurred.

Pinned source and profile

- Parent source: `f2dc4e3457bb422219c24d6658757f3cd588ff3115d4e320c0c23e9582d332fb`.
- Candidate source: `c0919f79087e4bf3ce4f6332956b79d7b9e9bb415a250288fb47bcecd7ca64b8`.
- Profile ID: `gemma4-direct-label-raw-q4-runtime-candidate-1`.
- Prospective profile JSON SHA-256: `d0e4f0aa97661a9fffbbf80a649b6e8b1add435d76366e3f775504d00b5058c7`. The source-derived JSON uses sorted keys and compact encoding, matching the intended nlohmann JSON dump. The first future qualification must compare it with the actually emitted profile and digest; this preparation did not execute that serializer.
- The candidate changes four physical knobs: F16 K/V (GGML enum 1), requested flash AUTO (enum -1), logical batch/decode chunk 2048, and physical microbatch 512.
- Context defaults remain 4096 via the unchanged max_len + max_tokens expression; accepted logical model length and batch-token caps remain 2048. Two threads, two sequence capacity, unified KV, and inherited full SWA remain unchanged.
- Requested AUTO is not evidence of effective flash activation. Candidate provenance leaves effective flash null. Future qualification must attribute actual resolution from native initialization diagnostics and retain unknown if unavailable.

Prospective qualification order

1. Preserve the original source, profile, frozen running benchmark, plans, and proofs. Do not start candidate native work while the original serial native lane is still active.
2. Freeze candidate source/profile identity and retain the exact pinned vendor/build identity. Any future compile must use this candidate source and its candidate SHA for GEMMA4_PROTOTYPE_SOURCE_SHA256, leaving the original binary untouched. Compilation is outside this source-preparation step.
3. Before any future candidate inference, independently verify the frozen raw q4_0 artifact and original raw/parser template identities using the existing authorized qualification workflow. This candidate retains the original prototype's explicit checksum-verification limitation and does not claim model bytes were read or verified here.
4. Perform fresh complete 194-row VALIDATION qualification for this exact source/profile. Keep the frozen row order, gold targets, v2 logical prompts, original Jinja/parser-source transform, disabled thinking, vocabulary BOS/exactly-one-BOS boundary, full-prefix/one-distinct-token label rule, response construction, and existing quality thresholds unchanged. Capture complete coverage, all failures, artifact/template/source/profile/build attribution, and effective runtime settings. Partial, interrupted, malformed, unknown, or failed qualification is not accepted.
5. Apply the existing direct-versus-full agreement gates and finite-label-logit/response-consistency checks with their unchanged tolerances, attributable to this candidate. F16 cache rounding, attention arithmetic, and chunk boundaries may alter numeric logits even though raw weight precision and exposed float output storage are unchanged.
6. Make no speed claim before terminal complete VALIDATION and required agreement gates pass. Only then may a separate future authorized benchmark plan compare this candidate with the frozen original using trustworthy decoded-work and wall-time accounting. This document changes no current benchmark plan. Larger microbatches may increase compute storage; AUTO may resolve disabled; neither fit nor performance improvement is established.
7. Do not read the TEST corpus, conduct final TEST evaluation, edit gold/quality gates, promote a classifier role/artifact, or activate globally under this candidate-preparation task. Such later steps retain their existing gate ordering and scope.

Reduced SWA, sequence capacity, and unified KV are not part of candidate 1. Any later change to those settings is a separately identified and freshly qualified hypothesis.
