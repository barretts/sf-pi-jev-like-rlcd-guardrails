import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, appendFile, mkdir, stat, mkdtemp, realpath } from 'node:fs/promises';
import { execFile, spawn } from 'node:child_process';
import { createServer } from 'node:net';
import { promisify } from 'node:util';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

// ROOT alone invokes this driver. An unreleased or unchecked source inventory
// fails before importing an adapter or starting a model process.
const flag = process.argv[2];
assert.ok(['--ROOT-freeze-only', '--ROOT-server-capability', '--ROOT-execute-frozen-312'].includes(flag), 'Explicit ROOT stage required');
const ROOT = '/Users/bsonntag/code/simple-jev-ts';
assert.equal(resolve(process.cwd()), ROOT);
const SELF = fileURLToPath(import.meta.url), PARENT = dirname(SELF);
const HERE = join(ROOT, '.build/improvement-experiments/gemma4-successor-direct-proposal');
const RELEASE = join(HERE, 'source-release-revision-2.json');
const REVIEW = join(PARENT, 'root-successor-direct-source-review-revision-2.json');
const PLAN = join(PARENT, 'performance-successor-root-frozen-plan-2.json');
const CAP = join(HERE, 'capability-native-proof-root-2');
const PERF = join(HERE, 'performance-native-proof-root-2');
const RELEASE_SHA256 = 'fe3edd4691d1e4da374ff9c9ebc55ba7b5bead5a19d7c79aa10c8071c4607ab6';
const execute = promisify(execFile);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const bytesOf = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const writeJson = (path, value, mode = 0o600) => writeFile(path, bytesOf(value), { flag: 'wx', mode });
async function identity(path) {
  const details = await stat(path); assert.ok(details.isFile());
  const digest = createHash('sha256'); for await (const chunk of createReadStream(path)) digest.update(chunk);
  return { path: resolve(path), bytes: details.size, sha256: digest.digest('hex') };
}
async function verifiedBytes(ref) {
  const bytes = await readFile(ref.path); assert.equal(bytes.length, ref.bytes); assert.equal(sha(bytes), ref.sha256); return bytes;
}
async function command(file, args) {
  try { const result = await execute(file, args, { timeout: 5000, maxBuffer: 1048576, encoding: 'utf8' }); return { ...result, code: 0 }; }
  catch (error) { if (error.code === 1 && !(error.stderr ?? '').trim()) return { stdout: error.stdout ?? '', stderr: '', code: 1 }; throw error; }
}
async function laneIdle() {
  const result = await command('/bin/ps', ['-axo', 'pid=,ppid=,comm=']); assert.equal(result.code, 0);
  const matches = result.stdout.split('\n').filter(line => /llama-server|gemma4-label-prototype|simple-jev-ts\/\.build\/rfdt-venv\/bin\/python/.test(line));
  assert.deepEqual(matches, [], 'Another known native/model/training process occupies the ROOT lane');
  return { actor: 'ROOT', observed_at: new Date().toISOString(), matching_processes: [], method: 'ps pid ppid comm only; no args/env/auth' };
}
async function rootPidGone(pid) {
  assert.ok(Number.isSafeInteger(pid) && pid > 0);
  const started = Date.now();
  while (Date.now() - started < 5000) {
    const result = await command('/bin/ps', ['-p', String(pid), '-o', 'pid=,ppid=,comm=']);
    if (result.code === 1 && !result.stdout.trim()) return { actor: 'ROOT', pid, absent: true,
      observed_at: new Date().toISOString(), method: 'independent ps -p PID after owned exit and stdio close; empty output and exit1' };
    await new Promise(done => setTimeout(done, 100));
  }
  throw new Error('Owned PID remained present after independent exit and stdio closure: ' + pid);
}
async function rootOwnedListener(pid, port) {
  assert.ok(Number.isSafeInteger(pid) && pid > 0); assert.equal(port, 8089);
  const result = await command('/usr/sbin/lsof', ['-nP', '-iTCP:' + port, '-sTCP:LISTEN', '-Fpcn']);
  const rows = []; let current = null;
  for (const line of result.stdout.split('\n')) {
    if (line.startsWith('p')) current = { pid: Number(line.slice(1)) };
    else if (line.startsWith('c') && current) current.comm = line.slice(1);
    else if (line.startsWith('n') && current) rows.push({ ...current, address: line.slice(1) });
  }
  return { actor: 'ROOT', pid, port, only_owned_listener: rows.length > 0 && rows.every(row => row.pid === pid && row.address === '127.0.0.1:8089'),
    observed_at: new Date().toISOString(), method: 'independent lsof numeric TCP LISTEN PID and address fields; no process args/env/auth', observed_listeners: rows };
}

// Original reviewed private server factory adapted for this ROOT-only synthetic capability.
async function availablePort(port) {
  await new Promise((done, reject) => {
    const listener = createServer(); listener.once('error', reject);
    listener.listen(port, '127.0.0.1', () => listener.close(error => error ? reject(error) : done()));
  });
}
async function startRootCapabilityServer({ plan, proof, audit, signal, observeOwnedListener }) {
  await laneIdle();
  assert.equal(typeof observeOwnedListener, 'function'); signal.throwIfAborted(); await availablePort(plan.generative.port); signal.throwIfAborted();
  assert.equal(await realpath(dirname(proof)), await realpath(HERE)); const slotPath = await mkdtemp(join(proof, 'owned-server-slot-store-'));
  const args = ['--model', plan.artifacts.model.path, '--jinja', '--chat-template-file', plan.artifacts.template.path,
    '--alias', plan.generative.model_id, '--host', '127.0.0.1', '--port', '8089', '--ctx-size', '4096', '--parallel', '1', '--n-gpu-layers', 'all',
    '--verbosity', '4', '--reasoning', 'on', '--slots', '--cache-ram', '0', '--slot-save-path', slotPath,
    '--cors-origins', '', '--no-cors-credentials', '--no-webui', '--no-agent'];
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !/^(LLAMA_|AIP_)/.test(key)));
  const child = spawn(plan.generative.binary, args, { cwd: HERE, stdio: ['ignore', 'pipe', 'pipe'], env });
  let logs = '', totalBytes = 0, truncated = false, error = null, exited = false, closed = false, exitCode = null, exitSignal = null, stopping = false;
  let finish; const closing = new Promise(resolvePromise => { finish = resolvePromise; });
  child.once('error', value => { error = String(value); }); child.once('exit', (code, sig) => { exited = true; exitCode = code; exitSignal = sig; if (!stopping) error ??= 'Unexpected owned server exit'; });
  child.once('close', () => { closed = true; finish(); });
  const abort = () => { error ??= 'Owned server stage aborted'; stopping = true; child.kill('SIGTERM'); };
  signal.addEventListener('abort', abort, { once: true }); if (signal.aborted) abort();
  const log = part => { totalBytes += part.length; if (totalBytes > protocol.BOUNDS.max_stderr_bytes) { truncated = true; error ??= 'Owned server log cap exceeded'; stopping = true; child.kill('SIGTERM'); }
    else logs += part.toString('utf8'); };
  child.stdout?.on('data', log); child.stderr?.on('data', log);
  const listenerObservations = [];
  return { pid: child.pid, logs: () => logs, failure: () => error || (exited ? 'Owned server exited' : null),
    ownsListener: async () => { const receipt = await runner.boundedRootObservation(observeOwnedListener, [child.pid, plan.generative.port], { signal }); listenerObservations.push(receipt);
      return receipt?.actor === 'ROOT' && receipt.pid === child.pid && receipt.port === 8089 && receipt.only_owned_listener === true && Number.isFinite(Date.parse(receipt.observed_at)) && typeof receipt.method === 'string' && receipt.method.length > 0 && !receipt.error; },
    close: async () => { stopping = true; if (!exited) child.kill('SIGTERM');
      const wait = async () => { let timer; try { await Promise.race([closing, new Promise(resolvePromise => { timer = setTimeout(resolvePromise, protocol.BOUNDS.exit_timeout_ms); })]); } finally { clearTimeout(timer); } };
      await wait(); if (!closed) { child.kill('SIGKILL'); await wait(); } signal.removeEventListener('abort', abort);
      const observations = capabilityModule.serverStderrObservations(logs, { truncated, pid: child.pid });
      const receipt = { pid: child.pid ?? null, exited, stdio_closed: closed, exit_code: exitCode, exit_signal: exitSignal, error,
        intentional_owned_shutdown: true, exit_and_stdio_close_observed: exited && closed, owned_cleanup_complete: exited && closed && !error && (exitCode === 0 || exitSignal === 'SIGTERM'),
        native_profile_passed: capabilityModule.serverProfilePassed(observations), native_observations: observations, listener_observations: listenerObservations, args, logs };
      try { await audit('owned_server_process', receipt); } catch (failure) { receipt.audit_error = String(failure); receipt.owned_cleanup_complete = false; } return receipt;
    } };
}


const releaseBytes = await readFile(RELEASE); assert.equal(sha(releaseBytes), RELEASE_SHA256, 'ROOT must pin the final reviewed source release');
const release = JSON.parse(releaseBytes);
assert.equal(release.kind, 'gemma4_successor_direct_matched312_source_release');
assert.equal(release.native_execution_authorized, false);
const sourceExpectations = release.source_identities;
assert.ok(Array.isArray(sourceExpectations) && sourceExpectations.length > 20);
for (const ref of sourceExpectations) assert.deepEqual(await identity(ref.path), ref, 'Source changed before ROOT import: ' + ref.path);
const reviewBytes = await readFile(REVIEW), review = JSON.parse(reviewBytes);
assert.equal(review.actor, 'ROOT'); assert.equal(review.source_release_sha256, RELEASE_SHA256);
assert.equal(review.source_review_passed, true); assert.equal(review.independent_focused_CPU_checks_passed, true);
assert.deepEqual(review.source_identities, sourceExpectations);
const sourceReleaseRef = { path: RELEASE, bytes: releaseBytes.length, sha256: sha(releaseBytes) };
const sourceReviewRef = { path: REVIEW, bytes: reviewBytes.length, sha256: sha(reviewBytes) };
const runnerRef = sourceExpectations.find(ref => ref.path === join(HERE, 'runner.mjs')); assert.ok(runnerRef);
const runner = await import(pathToFileURL(runnerRef.path).href + '?sha256=' + runnerRef.sha256);
const protocolRef = sourceExpectations.find(ref => ref.path === join(HERE, 'protocol.mjs')); assert.ok(protocolRef);
const protocol = await import(pathToFileURL(protocolRef.path).href + '?sha256=' + protocolRef.sha256);
const capabilityRef = sourceExpectations.find(ref => ref.path === join(HERE, 'capability.mjs')); assert.ok(capabilityRef);
const capabilityModule = await import(pathToFileURL(capabilityRef.path).href + '?sha256=' + capabilityRef.sha256);
const authorization = stage => ({ actor: 'ROOT', explicit: true, stage, logical_id: protocol.PINS.logicalId,
  research_profile: protocol.PINS.profileId, prototype_source_sha256: protocol.PINS.source, production_role_approval: false });

if (flag === '--ROOT-freeze-only') {
  const idle = await laneIdle();
  const plan = await runner.freezeRootMatched312({ rootAuthorization: authorization('successor_matched312_freeze'),
    qualificationRefs: await runner.qualificationRefsFromReleasedMetadata(), sourceReleaseRef, sourceExpectations });
  plan.root_entry_identity = await identity(SELF); plan.root_source_review = sourceReviewRef; plan.root_preparation_lane_observation = idle;
  const planBytes = bytesOf(plan); await writeFile(PLAN, planBytes, { flag: 'wx', mode: 0o400 });
  process.stdout.write(JSON.stringify({ frozen_plan_sha256: sha(planBytes), records: plan.dataset.records, groups: plan.dataset.groups,
    attempts: 312, order: plan.schedule.map(block => block.method), fresh194_qualified: true, native_processes_started: 0, quality_or_gain_proven: false }) + '\n');
  process.exit(0);
}

const planBytes = await readFile(PLAN), plan = JSON.parse(planBytes);
assert.deepEqual(plan.root_entry_identity, await identity(SELF)); assert.deepEqual(plan.root_source_review, sourceReviewRef);
assert.deepEqual(plan.source_release, sourceReleaseRef); await runner.verifyFrozen(plan);
const idle = await laneIdle();

if (flag === '--ROOT-server-capability') {
  await mkdir(CAP, { mode: 0o700 });
  const clearance = { kind: 'ROOT_successor_original_server_three_synthetic_capability_clearance', actor: 'ROOT',
    plan_sha256: sha(planBytes), root_entry_identity: plan.root_entry_identity, source_review: sourceReviewRef, lane_observation: idle,
    scope: 'three gold-free synthetic RFDT teacher operations only; no developer validation or TEST',
    native_GPU_inference_authorized: true, production_role_approval: false, benchmark_gain_established: false };
  await writeJson(join(CAP, 'root-clearance.json'), clearance); await writeFile(join(CAP, 'run-plan.json'), planBytes, { flag: 'wx', mode: 0o600 });
  const originals = join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality');
  const renderer = join(originals, 'render-reference.py');
  const capability = await import(pathToFileURL(join(HERE, 'capability.mjs')).href);
  const rfdtRef = sourceExpectations.find(ref => ref.path === join(ROOT, 'dist/rfdt.js')); assert.ok(rfdtRef);
  const decisionRef = sourceExpectations.find(ref => ref.path === join(ROOT, 'scripts/developer-decision-eval.mjs')); assert.ok(decisionRef);
  const rfdt = await import(pathToFileURL(rfdtRef.path).href + '?sha256=' + rfdtRef.sha256);
  const decision = await import(pathToFileURL(decisionRef.path).href + '?sha256=' + decisionRef.sha256);
  const probes = [
    { id: 'synthetic-choice', group_id: 'synthetic-choice', split: 'validation', request: { state: 'The bicycle is red.',
      questions: [{ id: 'q', type: 'choice', instructions: 'Which color is the bicycle?', criteria: [{ id: 'red', description: 'Red bicycle' }, { id: 'blue', description: 'Blue bicycle' }] }] } },
    { id: 'synthetic-earned-half', group_id: 'synthetic-earned-half', split: 'validation', request: { messages: [{ role: 'user', content: 'Check A is documented as partially implemented. Check B is absent.' }],
      questions: [{ id: 'q', type: 'score', instructions: 'Award one point for each of checks A and B that is fully implemented. An explicitly documented partially implemented check earns half a point. An absent check earns zero. Return total earned points.', criteria: ['Zero earned points', 'One earned point', 'Two earned points'] }] } },
    { id: 'synthetic-unknown', group_id: 'synthetic-unknown', split: 'validation', request: { state: 'The review outcome has not been recorded.',
      questions: [{ id: 'q', type: 'noul', instructions: 'The review was approved.' }] } },
  ];
  // Golds exist solely in this host-only synthetic grader and never reach run().
  const golds = [{ answer: 'red' }, { answer: 0.5 }, { answer: null }];
  for (const probe of probes) {
    probe.request.model = protocol.PINS.modelId;
    rfdt.validateRfdtExample({ ...probe, targets: {} }, true);
  }
  const controller = new AbortController(); const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(600000)]);
  const interrupted = () => controller.abort(new Error('ROOT capability interrupted'));
  process.once('SIGINT', interrupted); process.once('SIGTERM', interrupted);
  const rows = []; let adapter, cleanup = null, error = null, trial = 0, renderIndex = 0, auditFailure = null;
  const audit = async (kind, value) => { try { await appendFile(join(CAP, 'audit.jsonl'), JSON.stringify(protocol.finiteJson({ kind, ...value })) + '\n', { mode: 0o600 }); }
    catch (failure) { auditFailure = String(failure); controller.abort(failure); throw failure; } };
  try {
    adapter = await runner.makeGenerativeAdapter({ plan, proof: CAP, audit, labelRfdt: rfdt.labelRfdt,
      originalFetch: globalThis.fetch, nextTrial: () => ++trial, observeRootPidGone: rootPidGone, observeOwnedListener: rootOwnedListener,
      startServerImpl: startRootCapabilityServer,
      renderOriginal: async (messages, requestSignal, teacherTry) => {
        const id = 'capability-teacher-' + String(++renderIndex).padStart(4, '0');
        const requests = [{ record_id: id, branch: { branch_id: id, messages, answer_prefix: '' } }];
        const requestBytes = protocol.jsonBytes(requests), input = join(CAP, id + '-requests.json'), output = join(CAP, id + '-render.json');
        await writeFile(input, requestBytes, { flag: 'wx', mode: 0o600 });
        const execution = await execute(plan.host_runtime.renderer.python_executable, [renderer, '--requests', input, '--output', output,
          '--template', plan.artifacts.template.path, '--expected-sha256', protocol.PINS.template], { cwd: HERE, timeout: 60000, maxBuffer: 1048576, encoding: 'utf8', signal: requestSignal });
        const rendered = await readFile(output), reference = JSON.parse(rendered);
        capability.verifyIndependentRender(reference, requests, requestBytes, plan.host_runtime.renderer);
        teacherTry.independent_render_sha256 = sha(rendered); teacherTry.independent_render_process = { stdout: execution.stdout, stderr: execution.stderr, exit_code: 0 };
        return reference.rows[0];
      } });
    await adapter.initialize(signal);
    for (let index = 0; index < probes.length; index++) {
      const row = { record_id: probes[index].id, transport: [] }; rows.push(row);
      const returned = await adapter.run(probes[index], signal, row);
      row.host_grade = decision.scoreAnswer(probes[index].request.questions[0], golds[index], returned.q, 'generative');
      assert.equal(row.host_grade.correct_judgment, true); assert.equal(row.accounting_complete, true); assert.equal(row.cache_clear_proved, true);
    }
  } catch (failure) { error = String(failure); }
  finally {
    try { if (adapter) cleanup = await adapter.close(); } catch (failure) { error ??= 'Capability cleanup: ' + String(failure); }
    process.removeListener('SIGINT', interrupted); process.removeListener('SIGTERM', interrupted);
  }
  const passed = !error && !auditFailure && rows.length === 3 && rows.every(row => row.host_grade?.correct_judgment === true && row.accounting_complete && row.cache_clear_proved) &&
    cleanup?.owned_cleanup_complete === true && cleanup.exit_and_stdio_close_observed === true && cleanup.root_pid_gone?.absent === true;
  const proof = { kind: 'ROOT_successor_original_server_three_synthetic_capability_proof', actor: 'ROOT', observed_at: new Date().toISOString(),
    run_plan_sha256: sha(planBytes), root_entry_identity: plan.root_entry_identity, source_release_sha256: RELEASE_SHA256,
    native_server_processes_started: cleanup?.pid ? 1 : 0, rows, cleanup, error, audit_failure: auditFailure, passed,
    no_TEST_inference: true, no_developer_validation_inference: true, benchmark_gain_established: false, production_role_approval: false };
  await writeJson(join(CAP, 'proof.json'), proof);
  process.stdout.write(JSON.stringify({ passed, error, owned_server_pid: cleanup?.pid, owned_pid_absent: cleanup?.root_pid_gone?.absent,
    synthetic_records: rows.length, actual_dispatched_POSTs: rows.reduce((count, row) => count + row.transport.length, 0), benchmark_gain_established: false }) + '\n');
  process.exitCode = passed ? 0 : 1;
} else {
  const receiptPath = join(CAP, 'root-final-receipt-1.json'), receipt = JSON.parse(await readFile(receiptPath));
  assert.equal(receipt.kind, 'ROOT_successor_original_server_three_synthetic_capability_result_attestation');
  assert.equal(receipt.actor, 'ROOT'); assert.equal(receipt.passed, true); assert.equal(receipt.run_plan_sha256, sha(planBytes));
  assert.equal(receipt.source_release_sha256, RELEASE_SHA256); assert.equal(receipt.owned_pid_absent, true);
  assert.equal(receipt.all_three_actual_generated_outputs_and_original_Jinja_BOS_tokenization_verified, true);
  const clearance = { kind: 'ROOT_successor_direct_matched312_clearance', actor: 'ROOT', stage_cleared: true, plan_sha256: sha(planBytes),
    scope: 'full_developer_validation_78_DGGD_312_attempts_only', other_native_gpu_work_idle: true, lane_observation: idle,
    held_out_TEST_authorized: false, production_role_approval: false, source_review: sourceReviewRef,
    original_server_capability_root_receipt: await identity(receiptPath), root_entry_identity: plan.root_entry_identity };
  const clearanceBytes = bytesOf(clearance); await writeFile(join(PARENT, 'performance-successor-root-clearance-2.json'), clearanceBytes, { flag: 'wx', mode: 0o400 });
  process.stdout.write(JSON.stringify({ owner_node_pid: process.pid, frozen_plan_sha256: sha(planBytes), starting_attempts: 312, source_release_sha256: RELEASE_SHA256 }) + '\n');
  const result = await runner.runRootMatched312({ rootAuthorization: authorization('successor_matched312_run'), planBytes, clearanceBytes,
    proofDirectory: PERF, observeRootPidGone: rootPidGone, observeOwnedListener: rootOwnedListener });
  const driverProof = { kind: 'ROOT_successor_matched312_driver_closed', actor: 'ROOT', observed_at: new Date().toISOString(),
    run_plan_sha256: sha(planBytes), root_entry_identity: plan.root_entry_identity, actual_attempts: result.attempts?.length,
    benchmark_result: await identity(join(PERF, 'result.json')), independent_final_attestation_pending: true, benchmark_gain_established: false };
  await writeJson(join(PERF, 'root-driver-close-proof-1.json'), driverProof);
  process.stdout.write(JSON.stringify({ attempts: result.attempts?.length, actual_errors: result.attempts?.filter(row => row.error).length,
    pending_independent_ROOT_final_attestation: true, benchmark_gain_established: false }) + '\n');
}
