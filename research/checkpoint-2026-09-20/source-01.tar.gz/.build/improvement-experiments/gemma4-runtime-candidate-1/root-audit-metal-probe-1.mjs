import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { compileHalfGrid, responseHalfGrid } from '../fractional-score-hypothesis/candidate-2/grid.mjs';
import { scorePrediction } from '../../../dist/evaluation.js';

assert.equal(process.argv[2], '--ROOT-closed-probe-audit');
const root = '/Users/bsonntag/code/simple-jev-ts';
assert.equal(resolve(process.cwd()), root);
const here = dirname(fileURLToPath(import.meta.url));
const output = join(here, 'metal-proof-root-1');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const execute = promisify(execFile);
const proofBytes = await readFile(join(output, 'proof.json'));
assert.equal(sha(proofBytes), '15adf710d50cdb470423005a5881718d0fc2fddfe33e2a86d641812f6c00a2c5');
const proof = JSON.parse(proofBytes);
const planBytes = await readFile(join(output, 'run-plan.json'));
const plan = JSON.parse(planBytes);
assert.equal(sha(planBytes), proof.run_plan_sha256);
assert.equal(proof.passed, false);
assert.equal(proof.error, 'AssertionError [ERR_ASSERTION]: Synthetic answer did not pass original scoring');
assert.equal(proof.synthetic_rows.length, 2);
assert.equal(proof.rpc.length, 7);
assert.equal(proof.owned_pid, 53880);
for (const state of [proof.cleanup, proof.owned_native]) {
  assert.equal(state.pid, proof.owned_pid);
  assert.equal(state.exitCode, 0); assert.equal(state.signal, null);
  assert.equal(state.exitedObserved, true); assert.equal(state.closedObserved, true);
  assert.equal(state.pendingRequests, 0); assert.equal(state.failureCode, null);
  assert.equal(state.stderrTruncated, false);
  assert.ok(!state.cleanupError); assert.deepEqual(state.signalsSent, []);
}
const pid = await execute('/bin/ps', ['-p', String(proof.owned_pid), '-o', 'pid=,ppid=,comm=']).catch(error => {
  assert.equal(error.code, 1); assert.equal(error.stdout.trim(), ''); return { stdout: '' };
});
assert.equal(pid.stdout.trim(), '');
const currentIdentities = [];
for (const identity of plan.identities) {
  const info = await stat(identity.path); assert.ok(info.isFile()); assert.equal(info.size, identity.bytes);
  const digest = createHash('sha256'); for await (const chunk of createReadStream(identity.path)) digest.update(chunk);
  assert.equal(digest.digest('hex'), identity.sha256, identity.path);
  currentIdentities.push(identity);
}
const profileBytes = await readFile(join(here, 'physical-profile.json'));
assert.equal(sha(profileBytes), plan.physical_profile_file_sha256);
assert.equal(sha(profileBytes), proof.physical_profile_file_sha256);
assert.equal(sha(profileBytes), 'd0e4f0aa97661a9fffbbf80a649b6e8b1add435d76366e3f775504d00b5058c7');
const profile = JSON.parse(profileBytes);
const compileBytes = await readFile(join(here, 'compile-evidence-root-1.json'));
const compile = JSON.parse(compileBytes);
assert.equal(compile.compiler_exit_code, 0);
assert.equal(compile.source_sha256, proof.source_sha256);
assert.equal(compile.binary_sha256, proof.binary_sha256);
assert.deepEqual(proof.rpc[0].request, plan.init);
const initialized = proof.rpc[0].response;
assert.ok(!initialized.error); assert.equal(initialized.id, 'init');
const provenance = initialized.result.provenance;
assert.deepEqual(provenance.physical_profile, profile);
assert.equal(sha(JSON.stringify(provenance.physical_profile)), proof.actual_emitted_physical_profile_sha256);
assert.equal(provenance.physical_profile_sha256, '48dda5a0b1630b607f0e5c691366ced92843ea43f0d5d4aab9bc62cc2a7416fc');
assert.equal(provenance.prototype_source_sha256, proof.source_sha256);
assert.equal(provenance.actual_mode, 'quantized_metal'); assert.equal(provenance.device, 'metal');
for (const key of ['weights_loaded', 'context_created', 'explicit_backend_init']) assert.equal(provenance[key], true);
assert.equal(provenance.vocab_only, false);
assert.equal(provenance.flash_attn_effective, null);
assert.equal(profile.decode_chunk, 2048); assert.equal(profile.n_batch_requested, 2048);
assert.equal(profile.n_ubatch_requested, 512); assert.equal(profile.kv_dtype, 'f16');
const originalReferenceBytes = await readFile(join(output, 'independent-render.json'));
assert.equal(sha(originalReferenceBytes), plan.independent_render_sha256);
const renderer = join(root, '.build/improvement-experiments/gemma4-label-prototype/research-quality/render-reference.py');
const freshRenderPath = join(output, 'root-audit-independent-render-2.json');
await execute('/usr/bin/env', ['python3', renderer, '--requests', join(output, 'render-requests.json'), '--output', freshRenderPath,
  '--template', plan.init.chat_template_file, '--expected-sha256', 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4'],
  { timeout: 60000, maxBuffer: 1048576 });
const freshReferenceBytes = await readFile(freshRenderPath);
const freshReference = JSON.parse(freshReferenceBytes), oldReference = JSON.parse(originalReferenceBytes);
assert.deepEqual(freshReference.rows, oldReference.rows);
assert.deepEqual(freshReference.runtime_identity, oldReference.runtime_identity);
assert.equal(freshReference.rows.length, 3);
const rows = [];
const wire = branch => ({ branch_id: branch.branch_id, messages: branch.messages,
  answer_prefix: branch.answer_prefix, output_labels: branch.output_labels });
for (let index = 0; index < 3; index++) {
  const prepared = plan.prepared[index];
  const reconstructedPlan = compileHalfGrid({ ...prepared.request, options: { template_version: 'v2', raw_logits: true } });
  assert.deepEqual(JSON.parse(JSON.stringify(reconstructedPlan)), prepared.plan);
  const branch = reconstructedPlan.questions[0];
  const compilation = proof.rpc[index * 2 + 1], evaluation = proof.rpc[index * 2 + 2];
  assert.deepEqual(compilation.request, { v: 1, id: 'probe-' + index, op: 'compile', branches: [wire(branch)] });
  assert.ok(!compilation.response.error); assert.equal(compilation.response.id, compilation.request.id);
  assert.equal(compilation.response.result.length, 1);
  const compiled = compilation.response.result[0];
  assert.equal(compiled.rendered, freshReference.rows[index].rendered);
  assert.equal(compiled.tokens[0], 2); assert.equal(compiled.tokens.filter(token => token === 2).length, 1);
  assert.deepEqual(Object.keys(compiled.token_ids).sort(), [...branch.output_labels].sort());
  assert.equal(new Set(Object.values(compiled.token_ids)).size, branch.output_labels.length);
  assert.equal(compiled.rendered_generation_boundary, '<|turn>model\n<|channel>thought\n<channel|>' + branch.answer_prefix);
  assert.deepEqual(evaluation.request, { v: 1, id: 'evaluate-' + index, op: 'evaluate', full: true,
    branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] });
  assert.ok(!evaluation.response.error); assert.equal(evaluation.response.id, evaluation.request.id);
  const raw = evaluation.response.result, metrics = raw.metrics;
  assert.equal(raw.input_tokens, compiled.tokens.length);
  assert.equal(metrics.backend, 'llama.cpp'); assert.equal(metrics.prefill_strategy, 'full');
  for (const key of ['prefix_tokens', 'branch_output_tokens', 'padded_suffix_tokens']) assert.equal(metrics[key], 0);
  for (const key of ['computed_prompt_tokens', 'branch_prompt_tokens', 'logical_prefill_tokens']) assert.equal(metrics[key], compiled.tokens.length);
  assert.equal(metrics.engine_forwards, Math.ceil(compiled.tokens.length / 2048));
  assert.equal(metrics.scored_positions, 1); assert.deepEqual(metrics.suffix_batch_sizes, [1]);
  assert.deepEqual(metrics.provenance, provenance);
  const typed = responseHalfGrid(reconstructedPlan, raw.logits, compiled.tokens.length, true, { metrics, metadata: {
    actual_mode: 'quantized_metal', physical_profile_sha256: provenance.physical_profile_sha256,
    prototype_source_sha256: proof.source_sha256, binary_sha256: proof.binary_sha256,
    raw_model_sha256: proof.model_sha256, probabilities_calibrated: false, production_role_approved: false,
  } });
  assert.equal(typed.usage.output_tokens, 0);
  const question = reconstructedPlan.request.questions[0], target = { answer: index === 0 ? 'red' : index === 1 ? 0.5 : null };
  const grade = scorePrediction(question, target, typed.answers.q);
  const syntheticScoringPassed = index === 2 ? grade.uncertain === true && Number.isFinite(grade.normalized_absolute_error)
    && grade.normalized_absolute_error <= 0.1 : grade.correct === true;
  assert.equal(syntheticScoringPassed, true);
  if (index < 2) {
    assert.deepEqual(JSON.parse(JSON.stringify(typed)), proof.synthetic_rows[index].actual_response);
    assert.deepEqual(JSON.parse(JSON.stringify(grade)), proof.synthetic_rows[index].grade);
  } else assert.equal(Object.hasOwn(grade, 'correct'), false);
  rows.push({ record_id: prepared.id, type: question.type, compiled_prompt_sha256: reconstructedPlan.logical_prompt_sha256,
    original_jinja_render_match: true, exactly_one_BOS: true, unchanged_native_one_distinct_token_guard_passed: true,
    raw_selected_logits: raw.logits, actual_response: typed, original_grade: grade,
    synthetic_scoring_passed: syntheticScoringPassed, actual_metrics: metrics,
    full_clear_before_after_rule: 'frozen unchanged native source plus actual full:true operation', generated_output_tokens: 0 });
}
const stderrBytes = await readFile(join(output, 'native-stderr.log'));
assert.equal(stderrBytes.toString(), proof.owned_native.stderr);
assert.match(stderrBytes.toString(), /offloaded 61\/61 layers to GPU/);
assert.match(stderrBytes.toString(), /resolve_fused_ops: Flash Attention enabled/);
assert.match(stderrBytes.toString(), /MTL0 KV buffer size =\s+320\.00 MiB/);
assert.match(stderrBytes.toString(), /MTL0 KV buffer size =\s+3200\.00 MiB/);
const scorerIdentities = {};
for (const path of ['dist/evaluation.js', 'dist/core.js']) scorerIdentities[path] = sha(await readFile(join(root, path)));
const audit = { kind: 'ROOT_successor_three_synthetic_metal_result_audit', observed_at: new Date().toISOString(),
  original_proof_sha256: sha(proofBytes), run_plan_sha256: sha(planBytes), original_command_exit_code: 1,
  original_probe_passed: false, original_failure_due_to_missing_unknown_correct_field_only: true,
  raw_proof_and_RPC_rewritten: false, new_native_or_GPU_execution: false, submitted_native_evaluations: 3,
  passed: true, probe_contracts_passed: true, all_three_original_scoring_checks_passed: true,
  unknown_scoring_rule: 'original scorePrediction uncertain target; normalized_absolute_error <= 0.1; not a clear completed judgment',
  synthetic_rows: rows, current_source_artifact_hashes_verified: currentIdentities, audit_scorer_source_sha256: scorerIdentities,
  actual_emitted_physical_profile_sha256: provenance.physical_profile_sha256, physical_profile_file_sha256: sha(profileBytes),
  source_sha256: proof.source_sha256, binary_sha256: proof.binary_sha256, model_sha256: proof.model_sha256,
  logical_id: proof.logical_id, independent_render_sha256: sha(originalReferenceBytes),
  audit_independent_render_sha256: sha(freshReferenceBytes), compile_evidence_sha256: sha(compileBytes),
  actual_offloaded_layers: 61, actual_flash_attention_observed_enabled: true,
  actual_flash_observation_source: 'native stderr resolve_fused_ops: Flash Attention enabled; emitted provenance effective field remains null',
  actual_Metal_KV_buffers_MiB: [320, 3200], native_stderr_sha256: sha(stderrBytes),
  input_tokens: rows.reduce((sum, row) => sum + row.actual_response.usage.input_tokens, 0), generated_output_tokens: 0,
  owned_pid: proof.owned_pid, owned_pid_absent: true, exit_and_stdio_close_observed: true,
  weights_and_context_loaded: true, actual_native_GPU_inference: true,
  quality_or_gain_proven: false, production_role_approved: false, approval_effect: 'none', held_out_TEST_read: false };
const auditBytes = Buffer.from(JSON.stringify(audit, null, 2) + '\n');
await writeFile(join(output, 'root-result-audit-1.json'), auditBytes, { flag: 'wx', mode: 0o400 });
const receipt = { kind: 'ROOT_successor_three_synthetic_metal_final_receipt', observed_at: new Date().toISOString(),
  proof_sha256: sha(proofBytes), audit_sha256: sha(auditBytes), run_plan_sha256: sha(planBytes),
  owned_pid: proof.owned_pid, owned_pid_absent: true, exit_and_stdio_close_observed: true,
  original_command_exit_code: 1, original_probe_passed: false,
  original_failure_due_to_missing_unknown_correct_field_only: true, audited_probe_contracts_and_original_scoring_passed: true,
  all_three_actual_original_Jinja_BOS_one_token_contracts_recomputed: true,
  actual_emitted_physical_profile_sha256: provenance.physical_profile_sha256, physical_profile_file_sha256: sha(profileBytes),
  source_sha256: proof.source_sha256, binary_sha256: proof.binary_sha256, model_sha256: proof.model_sha256,
  logical_id: proof.logical_id, independent_render_sha256: sha(originalReferenceBytes),
  actual_native_GPU_inference: true, weights_and_context_loaded: true, actual_offloaded_layers: 61,
  actual_flash_attention_observed_enabled: true, quality_or_gain_proven: false, production_role_approved: false, approval_effect: 'none' };
await writeFile(join(output, 'root-final-receipt-1.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx', mode: 0o400 });
console.log(JSON.stringify({ passed: audit.passed, original_execution_exit: 1, native_exit: 0, owned_pid_absent: true,
  audit_sha256: sha(auditBytes), input_tokens: audit.input_tokens, generated_output_tokens: 0, additional_native_execution: false }));
