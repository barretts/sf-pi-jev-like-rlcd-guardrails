import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = '/Users/bsonntag/code/simple-jev-ts';
assert.equal(resolve(process.cwd()), root);
const here = dirname(fileURLToPath(import.meta.url));
const quality = join(here, 'quality-run');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const execute = promisify(execFile);
const sourceExpectations = {
  'protocol.mjs': 'a0cb80d2e1b2857c960de90e1b3f7c9e9354f20f0de2394d9a8071aba76fbcbc',
  'classifier.mjs': 'de7041fc747fc0a78876e167cf4415f65f2e369414c0bbca51bfe0caf0929c79',
  'runner.mjs': 'e227a816c9ab3390567a8a640ff642d4650f2df6683c29d0f3ff3d3980eb3703',
  'root-entry.mjs': '9229d229555d80c3508314d94e3cca9d09dd05f8f635557a3dd141478d8ba2b4',
};
const mode = process.argv[2];
assert.ok(['--ROOT-freeze-only', '--ROOT-execute-frozen-194'].includes(mode));
for (const [relative, expected] of Object.entries(sourceExpectations)) {
  assert.equal(sha(await readFile(join(quality, relative))), expected, 'Root-released source changed: ' + relative);
}
const sourceReleasePath = join(quality, 'source-release-revision-2.json');
const sourceReleaseBytes = await readFile(sourceReleasePath);
assert.equal(sha(sourceReleaseBytes), '53533082ec1f142b9ed6a56b905b7153da0bc59a3477917c5304e138b53d3f3d');
const sourceRelease = JSON.parse(sourceReleaseBytes);
assert.equal(sourceRelease.ownership_released, true); assert.equal(sourceRelease.release_revision, 2);
for (const identity of sourceRelease.sources) {
  const bytes = await readFile(identity.path);
  assert.equal(sha(bytes), identity.sha256); assert.equal(bytes.length, identity.bytes);
}
const runner = await import(pathToFileURL(join(quality, 'runner.mjs')).href);
const originalFrozenPlanBytes = await readFile(join(root,
  '.build/improvement-experiments/gemma4-label-prototype/research-quality/native-proof-root-1/run-plan.json'));
assert.equal(sha(originalFrozenPlanBytes), '367ec2f18be9514bb6319211be3f68cdfe5d076c8bd01811851de25680395a2b');
const authorize = stage => ({ kind: 'explicit_root_candidate_stage_authorization', actor: 'ROOT', stage, explicit: true,
  research_profile: 'gemma4-direct-label-raw-q4-runtime-candidate-1', logical_id: 'v2-earned-half-grid-alpha-research-1',
  prototype_source_sha256: 'c0919f79087e4bf3ce4f6332956b79d7b9e9bb415a250288fb47bcecd7ca64b8', production_role_approval: false });
const planPath = join(here, 'validation-root-frozen-plan-1.json');
const clearancePath = join(here, 'validation-root-clearance-1.json');
if (mode === '--ROOT-freeze-only') {
  const prerequisiteList = {
    vocabulary: ['vocab-proof-root-1/proof.json', '13ed29ed2f54a3a4c82b886cd5723461bf97d468059ce07b3cc24b5d95c95dc3'],
    vocabulary_plan: ['vocab-proof-root-1/run-plan.json', 'c031b53f3f07ce14d0a24de1dfecce676d89149a207a3695bb4a47b267306c49'],
    jinja: ['vocab-proof-root-1/independent-render.json', '691782e2d60144b7d30785cced54a3637fe0165fc195d8d97a711a0acfe57dde'],
    vocabulary_receipt: ['vocab-proof-root-1/root-final-receipt-1.json', '5e2beda950b56a6cd87d1a0917631e06a67fa64946642cc0d1101ef29d9b4c5a'],
    metal: ['metal-proof-root-1/proof.json', '15adf710d50cdb470423005a5881718d0fc2fddfe33e2a86d641812f6c00a2c5'],
    metal_plan: ['metal-proof-root-1/run-plan.json', '36db25381d154a7b5b4d46195c050129a4835428cf158b61a03e2a7b0fb4476e'],
    metal_audit: ['metal-proof-root-1/root-result-audit-1.json', '68b855f95e543a69302a8f2d21ae28198102c184b2222587d5d5cc828f328b1a'],
    metal_receipt: ['metal-proof-root-1/root-final-receipt-1.json', '9a0165c4bad086238cd84c9d52d38633db7cc526823bc16113e6418e8b4eecbc'],
  };
  const prerequisiteRefs = {};
  for (const [key, [relative, expected]] of Object.entries(prerequisiteList)) {
    const path = join(here, relative), bytes = await readFile(path); assert.equal(sha(bytes), expected);
    prerequisiteRefs[key] = { path, bytes: bytes.length, sha256: expected };
  }
  const plan = await runner.freezeRootPlan({ rootAuthorization: authorize('freeze_new_candidate_validation_194'),
    originalFrozenPlanBytes, prerequisiteRefs });
  plan.root_entry_identity = { path: fileURLToPath(import.meta.url), sha256: sha(await readFile(fileURLToPath(import.meta.url))) };
  plan.source_release_identity = { path: sourceReleasePath, sha256: sha(sourceReleaseBytes), bytes: sourceReleaseBytes.length };
  const bytes = jsonBytes(plan); await writeFile(planPath, bytes, { flag: 'wx', mode: 0o400 });
  console.log(JSON.stringify({ frozen_plan_sha256: sha(bytes), records: plan.expected_records, groups: plan.expected_groups,
    native_execution: false, quality_or_gain_proven: false, explicit_ROOT_execution_review_still_required: true }));
} else {
  const planBytes = await readFile(planPath), clearanceBytes = await readFile(clearancePath);
  const clearance = JSON.parse(clearanceBytes), plan = JSON.parse(planBytes);
  assert.equal(plan.root_entry_identity.path, fileURLToPath(import.meta.url));
  assert.equal(plan.root_entry_identity.sha256, sha(await readFile(fileURLToPath(import.meta.url))));
  assert.equal(plan.source_release_identity.sha256, sha(sourceReleaseBytes));
  assert.equal(clearance.run_plan_sha256, sha(planBytes));
  assert.equal(plan.expected_records, 194); assert.equal(plan.expected_groups, 83);
  assert.equal(clearance.stage_cleared, true);
  const inventory = await execute('/bin/ps', ['-axo', 'pid,ppid,rss,comm'], { timeout: 10000, maxBuffer: 1048576 });
  assert.deepEqual(inventory.stdout.split('\n').filter(line => /llama-server|gemma4-label-prototype/.test(line)), []);
  const observeRootPidGone = async pid => {
    assert.ok(Number.isSafeInteger(pid) && pid > 0);
    const result = await execute('/bin/ps', ['-p', String(pid), '-o', 'pid=,ppid=,comm='], { timeout: 5000, maxBuffer: 1048576 })
      .catch(error => { assert.equal(error.code, 1); assert.equal(error.stdout.trim(), ''); return { stdout: '' }; });
    return { actor: 'ROOT', pid, gone: result.stdout.trim() === '', observed_at: new Date().toISOString(),
      method: 'ROOT /bin/ps -p owned PID -o pid=,ppid=,comm= after exit and stdio closure' };
  };
  const controller = new AbortController();
  console.log(JSON.stringify({ ROOT_owner_pid: process.pid, expected_native_comm: join(here, 'gemma4-label-prototype'),
    run_plan_sha256: sha(planBytes), actual_validation_native_stage_starting: true }));
  const stage = await runner.runRootCandidate194({ rootAuthorization: authorize('execute_new_candidate_validation_194'),
    planBytes, clearanceBytes, originalFrozenPlanBytes, proofDirectory: join(quality, 'native-proof-root-1'),
    signal: controller.signal, observeRootPidGone });
  console.log(JSON.stringify({ passed: stage.passed, native_contracts_passed: stage.native_contracts_passed,
    root_pid_gone_passed: stage.root_pid_gone_passed, quality_gates_passed: stage.quality_gates_passed,
    error: stage.error ?? null, native_pid: stage.native_pid ?? null, records: 194, quality_or_gain_proven: false }));
  if (!stage.passed) process.exitCode = 1;
}
