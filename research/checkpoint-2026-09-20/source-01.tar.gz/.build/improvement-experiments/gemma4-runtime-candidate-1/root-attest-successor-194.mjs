import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { compileHalfGrid, responseHalfGrid } from '../fractional-score-hypothesis/candidate-2/grid.mjs';
import { gradeValidationResearch, SUCCESSOR_PHYSICAL_IDENTITY } from '../gemma4-successor-quality/grade.mjs';
import { validateQualityRecords } from '../../../dist/evaluation.js';

assert.equal(process.argv[2], '--ROOT-stage-closed');
const root = '/Users/bsonntag/code/simple-jev-ts'; assert.equal(resolve(process.cwd()), root);
const here = dirname(fileURLToPath(import.meta.url)), output = join(here, 'quality-run/native-proof-root-1');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const comparable = value => JSON.parse(JSON.stringify(value));
const execute = promisify(execFile);
const planBytes = await readFile(join(output, 'run-plan.json'));
assert.equal(sha(planBytes), '4cd1a1b6e3732f214e17d411a30fb57bec3447fabdd2f9a80f148e4ee42959a9');
const plan = JSON.parse(planBytes);
const stageBytes = await readFile(join(output, 'stage-proof.json')), stage = JSON.parse(stageBytes);
const reportBytes = await readFile(join(output, 'quality-report.json')), report = JSON.parse(reportBytes);
const envelopeBytes = await readFile(join(output, 'run-envelopes.json')), envelopes = JSON.parse(envelopeBytes);
const rpcBytes = await readFile(join(output, 'native-rpc.jsonl'));
assert.equal(rpcBytes.at(-1), 10, 'Final RPC audit must have no incomplete record');
const rpcRows = rpcBytes.toString().trim().split('\n').map(row => JSON.parse(row));
const evidenceBytes = await readFile(join(output, 'question-evidence.jsonl'));
assert.equal(evidenceBytes.at(-1), 10, 'Final question audit must have no incomplete record');
const evidence = evidenceBytes.toString().trim().split('\n').map(row => JSON.parse(row));
assert.equal(stage.run_plan_sha256, sha(planBytes));
assert.equal(stage.native_pid, 65800); assert.equal(stage.actual_native_process_launches, 1);
assert.equal(stage.actual_mode, 'quantized_metal'); assert.equal(stage.aborted, false);
assert.ok(!stage.error && !stage.audit_failure);
assert.equal(stage.owned_native_exit_event_observed, true);
for (const state of [stage.owned_native, stage.owned_native_close_result]) {
  assert.equal(state.pid, stage.native_pid); assert.equal(state.state, 'closed'); assert.equal(state.exitCode, 0);
  assert.equal(state.signal, null); assert.equal(state.exitedObserved, true); assert.equal(state.closedObserved, true);
  assert.equal(state.pendingRequests, 0); assert.equal(state.failureCode, null); assert.equal(state.stderrTruncated, false);
  assert.ok(!state.cleanupError); assert.deepEqual(state.signalsSent, []);
}
const absent = await execute('/bin/ps', ['-p', String(stage.native_pid), '-o', 'pid=,ppid=,comm=']).catch(error => {
  assert.equal(error.code, 1); assert.equal(error.stdout.trim(), ''); return { stdout: '' };
}); assert.equal(absent.stdout.trim(), '');
const identities = [...plan.sources.host, plan.sources.prototype, plan.sources.compile, ...plan.sources.libraries,
  ...Object.values(plan.artifacts), ...Object.values(plan.prerequisites), plan.root_entry_identity, plan.source_release_identity];
for (const identity of identities) {
  const info = await stat(identity.path); assert.ok(info.isFile());
  if (identity.bytes !== undefined) assert.equal(info.size, identity.bytes);
  const digest = createHash('sha256'); for await (const chunk of createReadStream(identity.path)) digest.update(chunk);
  assert.equal(digest.digest('hex'), identity.sha256, 'Current frozen file changed: ' + identity.path);
}
const originalFrozenPlanBytes = await readFile(join(root,
  '.build/improvement-experiments/gemma4-label-prototype/research-quality/native-proof-root-1/run-plan.json'));
assert.equal(sha(originalFrozenPlanBytes), plan.original_frozen_plan_sha256);
const inputSets = [], records = [];
for (const input of plan.inputs) {
  const bytes = await readFile(input.path);
  assert.equal(sha(bytes), input.sha256); assert.equal(bytes.length, input.bytes);
  const values = validateQualityRecords(bytes.toString().trim().split('\n').map(row => JSON.parse(row)));
  assert.equal(values.length, input.records); assert.equal(new Set(values.map(row => row.group_id)).size, input.groups);
  assert.deepEqual(values.map(row => row.id), input.expected_ids);
  inputSets.push({ name: input.name, bytes }); records.push(...values);
}
assert.equal(records.length, 194); assert.equal(new Set(records.map(row => row.group_id)).size, 83);
assert.equal(envelopes.length, 194); assert.deepEqual(envelopes, evidence);
assert.deepEqual(records.map(row => row.id), plan.execution_order);
assert.equal(rpcRows.length, 389); assert.equal(new Set(rpcRows.map(row => row.id)).size, 389);
assert.deepEqual(rpcRows[0].request, plan.rpc_init);
assert.ok(!rpcRows[0].error && !rpcRows[0].response.error);
const provenance = rpcRows[0].response.result.provenance;
assert.deepEqual(provenance, stage.init_provenance);
assert.deepEqual(provenance.physical_profile, plan.physical_profile);
assert.equal(provenance.physical_profile_sha256, plan.physical_profile_sha256);
assert.equal(sha(JSON.stringify(provenance.physical_profile)), plan.physical_profile_sha256);
assert.equal(provenance.prototype_source_sha256, plan.sources.prototype.sha256);
assert.equal(provenance.actual_mode, 'quantized_metal'); assert.equal(provenance.device, 'metal');
for (const key of ['weights_loaded', 'context_created', 'explicit_backend_init']) assert.equal(provenance[key], true);
assert.equal(provenance.vocab_only, false); assert.equal(provenance.flash_attn_effective, null);
const requestBytes = await readFile(join(output, 'render-requests.json'));
const originalRenderBytes = await readFile(join(output, 'independent-render.json'));
assert.equal(sha(originalRenderBytes), stage.independent_all_194_render_sha256);
const originalRender = JSON.parse(originalRenderBytes);
assert.equal(originalRender.requests_sha256, sha(requestBytes)); assert.equal(originalRender.rows.length, 194);
const freshRenderPath = join(output, 'root-independent-render-1.json');
await execute(plan.host_runtime.renderer.python_executable,
  [join(root, '.build/improvement-experiments/gemma4-label-prototype/research-quality/render-reference.py'),
    '--requests', join(output, 'render-requests.json'), '--output', freshRenderPath,
    '--template', plan.artifacts.template.path, '--expected-sha256', plan.artifacts.template.sha256],
  { timeout: 60000, maxBuffer: 1048576 });
const freshRenderBytes = await readFile(freshRenderPath), freshRender = JSON.parse(freshRenderBytes);
assert.deepEqual(freshRender.rows, originalRender.rows);
assert.deepEqual(freshRender.runtime_identity, plan.host_runtime.renderer);
const wire = branch => ({ branch_id: branch.branch_id, messages: branch.messages,
  answer_prefix: branch.answer_prefix, output_labels: branch.output_labels });
let tokens = 0, submittedDecodeCalls = 0;
for (let index = 0; index < 194; index++) {
  const record = records[index], envelope = envelopes[index]; assert.equal(envelope.record_id, record.id); assert.ok(!envelope.error);
  const logical = compileHalfGrid(record.request), branch = logical.questions[0];
  assert.equal(logical.questions.length, 1); assert.equal(logical.logical_prompt_sha256, envelope.logical_prompt_sha256);
  const prefix = 'r' + String(index).padStart(3, '0') + 'q0';
  const compilation = rpcRows[index * 2 + 1], evaluation = rpcRows[index * 2 + 2];
  assert.deepEqual(compilation.request, { v: 1, id: prefix + '-compile', op: 'compile', branches: [wire(branch)] });
  assert.ok(!compilation.error && !compilation.response.error);
  assert.equal(compilation.response.id, compilation.request.id); assert.equal(compilation.response.result.length, 1);
  const compiled = compilation.response.result[0];
  assert.equal(compiled.branch_id, branch.branch_id); assert.equal(compiled.rendered, freshRender.rows[index].rendered);
  assert.equal(freshRender.rows[index].record_id, record.id); assert.equal(freshRender.rows[index].branch_id, branch.branch_id);
  assert.equal(compiled.tokens[0], 2); assert.equal(compiled.tokens.filter(token => token === 2).length, 1);
  assert.ok(compiled.tokens.length <= 2048);
  assert.deepEqual(Object.keys(compiled.token_ids).sort(), [...branch.output_labels].sort());
  assert.equal(new Set(Object.values(compiled.token_ids)).size, branch.output_labels.length);
  assert.deepEqual(compiled.provenance, provenance);
  assert.equal(compiled.rendered_generation_boundary, '<|turn>model\n<|channel>thought\n<channel|>' + branch.answer_prefix);
  assert.deepEqual(evaluation.request, { v: 1, id: prefix + '-evaluate', op: 'evaluate', full: true,
    branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] });
  assert.ok(!evaluation.error && !evaluation.response.error);
  assert.equal(evaluation.response.id, evaluation.request.id);
  const raw = evaluation.response.result, metrics = raw.metrics; assert.equal(raw.input_tokens, compiled.tokens.length);
  assert.equal(metrics.backend, 'llama.cpp'); assert.equal(metrics.prefill_strategy, 'full');
  for (const key of ['prefix_tokens', 'branch_output_tokens', 'padded_suffix_tokens']) assert.equal(metrics[key], 0);
  for (const key of ['computed_prompt_tokens', 'branch_prompt_tokens', 'logical_prefill_tokens']) assert.equal(metrics[key], compiled.tokens.length);
  assert.equal(metrics.engine_forwards, Math.ceil(compiled.tokens.length / 2048));
  assert.equal(metrics.scored_positions, 1); assert.deepEqual(metrics.suffix_batch_sizes, [1]);
  assert.deepEqual(metrics.provenance, provenance);
  const responsePlan = { ...logical, request: { ...logical.request, options: { ...logical.request.options, raw_logits: true } } };
  const typed = responseHalfGrid(responsePlan, raw.logits, compiled.tokens.length, true, {
    metrics: { per_question_native: [metrics] }, metadata: { backend: 'llama.cpp', actual_mode: 'quantized_metal',
      research_profile: plan.research_profile, physical_profile_sha256: plan.physical_profile_sha256, logical_id: plan.logical_id,
      prototype_source_sha256: plan.sources.prototype.sha256, binary_sha256: plan.artifacts.binary.sha256,
      raw_model_sha256: plan.artifacts.model.sha256, raw_model_bytes: plan.artifacts.model.bytes,
      raw_template_sha256: plan.artifacts.template.sha256, parser_template_sha256: '6a1015c47ccfcfa67c3b772385bccee357a4d37c3cda37bd202e9047f391ab82',
      independent_render_match: true, actual_question_count: 1, production_role_approval: false,
      probability_semantics: 'uncalibrated softmax over selected labels only',
      usage_accounting: 'actual full-prefill prompt tokens; zero generated output tokens' } });
  assert.deepEqual(comparable(typed), envelope.response);
  assert.equal(typed.usage.output_tokens, 0); assert.equal(typed.usage.input_tokens, compiled.tokens.length);
  assert.equal(envelope.questions.length, 1); assert.deepEqual(envelope.questions[0].raw_selected_label_logits, raw.logits[branch.branch_id]);
  assert.deepEqual(envelope.questions[0].native_metrics, metrics);
  assert.equal(envelope.questions[0].compiled_token_sha256, sha(JSON.stringify(compiled.tokens)));
  tokens += compiled.tokens.length; submittedDecodeCalls += metrics.engine_forwards;
}
const independentlyGraded = gradeValidationResearch({ originalFrozenPlanBytes, inputSets, successorPhysicalIdentity: SUCCESSOR_PHYSICAL_IDENTITY,
  successorManifest: plan.successor_manifest, runEnvelopes: envelopes, createdAt: report.created_at });
assert.deepEqual(comparable(independentlyGraded), report);
const stderrBytes = await readFile(join(output, 'native-stderr.log'));
assert.equal(stderrBytes.toString(), stage.owned_native.stderr);
assert.match(stderrBytes.toString(), /offloaded 61\/61 layers to GPU/);
assert.equal(stage.quality_gates_passed, report.gates.passed);
assert.equal(stage.passed, stage.native_contracts_passed && stage.root_pid_gone_passed && report.gates.passed && stage.exact_194_envelope_order);
const receipt = { kind: 'ROOT_successor_full_validation_194_result_attestation', observed_at: new Date().toISOString(),
  run_plan_sha256: sha(planBytes), stage_sha256: sha(stageBytes), quality_report_sha256: sha(reportBytes),
  run_envelopes_sha256: sha(envelopeBytes), native_RPC_sha256: sha(rpcBytes), question_evidence_sha256: sha(evidenceBytes),
  root_independent_render_sha256: sha(freshRenderBytes), native_stderr_sha256: sha(stderrBytes),
  original_frozen_plan_sha256: sha(originalFrozenPlanBytes), original_targets_units_and_gates_unchanged: true,
  all_194_actual_responses_reconstructed_from_raw_native_logits: true, all_194_original_Jinja_BOS_and_one_token_guards_verified: true,
  independent_original_grade_and_all_per_set_and_diagnosis_and_score_gates_reproduced: true,
  current_full_source_artifact_model_template_and_prerequisite_hashes_verified: true,
  logical_id: plan.logical_id, research_profile: plan.research_profile, physical_profile_sha256: plan.physical_profile_sha256,
  physical_profile_file_sha256: plan.prospective_profile_file.sha256, prototype_source_sha256: plan.sources.prototype.sha256,
  binary_sha256: plan.artifacts.binary.sha256, raw_model_sha256: plan.artifacts.model.sha256, raw_model_bytes: plan.artifacts.model.bytes,
  records: 194, independent_groups: 83, actual_inference_errors: 0, actual_computed_prompt_tokens: tokens,
  submitted_llama_decode_calls: submittedDecodeCalls, submitted_calls_are_not_Metal_internal_ubatches_or_kernels: true,
  generated_output_tokens: 0, owned_native_processes: 1, owned_pid: stage.native_pid, owned_pid_absent: true,
  independent_exit_and_stdio_close_observed: true, actual_offloaded_layers: 61,
  actual_flash_attention_observed_enabled: /resolve_fused_ops: Flash Attention enabled/.test(stderrBytes.toString()),
  emitted_flash_effective_field_remains_null: true, native_full_validation_contracts_attested: true,
  all_quality_gates_passed: report.gates.passed, validation_quality_qualified: report.gates.passed,
  honest_completed_negative: !report.gates.passed, developer_score_correctness: report.prospective_developer_score_correctness,
  quality_gates: report.gates, quality_summary: report.summary, diagnosis: report.diagnosis,
  no_new_TEST_inference: true, production_role_approved: false, benchmark_gain_established: false,
  full_developer_workflow_gain_established: false, approval_effect: 'none' };
const receiptBytes = Buffer.from(JSON.stringify(receipt, null, 2) + '\n');
await writeFile(join(output, 'root-final-receipt-1.json'), receiptBytes, { flag: 'wx', mode: 0o400 });
console.log(JSON.stringify({ integrity_attested: true, validation_quality_qualified: receipt.validation_quality_qualified,
  developer_score_correctness: receipt.developer_score_correctness, tokens, submittedDecodeCalls, generated_output_tokens: 0,
  owned_pid_absent: true, receipt_sha256: sha(receiptBytes), benchmark_gain_established: false }));
