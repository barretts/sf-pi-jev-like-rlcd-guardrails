import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

assert.equal(process.argv[2], '--ROOT-server-capability-closed', 'No implicit native or model execution');
const ROOT = '/Users/bsonntag/code/simple-jev-ts';
assert.equal(process.cwd(), ROOT);
const PARENT = join(ROOT, '.build/improvement-experiments/gemma4-runtime-candidate-1');
const HERE = join(ROOT, '.build/improvement-experiments/gemma4-successor-direct-proposal');
const CAP = join(HERE, 'capability-native-proof-root-1');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const bytesOf = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const execute = promisify(execFile);
const serialized = value => JSON.parse(JSON.stringify(value));
async function identity(path) {
  const info = await stat(path); const hash = createHash('sha256');
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return { path, bytes: info.size, sha256: hash.digest('hex') };
}
const planBytes = await readFile(join(PARENT, 'performance-successor-root-frozen-plan-1.json'));
const plan = JSON.parse(planBytes);
for (const ref of [...plan.source_files, plan.source_release, plan.root_entry_identity, plan.root_source_review]) assert.deepEqual(await identity(ref.path), ref);
const runnerRef = plan.source_files.find(ref => ref.path === join(HERE, 'runner.mjs')); assert.ok(runnerRef);
const runner = await import(pathToFileURL(runnerRef.path).href + '?sha256=' + runnerRef.sha256);
await runner.verifyFrozen(plan);
const proofBytes = await readFile(join(CAP, 'proof.json')), proof = JSON.parse(proofBytes);
assert.equal(proof.kind, 'ROOT_successor_original_server_three_synthetic_capability_proof'); assert.equal(proof.actor, 'ROOT');
assert.equal(proof.passed, true); assert.equal(proof.run_plan_sha256, sha(planBytes)); assert.equal(proof.source_release_sha256, plan.source_release.sha256);
assert.equal(proof.error, null); assert.equal(proof.audit_failure, null); assert.equal(proof.native_server_processes_started, 1);
const cleanup = proof.cleanup; assert.ok(Number.isSafeInteger(cleanup.pid) && cleanup.pid > 0);
assert.equal(cleanup.exited, true); assert.equal(cleanup.stdio_closed, true); assert.equal(cleanup.exit_and_stdio_close_observed, true);
assert.equal(cleanup.intentional_owned_shutdown, true); assert.equal(cleanup.error, null);
assert.ok(cleanup.exit_code === 0 || cleanup.exit_signal === 'SIGTERM');
assert.equal(cleanup.owned_cleanup_complete, true); assert.equal(cleanup.root_pid_gone.actor, 'ROOT');
assert.equal(cleanup.root_pid_gone.pid, cleanup.pid); assert.equal(cleanup.root_pid_gone.absent, true);
let psAbsent = false;
try { await execute('/bin/ps', ['-p', String(cleanup.pid), '-o', 'pid=,ppid=,comm='], { timeout: 5000, encoding: 'utf8' }); }
catch (error) { psAbsent = error.code === 1 && !(error.stdout ?? '').trim() && !(error.stderr ?? '').trim(); }
assert.equal(psAbsent, true, 'Closed owned server is still present');
const logs = cleanup.logs;
assert.equal(typeof logs, 'string'); assert.equal(cleanup.native_observations.truncated, false);
assert.equal(cleanup.native_observations.logs_sha256, sha(logs));
const offloads = [...logs.matchAll(/offloaded (\d+)\/(\d+) layers to GPU/g)];
assert.equal(offloads.length, 1); assert.equal(Number(offloads[0][1]), 61); assert.equal(Number(offloads[0][2]), 61);
assert.match(logs, /(?:MTL\d|Metal)/);
for (const [name, expected] of [['n_ctx', 4096], ['n_batch', 2048], ['n_ubatch', 512]]) {
  const values = [...logs.matchAll(new RegExp('\\b' + name + '\\s*=\\s*(\\d+)', 'g'))].map(match => Number(match[1]));
  assert.ok(values.length > 0 && values.every(value => value === expected));
}
assert.match(logs, /type_k\s*=\s*['"]?f16/); assert.match(logs, /type_v\s*=\s*['"]?f16/);
const unified = [...logs.matchAll(/kv_unified\s*=\s*(0|1|false|true)\b/g)].map(match => match[1]);
assert.ok(unified.length > 0 && unified.every(value => value === '0' || value === 'false'));
for (const observation of cleanup.listener_observations) {
  assert.equal(observation.actor, 'ROOT'); assert.equal(observation.pid, cleanup.pid); assert.equal(observation.port, 8089);
  if (observation.only_owned_listener) assert.ok(observation.observed_listeners.length > 0 && observation.observed_listeners.every(row => row.pid === cleanup.pid && row.address === '127.0.0.1:8089'));
}
const qualityRunnerPath = join(PARENT, 'quality-run/runner.mjs');
const qualityRunnerRef = plan.source_files.find(ref => ref.path === qualityRunnerPath); assert.ok(qualityRunnerRef);
const qualityRunner = await import(pathToFileURL(qualityRunnerPath).href + '?sha256=' + qualityRunnerRef.sha256);
assert.deepEqual(await qualityRunner.rendererRuntimeIdentity(), plan.host_runtime.renderer);
const rfdtRef = plan.source_files.find(ref => ref.path === join(ROOT, 'dist/rfdt.js')); assert.ok(rfdtRef);
const decisionRef = plan.source_files.find(ref => ref.path === join(ROOT, 'scripts/developer-decision-eval.mjs')); assert.ok(decisionRef);
const rfdt = await import(pathToFileURL(rfdtRef.path).href + '?sha256=' + rfdtRef.sha256);
const decision = await import(pathToFileURL(decisionRef.path).href + '?sha256=' + decisionRef.sha256);
assert.deepEqual(proof.rows.map(row => row.record_id), ['synthetic-choice', 'synthetic-earned-half', 'synthetic-unknown']);
const golds = [{ answer: 'red' }, { answer: 0.5 }, { answer: null }];
const requests = [], checks = []; let promptTokens = 0, generatedTokens = 0;
for (const [index, row] of proof.rows.entries()) {
  assert.equal(row.teacher_tries.length, 1); assert.equal(row.transport.length, 1);
  const teacher = row.teacher_tries[0]; assert.deepEqual(teacher, row.transport[0]);
  assert.equal(teacher.ordinal, 0); assert.equal(teacher.dispatched, true); assert.ok(!teacher.error);
  assert.equal(teacher.ok, true); assert.equal(teacher.status, 200); assert.equal(teacher.erase_ACK_proved, true);
  assert.ok(Number.isSafeInteger(teacher.cache_reset.n_erased) && teacher.cache_reset.n_erased >= 0);
  const original = teacher.original_teacher_request, actual = teacher.actual_request;
  assert.deepEqual(actual, { ...original, chat_template_kwargs: { enable_thinking: false }, id_slot: 0, cache_prompt: false });
  assert.equal(original.model, plan.generative.model_id); assert.equal(original.temperature, 0); assert.equal(original.max_tokens, 2048);
  assert.equal(original.response_format.type, 'json_schema'); assert.equal(original.response_format.json_schema.name, 'rfdt_missing_targets');
  assert.equal(original.response_format.json_schema.strict, true); assert.equal(original.messages.length, 2);
  assert.equal(original.messages[0].role, 'system'); assert.equal(original.messages[1].role, 'user');
  const source = JSON.parse(original.messages[1].content); assert.deepEqual(Object.keys(source).sort(), ['context', 'questions']);
  assert.equal(source.questions.length, 1); const question = source.questions[0]; assert.equal(question.id, 'q');
  assert.equal(question.type, ['choice', 'score', 'noul'][index]);
  const wireText = teacher.response_text; assert.equal(teacher.response_sha256, sha(wireText));
  const reply = JSON.parse(wireText); assert.equal(reply.model, plan.generative.model_id);
  assert.ok(!reply.choices[0].message.reasoning_content && !reply.choices[0].message.reasoning);
  assert.ok(!reply.choices[0].message.tool_calls && !reply.choices[0].message.function_call);
  assert.equal(typeof reply.choices[0].message.content, 'string');
  let text = reply.choices[0].message.content.trim(); if (text.startsWith('```')) text = text.replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, '');
  const targets = JSON.parse(text); assert.deepEqual(Object.keys(targets), ['q']); rfdt.normalizeRfdtTarget(question, targets.q);
  assert.deepEqual(targets, row.actual_generated_targets);
  const grade = decision.scoreAnswer(question, golds[index], targets.q, 'generative');
  assert.equal(grade.correct_judgment, true); assert.deepEqual(grade, row.host_grade);
  assert.deepEqual(reply.usage, teacher.provider_usage); assert.deepEqual(reply.timings, teacher.server_timings);
  const counters = reply.timings; assert.equal(counters.cache_n, 0);
  assert.ok(Number.isSafeInteger(counters.prompt_n) && counters.prompt_n > 0); assert.ok(Number.isSafeInteger(counters.predicted_n) && counters.predicted_n >= 0);
  assert.equal(counters.prompt_n, reply.usage.prompt_tokens); assert.equal(counters.predicted_n, reply.usage.completion_tokens);
  const automatic = teacher.server_automatic_BOS_tokenization.tokens, explicit = teacher.original_explicit_BOS_tokenization.tokens;
  assert.deepEqual(automatic, explicit); assert.equal(automatic[0].id, 2); assert.equal(automatic[0].piece, '<bos>');
  assert.equal(automatic.filter(token => token.id === 2).length, 1); assert.equal(automatic.length, counters.prompt_n);
  const serverText = teacher.apply_template_response.prompt;
  assert.equal(typeof serverText, 'string'); assert.ok(!serverText.includes('<bos>'));
  const id = 'independent-capability-' + index;
  requests.push({ record_id: id, branch: { branch_id: id, messages: original.messages, answer_prefix: '' } });
  checks.push({ rendered: '<bos>' + serverText, original_Jinja_row: teacher.independent_Jinja_row });
  promptTokens += counters.prompt_n; generatedTokens += counters.predicted_n;
}
const requestPath = join(CAP, 'root-independent-render-requests-1.json'), renderPath = join(CAP, 'root-independent-render-1.json');
const requestBytes = bytesOf(requests); await writeFile(requestPath, requestBytes, { flag: 'wx', mode: 0o600 });
const renderer = join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality/render-reference.py');
await execute(plan.host_runtime.renderer.python_executable, [renderer, '--requests', requestPath, '--output', renderPath,
  '--template', plan.artifacts.template.path, '--expected-sha256', plan.artifacts.template.sha256], { cwd: ROOT, timeout: 60000, maxBuffer: 1048576, encoding: 'utf8' });
const renderBytes = await readFile(renderPath), rendered = JSON.parse(renderBytes);
assert.equal(rendered.requests_sha256, sha(requestBytes)); assert.deepEqual(rendered.runtime_identity, plan.host_runtime.renderer);
assert.equal(rendered.rows.length, 3); assert.equal(rendered.original_raw_template_sha256, plan.artifacts.template.sha256);
for (const [index, check] of checks.entries()) {
  const row = rendered.rows[index]; assert.equal(row.rendered, check.rendered); assert.equal(row.rendered_sha256, sha(row.rendered));
  assert.equal(row.rendered, check.original_Jinja_row.rendered); assert.equal(row.logical_messages_sha256, sha(JSON.stringify(requests[index].branch.messages)));
  assert.equal(row.rendered.split('<bos>').length, 2); assert.equal(row.answer_prefix, '');
}
const receipt = { kind: 'ROOT_successor_original_server_three_synthetic_capability_result_attestation', actor: 'ROOT', observed_at: new Date().toISOString(),
  run_plan_sha256: sha(planBytes), source_release_sha256: plan.source_release.sha256, proof_sha256: sha(proofBytes),
  root_independent_render_sha256: sha(renderBytes), current_full_source_model_binary_static_and_dynamic_library_template_runtime_and_qualification_hashes_verified: true,
  all_three_actual_generated_outputs_and_original_Jinja_BOS_tokenization_verified: true,
  actual_computed_prompt_tokens: promptTokens, actual_generated_output_tokens: generatedTokens, actual_POSTs: 3,
  actual_offloaded_layers: 61, actual_KV_f16_observed: true, actual_n_ctx: 4096, actual_n_batch: 2048, actual_n_ubatch: 512,
  owned_pid: cleanup.pid, owned_pid_absent: true, owned_exit_and_stdio_close_verified: true,
  passed: true, no_TEST_inference: true, production_role_approval: false, benchmark_gain_established: false, full_developer_workflow_gain_established: false };
const receiptBytes = bytesOf(receipt); await writeFile(join(CAP, 'root-final-receipt-1.json'), receiptBytes, { flag: 'wx', mode: 0o400 });
process.stdout.write(JSON.stringify({ integrity_attested: true, capability_passed: true, actual_POSTs: 3, promptTokens, generatedTokens,
  owned_pid_absent: true, root_receipt_sha256: sha(receiptBytes), benchmark_gain_established: false }) + '\n');
