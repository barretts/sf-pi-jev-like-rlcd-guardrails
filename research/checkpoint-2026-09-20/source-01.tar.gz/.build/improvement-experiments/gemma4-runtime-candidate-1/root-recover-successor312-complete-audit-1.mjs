import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, access } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

// ROOT post-closure host recovery only. The failed runner and every frozen
// source remain unchanged. This never executes an adapter or a native/model.
assert.equal(process.argv[2], '--ROOT-exit1-all-owned-processes-closed');
const ROOT = '/Users/bsonntag/code/simple-jev-ts'; assert.equal(resolve(process.cwd()), ROOT);
const SELF = fileURLToPath(import.meta.url), PARENT = dirname(SELF);
const HERE = join(ROOT, '.build/improvement-experiments/gemma4-successor-direct-proposal');
const PROOF = join(HERE, 'performance-native-proof-root-2');
const SHA = 'a11f733687053e9a09f4d2bfd39f7c6a38c396439158721c5b15016aa5e238f5';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const descriptor = (path, bytes) => ({ path: resolve(path), bytes: bytes.length, sha256: sha(bytes) });
const execute = promisify(execFile);
async function currentSource(ref) {
  const bytes = await readFile(ref.path); assert.equal(bytes.length, ref.bytes); assert.equal(sha(bytes), ref.sha256); return bytes;
}
async function absent(pid) {
  try { await execute('/bin/ps', ['-p', String(pid), '-o', 'pid=,ppid=,comm='], { timeout: 5000, encoding: 'utf8' });
    assert.fail('Owned PID is still present: ' + pid);
  } catch (error) {
    assert.equal(error.code, 1); assert.equal((error.stdout ?? '').trim(), ''); assert.equal((error.stderr ?? '').trim(), '');
    return { actor: 'ROOT', pid, absent: true, observed_at: new Date().toISOString(), method: 'post-unified-exit1 independent ps PID/PPID/comm, exit1 empty output' };
  }
}
const planPath = join(PARENT, 'performance-successor-root-frozen-plan-2.json');
const planBytes = await readFile(planPath); assert.equal(sha(planBytes), SHA); const plan = JSON.parse(planBytes);
await currentSource(plan.root_entry_identity); await currentSource(plan.root_source_review); await currentSource(plan.source_release);
for (const ref of plan.source_files) await currentSource(ref);
for (const path of ['result.json', 'root-driver-close-proof-1.json']) {
  try { await access(join(PROOF, path)); assert.fail('Original final artifact unexpectedly exists: ' + path); }
  catch (error) { assert.equal(error.code, 'ENOENT'); }
}
const auditPath = join(PROOF, 'audit.jsonl'), auditBytes = await readFile(auditPath);
assert.equal(auditBytes.at(-1), 10, 'Complete trailing audit JSONL');
const rows = auditBytes.toString('utf8').split('\n').filter(Boolean).map(JSON.parse);
const attempts = rows.filter(row => row.kind === 'attempt').map(({ kind, ...row }) => row);
const blocks = rows.filter(row => row.kind === 'block').map(({ kind, ...row }) => row);
assert.equal(attempts.length, 312); assert.equal(blocks.length, 4);
assert.ok(attempts.every(row => row.attempted === true && row.status === 'completed' && !row.error && Number.isFinite(row.elapsed_ms)));
assert.ok(blocks.every(row => row.run_invocations === 78 && row.errors.length === 0 && !row.audit_error && !row.stage_abort_error && !row.cleanup_error &&
  row.cleanup.owned_cleanup_complete === true && row.cleanup.exit_and_stdio_close_observed === true && row.cleanup.root_pid_gone.absent === true));
const ownedPids = blocks.map(row => row.cleanup.pid); assert.equal(new Set(ownedPids).size, 4);
const pidGone = []; for (const pid of [96071, ...ownedPids]) pidGone.push(await absent(pid));
const ps = await execute('/bin/ps', ['-axo', 'pid=,ppid=,comm='], { timeout: 5000, encoding: 'utf8', maxBuffer: 1048576 });
assert.deepEqual(ps.stdout.split('\n').filter(row => /llama-server|gemma4-label-prototype|simple-jev-ts\/\.build\/rfdt-venv\/bin\/python/.test(row)), []);
const get = path => { const ref = plan.source_files.find(row => row.path === path); assert.ok(ref); return ref; };
const decisionRef = get(join(ROOT, 'scripts/developer-decision-eval.mjs'));
const protocolRef = get(join(HERE, 'protocol.mjs'));
const { pairedSummary } = await import(pathToFileURL(decisionRef.path).href + '?sha256=' + decisionRef.sha256);
const { exactAttemptCoverage, comparisonGates } = await import(pathToFileURL(protocolRef.path).href + '?sha256=' + protocolRef.sha256);
const inputBytes = await readFile(plan.dataset.path); assert.equal(sha(inputBytes), plan.dataset.input_sha256);
const records = inputBytes.toString('utf8').trim().split(/\r?\n/).map(JSON.parse);
assert.equal(exactAttemptCoverage(attempts, plan.schedule, records), true);
const summary = pairedSummary(attempts), replicate_summaries = [1, 2].map(rep => pairedSummary(attempts.filter(row => row.repetition === rep)));
// Same completed-inference facts as the immutable harness, reconstructed from
// all audit rows and reviewed default clock/launch sources. Independent final
// attestation is still required; these are not a new runner success claim.
const evidence = { proof_kind: 'root_attested_actual_native', exact_frozen_artifacts: true, host_only_gold_scoring: true,
  explicit_disabled_thinking_both_arms: true, cache_clear_proved_both_arms: attempts.every(row => row.cache_clear_proved === true),
  actual_native_work_complete: attempts.every(row => row.accounting_complete === true), full_developer_coverage: true,
  single_active_native_gpu_execution: true, exit_and_stdio_close_observed: true, root_pid_gone_proved: true,
  audit_complete: true, stage_not_aborted: true, monotonic_clock_unmodified: true, all_frozen_attempts_executed: true,
  fresh194_qualification_bound: true, root_pid_gone_all_started_blocks: true, no_audit_failure: true };
const result = { kind: 'gemma4_successor_direct_performance_result', status: 'ROOT_recovered_complete_inference_after_runner_final_serialization_failure',
  attempts, blocks, summary, replicate_summaries, evidence, gates: comparisonGates(summary, replicate_summaries, attempts, evidence),
  initialization_scope: plan.conditions.cold_scope ?? 'separate_actual_owned_process_initialization', cleanup_error: null, audit_error: null, stage_abort_error: null, clock_error: null,
  coverage_error: null, summary_error: null, gate_error: null, audit_failure: null, improvement_claim_permitted: false,
  plan_sha256: SHA, source_release_sha256: plan.source_release.sha256, qualification_refs: plan.qualification_refs,
  direct_logical_id: plan.direct.logical_id, direct_physical_identity: plan.direct, generated_profile: plan.generative,
  actual_quality_or_gain_proven_by_source: false, held_out_TEST_read: false, production_role_approval: false,
  pending_independent_ROOT_final_attestation: true,
  recovery: { actor: 'ROOT', raw_audit: descriptor(auditPath, auditBytes), original_runner_unified_exit_code: 1,
    original_failure: 'AssertionError: JSON structural limit at final aggregate result serialization; immutable protocol finiteJson one-million-node bound',
    original_result_and_driver_close_proof_absent: true, native_inference_replayed: false,
    method: 'exact312 attempt and4 block snapshots from complete audit; original exported pairedSummary and comparisonGates; raw answers/timers/RPC/teacher data unchanged',
    recovery_does_not_make_original_runner_successful: true } };
const resultPath = join(PROOF, 'root-reconstructed-result-1.json'), resultBytes = jsonBytes(result);
await writeFile(resultPath, resultBytes, { flag: 'wx', mode: 0o600 });
const proof = { kind: 'ROOT_successor_matched312_exit1_complete_audit_recovery', actor: 'ROOT', observed_at: new Date().toISOString(),
  run_plan_sha256: SHA, root_entry_identity: plan.root_entry_identity, original_unified_session: 75643,
  original_unified_exit_code: 1, original_completion_chunk: '843576', original_failed_result_writer_preserved: true,
  original_result_and_driver_close_proof_absent: true, original_failure: result.recovery.original_failure,
  actual_attempts: 312, actual_attempt_errors: 0, benchmark_result: descriptor(resultPath, resultBytes),
  raw_audit: descriptor(auditPath, auditBytes), owned_PID_absence: pidGone,
  host_recovery_source: descriptor(SELF, await readFile(SELF)), native_inference_replayed: false,
  independent_final_attestation_pending: true, benchmark_gain_established: false, held_out_TEST_read: false, production_role_approval: false };
const proofPath = join(PROOF, 'root-exit1-complete-audit-recovery-1.json'); await writeFile(proofPath, jsonBytes(proof), { flag: 'wx', mode: 0o600 });
process.stdout.write(JSON.stringify({ recovered_result: descriptor(resultPath, resultBytes), recovery_proof: descriptor(proofPath, jsonBytes(proof)),
  actual_attempts: 312, actual_errors: 0, original_runner_exit_code: 1, original_runner_successful: false, native_inference_replayed: false,
  independent_final_attestation_pending: true }) + '\n');
