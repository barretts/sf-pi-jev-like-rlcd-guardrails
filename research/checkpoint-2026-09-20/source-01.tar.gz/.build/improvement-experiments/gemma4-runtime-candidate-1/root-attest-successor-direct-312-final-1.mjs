import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, stat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

// ROOT alone executes this CPU-only, post-closure observer. No model starts,
// tokenization, process signals, training, network or credential operations.
assert.equal(process.argv[2], '--ROOT-unified-session-closed');
const ROOT = '/Users/bsonntag/code/simple-jev-ts';
assert.equal(resolve(process.cwd()), ROOT);
const SELF = fileURLToPath(import.meta.url), PARENT = dirname(SELF);
const HERE = join(ROOT, '.build/improvement-experiments/gemma4-successor-direct-proposal');
const PROOF = join(HERE, 'performance-native-proof-root-2');
const AUDITOR = join(ROOT, '.build/improvement-experiments/gemma4-successor-direct-result-audit');
const PLAN_SHA = 'a11f733687053e9a09f4d2bfd39f7c6a38c396439158721c5b15016aa5e238f5';
const REVIEW_SHA = '86a723ebfa1bc5c39ff2c1abb4591276eb9289e7dac05553d777bc0a0314c36c';
const FREEZE_SHA = '96f73187cd3e980ad5885301543dd168bbcf37aac6f447fa68037004a3f54695';
const BENCHMARK_OWNER_PID = 96071;
const execute = promisify(execFile);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const writeJson = (path, value) => writeFile(path, jsonBytes(value), { flag: 'wx', mode: 0o600 });
async function identity(path) {
  const details = await stat(path); assert.ok(details.isFile());
  const digest = createHash('sha256');
  for await (const part of createReadStream(path)) digest.update(part);
  return { path: resolve(path), bytes: details.size, sha256: digest.digest('hex') };
}
async function verified(ref) {
  assert.equal(resolve(ref.path), ref.path, 'Canonical absolute artifact path');
  const bytes = await readFile(ref.path);
  assert.equal(bytes.length, ref.bytes, 'Consumed snapshot size: ' + ref.path);
  assert.equal(sha(bytes), ref.sha256, 'Consumed snapshot SHA: ' + ref.path);
  return bytes;
}
const snapshotRef = (path, bytes) => ({ path: resolve(path), bytes: bytes.length, sha256: sha(bytes) });
async function ps(file, args) {
  try {
    const result = await execute(file, args, { timeout: 5000, maxBuffer: 1048576, encoding: 'utf8' });
    assert.equal(result.stderr.trim(), ''); return { code: 0, stdout: result.stdout };
  } catch (error) {
    if (error.code === 1 && !(error.stderr ?? '').trim()) return { code: 1, stdout: error.stdout ?? '' };
    throw error;
  }
}
async function gone(pid) {
  assert.ok(Number.isSafeInteger(pid) && pid > 0);
  const observed = await ps('/bin/ps', ['-p', String(pid), '-o', 'pid=,ppid=,comm=']);
  assert.equal(observed.code, 1, 'Owned or ROOT driver PID must already be absent: ' + pid);
  assert.equal(observed.stdout.trim(), '');
  return { actor: 'ROOT', pid, absent: true, observed_at: new Date().toISOString(),
    method: 'independent post-unified-close ps PID/PPID/comm only; exit1 and empty output' };
}
async function laneIdle() {
  const observed = await ps('/bin/ps', ['-axo', 'pid=,ppid=,comm=']); assert.equal(observed.code, 0);
  const matches = observed.stdout.split('\n').filter(row => /llama-server|gemma4-label-prototype|simple-jev-ts\/\.build\/rfdt-venv\/bin\/python/.test(row));
  assert.deepEqual(matches, [], 'Known model/native/training lane must be idle');
  return { actor: 'ROOT', observed_at: new Date().toISOString(), matching_known_workers: [], method: 'ps PID/PPID/comm; no process args, environment or authentication' };
}

const planBytes = await readFile(join(PARENT, 'performance-successor-root-frozen-plan-2.json'));
assert.equal(sha(planBytes), PLAN_SHA); const plan = JSON.parse(planBytes);
assert.deepEqual(await identity(plan.root_entry_identity.path), plan.root_entry_identity);
await verified(plan.root_source_review);
const driverBytes = await readFile(join(PROOF, 'root-driver-close-proof-1.json'));
const driver = JSON.parse(driverBytes);
assert.equal(driver.kind, 'ROOT_successor_matched312_driver_closed'); assert.equal(driver.actor, 'ROOT');
assert.equal(driver.run_plan_sha256, PLAN_SHA); assert.equal(driver.actual_attempts, 312);
assert.deepEqual(driver.root_entry_identity, plan.root_entry_identity);
assert.equal(driver.benchmark_result.path, join(PROOF, 'result.json'), 'Driver result belongs to this exact owned proof');
const resultBytes = await verified(driver.benchmark_result), result = JSON.parse(resultBytes);
assert.equal(result.plan_sha256, PLAN_SHA); assert.equal(result.attempts.length, 312);
const driverPidGone = await gone(BENCHMARK_OWNER_PID);
const owned_process_observations = [];
for (const block of result.blocks) {
  if (!block.cleanup?.pid) continue;
  const receipt = block.cleanup;
  // These terminal facts were observed by the reviewed ROOT driver and owned
  // RPC/server lifecycle handlers; absence is checked again here independently.
  assert.equal(receipt.exit_and_stdio_close_observed, true);
  if (block.method === 'native') {
    for (const terminal of [receipt.close_result, receipt.snapshot]) {
      assert.equal(terminal.exitedObserved, true); assert.equal(terminal.closedObserved, true);
    }
  } else { assert.equal(receipt.exited, true); assert.equal(receipt.stdio_closed, true); }
  const logs = block.method === 'native' ? receipt.snapshot.stderr : receipt.logs;
  assert.equal(typeof logs, 'string');
  owned_process_observations.push({ pid: receipt.pid, block_index: block.block_index,
    exit_observed: true, stdio_close_observed: true, logs_sha256: sha(logs), pid_gone: await gone(receipt.pid) });
}
const laneObservation = await laneIdle();
const auditBytes = await readFile(join(PROOF, 'audit.jsonl'));
assert.ok(auditBytes.length === 0 || auditBytes.at(-1) === 10, 'Closed audit must end in a complete JSONL line');
const inputBytes = await readFile(plan.dataset.path);
assert.equal(inputBytes.length, plan.dataset.input_bytes); assert.equal(sha(inputBytes), plan.dataset.input_sha256);
const benchmarkReleaseBytes = await verified(plan.source_release);

const reviewPath = join(PARENT, 'root-successor-312-attester-source-review-1.json');
const reviewBytes = await readFile(reviewPath); assert.equal(sha(reviewBytes), REVIEW_SHA);
const review = JSON.parse(reviewBytes); assert.equal(review.actor, 'ROOT'); assert.equal(review.source_review_passed, true);
assert.equal(review.independent_focused_CPU_checks_passed, true);
const freezeBytes = await verified(review.source_release); assert.equal(sha(freezeBytes), FREEZE_SHA);
const freeze = JSON.parse(freezeBytes); assert.deepEqual(review.source_identities, freeze.source_identities);
const attester_source_identities = [];
for (const ref of freeze.source_identities) { const current = await identity(ref.path); assert.deepEqual(current, ref); attester_source_identities.push(current); }
const moduleRef = attester_source_identities.find(ref => ref.path === join(AUDITOR, 'attest.mjs')); assert.ok(moduleRef);
const auditor = await import(pathToFileURL(moduleRef.path).href + '?sha256=' + moduleRef.sha256);

const pythonDetails = await stat(plan.host_runtime.renderer.python_executable);
const expected = [...plan.source_files, plan.native_source, ...Object.values(plan.artifacts), ...plan.libraries,
  ...plan.native_runtime_libraries, { path: plan.generative.binary, bytes: plan.generative.binary_bytes, sha256: plan.generative.binary_sha256 },
  plan.model_registry, plan.host_runtime.node_executable, { path: plan.host_runtime.renderer.python_executable,
    bytes: pythonDetails.size, sha256: plan.host_runtime.renderer.python_executable_sha256 }];
const unique = [...new Map(expected.map(ref => [ref.path, ref])).values()].sort((a, b) => a.path.localeCompare(b.path));
const current_verified_identities = [];
for (const ref of unique) { const current = await identity(ref.path); assert.deepEqual(current, ref, ref.path); current_verified_identities.push(current); }
assert.equal(process.version, plan.host_runtime.node_version);
assert.deepEqual(await identity(process.execPath), plan.host_runtime.node_executable);
// The observer never overrides performance.now; the frozen runner passes the
// default bound host monotonic clock with no injected timing adapter.
assert.equal(typeof performance.now(), 'number');

const fresh194Bytes = {};
const qualificationDir = dirname(plan.qualification_refs.report.path);
for (const [key, ref] of Object.entries(auditor.QUALIFICATION_REFS)) {
  const path = plan.qualification_refs[key]?.path ?? join(qualificationDir, ref.name);
  fresh194Bytes[key] = await verified({ path, bytes: ref.bytes, sha256: ref.sha256 });
}
const qualificationReceipt = JSON.parse(fresh194Bytes.receipt);
assert.equal(qualificationReceipt.kind, 'ROOT_successor_full_validation_194_result_attestation');
assert.equal(qualificationReceipt.all_194_actual_responses_reconstructed_from_raw_native_logits, true);
assert.equal(qualificationReceipt.current_full_source_artifact_model_template_and_prerequisite_hashes_verified, true);
assert.equal(qualificationReceipt.all_quality_gates_passed, true);
assert.equal(qualificationReceipt.honest_completed_negative, false);

const { validateQualityRecords } = await import(pathToFileURL(join(ROOT, 'dist/evaluation.js')).href);
const records = validateQualityRecords(inputBytes.toString('utf8').trim().split(/\r?\n/).map(line => JSON.parse(line)));
const hookRef = attester_source_identities.find(ref => ref.path === join(AUDITOR, 'render-reference.py')); assert.ok(hookRef);
const bundles = [], render_executions = [];
for (const [name, requests] of [['alpha', auditor.buildAlphaRenderRequests(records)], ['teacher', auditor.buildTeacherRenderRequests(result.attempts)]]) {
  const requestsBytes = auditor.jsonBytes(requests);
  const requestsPath = join(PROOF, 'root-independent-' + name + '-render-requests-1.json');
  const referencePath = join(PROOF, 'root-independent-' + name + '-render-reference-1.json');
  await writeFile(requestsPath, requestsBytes, { flag: 'wx', mode: 0o600 });
  // Full hook/runtime/template byte checks occur before each fresh CPU execution.
  await verified(hookRef); await verified(plan.artifacts.template);
  const pythonRef = current_verified_identities.find(ref => ref.path === plan.host_runtime.renderer.python_executable); await verified(pythonRef);
  const execution = await execute(plan.host_runtime.renderer.python_executable, [hookRef.path, '--closed-stage', '--requests', requestsPath,
    '--output', referencePath, '--template', plan.artifacts.template.path, '--expected-sha256', plan.artifacts.template.sha256],
  { cwd: ROOT, timeout: 60000, maxBuffer: 1048576, encoding: 'utf8' });
  assert.equal(execution.stderr.trim(), ''); assert.equal(execution.stdout.trim(), '');
  const referenceBytes = await readFile(referencePath), reference = JSON.parse(referenceBytes);
  assert.deepEqual(reference.runtime_identity, plan.host_runtime.renderer);
  const artifact_binding = { requests_sha256: sha(requestsBytes), requests_bytes: requestsBytes.length,
    reference_sha256: sha(referenceBytes), reference_bytes: referenceBytes.length };
  bundles.push({ requestsBytes, referenceBytes });
  render_executions.push({ actor: 'ROOT', artifact_binding, executed_after_stage_closed: true, exit_code: 0,
    native_or_model_execution: false, runtime_identity: reference.runtime_identity, hook_source_sha256: hookRef.sha256 });
}
const artifact_hashes = { plan_sha256: sha(planBytes), result_sha256: sha(resultBytes), audit_sha256: sha(auditBytes), input_sha256: sha(inputBytes),
  alpha_render: render_executions[0].artifact_binding, teacher_render: render_executions[1].artifact_binding,
  benchmark_source_release_sha256: sha(benchmarkReleaseBytes), fresh194: Object.fromEntries(Object.entries(fresh194Bytes).map(([key, value]) => [key, sha(value)])) };
const rootFacts = { kind: 'ROOT_successor_closed312_independent_facts', actor: 'ROOT', proof_kind: 'ROOT_observed_actual_native_closed_stage',
  observed_at: new Date().toISOString(), artifact_hashes, current_verified_identities, python_executable_bytes: pythonDetails.size,
  fresh194_refs: plan.qualification_refs, attester_source_identities, render_executions, owned_process_observations,
  all_started_owned_processes_closed_and_gone: true, current_full_artifact_hashes_verified: true,
  current_runtime_and_attester_source_hashes_verified: true, fresh194_all_five_artifacts_verified: true,
  fresh194_native_contract_and_quality_receipt_independently_verified: true, single_active_native_gpu_execution_verified: true,
  monotonic_clock_unmodified_verified: true, host_only_gold_and_no_TEST_verified: true, no_other_native_model_calls_verified: true,
  held_out_TEST_read: false, production_role_approval: false, driver_PID_absence: driverPidGone, lane_observation: laneObservation,
  observer_scope: 'ROOT controlled native launches only; source-frozen sequential lane; all recorded owned exits/stdio and PID absence; no whole-OS historical process attestation' };
await writeJson(join(PROOF, 'root-independent-facts-1.json'), rootFacts);
const report = auditor.attestClosedSuccessor312({ stageClosed: true, inputBytes, planBytes, resultBytes, auditBytes,
  benchmarkReleaseBytes, fresh194Bytes, alphaRender: bundles[0], teacherRender: bundles[1], rootFacts });
const consumedResult = snapshotRef(join(PROOF, 'result.json'), resultBytes);
const consumedAudit = snapshotRef(join(PROOF, 'audit.jsonl'), auditBytes);
const consumedDriver = snapshotRef(join(PROOF, 'root-driver-close-proof-1.json'), driverBytes);
const consumedReview = snapshotRef(reviewPath, reviewBytes);
assert.deepEqual(consumedResult, driver.benchmark_result);
assert.equal(consumedResult.sha256, report.identities.result_sha256);
assert.equal(consumedAudit.sha256, report.identities.audit_sha256);
// A final receipt names the exact snapshots consumed by the pure attester,
// while also checking they have not changed at their on-disk paths.
for (const ref of [consumedResult, consumedAudit, consumedDriver, consumedReview]) await verified(ref);
const reportPath = join(PROOF, 'root-independent-result-attestation-1.json'); await writeJson(reportPath, report);
const final = { kind: 'ROOT_successor_matched312_final_result_attestation', actor: 'ROOT', observed_at: new Date().toISOString(),
  run_plan_sha256: sha(planBytes), raw_result: consumedResult, raw_audit: consumedAudit,
  Root_driver_closed: consumedDriver, Root_source_review: consumedReview,
  Root_observer_source: await identity(SELF), Root_independent_facts: await identity(join(PROOF, 'root-independent-facts-1.json')),
  independent_attestation: await identity(reportPath), exact_coverage: report.exact_coverage, integrity_attested: report.integrity_attested,
  actual_accounting_and_cleanup_complete: report.actual_token_cache_and_cleanup_contracts_complete,
  gates: report.gates, honest_negative_attested: report.honest_negative_attested,
  qualified_microcomparison_gain: report.root_qualified_improvement_claim_permitted,
  true_DX_gain_established: false, full_developer_workflow_gain_established: false, production_role_approval: false,
  held_out_TEST_read: false, approval_effect: 'none', owned_PID_absence: owned_process_observations.map(row => row.pid_gone) };
const finalPath = join(PROOF, 'root-final-receipt-1.json'); await writeJson(finalPath, final);
process.stdout.write(JSON.stringify({ final_receipt: await identity(finalPath), actual_attempts: report.exact_coverage.attempts,
  integrity_attested: report.integrity_attested, actual_accounting_and_cleanup_complete: report.actual_token_cache_and_cleanup_contracts_complete,
  qualified_microcomparison_gain: report.root_qualified_improvement_claim_permitted, gates: report.gates,
  actual_errors: report.execution_failures, true_DX_gain_established: false }) + '\n');
