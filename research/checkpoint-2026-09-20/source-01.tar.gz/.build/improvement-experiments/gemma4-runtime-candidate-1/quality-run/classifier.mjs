import { EXPECTED, LIMITS, insist, sha, wireBranch, validateProvenance } from './protocol.mjs';

export function verifyCompiledBranch(branch, compiled, reference, plan) {
  insist(compiled?.branch_id === branch.branch_id, 'Compiled branch ID mismatch');
  insist(Array.isArray(compiled.tokens) && compiled.tokens.length >= 1 && compiled.tokens.length <= 2048 && compiled.tokens.every(token => Number.isSafeInteger(token) && token >= 0), 'Invalid actual compiled tokens');
  insist(compiled.tokens[0] === 2 && compiled.tokens.filter(token => token === 2).length === 1, 'Actual tokens require exactly one initial BOS');
  insist(compiled.token_ids && Object.keys(compiled.token_ids).length === branch.output_labels.length && branch.output_labels.every(label => Number.isSafeInteger(compiled.token_ids[label]) && compiled.token_ids[label] >= 0) && new Set(Object.values(compiled.token_ids)).size === branch.output_labels.length, 'Selected label token identity mismatch');
  insist(typeof compiled.rendered === 'string' && reference?.rendered === compiled.rendered && reference.rendered_sha256 === sha(compiled.rendered), 'Independent new logical original-template render parity failed');
  insist(compiled.rendered_generation_boundary === EXPECTED.generationBoundary + branch.answer_prefix && compiled.rendered.endsWith(compiled.rendered_generation_boundary), 'Disabled-thinking/JSON boundary mismatch');
  validateProvenance(compiled.provenance, plan);
  return { actual_prompt_tokens: compiled.tokens.length, rendered_sha256: sha(compiled.rendered),
    independent_render_match: true, final_two_user_messages_merged: reference.final_two_user_messages_merged,
    selected_label_token_ids: compiled.token_ids, labels: branch.output_labels, answer_labels: branch.answer_labels,
    BOS_exactly_once: true, generation_tokens: 0,
    one_token_label_guard: 'native compile accepts only one distinct added token preserving the entire rendered prefix',
    full_clear_contract: 'frozen native source clears all sequence memory with data=true before and after each evaluate; this is a source-bound contract, not allocator telemetry' };
}
export function verifyNativeMetrics(metrics, compiled, plan) {
  insist(metrics?.backend === 'llama.cpp' && metrics.prefill_strategy === 'full' && metrics.prefix_tokens === 0 && metrics.branch_output_tokens === 0 && metrics.scored_positions === 1 && JSON.stringify(metrics.suffix_batch_sizes) === '[1]', 'Native one-question full-prefill/zero-generation contract failed');
  insist(metrics.computed_prompt_tokens === compiled.tokens.length && metrics.branch_prompt_tokens === compiled.tokens.length && metrics.logical_prefill_tokens === compiled.tokens.length && metrics.padded_suffix_tokens === 0 && metrics.engine_forwards === Math.ceil(compiled.tokens.length / LIMITS.decode_chunk), 'Actual token/2048-decode-forward accounting mismatch');
  validateProvenance(metrics.provenance, plan);
}

/** Injected transport/compiler permit CPU mocks. This class never spawns or loads a model. */
export class SuccessorResearchClassifier {
  constructor({ rpc, plan, compiler, orderedRecords, renderReference, evidenceSink, signal }) {
    insist(compiler.LOGICAL_ID === EXPECTED.logicalId, 'Unsupported released compiler');
    this.rpc = rpc; this.plan = plan; this.compiler = compiler; this.records = orderedRecords;
    this.reference = new Map(renderReference.rows.map(row => [row.record_id + ':' + row.branch_id, row]));
    this.evidenceSink = evidenceSink; this.signal = signal; this.cursor = 0; this.terminalError = null;
  }
  async classifyRecord(record, requestSignal) {
    insist(record === this.records[this.cursor++], 'Frozen exact record order changed');
    const logical = this.compiler.compileHalfGrid(record.request);
    insist(logical.template_version === EXPECTED.logicalId && logical.logical_prompt_sha256 === sha(JSON.stringify(logical.questions)) && logical.questions.length === 1, 'New logical plan mismatch');
    const expected = this.plan.inputs.flatMap(set => set.record_manifest).find(entry => entry.record_id === record.id);
    insist(expected?.logical_prompt_sha256 === logical.logical_prompt_sha256, 'Frozen logical prompt changed');
    const envelope = { record_id: record.id, logical_id: EXPECTED.logicalId, logical_prompt_sha256: logical.logical_prompt_sha256,
      research_profile: EXPECTED.profile, physical_profile_sha256: this.plan.physical_profile_sha256,
      raw_model_sha256: this.plan.artifacts.model.sha256, raw_model_bytes: this.plan.artifacts.model.bytes,
      prototype_source_sha256: this.plan.sources.prototype.sha256, binary_sha256: this.plan.artifacts.binary.sha256,
      model: record.request.model, elapsed_ms: 0, questions: [], actual_mode: 'quantized_metal' };
    const started = performance.now();
    try {
      if (this.terminalError) throw new Error(this.terminalError);
      const signals = [this.signal, requestSignal].filter(Boolean);
      const signal = signals.length > 1 ? AbortSignal.any(signals) : signals[0];
      signal?.throwIfAborted();
      const branch = logical.questions[0]; const prefix = 'r' + String(this.cursor - 1).padStart(3, '0') + 'q0';
      const compiledEnvelope = await this.rpc.request({ v: 1, id: prefix + '-compile', op: 'compile', branches: [wireBranch(branch)] }, { signal });
      if (compiledEnvelope.error) throw new Error('Native compile: ' + JSON.stringify(compiledEnvelope.error));
      insist(Array.isArray(compiledEnvelope.result) && compiledEnvelope.result.length === 1, 'Exactly one native compiled branch required');
      const compiled = compiledEnvelope.result[0];
      const parity = verifyCompiledBranch(branch, compiled, this.reference.get(record.id + ':' + branch.branch_id), this.plan);
      signal?.throwIfAborted();
      const evaluatedEnvelope = await this.rpc.request({ v: 1, id: prefix + '-evaluate', op: 'evaluate', full: true,
        branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] }, { signal });
      if (evaluatedEnvelope.error) throw new Error('Native evaluate: ' + JSON.stringify(evaluatedEnvelope.error));
      const evaluated = evaluatedEnvelope.result; verifyNativeMetrics(evaluated?.metrics, compiled, this.plan);
      insist(evaluated.input_tokens === compiled.tokens.length, 'Actual/unique single-question token count mismatch');
      insist(Object.keys(evaluated.logits ?? {}).length === 1 && Object.hasOwn(evaluated.logits, branch.branch_id), 'Selected logit branch mismatch');
      const responsePlan = { ...logical, request: { ...logical.request, options: { ...logical.request.options, raw_logits: true } } };
      envelope.response = this.compiler.responseHalfGrid(responsePlan, evaluated.logits, compiled.tokens.length, true, {
        metrics: { per_question_native: [evaluated.metrics] },
        metadata: { backend: 'llama.cpp', actual_mode: 'quantized_metal', research_profile: EXPECTED.profile,
          physical_profile_sha256: this.plan.physical_profile_sha256, logical_id: EXPECTED.logicalId,
          prototype_source_sha256: this.plan.sources.prototype.sha256, binary_sha256: this.plan.artifacts.binary.sha256,
          raw_model_sha256: this.plan.artifacts.model.sha256, raw_model_bytes: this.plan.artifacts.model.bytes,
          raw_template_sha256: EXPECTED.templateSha256, parser_template_sha256: EXPECTED.parserTemplateSha256,
          independent_render_match: true, actual_question_count: 1, production_role_approval: false,
          probability_semantics: 'uncalibrated softmax over selected labels only',
          usage_accounting: 'actual full-prefill prompt tokens; zero generated output tokens' } });
      insist(envelope.response.metadata.template_version === EXPECTED.logicalId && envelope.response.metadata.logical_prompt_sha256 === logical.logical_prompt_sha256, 'Adapter must retain new inference metadata');
      envelope.questions.push({ question_id: branch.question_id, branch_id: branch.branch_id, ...parity,
        raw_selected_label_logits: evaluated.logits[branch.branch_id], native_metrics: evaluated.metrics,
        compiled_token_sha256: sha(JSON.stringify(compiled.tokens)) });
    } catch (error) {
      envelope.error = error instanceof Error ? error.message : String(error);
      envelope.error_code = error?.code ?? error?.name ?? null;
      const state = this.rpc.snapshot();
      if (this.signal?.aborted || requestSignal?.aborted || state.failure || state.failureCode || state.state !== 'running' || state.exitCode != null)
        this.terminalError = 'Owned native transport terminal: ' + envelope.error;
    } finally {
      envelope.elapsed_ms = performance.now() - started;
      await this.evidenceSink(envelope);
    }
    return envelope;
  }
}
