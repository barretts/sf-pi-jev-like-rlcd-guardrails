import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
/** Source-only entry description. No model/binary reads, clearance creation, or native launch. */
export const ROOT_ENTRY_STATUS = Object.freeze({
  kind: 'gemma4_successor_quality_ROOT_entry_pending', inference_pending_ROOT: true,
  stages: ['ROOT reviews new vocabulary/Jinja and three synthetic Metal proofs',
    'ROOT injects exact reviewed original metadata plan bytes and invokes freezeRootPlan',
    'ROOT writes and reviews explicit clearance binding the exact new frozen plan bytes',
    'ROOT invokes runRootCandidate194 with AbortSignal and separate post-cleanup PID observer'],
  native_launch_on_import: false, native_launch_cli: false, production_role_approval: false,
  held_out_TEST_authorized: false, actual_quality_gain: null,
});
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  console.log(JSON.stringify(ROOT_ENTRY_STATUS, null, 2));
  console.error('Native execution is pending explicit ROOT stage clearance. This entry does not execute inference.');
  process.exitCode = 1;
}
