import { createHash } from 'node:crypto';
import { readFile, writeFile, stat, realpath } from 'node:fs/promises';
import { createReadStream } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { validateQualityRecords, scorePrediction, QUALITY_GATES } from '../../../../dist/evaluation.js';
import { preparePrompt } from '../../../../dist/core.js';

export const HERE = dirname(fileURLToPath(import.meta.url));
export const CANDIDATE = dirname(HERE);
export const ROOT = resolve(HERE, '../../../..');
export const ORIGINAL = join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality');
export const GRID = join(ROOT, '.build/improvement-experiments/fractional-score-hypothesis/candidate-2/grid.mjs');
export const GRADER = join(ROOT, '.build/improvement-experiments/gemma4-successor-quality/grade.mjs');
export const BINARY = join(CANDIDATE, 'gemma4-label-prototype');
export const MODEL = join(ROOT, 'models/gemma-4-31B_q4_0-it.gguf');
export const TEMPLATE = join(ROOT, 'models/gemma-4-31B-it.chat_template.jinja');
export const EXPECTED = Object.freeze({
  sourceSha256: 'c0919f79087e4bf3ce4f6332956b79d7b9e9bb415a250288fb47bcecd7ca64b8',
  profileFileSha256: 'd0e4f0aa97661a9fffbbf80a649b6e8b1add435d76366e3f775504d00b5058c7',
  profileFileBytes: 1438,
  emittedProfileSha256: '48dda5a0b1630b607f0e5c691366ced92843ea43f0d5d4aab9bc62cc2a7416fc',
  profile: 'gemma4-direct-label-raw-q4-runtime-candidate-1',
  logicalId: 'v2-earned-half-grid-alpha-research-1',
  gridSha256: '92176c96d6a49a600c281c43578eb55aea20082b0847019bfef64282f7b40872',
  rpcSha256: '8980b01e27b306ebd21f1ad788056f1eb2e5a1a3124f97691ba0e10b16b5f770',
  rendererSha256: 'cd7aa8aa765d5870c7619656bd8009e638f65248107faed2c7fc2c26cf941546',
  originalPlanSha256: '367ec2f18be9514bb6319211be3f68cdfe5d076c8bd01811851de25680395a2b',
  modelSha256: '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b',
  modelBytes: 17651001568,
  templateSha256: 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4',
  templateBytes: 18683,
  parserTemplateSha256: '6a1015c47ccfcfa67c3b772385bccee357a4d37c3cda37bd202e9047f391ab82',
  parserTemplateBytes: 18682,
  generationBoundary: '<|turn>model\n<|channel>thought\n<channel|>',
});
export const INPUTS = Object.freeze([
  { name: 'legacy-validation-60', path: join(ROOT, '.build/improvement-experiments/validation-label-audit/legacy-validation-60.jsonl'), records: 60, groups: 30, bytes: 41930, sha256: 'e9963dd58cb6e31e4e6f49be245145ec992329134df09f1d5f1c9169b3866217' },
  { name: 'developer-validation-78', path: join(ROOT, '.build/improvement-experiments/validation-label-audit/validation-78.jsonl'), records: 78, groups: 39, bytes: 158054, sha256: '4ca805a0eb60be5add66db7c79f673a41141b47b1b309ced228af908ada50ef0' },
  { name: 'diagnosis-validation-56', path: join(ROOT, '.build/improvement-experiments/conditional-supervision-comparison/diagnosis-validation-56.jsonl'), records: 56, groups: 14, bytes: 153580, sha256: 'b2f899fc1b92db198139ca6b16b8a2a44a55a219951bc627351bf93e521faae9' },
]);
export const LIMITS = Object.freeze({
  requestTimeoutMs: 600000, totalTimeoutMs: 21600000, exitTimeoutMs: 10000,
  maxPacketBytes: 262144, maxResponseBytes: 67108864, maxStderrBytes: 16777216,
  maxRequests: 389, max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048,
  decode_chunk: 2048, physical_ubatch: 512, maxRecords: 194, groups: 83,
  nativeProcesses: 1, concurrentRpc: 1, generationTokens: 0, prefillStrategy: 'full',
  auditBytes: 134217728,
});
export const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
export const insist = (condition, message) => { if (!condition) throw new Error(message); };
export const canonical = value => JSON.stringify(sortObject(value));
function sortObject(value) { return Array.isArray(value) ? value.map(sortObject) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(key => [key, sortObject(value[key])])) : value; }
export const wireBranch = branch => ({ branch_id: branch.branch_id, messages: branch.messages, answer_prefix: branch.answer_prefix, output_labels: branch.output_labels });
export function packetBytes(value) {
  const bytes = Buffer.byteLength(JSON.stringify(value)) + 1;
  insist(bytes <= LIMITS.maxPacketBytes, 'Outgoing packet exceeds frozen 256 KiB cap');
  return bytes;
}
export const initRequest = () => ({ v: 1, id: 'init', op: 'init', research_profile: EXPECTED.profile,
  model_file: MODEL, chat_template_file: TEMPLATE, vocab_only: false, device: 'metal',
  max_model_len: LIMITS.max_model_len, max_batch_size: LIMITS.max_batch_size, max_batch_tokens: LIMITS.max_batch_tokens });
export async function fileIdentity(path, { stream = false } = {}) {
  const info = await stat(path); insist(info.isFile(), `Expected regular file: ${path}`);
  const hash = createHash('sha256');
  if (stream) for await (const chunk of createReadStream(path)) hash.update(chunk);
  else hash.update(await readFile(path));
  return { path: resolve(path), bytes: info.size, sha256: hash.digest('hex') };
}
export async function ownedNewPath(path) {
  const absolute = resolve(path); const parent = await realpath(dirname(absolute));
  insist(parent === HERE || parent.startsWith(HERE + '/'), 'Output parent must remain inside candidate quality-run');
  try { await stat(absolute); throw new Error('Output already exists; preserve existing evidence'); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  return absolute;
}
export function diagnosisGrid(records) {
  const counts = { 'state/order1': 0, 'chat/order1': 0, 'state/order2': 0, 'chat/order2': 0 };
  let valid = records.length === 4 && new Set(records.map(record => record.id)).size === 4;
  for (const record of records) {
    const representation = record.request.state != null ? 'state' : record.request.messages != null ? 'chat' : null;
    const suffix = record.id.match(/-order([12])-(state|chat)$/);
    if (!suffix || suffix[2] !== representation) { valid = false; continue; }
    counts[representation + '/order' + suffix[1]]++;
  }
  return { counts, complete: valid && Object.values(counts).every(count => count === 1) };
}
export async function compilerModule() {
  const identity = await fileIdentity(GRID); insist(identity.sha256 === EXPECTED.gridSha256, 'Released candidate-2 grid source changed');
  const module = await import(pathToFileURL(GRID).href + '?sha256=' + identity.sha256);
  insist(module.LOGICAL_ID === EXPECTED.logicalId, 'Logical compiler identity mismatch'); return module;
}
/** CPU-only exact safe VAL bytes; no mixed fixtures and no default dataset path. */
export async function readInputSets(snapshotDirectory = null) {
  if (snapshotDirectory !== null) {
    const actual = await realpath(snapshotDirectory);
    insist(actual.startsWith(HERE + '/'), 'Input snapshots must remain inside candidate quality-run');
  }
  const compiler = await compilerModule();
  const sets = []; const ids = new Set(); const groups = new Set();
  for (const spec of INPUTS) {
    const bytes = await readFile(spec.path);
    insist(bytes.length === spec.bytes && sha(bytes) === spec.sha256, `${spec.name}: exact input bytes/SHA mismatch`);
    const values = bytes.toString('utf8').split(/\r?\n/).filter(line => line.trim()).map(line => JSON.parse(line));
    const records = validateQualityRecords(values);
    insist(records.length === spec.records && records.every(record => record.split === 'validation'), `${spec.name}: only exact validation coverage permitted`);
    const localGroups = new Set(records.map(record => record.group_id));
    insist(localGroups.size === spec.groups, `${spec.name}: exact group coverage required`);
    const manifest = [];
    for (const record of records) {
      insist(!ids.has(record.id), 'Duplicate global record ID: ' + record.id); ids.add(record.id);
      insist(record.request.questions.length === 1, 'Exactly one original question per record required');
      const logical = compiler.compileHalfGrid(record.request);
      insist(logical.template_version === EXPECTED.logicalId && logical.logical_prompt_sha256 === sha(JSON.stringify(logical.questions)), 'Compiled logical identity mismatch');
      insist(logical.questions.length === 1, 'Exactly one compiled branch per record required');
      packetBytes({ v: 1, id: 'preflight', op: 'compile', branches: logical.questions.map(wireBranch) });
      const original = preparePrompt(record.request, 'v2');
      manifest.push({ record_id: record.id, group_id: record.group_id,
        original_v2_prompt_sha256: sha(JSON.stringify(original.questions)),
        logical_id: EXPECTED.logicalId, logical_prompt_sha256: logical.logical_prompt_sha256 });
    }
    for (const group of localGroups) { insist(!groups.has(group), 'Duplicate global group: ' + group); groups.add(group); }
    if (spec.name === 'diagnosis-validation-56') {
      insist(records.every(record => record.request.questions[0].type === 'choice'), 'Diagnosis requires choice questions');
      for (const group of localGroups) insist(diagnosisGrid(records.filter(record => record.group_id === group)).complete, 'Incomplete diagnosis representation grid: ' + group);
    }
    if (snapshotDirectory) {
      const snapshot = join(snapshotDirectory, spec.name + '.jsonl');
      await writeFile(snapshot, bytes, { flag: 'wx', mode: 0o600 });
      insist(sha(await readFile(snapshot)) === spec.sha256, 'Snapshot changed after write');
    }
    sets.push({ ...spec, records, bytesSnapshot: bytes, expected_ids: records.map(record => record.id), record_manifest: manifest });
  }
  insist(ids.size === 194 && groups.size === 83, 'Exactly 194 records and 83 distinct groups required'); return sets;
}
export const inputManifest = sets => sets.map(({ records, bytesSnapshot, ...set }) => ({ ...set, records: records.length }));
export const inputBytesForGrader = sets => sets.map(set => ({ name: set.name, bytes: set.bytesSnapshot }));
/** Derive the ordered native dump independently from the physical_profile source key order. */
export function sourceEmittedProfile(profile, source) {
  const body = source.match(/static json physical_profile\(\) \{([\s\S]*?)\n\}/)?.[1];
  insist(body && body.includes('return {{"id", research_profile}'), 'Unknown native profile source form');
  const keys = ['id', ...[...body.matchAll(/^          \{"([^"]+)",/gm)].map(match => match[1])];
  insist(new Set(keys).size === keys.length && canonical([...keys].sort()) === canonical(Object.keys(profile).sort()), 'Native profile key inventory mismatch');
  const emitted = Object.fromEntries(keys.map(key => [key, profile[key]]));
  for (const key of ['kv_type_k_requested', 'kv_type_v_requested', 'flash_attn_requested']) {
    insist(body.includes('{"' + key + '", {{"name",'), 'Unknown native nested request profile order: ' + key);
    emitted[key] = { name: profile[key].name, enum: profile[key].enum };
  }
  return emitted;
}
export async function candidateProfile() {
  const path = join(CANDIDATE, 'physical-profile.json'); const bytes = await readFile(path);
  const sourceBytes = await readFile(join(CANDIDATE, 'main.cpp'));
  insist(bytes.length === EXPECTED.profileFileBytes && sha(bytes) === EXPECTED.profileFileSha256, 'Candidate prospective profile file identity changed');
  insist(sha(sourceBytes) === EXPECTED.sourceSha256, 'Candidate native source changed');
  const prospective = JSON.parse(bytes); const emitted = sourceEmittedProfile(prospective, sourceBytes.toString('utf8'));
  insist(prospective.id === EXPECTED.profile && prospective.decode_chunk === 2048 && prospective.n_batch_requested === 2048 && prospective.n_ubatch_requested === 512 && prospective.kv_type_k_requested.enum === 1 && prospective.kv_type_v_requested.enum === 1 && prospective.flash_attn_requested.enum === -1, 'Candidate knobs/profile mismatch');
  insist(sha(JSON.stringify(emitted)) === EXPECTED.emittedProfileSha256, 'Source-derived emitted profile differs from ROOT-released new vocabulary observation');
  return { physical_profile: emitted, physical_profile_sha256: sha(JSON.stringify(emitted)),
    prospective_profile_file: { path, bytes: bytes.length, sha256: sha(bytes) },
    physical_profile_runtime_observed: false,
    serialization: 'nlohmann::ordered_json dump order independently derived from frozen physical_profile() source; semantic profile equals sorted prospective file' };
}
export function validateProvenance(provenance, plan, { vocabulary = false } = {}) {
  insist(provenance?.prototype_source_sha256 === EXPECTED.sourceSha256, 'Executed candidate source mismatch');
  insist(provenance.physical_profile?.id === EXPECTED.profile, 'Physical profile ID mismatch');
  insist(provenance.physical_profile_sha256 === plan.physical_profile_sha256 && sha(JSON.stringify(provenance.physical_profile)) === provenance.physical_profile_sha256, 'Physical emitted profile SHA mismatch');
  insist(JSON.stringify(provenance.physical_profile) === JSON.stringify(plan.physical_profile), 'Physical emitted profile contents/order mismatch');
  insist(provenance.model_expected_sha256 === EXPECTED.modelSha256 && provenance.physical_profile.model_expected_size === EXPECTED.modelBytes, 'Raw model expected identity mismatch');
  insist(provenance.template_raw_identity?.sha256 === EXPECTED.templateSha256 && provenance.template_raw_identity.bytes === EXPECTED.templateBytes && provenance.template_raw_identity.verified === true, 'Raw template identity mismatch');
  insist(provenance.template_parser_identity?.sha256 === EXPECTED.parserTemplateSha256 && provenance.template_parser_identity.bytes === EXPECTED.parserTemplateBytes && provenance.template_parser_identity.verified === true, 'Parser template identity mismatch');
  insist(provenance.bos_token_id === 2 && provenance.bos_piece === '<bos>', 'BOS identity mismatch');
  insist(provenance.actual_mode === (vocabulary ? 'cpu_vocabulary_only_no_context' : 'quantized_metal'), 'Actual execution mode mismatch');
  insist(provenance.vocab_only === vocabulary && provenance.weights_loaded === !vocabulary && provenance.context_created === !vocabulary && provenance.explicit_backend_init === !vocabulary && provenance.device === (vocabulary ? 'cpu' : 'metal'), 'Initialization scope/device mismatch');
  insist(provenance.effective_limits?.max_model_len === 2048 && provenance.effective_limits.max_batch_size === 1 && provenance.effective_limits.max_batch_tokens === 2048 && provenance.effective_limits.context_capacity === (vocabulary ? 0 : 4096), 'Effective runtime limits mismatch');
  insist(provenance.flash_attn_effective === null && provenance.flash_attn_effective_status === 'unobserved; AUTO is a request and may resolve enabled or disabled', 'AUTO request must not be represented as observed effective attention');
  if (!vocabulary) insist(provenance.gpu_layers_requested === 99 && provenance.offload_kqv === true && provenance.op_offload === true && provenance.context_train_limit_checked === true, 'Metal offload/train-context request mismatch');
}
export function requireRootAuthorization(authorization, stage) {
  insist(authorization?.kind === 'explicit_root_candidate_stage_authorization' && authorization.actor === 'ROOT' && authorization.stage === stage && authorization.explicit === true,
    'Explicit ROOT authorization for the exact new candidate stage is required');
  insist(authorization.research_profile === EXPECTED.profile && authorization.logical_id === EXPECTED.logicalId && authorization.prototype_source_sha256 === EXPECTED.sourceSha256 && authorization.production_role_approval === false,
    'ROOT authorization candidate/logical/source/scope mismatch');
}
export function cleanOwnedTerminal(value, pid = value?.pid) {
  return Number.isSafeInteger(pid) && pid > 0 && value?.pid === pid && value.state === 'closed' && value.exitedObserved === true && value.closedObserved === true && value.exitCode === 0 && value.signal === null && value.failureCode === null && value.pendingRequests === 0 && !value.cleanupError;
}
export function rootGoneObservationValid(observation, pid) {
  return Number.isSafeInteger(pid) && pid > 0 && observation?.actor === 'ROOT' && observation.pid === pid && observation.gone === true && typeof observation.observed_at === 'string' && Number.isFinite(Date.parse(observation.observed_at)) && typeof observation.method === 'string' && observation.method.length > 0 && !observation.error;
}
export const PREREQUISITE_KEYS = Object.freeze(['vocabulary', 'vocabulary_plan', 'jinja', 'vocabulary_receipt', 'metal', 'metal_plan', 'metal_audit', 'metal_receipt']);
function syntheticPlanContract(proofPlan, plan, compiler, vocabulary) {
  insist(Array.isArray(proofPlan?.identities) && proofPlan.prepared?.length === 3 && proofPlan.init?.research_profile === EXPECTED.profile && proofPlan.init.vocab_only === vocabulary && proofPlan.init.device === (vocabulary ? 'cpu' : 'metal'), 'New synthetic plan/profile/mode required');
  for (const identity of [plan.sources.prototype, plan.artifacts.binary, plan.artifacts.model, plan.artifacts.template]) {
    const frozen = proofPlan.identities.find(entry => entry.path === identity.path);
    insist(frozen?.sha256 === identity.sha256 && frozen.bytes === identity.bytes, 'Synthetic plan must bind exact new source/binary/raw artifacts: ' + identity.path);
  }
  insist(canonical(proofPlan.prepared.map(entry => entry.request.questions[0].type)) === canonical(['choice', 'score', 'noul']), 'New synthetic plan must retain ordered choice/score/unknown NOUL');
  for (const entry of proofPlan.prepared) {
    insist(entry.request.questions.length === 1, 'One synthetic question required');
    const compiled = compiler.compileHalfGrid({ ...entry.request, options: { template_version: 'v2', raw_logits: true } });
    insist(canonical(compiled) === canonical(entry.plan) && compiled.template_version === EXPECTED.logicalId && compiled.logical_prompt_sha256 === sha(JSON.stringify(compiled.questions)), 'Synthetic new logical plan/compiler changed');
  }
}
function compiledSyntheticContract(compiled, branch, plan, vocabulary) {
  insist(compiled?.branch_id === branch.branch_id && Array.isArray(compiled.tokens) && compiled.tokens.length > 0 && compiled.tokens.length <= 2048 && compiled.tokens.every(token => Number.isSafeInteger(token) && token >= 0) && compiled.tokens[0] === 2 && compiled.tokens.filter(token => token === 2).length === 1, 'Synthetic actual branch/tokens/BOS mismatch');
  insist(compiled.token_ids && canonical(Object.keys(compiled.token_ids).sort()) === canonical([...branch.output_labels].sort()) && Object.values(compiled.token_ids).every(token => Number.isSafeInteger(token) && token >= 0) && new Set(Object.values(compiled.token_ids)).size === branch.output_labels.length, 'Synthetic actual distinct one-token selected labels mismatch');
  insist(typeof compiled.rendered === 'string' && compiled.rendered.startsWith('<bos>') && compiled.rendered_generation_boundary === EXPECTED.generationBoundary + branch.answer_prefix && compiled.rendered.endsWith(compiled.rendered_generation_boundary), 'Synthetic render/BOS/boundary mismatch');
  validateProvenance(compiled.provenance, plan, { vocabulary });
}
function sharedProofAttribution(proof, plan) {
  insist(proof.source_sha256 === EXPECTED.sourceSha256 && proof.binary_sha256 === plan.artifacts.binary.sha256 && proof.model_sha256 === EXPECTED.modelSha256 && proof.logical_id === EXPECTED.logicalId && proof.actual_emitted_physical_profile_sha256 === EXPECTED.emittedProfileSha256 && proof.physical_profile_file_sha256 === EXPECTED.profileFileSha256, 'New Metal source/binary/raw model/logical/separate profile attribution mismatch');
}
/** Future ROOT exact eight-reference gate. It never relabels or rewrites the raw host-failed Metal proof. */
export function validateNewPrerequisites(proofs, plan, compiler) {
  const { vocabulary, vocabulary_plan, jinja, vocabulary_receipt, metal: metal_raw, metal_plan, metal_audit, metal_receipt } = proofs;
  syntheticPlanContract(vocabulary_plan, plan, compiler, true);
  insist(vocabulary?.kind === 'ROOT_successor_vocabulary_only_proof' && vocabulary.passed === true && vocabulary.probe_contracts_passed === true && vocabulary.evaluation_rejected === true && vocabulary.run_plan_sha256 === plan.prerequisites.vocabulary_plan.sha256 && vocabulary.quality_or_gain_proven === false && vocabulary.production_role_approval === false, 'New successful zero-weight vocabulary proof required');
  insist(vocabulary.actual_emitted_physical_profile_sha256 === EXPECTED.emittedProfileSha256 && vocabulary.physical_profile_file_sha256 === EXPECTED.profileFileSha256, 'New vocabulary separate-profile identity mismatch');
  insist(cleanOwnedTerminal(vocabulary.owned_native, vocabulary.owned_pid) && cleanOwnedTerminal(vocabulary.cleanup, vocabulary.owned_pid), 'New vocabulary clean exit+close/pending0 required');
  insist(canonical(vocabulary.rpc[0]?.request) === canonical(vocabulary_plan.init) && !vocabulary.rpc[0]?.response?.error, 'New vocabulary actual frozen init mismatch');
  validateProvenance(vocabulary.rpc[0].response.result?.provenance, plan, { vocabulary: true });
  insist(jinja?.kind === 'gemma4_independent_full_validation_jinja_render' && jinja.native_or_model_execution === false && jinja.original_raw_template_sha256 === EXPECTED.templateSha256 && jinja.original_raw_template_bytes === EXPECTED.templateBytes && jinja.python_jinja_version === '3.1.6' && jinja.rows?.length === 3 && vocabulary_plan.independent_render_sha256 === plan.prerequisites.jinja.sha256, 'New independent Jinja three-synthetic render/plan binding required');
  const compilations = vocabulary.rpc.filter(attempt => attempt.request?.op === 'compile');
  insist(compilations.length === 3, 'Exactly three new vocabulary actual compilations required');
  for (let index = 0; index < 3; index++) {
    const prepared = vocabulary_plan.prepared[index]; const branch = prepared.plan.questions[0]; const attempt = compilations[index]; const row = jinja.rows[index];
    insist(canonical(attempt.request) === canonical({ v: 1, id: 'probe-' + index, op: 'compile', branches: [wireBranch(branch)] }) && !attempt.response?.error && attempt.response?.id === attempt.request.id && attempt.response.result?.length === 1, 'Vocabulary ordered actual RPC compile mismatch');
    const compiled = attempt.response.result[0]; compiledSyntheticContract(compiled, branch, plan, true);
    insist(row.record_id === prepared.id && row.branch_id === compiled.branch_id && row.rendered === compiled.rendered && row.rendered_sha256 === sha(compiled.rendered), 'Vocabulary exact synthetic record+branch/Jinja parity mismatch');
  }
  insist(vocabulary.rpc.some(attempt => attempt.request?.op === 'evaluate' && attempt.response?.error?.kind === 'invalid_request'), 'New vocabulary evaluation must actually reject');
  insist(vocabulary_receipt?.kind === 'ROOT_successor_vocabulary_final_receipt' && vocabulary_receipt.logical_id === EXPECTED.logicalId && vocabulary_receipt.proof_sha256 === plan.prerequisites.vocabulary.sha256 && vocabulary_receipt.owned_pid === vocabulary.owned_pid && vocabulary_receipt.owned_pid_absent === true && vocabulary_receipt.exit_and_stdio_close_observed === true && vocabulary_receipt.all_three_actual_original_Jinja_BOS_one_token_contracts_recomputed === true && vocabulary_receipt.weights_and_context_loaded === false && vocabulary_receipt.actual_native_GPU_inference === false && vocabulary_receipt.quality_or_gain_proven === false && vocabulary_receipt.production_role_approved === false && vocabulary_receipt.actual_emitted_physical_profile_sha256 === EXPECTED.emittedProfileSha256 && vocabulary_receipt.physical_profile_file_sha256 === EXPECTED.profileFileSha256, 'New vocabulary ROOT final receipt exact identity required');

  syntheticPlanContract(metal_plan, plan, compiler, false);
  sharedProofAttribution(metal_raw, plan); sharedProofAttribution(metal_audit, plan); sharedProofAttribution(metal_receipt, plan);
  insist(metal_raw.passed === false && metal_raw.run_plan_sha256 === plan.prerequisites.metal_plan.sha256 && metal_raw.error === 'AssertionError [ERR_ASSERTION]: Synthetic answer did not pass original scoring' && metal_raw.synthetic_rows?.length === 2 && metal_raw.rpc?.length === 7 && metal_raw.owned_pid === metal_audit.owned_pid && cleanOwnedTerminal(metal_raw.owned_native, metal_raw.owned_pid) && cleanOwnedTerminal(metal_raw.cleanup, metal_raw.owned_pid), 'Original new Metal host failure/native clean closure must be retained exactly');
  insist(metal_audit.kind === 'ROOT_successor_three_synthetic_metal_result_audit' && metal_audit.original_proof_sha256 === plan.prerequisites.metal.sha256 && metal_audit.run_plan_sha256 === plan.prerequisites.metal_plan.sha256 && metal_audit.original_command_exit_code === 1 && metal_audit.original_probe_passed === false && metal_audit.original_failure_due_to_missing_unknown_correct_field_only === true && metal_audit.raw_proof_and_RPC_rewritten === false && metal_audit.new_native_or_GPU_execution === false && metal_audit.submitted_native_evaluations === 3 && metal_audit.passed === true && metal_audit.probe_contracts_passed === true && metal_audit.all_three_original_scoring_checks_passed === true && metal_audit.synthetic_rows?.length === 3 && metal_audit.compile_evidence_sha256 === plan.sources.compile.sha256 && metal_audit.independent_render_sha256 === metal_plan.independent_render_sha256 && metal_audit.generated_output_tokens === 0, 'New ROOT Metal audit must bind the original execution and specific host unknown-correct-field defect only');
  insist(canonical(metal_raw.rpc[0].request) === canonical(metal_plan.init) && !metal_raw.rpc[0].response?.error, 'New Metal actual frozen init mismatch');
  validateProvenance(metal_raw.rpc[0].response.result?.provenance, plan);
  let inputTokens = 0;
  for (let index = 0; index < 3; index++) {
    const prepared = metal_plan.prepared[index]; const branch = prepared.plan.questions[0]; const compilation = metal_raw.rpc[2 * index + 1]; const evaluation = metal_raw.rpc[2 * index + 2]; const row = metal_audit.synthetic_rows[index];
    const vocabularyPrepared = vocabulary_plan.prepared[index]; const frozenJinjaRow = jinja.rows[index];
    insist(prepared.id === vocabularyPrepared.id && canonical(prepared.plan.questions) === canonical(vocabularyPrepared.plan.questions) && prepared.plan.logical_prompt_sha256 === vocabularyPrepared.plan.logical_prompt_sha256 && frozenJinjaRow.record_id === prepared.id && frozenJinjaRow.branch_id === branch.branch_id, 'Metal synthetic record/logical branches must equal the separately frozen vocabulary/Jinja branches');
    insist(canonical(compilation.request) === canonical({ v: 1, id: 'probe-' + index, op: 'compile', branches: [wireBranch(branch)] }) && !compilation.response?.error && compilation.response?.id === compilation.request.id && compilation.response.result?.length === 1, 'Metal ordered actual compile RPC mismatch');
    const compiled = compilation.response.result[0]; compiledSyntheticContract(compiled, branch, plan, false);
    insist(compiled.rendered === frozenJinjaRow.rendered && sha(compiled.rendered) === frozenJinjaRow.rendered_sha256, 'Metal actual compiled render must exactly match the frozen independent Jinja row for its identical logical branch');
    insist(canonical(evaluation.request) === canonical({ v: 1, id: 'evaluate-' + index, op: 'evaluate', full: true, branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] }) && !evaluation.response?.error && evaluation.response?.id === evaluation.request.id, 'Metal actual one-question full evaluation RPC mismatch');
    const raw = evaluation.response.result; const metrics = raw?.metrics;
    insist(raw.input_tokens === compiled.tokens.length && metrics.backend === 'llama.cpp' && metrics.prefill_strategy === 'full' && metrics.prefix_tokens === 0 && metrics.branch_output_tokens === 0 && metrics.padded_suffix_tokens === 0 && metrics.scored_positions === 1 && canonical(metrics.suffix_batch_sizes) === '[1]' && metrics.computed_prompt_tokens === compiled.tokens.length && metrics.branch_prompt_tokens === compiled.tokens.length && metrics.logical_prefill_tokens === compiled.tokens.length && metrics.engine_forwards === Math.ceil(compiled.tokens.length / 2048), 'Metal actual native token/forward/full-prefill contract mismatch');
    validateProvenance(metrics.provenance, plan);
    const typed = compiler.responseHalfGrid(prepared.plan, raw.logits, compiled.tokens.length, true, { metrics,
      metadata: { actual_mode: 'quantized_metal', physical_profile_sha256: EXPECTED.emittedProfileSha256,
        prototype_source_sha256: EXPECTED.sourceSha256, binary_sha256: plan.artifacts.binary.sha256,
        raw_model_sha256: EXPECTED.modelSha256, probabilities_calibrated: false, production_role_approved: false } });
    const question = prepared.plan.request.questions[0]; const target = { answer: index === 0 ? 'red' : index === 1 ? 0.5 : null };
    const grade = scorePrediction(question, target, typed.answers.q);
    const scoringPassed = index === 2 ? grade.uncertain === true && !Object.hasOwn(grade, 'correct') && Number.isFinite(grade.normalized_absolute_error) && grade.normalized_absolute_error <= 0.1 : grade.correct === true;
    insist(scoringPassed && row.record_id === prepared.id && row.type === question.type && row.compiled_prompt_sha256 === prepared.plan.logical_prompt_sha256 && row.original_jinja_render_match === true && row.exactly_one_BOS === true && row.unchanged_native_one_distinct_token_guard_passed === true && row.synthetic_scoring_passed === true && row.generated_output_tokens === 0 && row.full_clear_before_after_rule === 'frozen unchanged native source plus actual full:true operation' && canonical(row.actual_metrics) === canonical(metrics) && canonical(row.raw_selected_logits) === canonical(raw.logits) && canonical(row.actual_response) === canonical(typed) && canonical(row.original_grade) === canonical(grade), 'ROOT Metal audited row must reconstruct exact unchanged actual response/grade/contracts');
    if (index < 2) insist(canonical(metal_raw.synthetic_rows[index].actual_response) === canonical(typed) && canonical(metal_raw.synthetic_rows[index].grade) === canonical(grade), 'ROOT audit must preserve originally retained successful rows');
    inputTokens += compiled.tokens.length;
  }
  insist(metal_audit.input_tokens === inputTokens && metal_audit.owned_pid_absent === true && metal_audit.exit_and_stdio_close_observed === true && metal_audit.weights_and_context_loaded === true && metal_audit.actual_native_GPU_inference === true && metal_audit.quality_or_gain_proven === false && metal_audit.production_role_approved === false && metal_audit.approval_effect === 'none' && metal_audit.held_out_TEST_read === false, 'ROOT audited tiny inference scope/cleanup must remain distinct from quality or approval');
  insist(metal_receipt.kind === 'ROOT_successor_three_synthetic_metal_final_receipt' && metal_receipt.proof_sha256 === plan.prerequisites.metal.sha256 && metal_receipt.audit_sha256 === plan.prerequisites.metal_audit.sha256 && metal_receipt.run_plan_sha256 === plan.prerequisites.metal_plan.sha256 && metal_receipt.owned_pid === metal_raw.owned_pid && metal_receipt.owned_pid_absent === true && metal_receipt.exit_and_stdio_close_observed === true && metal_receipt.original_command_exit_code === 1 && metal_receipt.original_probe_passed === false && metal_receipt.original_failure_due_to_missing_unknown_correct_field_only === true && metal_receipt.audited_probe_contracts_and_original_scoring_passed === true && metal_receipt.all_three_actual_original_Jinja_BOS_one_token_contracts_recomputed === true && metal_receipt.actual_native_GPU_inference === true && metal_receipt.weights_and_context_loaded === true && metal_receipt.quality_or_gain_proven === false && metal_receipt.production_role_approved === false && metal_receipt.approval_effect === 'none', 'New ROOT Metal final receipt must bind the exact retained failure and successful audit separately');
}
export const QUALITY_GATE_LITERALS = QUALITY_GATES;
