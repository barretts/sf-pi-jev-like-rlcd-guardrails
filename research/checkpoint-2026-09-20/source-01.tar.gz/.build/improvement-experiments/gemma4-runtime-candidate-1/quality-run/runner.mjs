import { mkdir, readFile, writeFile, appendFile } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join, resolve, relative } from 'node:path';
import { pathToFileURL } from 'node:url';
import { HERE, ROOT, CANDIDATE, ORIGINAL, GRID, GRADER, BINARY, MODEL, TEMPLATE, EXPECTED, LIMITS,
  insist, sha, jsonBytes, canonical, fileIdentity, ownedNewPath, packetBytes, initRequest,
  readInputSets, inputManifest, inputBytesForGrader, compilerModule, candidateProfile,
  validateProvenance, requireRootAuthorization, validateNewPrerequisites, PREREQUISITE_KEYS, cleanOwnedTerminal, rootGoneObservationValid, wireBranch, QUALITY_GATE_LITERALS } from './protocol.mjs';
import { SuccessorResearchClassifier } from './classifier.mjs';

const executeFile = promisify(execFile);
const COMPILE = join(CANDIDATE, 'compile-evidence-root-1.json');
export const RELEASED_BINARY = Object.freeze({ sha256: 'cd437329ecbecbcd3db2fc81b90f22c2b603d77b9f4b97f1abf0861b333fdfd2', bytes: 9671688 });
export const STATIC_LIBRARIES = Object.freeze({
  '.build/llama/src/libllama.a': '5ca3110a3313770b055ddc298129ebc2ed5fbcac60fbb8f73bf67e66cd6c8ac8',
  '.build/llama/common/libllama-common.a': '0aea8ff54dfe7ad003c8b5f51b7665846a4470d23be10b234385c4703aaf29d5',
  '.build/llama/ggml/src/libggml.a': '39d9baea0d40aaa1c93fb04923c36c5e0120d6cfe37de4b2eab8ccd1a2adda98',
  '.build/llama/ggml/src/libggml-cpu.a': '32477b3527ea5b53d315657067f659c14ddcbd8b455ad8fe4f8220e0bf3f2175',
  '.build/llama/ggml/src/ggml-metal/libggml-metal.a': '2f93b9991e41d1c236a3e997aadfaa3dc790fb0e1a6359bc0f9f87ec17e20deb',
  '.build/llama/ggml/src/libggml-base.a': '5a5e28810fde644ee61173ee79801501002296def09730664d2d0c455aac0399',
  '.build/llama/common/libllama-common-base.a': '421df51ece9c03761925f049a29d9b6fe3abe3079b65ad1229d8e0d700342869',
  '.build/llama/vendor/cpp-httplib/libcpp-httplib.a': '8e5b55442d0832de5607efbb2b6d42a055415115c4196b2135e89b10e5cfce01',
});
// Filled from the independent grader's explicit source release; never discover arbitrary grader code.
export const GRADER_RELEASE = Object.freeze({ sha256: '0821757efa2dd445e645a2f6d22751d455895d30543aadcc32901a2c6fda794b', bytes: 18539,
  manifestPath: join(ROOT, '.build/improvement-experiments/gemma4-successor-quality/release-revision-2.json'),
  manifestSha256: '050cb7c46eb15eaceef889dd511bcd22a51db2ccc6a226b9083386b2e96a53c1' });

export function validateCompileEvidence(evidence) {
  insist(evidence?.kind === 'ROOT_successor_runtime_compile' && evidence.compiler_exit_code === 0 && evidence.source_sha256 === EXPECTED.sourceSha256 && evidence.binary_sha256 === RELEASED_BINARY.sha256 && evidence.binary_bytes === RELEASED_BINARY.bytes, 'New successful candidate compile metadata required');
  insist(canonical(evidence.reused_library_sha256) === canonical(STATIC_LIBRARIES), 'Exact reused static-library set/SHA required');
  insist(evidence.vendor_revision === 'f072b103714dfa1eee531f80b24512faf38e3dd2', 'Vendor revision mismatch');
  const libraries = evidence.compiler_argv?.filter(arg => arg.endsWith('.a'));
  insist(Array.isArray(libraries) && new Set(libraries).size === Object.keys(STATIC_LIBRARIES).length && libraries.every(path => STATIC_LIBRARIES[relative(ROOT, path)]), 'Compiler must link only the exact frozen static-library set');
  insist(canonical(evidence.protected_source_hashes_before) === canonical(evidence.protected_source_hashes_after), 'Compile protected-source identity drift');
  insist(evidence.native_binary_executed === false && evidence.model_tokenizer_native_GPU_network_or_auth_executed === false && evidence.held_out_TEST_read === false && evidence.production_role_approved === false, 'Compile evidence must retain source/CPU-only limits');
}
export async function verifiedGraderSources() {
  const bytes = await readFile(GRADER_RELEASE.manifestPath);
  insist(sha(bytes) === GRADER_RELEASE.manifestSha256, 'Frozen grader revision-2 release metadata changed');
  const release = JSON.parse(bytes);
  insist(release.release_revision === 2 && release.logical_id === EXPECTED.logicalId && release.scope === 'source_only_no_inference_or_promotion' && release.original_plan_sha256 === EXPECTED.originalPlanSha256 && canonical(release.successor_physical_identity) === canonical(successorPhysicalIdentity({ physical_profile_sha256: EXPECTED.emittedProfileSha256, prospective_profile_file: { sha256: EXPECTED.profileFileSha256 } })), 'Grader release scope or separately pinned physical identity changed');
  const expectedPaths = ['grade.mjs', 'grade.cpu.test.mjs', 'README.md', 'release.mjs'].map(name => join(ROOT, '.build/improvement-experiments/gemma4-successor-quality', name));
  expectedPaths.push(GRID, join(ORIGINAL, 'quality.mjs'), join(ORIGINAL, 'protocol.mjs'), join(ROOT, 'dist/core.js'), join(ROOT, 'dist/evaluation.js'));
  insist(canonical(release.sources.map(identity => identity.path).sort()) === canonical(expectedPaths.sort()), 'Exact grader release source/dependency inventory required');
  const identities = [];
  for (const identity of release.sources) { const current = await fileIdentity(identity.path); insist(current.sha256 === identity.sha256 && current.bytes === identity.bytes, 'Frozen grader source/dependency changed: ' + identity.path); identities.push(current); }
  return [...identities, { path: GRADER_RELEASE.manifestPath, sha256: sha(bytes), bytes: bytes.length }];
}
export async function sourceIdentities() {
  const own = ['protocol.mjs', 'classifier.mjs', 'runner.mjs', 'root-entry.mjs', 'lifecycle.cpu.test.mjs', 'README.md'];
  const paths = [...own.map(name => join(HERE, name)), GRID, GRADER, join(ORIGINAL, 'rpc.mjs'), join(ORIGINAL, 'render-reference.py'),
    ...['src/core.ts', 'src/evaluation.ts', 'dist/core.js', 'dist/evaluation.js'].map(name => join(ROOT, name))];
  const identities = await Promise.all(paths.map(path => fileIdentity(path)));
  insist(identities.find(item => item.path === GRID).sha256 === EXPECTED.gridSha256 && identities.find(item => item.path === join(ORIGINAL, 'rpc.mjs')).sha256 === EXPECTED.rpcSha256 && identities.find(item => item.path === join(ORIGINAL, 'render-reference.py')).sha256 === EXPECTED.rendererSha256, 'Frozen compiler/RPC/renderer source changed');
  const grader = identities.find(item => item.path === GRADER);
  insist(grader.sha256 === GRADER_RELEASE.sha256 && grader.bytes === GRADER_RELEASE.bytes, 'Independent grader source release is pending or changed');
  const graderSources = await verifiedGraderSources();
  return [...new Map([...identities, ...graderSources].map(identity => [identity.path, identity])).values()];
}
async function graderModule() {
  await verifiedGraderSources();
  const identity = await fileIdentity(GRADER);
  insist(identity.sha256 === GRADER_RELEASE.sha256 && identity.bytes === GRADER_RELEASE.bytes, 'Independent grader source release mismatch');
  return import(pathToFileURL(GRADER).href + '?sha256=' + identity.sha256);
}
export function successorPhysicalIdentity(plan) {
  insist(plan.physical_profile_sha256 === EXPECTED.emittedProfileSha256 && plan.prospective_profile_file.sha256 === EXPECTED.profileFileSha256, 'New successor physical identity mismatch');
  return { research_profile: EXPECTED.profile, physical_profile_sha256: EXPECTED.emittedProfileSha256,
    physical_profile_file_sha256: EXPECTED.profileFileSha256,
    raw_model_sha256: EXPECTED.modelSha256, raw_model_bytes: EXPECTED.modelBytes };
}
export async function sourceCpuPlan() {
  const sets = await readInputSets(); const profile = await candidateProfile();
  const compileBytes = await readFile(COMPILE); validateCompileEvidence(JSON.parse(compileBytes));
  return { kind: 'gemma4_successor_validation_source_cpu_plan', schema_version: 1, created_at: new Date().toISOString(),
    status: 'new_physical_and_logical_candidate_unqualified_native_inference_pending_ROOT',
    scope: 'validation_only_research_no_role_approval_no_TEST_no_actual_gain_claim',
    logical_id: EXPECTED.logicalId, research_profile: EXPECTED.profile, ...profile,
    source_identities: await sourceIdentities(), native_source: await fileIdentity(join(CANDIDATE, 'main.cpp')),
    compile_metadata: { path: COMPILE, sha256: sha(compileBytes), bytes: compileBytes.length },
    compile_metadata_is_not_runtime_proof: true, native_binary_literal: RELEASED_BINARY,
    inputs: inputManifest(sets), execution_order: sets.flatMap(set => set.expected_ids), expected_records: 194, expected_groups: 83,
    runtime_bounds: LIMITS, quality_gates: QUALITY_GATE_LITERALS,
    source_cpu_stage_reads_binary_model_or_template: false, model_tokenizer_native_gpu_training_network_auth_executed: false,
    prerequisites_still_required: ['explicit ROOT stage clearance', 'new successful candidate vocabulary proof', 'new independent synthetic Jinja proof', 'new three-synthetic-question Metal proof', 'all 194 new logical independent Jinja rows before native launch', 'fresh full SHA of source, binary, static libraries, raw 17,651,001,568-byte model and raw template'],
    old_proofs_do_not_qualify_this_candidate: true, production_role_approval: false, actual_quality_gain: null };
}
export async function rendererRuntimeIdentity() {
  const identity = await fileIdentity(join(ORIGINAL, 'render-reference.py'));
  insist(identity.sha256 === EXPECTED.rendererSha256, 'Original immutable renderer source changed');
  const { stdout } = await executeFile('/usr/bin/env', ['python3', identity.path, '--runtime-identity'],
    { cwd: HERE, timeout: 10000, maxBuffer: 1048576, encoding: 'utf8' });
  const runtime = JSON.parse(stdout); insist(runtime.jinja_version === '3.1.6', 'Reviewed Jinja 3.1.6 required'); return runtime;
}
async function newProofIdentities(prerequisiteRefs) {
  const output = {};
  insist(canonical(Object.keys(prerequisiteRefs ?? {}).sort()) === canonical([...PREREQUISITE_KEYS].sort()), 'Exact eight new prerequisite reference keys required');
  for (const key of PREREQUISITE_KEYS) {
    const reference = prerequisiteRefs?.[key];
    insist(reference?.path && /^[a-f0-9]{64}$/.test(reference.sha256), 'Explicit new prerequisite identity required: ' + key);
    const path = resolve(reference.path);
    insist(path.startsWith(CANDIDATE + '/') && !path.startsWith(HERE + '/'), 'Prerequisite must be a new candidate ROOT proof, never an old prototype proof');
    output[key] = await fileIdentity(path);
    insist(output[key].sha256 === reference.sha256 && output[key].bytes === reference.bytes, 'New prerequisite byte identity mismatch: ' + key);
  }
  return output;
}
async function readAndValidateNewProofs(plan) {
  const proofs = {};
  insist(canonical(Object.keys(plan.prerequisites ?? {}).sort()) === canonical([...PREREQUISITE_KEYS].sort()), 'Frozen exact eight new prerequisite keys required');
  for (const key of PREREQUISITE_KEYS) {
    const identity = plan.prerequisites[key]; const bytes = await readFile(identity.path);
    insist(bytes.length === identity.bytes && sha(bytes) === identity.sha256, 'Exact new prerequisite parse bytes changed: ' + key);
    proofs[key] = JSON.parse(bytes);
  }
  validateNewPrerequisites(proofs, plan, await compilerModule()); return proofs;
}
/** Future ROOT function. Authorization precedes any binary/model/template/static-library reads. */
export async function freezeRootPlan({ rootAuthorization, originalFrozenPlanBytes, prerequisiteRefs }) {
  requireRootAuthorization(rootAuthorization, 'freeze_new_candidate_validation_194');
  insist(sha(originalFrozenPlanBytes) === EXPECTED.originalPlanSha256, 'ROOT-injected original immutable metadata plan SHA mismatch');
  const sets = await readInputSets(); const profile = await candidateProfile();
  const compileBytes = await readFile(COMPILE); const compile = JSON.parse(compileBytes); validateCompileEvidence(compile);
  const binary = await fileIdentity(BINARY); const model = await fileIdentity(MODEL, { stream: true }); const template = await fileIdentity(TEMPLATE);
  insist(binary.sha256 === RELEASED_BINARY.sha256 && binary.bytes === RELEASED_BINARY.bytes, 'New candidate binary full SHA/bytes mismatch');
  insist(model.sha256 === EXPECTED.modelSha256 && model.bytes === EXPECTED.modelBytes, 'Exact raw 17 GB model full SHA/bytes mismatch');
  insist(template.sha256 === EXPECTED.templateSha256 && template.bytes === EXPECTED.templateBytes, 'Exact raw original Jinja full SHA/bytes mismatch');
  const libraries = [];
  for (const [path, expectedSha] of Object.entries(STATIC_LIBRARIES)) { const identity = await fileIdentity(join(ROOT, path)); insist(identity.sha256 === expectedSha, 'Static library changed: ' + path); libraries.push(identity); }
  const grader = await graderModule();
  const successorManifest = grader.buildSuccessorManifest({ originalFrozenPlanBytes, inputSets: inputBytesForGrader(sets), successorPhysicalIdentity: successorPhysicalIdentity(profile) });
  const plan = { kind: 'gemma4_successor_validation_frozen_root_plan', schema_version: 1, frozen_at: new Date().toISOString(),
    scope: 'validation_194_one_owned_sequential_metal_process', logical_id: EXPECTED.logicalId,
    research_profile: EXPECTED.profile, ...profile,
    original_frozen_plan_sha256: sha(originalFrozenPlanBytes), successor_manifest: successorManifest,
    sources: { host: await sourceIdentities(), prototype: await fileIdentity(join(CANDIDATE, 'main.cpp')),
      compile: { path: COMPILE, sha256: sha(compileBytes), bytes: compileBytes.length }, libraries },
    artifacts: { binary, model, template }, prerequisites: await newProofIdentities(prerequisiteRefs),
    host_runtime: { node_version: process.version, node_executable: await fileIdentity(process.execPath), renderer: await rendererRuntimeIdentity() },
    inputs: inputManifest(sets), execution_order: sets.flatMap(set => set.expected_ids), expected_records: 194, expected_groups: 83,
    rpc_init: initRequest(), runtime_bounds: LIMITS, quality_gates: QUALITY_GATE_LITERALS,
    logical_prompt_rule: 'released candidate-2 compileHalfGrid on unchanged validated original request/targets; retain new logical metadata',
    native_question_rule: 'full prefill one branch; actual one-token label and initial BOS guards; selected logits; zero generation; full memory clear before and after',
    independent_render_rule: 'independent Jinja original raw template for every new compiled branch before owned native launch; exact parity again per native compile',
    probability_semantics: 'uncalibrated softmax over selected labels only', production_role_approval: false,
    approval_effect: 'none; quality is validation research only; no held-out TEST and no measured-gain claim',
    cold_scope: 'new owned process, raw quantized weight/context initialization; filesystem cache and prior GPU state may be warm' };
  await readAndValidateNewProofs(plan);
  plan.physical_profile_runtime_observed = true;
  plan.physical_profile_runtime_observation = 'new frozen candidate vocabulary proof; emitted ordered JSON/digest independently verified';
  return plan;
}
export function checkRootClearance(clearance, planBytes, plan) {
  insist(clearance?.kind === 'gemma4_successor_validation_root_clearance' && clearance.actor === 'ROOT' && clearance.stage_cleared === true && clearance.clearance_scope === 'validation_194_one_owned_sequential_metal_process', 'Explicit new ROOT validation-stage clearance required');
  insist(clearance.run_plan_sha256 === sha(planBytes) && clearance.prototype_source_sha256 === EXPECTED.sourceSha256 && clearance.binary_sha256 === RELEASED_BINARY.sha256 && clearance.logical_id === EXPECTED.logicalId && clearance.research_profile === EXPECTED.profile && clearance.physical_profile_sha256 === plan.physical_profile_sha256 && clearance.exact_model_sha256_verified === EXPECTED.modelSha256, 'ROOT clearance exact new frozen candidate identities mismatch');
  insist(clearance.new_vocab_and_independent_jinja_reviewed === true && clearance.new_three_synthetic_metal_reviewed === true && canonical(clearance.prerequisite_sha256) === canonical(Object.fromEntries(Object.entries(plan.prerequisites).map(([key, identity]) => [key, identity.sha256]))), 'ROOT must review exact new prerequisite proofs');
  insist(clearance.production_role_approval === false && clearance.held_out_TEST_authorized === false, 'ROOT clearance must remain research validation only');
}
export async function verifyFrozenIdentities(plan, originalFrozenPlanBytes) {
  insist(plan?.kind === 'gemma4_successor_validation_frozen_root_plan' && plan.logical_id === EXPECTED.logicalId && plan.research_profile === EXPECTED.profile && plan.expected_records === 194 && plan.expected_groups === 83 && plan.scope === 'validation_194_one_owned_sequential_metal_process' && plan.physical_profile_runtime_observed === true, 'Unsupported or unobserved new candidate plan');
  insist(sha(originalFrozenPlanBytes) === EXPECTED.originalPlanSha256 && plan.original_frozen_plan_sha256 === EXPECTED.originalPlanSha256, 'ROOT-injected immutable original metadata plan changed');
  insist(canonical(plan.runtime_bounds) === canonical(LIMITS) && canonical(plan.rpc_init) === canonical(initRequest()) && canonical(plan.quality_gates) === canonical(QUALITY_GATE_LITERALS), 'Frozen limits/init/quality-gates mismatch');
  insist(plan.artifacts.binary.path === BINARY && plan.artifacts.model.path === MODEL && plan.artifacts.template.path === TEMPLATE && plan.sources.prototype.path === join(CANDIDATE, 'main.cpp') && plan.sources.compile.path === COMPILE, 'Literal new candidate artifact paths required');
  insist(plan.artifacts.binary.sha256 === RELEASED_BINARY.sha256 && plan.artifacts.binary.bytes === RELEASED_BINARY.bytes && plan.artifacts.model.sha256 === EXPECTED.modelSha256 && plan.artifacts.model.bytes === EXPECTED.modelBytes && plan.sources.prototype.sha256 === EXPECTED.sourceSha256 && plan.artifacts.template.sha256 === EXPECTED.templateSha256 && plan.artifacts.template.bytes === EXPECTED.templateBytes, 'Frozen exact artifact identity mismatch');
  const profile = await candidateProfile();
  insist(JSON.stringify(plan.physical_profile) === JSON.stringify(profile.physical_profile) && plan.physical_profile_sha256 === profile.physical_profile_sha256 && canonical(plan.prospective_profile_file) === canonical(profile.prospective_profile_file), 'Prospective file/emitted profile source identity changed');
  const identities = [...plan.sources.host, plan.sources.prototype, plan.sources.compile, ...plan.sources.libraries, ...Object.values(plan.artifacts), ...Object.values(plan.prerequisites)];
  for (const identity of identities) { const current = await fileIdentity(identity.path, { stream: identity.path === MODEL }); insist(current.sha256 === identity.sha256 && current.bytes === identity.bytes, 'Frozen full-byte artifact changed: ' + identity.path); }
  insist(canonical(plan.sources.host) === canonical(await sourceIdentities()), 'Frozen host source inventory changed');
  insist(canonical(Object.fromEntries(plan.sources.libraries.map(identity => [relative(ROOT, identity.path), identity.sha256]))) === canonical(STATIC_LIBRARIES), 'Frozen library inventory changed');
  validateCompileEvidence(JSON.parse(await readFile(COMPILE))); await readAndValidateNewProofs(plan);
  insist(plan.host_runtime.node_version === process.version && canonical(plan.host_runtime.node_executable) === canonical(await fileIdentity(process.execPath)) && canonical(plan.host_runtime.renderer) === canonical(await rendererRuntimeIdentity()), 'Frozen Node/Python/Jinja runtime changed');
  const sets = await readInputSets(); insist(canonical(plan.inputs) === canonical(inputManifest(sets)) && canonical(plan.execution_order) === canonical(sets.flatMap(set => set.expected_ids)), 'Frozen exact 194 IDs/bytes/groups/logical prompt SHAs changed');
  const grader = await graderModule();
  insist(canonical(plan.successor_manifest) === canonical(grader.buildSuccessorManifest({ originalFrozenPlanBytes, inputSets: inputBytesForGrader(sets), successorPhysicalIdentity: successorPhysicalIdentity(plan) })), 'Frozen successor grader manifest changed');
  return sets;
}
export function verifyIndependentRender(reference, requests, requestBytes, runtime) {
  insist(reference?.kind === 'gemma4_independent_full_validation_jinja_render' && reference.requests_sha256 === sha(requestBytes) && reference.original_raw_template_sha256 === EXPECTED.templateSha256 && reference.original_raw_template_bytes === EXPECTED.templateBytes && reference.native_or_model_execution === false && canonical(reference.runtime_identity) === canonical(runtime) && reference.python_jinja_version === '3.1.6' && reference.rows?.length === 194 && requests.length === 194, 'Independent all-194 Jinja identity/coverage/runtime mismatch');
  insist(reference.render_options?.enable_thinking === false && reference.render_options.add_generation_prompt === true && reference.render_options.bos_token === '<bos>' && reference.render_options.eos_token === '' && reference.render_options.tools_argument_supplied === false, 'Independent Jinja render options changed');
  const seen = new Set();
  for (let index = 0; index < requests.length; index++) {
    const expected = requests[index]; const actual = reference.rows[index]; const key = actual.record_id + ':' + actual.branch_id;
    insist(!seen.has(key) && actual.record_id === expected.record_id && actual.branch_id === expected.branch.branch_id, 'Independent exact record/branch order duplicate or mismatch'); seen.add(key);
    const messages = expected.branch.messages; const merged = messages.length > 1 && messages.at(-1).role === 'user' && messages.at(-2).role === 'user';
    insist(actual.logical_messages_sha256 === sha(JSON.stringify(messages)) && actual.answer_prefix === expected.branch.answer_prefix && actual.final_two_user_messages_merged === merged && actual.messages_before === messages.length && actual.messages_after === messages.length - Number(merged), 'Independent per-record logical messages/normalization mismatch');
    insist(typeof actual.rendered === 'string' && actual.rendered_sha256 === sha(actual.rendered) && actual.rendered.startsWith('<bos>') && actual.rendered.split('<bos>').length === 2 && actual.rendered.endsWith(EXPECTED.generationBoundary + expected.branch.answer_prefix), 'Independent per-record render/BOS/boundary mismatch');
  }
  return true;
}
export function nativeContractsPassed(stage, auditFailure = null) {
  return Number.isSafeInteger(stage.native_pid) && stage.native_pid > 0 && !stage.error && !auditFailure && stage.aborted !== true && stage.actual_mode === 'quantized_metal' && stage.actual_native_process_launches === 1 && stage.owned_native_exit_event_observed === true && cleanOwnedTerminal(stage.owned_native, stage.native_pid) && cleanOwnedTerminal(stage.owned_native_close_result, stage.native_pid) && stage.fresh_native_stderr_observations?.native_pid === stage.native_pid && stage.fresh_native_stderr_observations.qualifying_full_metal_offload === true;
}
export function nativeStderrObservations(snapshot) {
  const stderr = snapshot.stderr ?? ''; const offload = [...stderr.matchAll(/offloaded (\d+)\/(\d+) layers to GPU/g)].map(match => ({ offloaded: Number(match[1]), total: Number(match[2]), source_line: match[0] }));
  const flash = [...stderr.matchAll(/resolve_fused_ops: Flash Attention (enabled|disabled)/g)].map(match => ({ observed: match[1], source_line: match[0] }));
  const flashValues = new Set(flash.map(row => row.observed));
  const sizes = [...stderr.matchAll(/MTL0 KV buffer size =\s+([\d.]+)\s+MiB/g)].map(match => ({ MiB: Number(match[1]), source_line: match[0] }));
  return { source: 'fresh_directly_owned_native_stderr_after_cleanup', native_pid: snapshot.pid,
    persisted_utf8_log_sha256: sha(Buffer.from(stderr)), stderr_bytes_seen: snapshot.stderrBytesSeen ?? null,
    stderr_bytes_retained: snapshot.stderrBytesRetained ?? null, stderr_truncated: snapshot.stderrTruncated ?? null,
    offloaded_layers: offload, actual_flash_attention_observed: flashValues.size === 1 ? [...flashValues][0] : flashValues.size > 1 ? 'ambiguous' : 'unknown',
    flash_attention_observation_lines: flash, emitted_flash_attention_effective_field: null,
    actual_Metal_KV_buffer_observations: sizes,
    qualifying_full_metal_offload: snapshot.stderrTruncated === false && offload.length === 1 && offload[0].offloaded === 61 && offload[0].total === 61,
    limits: 'Fresh native log observations; no GPU allocation peak, host memory limit, calibrated probability, quality gain, or role approval claim. The emitted effective-attention field remains null.' };
}
export function rootPidGonePassed(observation, pid) {
  return rootGoneObservationValid(observation, pid);
}
export function failedRemainingEnvelopes(records, plan, count, error) {
  insist(Number.isSafeInteger(count) && count >= 0 && count <= records.length, 'Invalid retained envelope coverage');
  return records.slice(count).map(record => {
    const frozen = plan.inputs.flatMap(set => set.record_manifest).find(entry => entry.record_id === record.id);
    insist(frozen?.logical_id === EXPECTED.logicalId && /^[a-f0-9]{64}$/.test(frozen.logical_prompt_sha256), 'Missing frozen failure-row logical identity');
    return { record_id: record.id, logical_id: EXPECTED.logicalId, logical_prompt_sha256: frozen.logical_prompt_sha256,
      research_profile: EXPECTED.profile, physical_profile_sha256: plan.physical_profile_sha256,
      raw_model_sha256: EXPECTED.modelSha256, raw_model_bytes: EXPECTED.modelBytes,
      prototype_source_sha256: plan.sources.prototype.sha256, binary_sha256: plan.artifacts.binary.sha256,
      model: record.request.model, elapsed_ms: 0, error, inference_completed: false };
  });
}
export async function rootObservationWithDeadline(observer, pid, evidence, timeoutMs = LIMITS.exitTimeoutMs) {
  insist(Number.isSafeInteger(timeoutMs) && timeoutMs > 0 && timeoutMs <= LIMITS.exitTimeoutMs, 'ROOT observation deadline must be bounded');
  let timer;
  try {
    return await Promise.race([
      Promise.resolve().then(() => observer(pid, evidence)).then(observation => observation && typeof observation === 'object' ? observation : { actor: 'ROOT', pid, gone: null, error: 'ROOT observer returned no observation' }).catch(error => ({ actor: 'ROOT', pid, gone: null, error: error?.message ?? String(error) })),
      new Promise(resolve => { timer = setTimeout(() => resolve({ actor: 'ROOT', pid, gone: null, error: 'ROOT PID-gone observation did not settle within ' + timeoutMs + ' ms' }), timeoutMs); }),
    ]);
  } finally { clearTimeout(timer); }
}
/** Pin original OwnedRpc source before import; independent exit-event adapter uses its reviewed _child field. */
export function ownedLifecycle(rpc, signal) {
  insist(signal && typeof signal.addEventListener === 'function', 'Stage AbortSignal required');
  insist(rpc._child && typeof rpc._child.once === 'function', 'Frozen OwnedRpc exit-event adapter unavailable');
  let exitEventObserved = false; rpc._child.once('exit', () => { exitEventObserved = true; });
  let abortCleanup = null;
  const abort = () => { abortCleanup ??= rpc.request({ v: 1, id: 'stage-abort', op: 'never-sent-preaborted' }, { signal }).catch(() => {}); };
  signal.addEventListener('abort', abort, { once: true }); if (signal.aborted) abort();
  return { exitObserved: () => exitEventObserved, dispose: async () => { signal.removeEventListener('abort', abort); await abortCleanup; } };
}
function stageSignals(externalSignal) {
  insist(externalSignal && typeof externalSignal.throwIfAborted === 'function', 'ROOT must supply stage AbortSignal');
  const controller = new AbortController(); const signal = AbortSignal.any([externalSignal, controller.signal]);
  const onInterrupt = () => controller.abort(new Error('ROOT runner interrupted by SIGINT'));
  const onTerminate = () => controller.abort(new Error('ROOT runner interrupted by SIGTERM'));
  process.on('SIGINT', onInterrupt); process.on('SIGTERM', onTerminate);
  return { signal, dispose: () => { process.off('SIGINT', onInterrupt); process.off('SIGTERM', onTerminate); } };
}
/** Explicit ROOT API only. Imports and direct CLI have no native launch path. */
export async function runRootCandidate194({ rootAuthorization, planBytes, clearanceBytes, originalFrozenPlanBytes, proofDirectory, signal: externalSignal, observeRootPidGone }) {
  requireRootAuthorization(rootAuthorization, 'execute_new_candidate_validation_194');
  insist(typeof observeRootPidGone === 'function', 'Separate ROOT post-cleanup PID-gone observer required');
  const plan = JSON.parse(planBytes); const clearance = JSON.parse(clearanceBytes); checkRootClearance(clearance, planBytes, plan);
  const stageControl = stageSignals(externalSignal); const signal = stageControl.signal;
  let rpc = null; let lifecycle = null; let report = null; let auditFailure = null; let auditBytes = 0; let sets = null; let compiler = null;
  const envelopes = [];
  const stage = { kind: 'gemma4_successor_validation_native_stage', started_at: new Date().toISOString(),
    status: 'new_validation_research_candidate_no_role_approval', run_plan_sha256: sha(planBytes), root_clearance_sha256: sha(clearanceBytes),
    logical_id: EXPECTED.logicalId, research_profile: EXPECTED.profile, physical_profile_sha256: plan.physical_profile_sha256,
    prospective_profile_file_sha256: plan.prospective_profile_file.sha256, requested_native_process_count: 1, actual_native_process_launches: 0,
    probabilities_calibrated: false, production_role_approval: false, held_out_TEST_read: false, actual_quality_gain: null,
    runtime_bounds: LIMITS, resource_enforcement: 'protocol byte caps and cooperative deadlines only; no kernel CPU/RSS/Metal allocation cap',
    native_artifacts: plan.artifacts, native_source: plan.sources.prototype, old_proofs_used_to_qualify_changed_candidate: false };
  const started = performance.now(); let output = null;
  const appendAudit = async (filename, value) => {
    const bytes = Buffer.from(JSON.stringify(value) + '\n'); auditBytes += bytes.length;
    if (auditBytes > LIMITS.auditBytes) { auditFailure = 'Frozen 128 MiB combined RPC/question audit cap exceeded'; throw new Error(auditFailure); }
    try { await appendFile(join(output, filename), bytes, { mode: 0o600 }); }
    catch (error) { auditFailure = String(error); throw error; }
  };
  try {
    signal.throwIfAborted();
    sets = await verifyFrozenIdentities(plan, originalFrozenPlanBytes); compiler = await compilerModule(); signal.throwIfAborted();
    output = await ownedNewPath(proofDirectory); await mkdir(output, { mode: 0o700 });
    const snapshots = join(output, 'inputs'); await mkdir(snapshots, { mode: 0o700 });
    const snapshotSets = await readInputSets(snapshots);
    insist(canonical(inputManifest(snapshotSets)) === canonical(plan.inputs), 'Launch input snapshots do not match frozen manifest');
    await writeFile(join(output, 'run-plan.json'), planBytes, { flag: 'wx', mode: 0o600 });
    await writeFile(join(output, 'root-clearance.json'), clearanceBytes, { flag: 'wx', mode: 0o600 });
    const requests = sets.flatMap(set => set.records.map(record => ({ record_id: record.id, branch: wireBranch(compiler.compileHalfGrid(record.request).questions[0]) })));
    const requestBytes = jsonBytes(requests); await writeFile(join(output, 'render-requests.json'), requestBytes, { flag: 'wx', mode: 0o600 });
    const render = await executeFile(plan.host_runtime.renderer.python_executable, [join(ORIGINAL, 'render-reference.py'), '--requests', join(output, 'render-requests.json'), '--output', join(output, 'independent-render.json'), '--template', TEMPLATE, '--expected-sha256', EXPECTED.templateSha256],
      { cwd: HERE, timeout: 60000, maxBuffer: 1048576, encoding: 'utf8', signal });
    stage.independent_renderer_stdout = render.stdout; stage.independent_renderer_stderr = render.stderr;
    const renderBytes = await readFile(join(output, 'independent-render.json')); const reference = JSON.parse(renderBytes);
    verifyIndependentRender(reference, requests, requestBytes, plan.host_runtime.renderer);
    stage.independent_all_194_render_sha256 = sha(renderBytes); stage.independent_all_194_render_passed_before_launch = true;
    // Fresh full artifact/source verification immediately after Jinja and before launch.
    await verifyFrozenIdentities(plan, originalFrozenPlanBytes); signal.throwIfAborted(); packetBytes(initRequest());
    const rpcIdentity = await fileIdentity(join(ORIGINAL, 'rpc.mjs')); insist(rpcIdentity.sha256 === EXPECTED.rpcSha256, 'Frozen owned RPC changed before import');
    const { OwnedRpc } = await import(pathToFileURL(rpcIdentity.path).href + '?sha256=' + rpcIdentity.sha256);
    signal.throwIfAborted();
    rpc = OwnedRpc.spawn(BINARY, [], { cwd: HERE, requestTimeoutMs: LIMITS.requestTimeoutMs, totalTimeoutMs: LIMITS.totalTimeoutMs, maxPacketBytes: LIMITS.maxPacketBytes, maxResponseBytes: LIMITS.maxResponseBytes, maxStderrBytes: LIMITS.maxStderrBytes, exitTimeoutMs: LIMITS.exitTimeoutMs, maxRequests: LIMITS.maxRequests });
    stage.actual_native_process_launches = 1; stage.native_pid = rpc.snapshot().pid; lifecycle = ownedLifecycle(rpc, signal);
    const auditedRpc = { snapshot: () => ({ ...rpc.snapshot(), ...(auditFailure ? { failure: auditFailure } : {}) }),
      request: async (request, options = {}) => {
        signal.throwIfAborted(); insist(!auditFailure, 'Inference stopped after audit failure');
        const requestSignal = options.signal && options.signal !== signal ? AbortSignal.any([signal, options.signal]) : signal;
        const attempt = { id: request.id, op: request.op, request }; const sent = performance.now();
        try { attempt.response = await rpc.request(request, { signal: requestSignal }); return attempt.response; }
        catch (error) { attempt.error = error.message ?? String(error); attempt.error_code = error.code ?? error.name ?? null; attempt.cleanup_details = error.details ?? null; throw error; }
        finally { attempt.elapsed_ms = performance.now() - sent; await appendAudit('native-rpc.jsonl', attempt); }
      } };
    const init = await auditedRpc.request(initRequest(), { signal });
    if (init.error) throw new Error('Native init: ' + JSON.stringify(init.error));
    validateProvenance(init.result?.provenance, plan);
    insist(init.result.ready === true && init.result.architecture === 'gemma4' && init.result.device === 'metal', 'Actual init architecture/readiness/device mismatch');
    stage.init_provenance = init.result.provenance; stage.actual_mode = init.result.provenance.actual_mode;
    const orderedRecords = sets.flatMap(set => set.records);
    const classifier = new SuccessorResearchClassifier({ rpc: auditedRpc, plan, compiler, orderedRecords, renderReference: reference, evidenceSink: entry => appendAudit('question-evidence.jsonl', entry), signal });
    for (const record of orderedRecords) {
      try { envelopes.push(await classifier.classifyRecord(record)); }
      catch (error) { stage.error = stage.error ?? error.message ?? String(error); break; }
    }
    // Every missing inference remains an explicit failure row with retained successor identity.
    envelopes.push(...failedRemainingEnvelopes(orderedRecords, plan, envelopes.length, stage.error ?? 'No inference after terminal audit/transport failure'));
    const grader = await graderModule();
    report = grader.gradeValidationResearch({ originalFrozenPlanBytes, inputSets: inputBytesForGrader(sets), successorPhysicalIdentity: successorPhysicalIdentity(plan), successorManifest: plan.successor_manifest, runEnvelopes: envelopes });
    stage.exact_194_envelope_order = envelopes.length === 194 && canonical(envelopes.map(envelope => envelope.record_id)) === canonical(plan.execution_order);
  } catch (error) { stage.error = error.message ?? String(error); stage.error_code = error.code ?? error.name ?? null; }
  finally {
    stage.aborted = signal.aborted;
    if (rpc) {
      try { stage.owned_native_close_result = await rpc.close(); }
      catch (error) { stage.error = stage.error ?? 'Owned native close: ' + error.message; }
      await lifecycle?.dispose(); stage.owned_native = rpc.snapshot(); stage.owned_native_exit_event_observed = lifecycle?.exitObserved() === true;
      stage.fresh_native_stderr_observations = nativeStderrObservations(stage.owned_native);
      stage.root_pid_gone_observation = await rootObservationWithDeadline(observeRootPidGone, stage.native_pid, { owned_native: stage.owned_native, close_result: stage.owned_native_close_result });
    }
    if (sets && envelopes.length < 194) {
      envelopes.push(...failedRemainingEnvelopes(sets.flatMap(set => set.records), plan, envelopes.length, stage.error ?? 'No inference after initialization/preflight failure'));
      stage.exact_194_envelope_order = canonical(envelopes.map(envelope => envelope.record_id)) === canonical(plan.execution_order);
    }
    if (!report && sets && envelopes.length === 194) {
      try { const grader = await graderModule(); report = grader.gradeValidationResearch({ originalFrozenPlanBytes, inputSets: inputBytesForGrader(sets), successorPhysicalIdentity: successorPhysicalIdentity(plan), successorManifest: plan.successor_manifest, runEnvelopes: envelopes }); }
      catch (error) { stage.error = stage.error ?? 'Research grading failed closed: ' + (error.message ?? String(error)); }
    }
    stage.aborted = signal.aborted;
    stageControl.dispose(); stage.elapsed_ms = performance.now() - started; stage.completed_at = new Date().toISOString(); stage.audit_bytes = auditBytes; stage.audit_failure = auditFailure;
    stage.native_contracts_passed = nativeContractsPassed(stage, auditFailure);
    stage.root_pid_gone_passed = rootPidGonePassed(stage.root_pid_gone_observation, stage.native_pid);
    stage.quality_gates_passed = report?.gates?.passed === true;
    stage.passed = stage.native_contracts_passed && stage.root_pid_gone_passed && stage.quality_gates_passed && stage.exact_194_envelope_order === true;
    if (output) {
      if (rpc) await writeFile(join(output, 'native-stderr.log'), stage.owned_native.stderr ?? '', { flag: 'wx', mode: 0o600 });
      await writeFile(join(output, 'run-envelopes.json'), jsonBytes(envelopes), { flag: 'wx', mode: 0o600 });
      if (report) await writeFile(join(output, 'quality-report.json'), jsonBytes(report), { flag: 'wx', mode: 0o600 });
      await writeFile(join(output, 'stage-proof.json'), jsonBytes(stage), { flag: 'wx', mode: 0o600 });
    }
  }
  return stage;
}
async function main() {
  const argv = process.argv.slice(2);
  insist(argv.length === 3 && argv[0] === 'cpu-plan' && argv[1] === '--output', 'Only CLI: node runner.mjs cpu-plan --output fresh-owned.json. Native inference is pending explicit ROOT APIs; no run/freeze CLI exists.');
  const output = await ownedNewPath(argv[2]); const bytes = jsonBytes(await sourceCpuPlan()); await writeFile(output, bytes, { flag: 'wx', mode: 0o600 });
  console.log(JSON.stringify({ output, sha256: sha(bytes), native_execution: false, root_native_clearance: false }));
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url)
  main().catch(error => { console.error(error.stack ?? String(error)); process.exitCode = 1; });
