import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { EXPECTED, LIMITS, CANDIDATE, BINARY, MODEL, TEMPLATE, PREREQUISITE_KEYS, sha, jsonBytes, canonical, candidateProfile, readInputSets,
  inputManifest, compilerModule, initRequest, wireBranch, requireRootAuthorization, validateProvenance, validateNewPrerequisites } from './protocol.mjs';
import { SuccessorResearchClassifier, verifyNativeMetrics } from './classifier.mjs';
import { checkRootClearance, nativeContractsPassed, rootPidGonePassed, ownedLifecycle,
  verifyIndependentRender, freezeRootPlan, runRootCandidate194, failedRemainingEnvelopes, nativeStderrObservations, rootObservationWithDeadline, validateCompileEvidence, STATIC_LIBRARIES, RELEASED_BINARY } from './runner.mjs';

const tokenMetrics = (provenance, count) => ({ backend: 'llama.cpp', prefill_strategy: 'full', prefix_tokens: 0,
  branch_output_tokens: 0, scored_positions: 1, suffix_batch_sizes: [1], computed_prompt_tokens: count,
  branch_prompt_tokens: count, logical_prefill_tokens: count, padded_suffix_tokens: 0,
  engine_forwards: Math.ceil(count / 2048), provenance });
function mockedProvenance(profile, vocabulary = false) {
  return { prototype_source_sha256: EXPECTED.sourceSha256, physical_profile: profile.physical_profile,
    physical_profile_sha256: profile.physical_profile_sha256, model_expected_sha256: EXPECTED.modelSha256,
    template_raw_identity: { sha256: EXPECTED.templateSha256, bytes: EXPECTED.templateBytes, verified: true },
    template_parser_identity: { sha256: EXPECTED.parserTemplateSha256, bytes: EXPECTED.parserTemplateBytes, verified: true },
    bos_token_id: 2, bos_piece: '<bos>', actual_mode: vocabulary ? 'cpu_vocabulary_only_no_context' : 'quantized_metal',
    vocab_only: vocabulary, weights_loaded: !vocabulary, context_created: !vocabulary, explicit_backend_init: !vocabulary,
    device: vocabulary ? 'cpu' : 'metal', effective_limits: { max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048, context_capacity: vocabulary ? 0 : 4096 },
    flash_attn_effective: null, flash_attn_effective_status: 'unobserved; AUTO is a request and may resolve enabled or disabled',
    gpu_layers_requested: vocabulary ? 0 : 99, offload_kqv: !vocabulary, op_offload: !vocabulary, context_train_limit_checked: !vocabulary };
}
function terminal(pid = 12345) { return { pid, state: 'closed', exitedObserved: true, closedObserved: true, exitCode: 0, signal: null, failureCode: null, pendingRequests: 0 }; }
function terminalStage() { return { actual_mode: 'quantized_metal', actual_native_process_launches: 1, native_pid: 12345,
  owned_native: terminal(), owned_native_close_result: terminal(), owned_native_exit_event_observed: true, aborted: false,
  fresh_native_stderr_observations: nativeStderrObservations({ pid: 12345, stderr: 'offloaded 61/61 layers to GPU\nresolve_fused_ops: Flash Attention enabled\nMTL0 KV buffer size = 320.00 MiB\nMTL0 KV buffer size = 3200.00 MiB\n', stderrTruncated: false }) }; }
function renderFixture() {
  const requests = Array.from({ length: 194 }, (_, index) => ({ record_id: 'invented-' + index,
    branch: { branch_id: 'q', messages: [{ role: 'user', content: 'invented context ' + index }, { role: 'user', content: 'invented question' }], answer_prefix: '{"answer": "', output_labels: ['A', 'B'] } }));
  const requestBytes = jsonBytes(requests); const runtime = { jinja_version: '3.1.6', injected_cpu: true };
  const reference = { kind: 'gemma4_independent_full_validation_jinja_render', requests_sha256: sha(requestBytes),
    original_raw_template_sha256: EXPECTED.templateSha256, original_raw_template_bytes: EXPECTED.templateBytes,
    native_or_model_execution: false, runtime_identity: runtime, python_jinja_version: '3.1.6',
    render_options: { enable_thinking: false, add_generation_prompt: true, bos_token: '<bos>', eos_token: '', tools_argument_supplied: false },
    rows: requests.map(entry => { const rendered = '<bos>invented render ' + entry.record_id + EXPECTED.generationBoundary + entry.branch.answer_prefix;
      return { record_id: entry.record_id, branch_id: 'q', logical_messages_sha256: sha(JSON.stringify(entry.branch.messages)),
        answer_prefix: entry.branch.answer_prefix, final_two_user_messages_merged: true, messages_before: 2, messages_after: 1,
        rendered, rendered_sha256: sha(rendered) }; }) };
  return { requests, requestBytes, runtime, reference };
}

test('CPU safe VAL coverage freezes exact 194 records/83 groups and all new logical hashes', async () => {
  const sets = await readInputSets(); const manifest = inputManifest(sets);
  assert.deepEqual(manifest.map(set => [set.records, set.groups]), [[60, 30], [78, 39], [56, 14]]);
  assert.equal(new Set(sets.flatMap(set => set.records.map(record => record.group_id))).size, 83);
  assert.equal(manifest.flatMap(set => set.record_manifest).length, 194);
  assert.ok(manifest.flatMap(set => set.record_manifest).every(row => row.logical_id === EXPECTED.logicalId && /^[a-f0-9]{64}$/.test(row.logical_prompt_sha256)));
  assert.ok(manifest.flatMap(set => set.record_manifest).some(row => row.original_v2_prompt_sha256 !== row.logical_prompt_sha256));
  assert.ok(sets.every(set => set.bytesSnapshot.length === set.bytes && sha(set.bytesSnapshot) === set.sha256));
});
test('source-derived emitted profile stays distinct from sorted prospective file SHA', async () => {
  const profile = await candidateProfile();
  assert.equal(profile.prospective_profile_file.sha256, EXPECTED.profileFileSha256);
  assert.equal(profile.physical_profile_sha256, '48dda5a0b1630b607f0e5c691366ced92843ea43f0d5d4aab9bc62cc2a7416fc');
  assert.notEqual(profile.physical_profile_sha256, profile.prospective_profile_file.sha256);
  assert.equal(profile.physical_profile_runtime_observed, false);
  assert.equal(profile.physical_profile.n_ubatch_requested, 512);
  assert.equal(profile.physical_profile.flash_attn_requested.name, 'auto');
});
test('ROOT native and freeze entry reject before artifact I/O without exact authorization', async () => {
  await assert.rejects(freezeRootPlan({}), /Explicit ROOT authorization/);
  await assert.rejects(runRootCandidate194({}), /Explicit ROOT authorization/);
  assert.throws(() => requireRootAuthorization({ kind: 'explicit_root_candidate_stage_authorization', actor: 'ROOT', stage: 'execute_new_candidate_validation_194', explicit: true, research_profile: 'old', logical_id: EXPECTED.logicalId, prototype_source_sha256: EXPECTED.sourceSha256, production_role_approval: false }, 'execute_new_candidate_validation_194'), /mismatch/);
});
test('mocked lifetime abort is propagated between requests and cleanup is disposed', async () => {
  const controller = new AbortController(); const child = new EventEmitter(); const seen = [];
  const rpc = { _child: child, request: async (request, options) => { seen.push({ request, aborted: options.signal.aborted }); throw Object.assign(new Error('mock aborted'), { code: 'ABORTED' }); } };
  const lifecycle = ownedLifecycle(rpc, controller.signal);
  assert.equal(lifecycle.exitObserved(), false); child.emit('close', 0, null); assert.equal(lifecycle.exitObserved(), false);
  controller.abort(); await lifecycle.dispose(); assert.equal(seen.length, 1); assert.equal(seen[0].aborted, true);
  assert.equal(seen[0].request.op, 'never-sent-preaborted');
  child.emit('exit', 0, null); assert.equal(lifecycle.exitObserved(), true);
});
test('mocked clean lifecycle requires distinct exit+close, matching PID, exit0 and pending0', () => {
  assert.equal(nativeContractsPassed(terminalStage()), true);
  for (const field of ['exitedObserved', 'closedObserved']) { const stage = terminalStage(); stage.owned_native[field] = false; assert.equal(nativeContractsPassed(stage), false); }
  for (const [field, value] of [['exitCode', 1], ['signal', 'SIGTERM'], ['failureCode', 'ABORTED'], ['pendingRequests', 1], ['state', 'closing'], ['pid', 98765]]) {
    const stage = terminalStage(); stage.owned_native_close_result[field] = value; assert.equal(nativeContractsPassed(stage), false);
  }
  for (const change of [{ aborted: true }, { owned_native_exit_event_observed: false }, { actual_native_process_launches: 2 }, { error: 'audit stopped' }]) assert.equal(nativeContractsPassed({ ...terminalStage(), ...change }), false);
  const cleanup = terminalStage(); cleanup.owned_native_close_result.cleanupError = 'timeout'; assert.equal(nativeContractsPassed(cleanup), false);
  assert.equal(nativeContractsPassed(terminalStage(), 'audit failed'), false);
});
test('ROOT PID-gone acceptance is a separate post-cleanup observation', () => {
  const observation = { actor: 'ROOT', pid: 12345, gone: true, observed_at: '2030-01-01T00:00:00Z', method: 'mocked_ROOT_observer' };
  assert.equal(rootPidGonePassed(observation, 12345), true);
  for (const change of [{ gone: null }, { gone: false }, { actor: 'runner' }, { pid: 98765 }, { method: '' }, { error: 'unknown' }]) assert.equal(rootPidGonePassed({ ...observation, ...change }, 12345), false);
  assert.equal(nativeContractsPassed(terminalStage()), true); assert.equal(rootPidGonePassed(undefined, 12345), false);
  assert.equal(nativeContractsPassed({ ...terminalStage(), native_pid: undefined, owned_native: terminal(undefined), owned_native_close_result: terminal(undefined) }), false);
});
test('fresh stderr full Metal offload is required; AUTO outcome and KV logs stay source-tagged', () => {
  const snapshot = { pid: 12345, stderr: 'offloaded 61/61 layers to GPU\nresolve_fused_ops: Flash Attention disabled\nMTL0 KV buffer size = 320.00 MiB\nMTL0 KV buffer size = 3200.00 MiB\n', stderrTruncated: false };
  const observed = nativeStderrObservations(snapshot);
  assert.equal(observed.qualifying_full_metal_offload, true); assert.equal(observed.actual_flash_attention_observed, 'disabled');
  assert.equal(observed.emitted_flash_attention_effective_field, null); assert.deepEqual(observed.actual_Metal_KV_buffer_observations.map(row => row.MiB), [320, 3200]);
  assert.equal(nativeStderrObservations({ ...snapshot, stderrTruncated: true }).qualifying_full_metal_offload, false);
  assert.equal(nativeStderrObservations({ ...snapshot, stderr: snapshot.stderr.replace('61/61', '60/61') }).qualifying_full_metal_offload, false);
  const stage = terminalStage(); delete stage.fresh_native_stderr_observations; assert.equal(nativeContractsPassed(stage), false);
  assert.equal(nativeStderrObservations({ ...snapshot, stderr: 'offloaded 61/61 layers to GPU\n' }).actual_flash_attention_observed, 'unknown');
});
test('mocked ROOT observer timeout or error remains unknown and cannot hang cleanup reporting', async () => {
  const timedOut = await rootObservationWithDeadline(() => new Promise(() => {}), 12345, {}, 1);
  assert.equal(timedOut.gone, null); assert.match(timedOut.error, /did not settle/); assert.equal(rootPidGonePassed(timedOut, 12345), false);
  const failed = await rootObservationWithDeadline(() => { throw new Error('mock unknown'); }, 12345, {}, 1);
  assert.equal(failed.gone, null); assert.equal(failed.error, 'mock unknown');
  for (const value of [null, undefined]) { const malformed = await rootObservationWithDeadline(() => Promise.reject(value), 12345, {}, 1); assert.equal(malformed.gone, null); assert.equal(malformed.error, String(value)); }
  for (const value of [null, undefined]) { const absent = await rootObservationWithDeadline(() => value, 12345, {}, 1); assert.equal(absent.gone, null); assert.match(absent.error, /no observation/); }
});
test('clearance binds exact new frozen plan, candidate identities and all eight reviewed references', () => {
  const bytes = Buffer.from('invented frozen plan bytes'); const plan = { physical_profile_sha256: EXPECTED.emittedProfileSha256,
    prerequisites: Object.fromEntries(PREREQUISITE_KEYS.map((key, index) => [key, { sha256: (index + 1).toString(16).repeat(64) }])) };
  const clearance = { kind: 'gemma4_successor_validation_root_clearance', actor: 'ROOT', stage_cleared: true,
    clearance_scope: 'validation_194_one_owned_sequential_metal_process', run_plan_sha256: sha(bytes), prototype_source_sha256: EXPECTED.sourceSha256,
    binary_sha256: RELEASED_BINARY.sha256, logical_id: EXPECTED.logicalId, research_profile: EXPECTED.profile, physical_profile_sha256: EXPECTED.emittedProfileSha256,
    exact_model_sha256_verified: EXPECTED.modelSha256, new_vocab_and_independent_jinja_reviewed: true, new_three_synthetic_metal_reviewed: true,
    prerequisite_sha256: Object.fromEntries(Object.entries(plan.prerequisites).map(([key, value]) => [key, value.sha256])),
    production_role_approval: false, held_out_TEST_authorized: false };
  assert.doesNotThrow(() => checkRootClearance(clearance, bytes, plan));
  assert.throws(() => checkRootClearance(clearance, Buffer.from('changed'), plan), /identities/);
  for (const change of [{ new_three_synthetic_metal_reviewed: false }, { physical_profile_sha256: EXPECTED.profileFileSha256 }, { production_role_approval: true }, { held_out_TEST_authorized: true }]) assert.throws(() => checkRootClearance({ ...clearance, ...change }, bytes, plan));
  const missing = structuredClone(clearance); delete missing.prerequisite_sha256.metal_audit; assert.throws(() => checkRootClearance(missing, bytes, plan), /prerequisite/);
});
test('all-194 independent Jinja preflight rejects one missing/duplicate or changed row', () => {
  let fixture = renderFixture(); assert.equal(verifyIndependentRender(fixture.reference, fixture.requests, fixture.requestBytes, fixture.runtime), true);
  fixture = renderFixture(); fixture.reference.rows.pop(); assert.throws(() => verifyIndependentRender(fixture.reference, fixture.requests, fixture.requestBytes, fixture.runtime), /coverage/);
  fixture = renderFixture(); fixture.reference.rows[193] = fixture.reference.rows[192]; assert.throws(() => verifyIndependentRender(fixture.reference, fixture.requests, fixture.requestBytes, fixture.runtime), /duplicate/);
  fixture = renderFixture(); fixture.reference.rows[19].logical_messages_sha256 = '0'.repeat(64); assert.throws(() => verifyIndependentRender(fixture.reference, fixture.requests, fixture.requestBytes, fixture.runtime), /logical messages/);
  fixture = renderFixture(); fixture.reference.rows[5].rendered += '<bos>'; fixture.reference.rows[5].rendered_sha256 = sha(fixture.reference.rows[5].rendered); assert.throws(() => verifyIndependentRender(fixture.reference, fixture.requests, fixture.requestBytes, fixture.runtime), /BOS/);
});
test('compile metadata rejects missing static library and protected-source drift', () => {
  const evidence = { kind: 'ROOT_successor_runtime_compile', compiler_exit_code: 0, source_sha256: EXPECTED.sourceSha256,
    binary_sha256: RELEASED_BINARY.sha256, binary_bytes: RELEASED_BINARY.bytes, reused_library_sha256: { ...STATIC_LIBRARIES },
    vendor_revision: 'f072b103714dfa1eee531f80b24512faf38e3dd2', compiler_argv: Object.keys(STATIC_LIBRARIES).map(path => ROOT_PATH(path)),
    protected_source_hashes_before: { invented: '1'.repeat(64) }, protected_source_hashes_after: { invented: '1'.repeat(64) },
    native_binary_executed: false, model_tokenizer_native_GPU_network_or_auth_executed: false, held_out_TEST_read: false, production_role_approved: false };
  assert.doesNotThrow(() => validateCompileEvidence(evidence));
  const incomplete = structuredClone(evidence); delete incomplete.reused_library_sha256[Object.keys(STATIC_LIBRARIES)[0]]; assert.throws(() => validateCompileEvidence(incomplete), /static-library/);
  const drift = structuredClone(evidence); drift.protected_source_hashes_after.invented = '2'.repeat(64); assert.throws(() => validateCompileEvidence(drift), /drift/);
});
const ROOT_PATH = path => '/Users/bsonntag/code/simple-jev-ts/' + path;
test('actual token accounting uses native decode 2048, not physical ubatch512 or old decode256', async () => {
  const profile = await candidateProfile(); const provenance = mockedProvenance(profile); const compiled = { tokens: Array(2048).fill(3) };
  const good = tokenMetrics(provenance, 2048); assert.doesNotThrow(() => verifyNativeMetrics(good, compiled, profile));
  for (const wrong of [4, 8]) assert.throws(() => verifyNativeMetrics({ ...good, engine_forwards: wrong }, compiled, profile), /2048-decode/);
  assert.throws(() => verifyNativeMetrics({ ...good, computed_prompt_tokens: 2047 }, compiled, profile), /accounting/);
  assert.throws(() => validateProvenance({ ...provenance, physical_profile_sha256: EXPECTED.profileFileSha256 }, profile), /emitted profile/);
});
test('initialization or partial transport failure retains every missing row as an attributed failure', async () => {
  const compiler = await compilerModule(); const profile = await candidateProfile();
  const records = Array.from({ length: 194 }, (_, index) => ({ id: 'invented-failure-' + index, request: { model: 'invented-model', state: 'invented context',
    questions: [{ id: 'q', type: 'choice', instructions: 'invented instruction', criteria: [{ id: 'A', description: 'invented A' }, { id: 'B', description: 'invented B' }] }] } }));
  const plan = { ...profile, sources: { prototype: { sha256: EXPECTED.sourceSha256 } }, artifacts: { binary: RELEASED_BINARY },
    inputs: [{ record_manifest: records.map(record => ({ record_id: record.id, logical_id: EXPECTED.logicalId, logical_prompt_sha256: compiler.compileHalfGrid(record.request).logical_prompt_sha256 })) }] };
  const all = failedRemainingEnvelopes(records, plan, 0, 'mocked initialization failed');
  assert.equal(all.length, 194); assert.deepEqual(all.map(row => row.record_id), records.map(record => record.id));
  assert.ok(all.every(row => row.error === 'mocked initialization failed' && row.logical_id === EXPECTED.logicalId && row.physical_profile_sha256 === profile.physical_profile_sha256 && !('response' in row)));
  assert.equal(failedRemainingEnvelopes(records, plan, 13, 'mocked transport failed').length, 181);
  assert.throws(() => failedRemainingEnvelopes(records, plan, 195, 'invalid'), /coverage/);
});
test('mocked new classifier forwards stage signal and retains new half-grid metadata/units', async () => {
  const compiler = await compilerModule(); const profile = await candidateProfile(); const provenance = mockedProvenance(profile);
  const record = { id: 'invented-score', request: { model: 'invented-model', state: 'Explicit rule: one completed part earns half credit.',
    questions: [{ id: 'earned', type: 'score', instructions: 'Apply explicit earned half credit.', criteria: ['no earned credit', 'one earned point'] }] } };
  const logical = compiler.compileHalfGrid(record.request); const branch = logical.questions[0]; const rendered = '<bos>invented' + EXPECTED.generationBoundary + branch.answer_prefix;
  const plan = { ...profile, artifacts: { model: { sha256: EXPECTED.modelSha256, bytes: EXPECTED.modelBytes }, binary: RELEASED_BINARY },
    sources: { prototype: { sha256: EXPECTED.sourceSha256 } }, inputs: [{ record_manifest: [{ record_id: record.id, logical_prompt_sha256: logical.logical_prompt_sha256 }] }] };
  const token_ids = Object.fromEntries(branch.output_labels.map((label, index) => [label, 10 + index])); const tokens = [2, 3, 4];
  const controller = new AbortController(); const calls = []; const sink = [];
  const rpc = { snapshot: () => ({ state: 'running', failureCode: null, exitCode: null }), request: async (request, options) => {
    calls.push({ request, signal: options.signal });
    if (request.op === 'compile') return { v: 1, id: request.id, result: [{ branch_id: branch.branch_id, tokens, token_ids, rendered,
      rendered_generation_boundary: EXPECTED.generationBoundary + branch.answer_prefix, provenance }] };
    return { v: 1, id: request.id, result: { input_tokens: tokens.length, metrics: tokenMetrics(provenance, tokens.length),
      logits: { [branch.branch_id]: Object.fromEntries(branch.output_labels.map(label => [label, label === 'B' ? 20 : -20])) } } };
  } };
  const classifier = new SuccessorResearchClassifier({ rpc, plan, compiler, orderedRecords: [record], renderReference: { rows: [{ record_id: record.id, branch_id: branch.branch_id, rendered, rendered_sha256: sha(rendered), final_two_user_messages_merged: false }] }, evidenceSink: async entry => sink.push(entry), signal: controller.signal });
  const result = await classifier.classifyRecord(record);
  assert.equal(result.error, undefined); assert.equal(result.response.metadata.template_version, EXPECTED.logicalId);
  assert.equal(result.response.metadata.logical_prompt_sha256, logical.logical_prompt_sha256);
  assert.equal(result.response.metadata.research_profile, EXPECTED.profile); assert.equal(result.response.metadata.physical_profile_sha256, profile.physical_profile_sha256);
  assert.equal(result.response.answers.earned.score, 0.5); assert.equal(result.response.usage.output_tokens, 0);
  assert.ok(calls.every(call => call.signal === controller.signal)); assert.equal(calls[1].request.full, true);
  assert.equal(sink[0], result); assert.equal(result.questions[0].native_metrics.engine_forwards, 1);
});

async function inventedEightProofFixture() {
  const compiler = await compilerModule(); const profile = await candidateProfile(); const vocabProvenance = mockedProvenance(profile, true); const metalProvenance = mockedProvenance(profile);
  const plan = { ...profile, sources: { prototype: { path: CANDIDATE + '/main.cpp', sha256: EXPECTED.sourceSha256, bytes: 34498 },
    compile: { sha256: 'c'.repeat(64) } }, artifacts: { binary: { path: BINARY, ...RELEASED_BINARY },
    model: { path: MODEL, sha256: EXPECTED.modelSha256, bytes: EXPECTED.modelBytes }, template: { path: TEMPLATE, sha256: EXPECTED.templateSha256, bytes: EXPECTED.templateBytes } },
    prerequisites: Object.fromEntries(PREREQUISITE_KEYS.map((key, index) => [key, { sha256: (index + 1).toString(16).repeat(64) }])) };
  const requests = [
    { model: 'invented-model', state: 'invented red context', questions: [{ id: 'q', type: 'choice', instructions: 'invented choose red', criteria: [{ id: 'red', description: 'red' }, { id: 'blue', description: 'blue' }] }] },
    { model: 'invented-model', state: 'invented explicit earned half rule and one completed part', questions: [{ id: 'q', type: 'score', instructions: 'invented explicit earned half credit', criteria: ['zero earned', 'one earned'] }] },
    { model: 'invented-model', state: 'invented unresolved context', questions: [{ id: 'q', type: 'noul', instructions: 'invented did the event finish?' }] },
  ];
  const prepared = requests.map((request, index) => ({ id: 'invented-synthetic-' + index, request,
    plan: compiler.compileHalfGrid({ ...request, options: { template_version: 'v2', raw_logits: true } }) }));
  const identities = [plan.sources.prototype, ...Object.values(plan.artifacts)];
  const vocabulary_plan = { identities, prepared, init: { ...initRequest(), vocab_only: true, device: 'cpu' }, independent_render_sha256: plan.prerequisites.jinja.sha256 };
  const metal_plan = { identities, prepared, init: initRequest(), independent_render_sha256: 'd'.repeat(64) };
  const compiled = (entry, provenance) => { const branch = entry.plan.questions[0]; return { branch_id: branch.branch_id, tokens: [2, 3, 4],
    token_ids: Object.fromEntries(branch.output_labels.map((label, index) => [label, 10 + index])), rendered: '<bos>invented-render-' + entry.id + EXPECTED.generationBoundary + branch.answer_prefix,
    rendered_generation_boundary: EXPECTED.generationBoundary + branch.answer_prefix, provenance }; };
  const compilation = (entry, index, provenance) => ({ request: { v: 1, id: 'probe-' + index, op: 'compile', branches: [wireBranch(entry.plan.questions[0])] },
    response: { v: 1, id: 'probe-' + index, result: [compiled(entry, provenance)] } });
  const vocabulary = { kind: 'ROOT_successor_vocabulary_only_proof', passed: true, probe_contracts_passed: true, evaluation_rejected: true,
    run_plan_sha256: plan.prerequisites.vocabulary_plan.sha256, quality_or_gain_proven: false, production_role_approval: false,
    actual_emitted_physical_profile_sha256: EXPECTED.emittedProfileSha256, physical_profile_file_sha256: EXPECTED.profileFileSha256,
    owned_pid: 12345, owned_native: terminal(), cleanup: terminal(), rpc: [
      { request: vocabulary_plan.init, response: { result: { provenance: vocabProvenance } } },
      ...prepared.map((entry, index) => compilation(entry, index, vocabProvenance)), { request: { op: 'evaluate' }, response: { error: { kind: 'invalid_request' } } },
    ] };
  const jinja = { kind: 'gemma4_independent_full_validation_jinja_render', native_or_model_execution: false,
    original_raw_template_sha256: EXPECTED.templateSha256, original_raw_template_bytes: EXPECTED.templateBytes, python_jinja_version: '3.1.6',
    rows: prepared.map(entry => { const branch = compiled(entry, vocabProvenance); return { record_id: entry.id, branch_id: branch.branch_id, rendered: branch.rendered, rendered_sha256: sha(branch.rendered) }; }) };
  const vocabulary_receipt = { kind: 'ROOT_successor_vocabulary_final_receipt', logical_id: EXPECTED.logicalId, proof_sha256: plan.prerequisites.vocabulary.sha256,
    owned_pid: 12345, owned_pid_absent: true, exit_and_stdio_close_observed: true, all_three_actual_original_Jinja_BOS_one_token_contracts_recomputed: true,
    weights_and_context_loaded: false, actual_native_GPU_inference: false, quality_or_gain_proven: false, production_role_approved: false,
    actual_emitted_physical_profile_sha256: EXPECTED.emittedProfileSha256, physical_profile_file_sha256: EXPECTED.profileFileSha256 };
  const attribution = { source_sha256: EXPECTED.sourceSha256, binary_sha256: RELEASED_BINARY.sha256, model_sha256: EXPECTED.modelSha256,
    logical_id: EXPECTED.logicalId, actual_emitted_physical_profile_sha256: EXPECTED.emittedProfileSha256, physical_profile_file_sha256: EXPECTED.profileFileSha256 };
  const metal_raw = { ...attribution, passed: false, run_plan_sha256: plan.prerequisites.metal_plan.sha256,
    error: 'AssertionError [ERR_ASSERTION]: Synthetic answer did not pass original scoring', owned_pid: 12345, owned_native: terminal(), cleanup: terminal(),
    synthetic_rows: [], rpc: [{ request: metal_plan.init, response: { result: { provenance: metalProvenance } } }] };
  const rows = [];
  const { scorePrediction } = await import('../../../../dist/evaluation.js');
  for (let index = 0; index < 3; index++) {
    const entry = prepared[index]; const branch = entry.plan.questions[0]; const actual = compiled(entry, metalProvenance); const metrics = tokenMetrics(metalProvenance, 3);
    const selected = index === 0 ? branch.output_labels[0] : index === 1 ? 'B' : '5';
    const logits = { [branch.branch_id]: Object.fromEntries(branch.output_labels.map(label => [label, label === selected ? 20 : -20])) };
    metal_raw.rpc.push(compilation(entry, index, metalProvenance), { request: { v: 1, id: 'evaluate-' + index, op: 'evaluate', full: true, branches: [{ branch_id: actual.branch_id, tokens: actual.tokens, token_ids: actual.token_ids }] },
      response: { v: 1, id: 'evaluate-' + index, result: { input_tokens: 3, metrics, logits } } });
    const typed = compiler.responseHalfGrid(entry.plan, logits, 3, true, { metrics, metadata: { actual_mode: 'quantized_metal', physical_profile_sha256: EXPECTED.emittedProfileSha256,
      prototype_source_sha256: EXPECTED.sourceSha256, binary_sha256: RELEASED_BINARY.sha256, raw_model_sha256: EXPECTED.modelSha256, probabilities_calibrated: false, production_role_approved: false } });
    const grade = scorePrediction(entry.plan.request.questions[0], { answer: index === 0 ? 'red' : index === 1 ? 0.5 : null }, typed.answers.q);
    if (index < 2) metal_raw.synthetic_rows.push({ actual_response: typed, grade });
    rows.push({ record_id: entry.id, type: entry.plan.request.questions[0].type, compiled_prompt_sha256: entry.plan.logical_prompt_sha256,
      original_jinja_render_match: true, exactly_one_BOS: true, unchanged_native_one_distinct_token_guard_passed: true,
      synthetic_scoring_passed: true, generated_output_tokens: 0, full_clear_before_after_rule: 'frozen unchanged native source plus actual full:true operation',
      actual_metrics: metrics, raw_selected_logits: logits, actual_response: typed, original_grade: grade });
  }
  const metal_audit = { ...attribution, kind: 'ROOT_successor_three_synthetic_metal_result_audit', original_proof_sha256: plan.prerequisites.metal.sha256,
    run_plan_sha256: plan.prerequisites.metal_plan.sha256, original_command_exit_code: 1, original_probe_passed: false,
    original_failure_due_to_missing_unknown_correct_field_only: true, raw_proof_and_RPC_rewritten: false, new_native_or_GPU_execution: false,
    submitted_native_evaluations: 3, passed: true, probe_contracts_passed: true, all_three_original_scoring_checks_passed: true, synthetic_rows: rows,
    compile_evidence_sha256: plan.sources.compile.sha256, independent_render_sha256: metal_plan.independent_render_sha256, generated_output_tokens: 0,
    input_tokens: 9, owned_pid: 12345, owned_pid_absent: true, exit_and_stdio_close_observed: true, weights_and_context_loaded: true, actual_native_GPU_inference: true,
    quality_or_gain_proven: false, production_role_approved: false, approval_effect: 'none', held_out_TEST_read: false };
  const metal_receipt = { ...attribution, kind: 'ROOT_successor_three_synthetic_metal_final_receipt', proof_sha256: plan.prerequisites.metal.sha256,
    audit_sha256: plan.prerequisites.metal_audit.sha256, run_plan_sha256: plan.prerequisites.metal_plan.sha256, owned_pid: 12345, owned_pid_absent: true,
    exit_and_stdio_close_observed: true, original_command_exit_code: 1, original_probe_passed: false, original_failure_due_to_missing_unknown_correct_field_only: true,
    audited_probe_contracts_and_original_scoring_passed: true, all_three_actual_original_Jinja_BOS_one_token_contracts_recomputed: true,
    actual_native_GPU_inference: true, weights_and_context_loaded: true, quality_or_gain_proven: false, production_role_approved: false, approval_effect: 'none' };
  return { plan, compiler, proofs: { vocabulary, vocabulary_plan, jinja, vocabulary_receipt, metal: metal_raw, metal_plan, metal_audit, metal_receipt } };
}
test('invented eight-proof schema allows repeated branch0 IDs while retaining host failure and separate audit', async () => {
  const fixture = await inventedEightProofFixture();
  assert.doesNotThrow(() => validateNewPrerequisites(fixture.proofs, fixture.plan, fixture.compiler));
  assert.equal(fixture.proofs.metal.passed, false); assert.equal(fixture.proofs.metal_audit.original_command_exit_code, 1);
  assert.equal(fixture.proofs.metal_audit.synthetic_rows[2].original_grade.correct, undefined);
  for (const mutate of [
    proofs => { proofs.jinja.rows[2].record_id = proofs.jinja.rows[1].record_id; },
    proofs => { proofs.metal.passed = true; },
    proofs => { proofs.metal_audit.new_native_or_GPU_execution = true; },
    proofs => { proofs.metal_audit.synthetic_rows[2].original_grade.correct = true; },
    proofs => { proofs.metal_plan.prepared[0].id = 'changed-event-id'; proofs.metal_audit.synthetic_rows[0].record_id = 'changed-event-id'; },
    proofs => { proofs.metal.rpc[5].response.result[0].rendered = proofs.metal.rpc[5].response.result[0].rendered.replace('invented-render-', 'mutated-render-'); },
    proofs => { proofs.metal.rpc[6].response.result.metrics.engine_forwards = 4; },
    proofs => { proofs.metal_receipt.audit_sha256 = '0'.repeat(64); },
  ]) {
    const changed = structuredClone(fixture.proofs); mutate(changed); assert.throws(() => validateNewPrerequisites(changed, fixture.plan, fixture.compiler));
  }
});
