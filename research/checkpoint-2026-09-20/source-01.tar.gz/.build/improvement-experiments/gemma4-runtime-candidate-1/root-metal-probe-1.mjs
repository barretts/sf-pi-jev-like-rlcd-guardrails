import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, writeFile, mkdir, stat } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { scorePrediction } from '../../../dist/evaluation.js';
import { OwnedRpc } from '../gemma4-label-prototype/research-quality/rpc.mjs';
import { compileHalfGrid, responseHalfGrid } from '../fractional-score-hypothesis/candidate-2/grid.mjs';

assert.equal(process.argv[2], '--ROOT-three-synthetic-Metal', 'No implicit native execution');
const root = '/Users/bsonntag/code/simple-jev-ts', here = dirname(fileURLToPath(import.meta.url));
assert.equal(resolve(process.cwd()), root);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const execute = promisify(execFile);
const model = join(root, 'models/gemma-4-31B_q4_0-it.gguf');
const template = join(root, 'models/gemma-4-31B-it.chat_template.jinja');
const binary = join(here, 'gemma4-label-prototype');
const profileFile = JSON.parse(await readFile(join(here, 'physical-profile.json')));
const compile = JSON.parse(await readFile(join(here, 'compile-evidence-root-1.json')));
const priorVocabBytes = await readFile(join(here, 'vocab-proof-root-1/proof.json'));
assert.equal(sha(priorVocabBytes), '13ed29ed2f54a3a4c82b886cd5723461bf97d468059ce07b3cc24b5d95c95dc3');
const priorVocab = JSON.parse(priorVocabBytes);
assert.equal(priorVocab.passed, true);
const priorVocabReceipt = JSON.parse(await readFile(join(here, 'vocab-proof-root-1/root-final-receipt-1.json')));
assert.equal(priorVocabReceipt.owned_pid_absent, true);
assert.equal(priorVocabReceipt.proof_sha256, sha(priorVocabBytes));
const identities = [];
async function identify(path, expected, bytes) {
  const info = await stat(path); assert.ok(info.isFile()); if (bytes !== undefined) assert.equal(info.size, bytes);
  const hash = createHash('sha256'); for await (const chunk of createReadStream(path)) hash.update(chunk);
  const result = { path, bytes: info.size, sha256: hash.digest('hex') };
  if (expected) assert.equal(result.sha256, expected, path); identities.push(result); return result;
}
assert.equal(compile.compiler_exit_code, 0);
await identify(join(here, 'main.cpp'), 'c0919f79087e4bf3ce4f6332956b79d7b9e9bb415a250288fb47bcecd7ca64b8');
await identify(binary, 'cd437329ecbecbcd3db2fc81b90f22c2b603d77b9f4b97f1abf0861b333fdfd2', 9671688);
await identify(model, '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b', 17651001568);
await identify(template, 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4', 18683);
for (const [path, expected] of Object.entries(compile.reused_library_sha256)) await identify(join(root, path), expected);
await identify(join(root, '.build/improvement-experiments/fractional-score-hypothesis/candidate-2/grid.mjs'),
  '92176c96d6a49a600c281c43578eb55aea20082b0847019bfef64282f7b40872');
await identify(join(root, '.build/improvement-experiments/gemma4-label-prototype/research-quality/rpc.mjs'),
  '8980b01e27b306ebd21f1ad788056f1eb2e5a1a3124f97691ba0e10b16b5f770');
const renderer = join(root, '.build/improvement-experiments/gemma4-label-prototype/research-quality/render-reference.py');
await identify(renderer, 'cd7aa8aa765d5870c7619656bd8009e638f65248107faed2c7fc2c26cf941546');
const { stdout: ps } = await execute('/bin/ps', ['-axo', 'pid,ppid,rss,comm'], { timeout: 10000, maxBuffer: 1024 * 1024 });
assert.deepEqual(ps.split('\n').filter(line => /llama-server|gemma4-label-prototype/.test(line)), []);
const probes = [
  { id: 'synthetic-choice', request: { model: profileFile.id, state: 'The bicycle is red.', questions: [{ id: 'q', type: 'choice',
    instructions: 'Which color is the bicycle?', criteria: [{ id: 'red', description: 'Red bicycle' }, { id: 'blue', description: 'Blue bicycle' }] }] } },
  { id: 'synthetic-earned-half', request: { model: profileFile.id, messages: [{ role: 'user', content:
    'Check A is documented as partially implemented. Check B is absent.' }], questions: [{ id: 'q', type: 'score',
    instructions: 'Award one point for each of checks A and B that is fully implemented. An explicitly documented partially implemented check earns half a point. An absent check earns zero. Return total earned points.',
    criteria: ['Zero earned points', 'One earned point', 'Two earned points'] }] } },
  { id: 'synthetic-unknown', request: { model: profileFile.id, state: 'The review outcome has not been recorded.', questions: [{ id: 'q', type: 'noul',
    instructions: 'The review was approved.' }] } },
];
const prepared = probes.map(probe => ({ ...probe, plan: compileHalfGrid({ ...probe.request, options: { template_version: 'v2', raw_logits: true } }) }));
const wire = branch => ({ branch_id: branch.branch_id, messages: branch.messages,
  answer_prefix: branch.answer_prefix, output_labels: branch.output_labels });
const output = join(here, 'metal-proof-root-1'); await mkdir(output, { mode: 0o700 });
const requestsPath = join(output, 'render-requests.json');
await writeFile(requestsPath, JSON.stringify(prepared.map(probe => ({ record_id: probe.id, branch: wire(probe.plan.questions[0]) }))) + '\n', { flag: 'wx', mode: 0o600 });
await execute('/usr/bin/env', ['python3', renderer, '--requests', requestsPath, '--output', join(output, 'independent-render.json'),
  '--template', template, '--expected-sha256', 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4'],
  { timeout: 60000, maxBuffer: 1024 * 1024 });
const referenceBytes = await readFile(join(output, 'independent-render.json')), reference = JSON.parse(referenceBytes);
assert.equal(reference.rows.length, 3);
const init = { v: 1, id: 'init', op: 'init', research_profile: profileFile.id, model_file: model, chat_template_file: template,
  vocab_only: false, device: 'metal', max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048 };
const frozen = { kind: 'ROOT_successor_three_synthetic_metal_frozen_plan', created_at: new Date().toISOString(), init,
  physical_profile_file_sha256: sha(await readFile(join(here, 'physical-profile.json'))),
  requested_profile: profileFile, prepared, identities, independent_render_sha256: sha(referenceBytes),
  native_weights_or_context_permitted: true, actual_native_GPU_inference_permitted: true,
  approval_effect: 'none', held_out_TEST_read: false };
const planBytes = Buffer.from(JSON.stringify(frozen, null, 2) + '\n');
await writeFile(join(output, 'run-plan.json'), planBytes, { flag: 'wx', mode: 0o400 });
const proof = { kind: 'gemma4_runtime_candidate_three_synthetic_metal_proof', run_plan_sha256: sha(planBytes), rpc: [],
  probe_contracts_passed: false, synthetic_rows: [], quality_or_gain_proven: false, production_role_approval: false };
let rpc, failure;
try {
  rpc = OwnedRpc.spawn(binary, [], { cwd: here, requestTimeoutMs: 60000, totalTimeoutMs: 300000,
    maxPacketBytes: 262144, maxResponseBytes: 67108864, maxStderrBytes: 16777216, exitTimeoutMs: 10000 });
  proof.owned_pid = rpc.snapshot().pid;
  const request = async value => { const response = await rpc.request(value); proof.rpc.push({ request: value, response }); return response; };
  const initialized = await request(init); assert.ok(!initialized.error);
  const provenance = initialized.result.provenance;
  assert.deepEqual(provenance.physical_profile, profileFile);
  assert.equal(provenance.physical_profile_sha256, sha(JSON.stringify(provenance.physical_profile)));
  assert.equal(provenance.physical_profile_sha256, priorVocab.actual_emitted_physical_profile_sha256);
  assert.equal(provenance.prototype_source_sha256, compile.source_sha256);
  assert.equal(provenance.actual_mode, 'quantized_metal');
  for (const key of ['weights_loaded', 'context_created', 'explicit_backend_init']) assert.equal(provenance[key], true);
  assert.equal(provenance.vocab_only, false); assert.equal(provenance.device, 'metal');
  proof.actual_emitted_physical_profile_sha256 = provenance.physical_profile_sha256;
  proof.physical_profile_file_sha256 = frozen.physical_profile_file_sha256;
  for (let index = 0; index < prepared.length; index++) {
    const branch = prepared[index].plan.questions[0];
    const compiled = await request({ v: 1, id: 'probe-' + index, op: 'compile', branches: [wire(branch)] });
    assert.ok(!compiled.error); assert.equal(compiled.result.length, 1);
    const row = compiled.result[0]; assert.equal(row.rendered, reference.rows[index].rendered);
    assert.equal(row.tokens[0], 2); assert.equal(row.tokens.filter(token => token === 2).length, 1);
    assert.deepEqual(Object.keys(row.token_ids).sort(), [...branch.output_labels].sort());
    assert.equal(new Set(Object.values(row.token_ids)).size, branch.output_labels.length);
    assert.equal(row.rendered_generation_boundary, '<|turn>model\n<|channel>thought\n<channel|>' + branch.answer_prefix);
    const evaluated = await request({ v: 1, id: 'evaluate-' + index, op: 'evaluate', full: true,
      branches: [{ branch_id: row.branch_id, tokens: row.tokens, token_ids: row.token_ids }] });
    assert.ok(!evaluated.error);
    const raw = evaluated.result, metrics = raw.metrics;
    assert.equal(raw.input_tokens, row.tokens.length);
    assert.equal(metrics.backend, 'llama.cpp'); assert.equal(metrics.prefill_strategy, 'full');
    for (const key of ['prefix_tokens', 'branch_output_tokens', 'padded_suffix_tokens']) assert.equal(metrics[key], 0);
    for (const key of ['computed_prompt_tokens', 'branch_prompt_tokens', 'logical_prefill_tokens']) assert.equal(metrics[key], row.tokens.length);
    assert.equal(metrics.engine_forwards, Math.ceil(row.tokens.length / 2048));
    assert.equal(metrics.scored_positions, 1); assert.deepEqual(metrics.suffix_batch_sizes, [1]);
    const typed = responseHalfGrid(prepared[index].plan, raw.logits, row.tokens.length, true,
      { metrics, metadata: { actual_mode: 'quantized_metal', physical_profile_sha256: provenance.physical_profile_sha256,
        prototype_source_sha256: compile.source_sha256, binary_sha256: compile.binary_sha256,
        raw_model_sha256: '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b',
        probabilities_calibrated: false, production_role_approved: false } });
    const expected = index === 0 ? 'red' : 0.5;
    const grade = scorePrediction(prepared[index].plan.request.questions[0], { answer: index === 2 ? null : expected }, typed.answers.q);
    assert.ok(grade.correct, 'Synthetic answer did not pass original scoring');
    assert.equal(typed.usage.output_tokens, 0);
    proof.synthetic_rows.push({ record_id: prepared[index].id, type: prepared[index].plan.request.questions[0].type,
      compiled_prompt_sha256: prepared[index].plan.logical_prompt_sha256, original_jinja_render_match: true,
      exactly_one_BOS: true, unchanged_native_one_distinct_token_guard_passed: true,
      raw_selected_logits: raw.logits, actual_response: typed, grade, actual_metrics: metrics,
      full_clear_before_after_rule: 'frozen unchanged native source plus full:true actual operation', generated_output_tokens: 0 });
  }
  proof.probe_contracts_passed = true;
} catch (error) { failure = String(error); proof.error = failure; }
finally {
  if (rpc) {
    try { proof.cleanup = await rpc.close(); }
    catch (error) { proof.cleanup_error = String(error); failure ??= String(error); }
    const state = rpc.snapshot(); proof.owned_native = state;
    if (state.exitCode !== 0 || state.signal !== null || !state.exitedObserved || !state.closedObserved || state.pendingRequests !== 0 || state.failureCode !== null) failure ??= 'Unproven native close';
    const offload = state.stderr.match(/offloaded (\d+)\/(\d+) layers to GPU/);
    if (!offload || offload[1] !== '61' || offload[2] !== '61') failure ??= 'Actual full Metal offload not observed';
    proof.actual_offloaded_layers = offload ? Number(offload[1]) : null;
    proof.actual_device_observation = state.stderr.match(/GPU name:\s*([^\n]+)/)?.[1] ?? null;
    proof.actual_flash_diagnostics = state.stderr.split('\n').filter(line => /flash_attn|flash attention/i.test(line));
    await writeFile(join(output, 'native-stderr.log'), state.stderr, { flag: 'wx', mode: 0o600 });
  }
  if (failure) proof.error = failure;
  proof.passed = !failure && proof.probe_contracts_passed && proof.synthetic_rows.length === 3 && proof.synthetic_rows.every(row => row.grade.correct);
  if (proof.cleanup?.cleanupError) { failure ??= String(proof.cleanup.cleanupError); proof.passed = false; }
  proof.binary_sha256 = compile.binary_sha256; proof.source_sha256 = compile.source_sha256;
  proof.logical_id = 'v2-earned-half-grid-alpha-research-1';
  proof.model_sha256 = '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b';
  proof.observed_at = new Date().toISOString();
  await writeFile(join(output, 'proof.json'), JSON.stringify(proof, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
}
console.log(JSON.stringify({ passed: proof.passed, actual_emitted_profile_sha256: proof.actual_emitted_physical_profile_sha256,
  prospective_file_sha256: proof.physical_profile_file_sha256, owned_pid: proof.owned_pid, proof_sha256: sha(await readFile(join(output, 'proof.json'))) }));
if (!proof.passed) process.exitCode = 1;
