export function summarizeContact(contact) {
    const name = contact.displayName?.trim() || null;
    const email = contact.email?.trim().toLowerCase() || null;
    return {
        label: name || email || "Anonymous contact",
        email,
    };
}
