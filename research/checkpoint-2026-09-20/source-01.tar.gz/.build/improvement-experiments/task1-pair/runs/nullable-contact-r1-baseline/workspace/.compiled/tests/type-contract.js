import { summarizeContact, } from "../src/contact.js";
const nullableInput = { displayName: null, email: null };
const nullableOutput = summarizeContact(nullableInput);
void nullableOutput;
