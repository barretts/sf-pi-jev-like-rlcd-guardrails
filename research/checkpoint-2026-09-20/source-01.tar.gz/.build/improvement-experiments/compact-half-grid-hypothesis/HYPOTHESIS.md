# Compact earned-point map: source-only hypothesis

Logical candidate: `v2-earned-half-grid-compact-map-research-1`.

This candidate changes one part of Alpha candidate 2's score prompt: each categorical map row keeps `label: earned_points=value` and removes its trailing `; original integer anchor N` or `; explicit earned half credit between original anchors L and U`. The complete original integer-anchor list already defines those anchors, and Alpha's entire preceding scoring-policy paragraph remains byte-for-byte intact. That paragraph still requires explicit question permission plus establishing evidence for earned half credit, applies the original anchors, prohibits invented partial credit, distinguishes earned credit from confidence, and selects integer totals otherwise.

The original request, contexts, message construction, selected question, full rubric entries, ORIGINAL maximum/normalization denominator, categorical label order, earned integer/half values, JSON output format and decoder stay unchanged. Choice and Noul branches are exactly Alpha's branches. Response decoding delegates to Alpha's existing production-core validation and point-unit conversion, then records this candidate's distinct research identity. Actual requested raw fields, probabilities, score expectation/variance and usage retain their meanings. No calibration, production default, artifact approval, role approval or fallback is introduced.

The redundant per-row annotations grow with the half-grid vocabulary: a maximum of N creates 2N+1 categorical entries. Removing those annotations could reduce score-branch prefill work without removing the question's evidence or score rules. CPU byte comparisons on explicitly authored contract probes can show shorter source strings; they do not show tokenizer counts, native execution or latency.

## Declared gates and falsifiers

Actual evaluation belongs only to ROOT's frozen matched benchmark and exclusive GPU lane. This source preparation does not read validation/test records, prior actual run proofs or model files, and does not execute models, native/tokenizer/Jinja code, training, servers or network requests.

The original full quality gates remain: choice accuracy at least 0.90; clear Noul accuracy at least 0.95; Noul Brier at most 0.10; normalized score MAE at most 0.10 using the ORIGINAL rubric maximum; uncertain Noul MAE at most 0.10; zero execution failures; every marked regression. Developer per-score acceptance must additionally be at least 0.90, with each score accepted only at normalized absolute error at most 0.10 using the unchanged ORIGINAL maximum. These are concurrent gates, not interchangeable alternatives.

Reject this candidate for any contract/context/choice/Noul construction difference beyond the declared score-map suffix deletion and distinct research identity; any changed label count/order/value, range, denominator, point moment, requested raw evidence or usage; failed one-token label guard; inappropriate earned-half-label behavior; any marked regression or original quality-gate failure; material score-quality regression; or no measured useful reduction in actual prompt work and accepted-result time under the matched conditions. The root's original end-to-end success thresholds also remain: direct accepted decisions require at least a twofold matched time gain with equivalent quality/coverage; complete pi requires at least 20% median latency improvement or 30% less actual generative work with equivalent correctness and no material latency regression. A smaller prompt alone establishes neither result.

A fractional returned score is a probability-weighted expectation in original point units. It can arise from mixed integer-label mass; fractionality alone is not evidence of invented half credit. Actual quality checks must use original earned-sum targets and the explicitly permitted half-credit semantics, rather than interpret the expectation as confidence or automatically reject every fractional mean.

## CPU-only checks and ownership

Run from `/Users/bsonntag/code/simple-jev-ts`:

```sh
node --test .build/improvement-experiments/compact-half-grid-hypothesis/grid.test.mjs
```

The checks use only authored CPU requests and supplied synthetic logits, exercising exact suffix-only construction, state/chat preservation, all categorical values and original maxima, choice/Noul equivalence, decoder moments/raw-field retention, input immutability and rejection without fallback. Public exports are `LOGICAL_ID`, `MAX_ORIGINAL_SCORE`, `compileHalfGrid(input)` and `responseHalfGrid(plan, logits, inputTokens, advanced, extra)`, matching Alpha's adapter shape.

Owned new source inventory is limited to this folder: `grid.mjs`, `grid.test.mjs`, `HYPOTHESIS.md` and `candidate.json`. Alpha candidate 2 and the frozen successor proposal remain unchanged. `candidate.json` declares source identity and gates; it is not an execution or approval report. Ownership is released after CPU checks for ROOT's review and optional separately authorized model evaluation. This agent will not launch later model runs.
