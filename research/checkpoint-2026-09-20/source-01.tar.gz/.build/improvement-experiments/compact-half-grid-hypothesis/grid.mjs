import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import {
  compileHalfGrid as compileAlpha,
  responseHalfGrid as responseAlpha,
  LOGICAL_ID as ALPHA_LOGICAL_ID,
  MAX_ORIGINAL_SCORE,
} from '../fractional-score-hypothesis/candidate-2/grid.mjs';

// Source-only research candidate. This module never starts a model, tokenizer,
// native runtime, training job, server or artifact approval.
export const LOGICAL_ID = 'v2-earned-half-grid-compact-map-research-1';
export { MAX_ORIGINAL_SCORE };

const MAP_HEADING = '\nCategorical output label to ORIGINAL earned point value:\n';
const RETURN_FORMAT = '\nReturn only JSON with one answer field containing the selected label as a string.';
const sha = value => createHash('sha256').update(value).digest('hex');

function compactInstruction(branch) {
  const values = branch.research_score_values;
  const expanded = branch.output_labels.map((label, index) => {
    const value = values[index];
    return label + ': earned_points=' + value
      + (Number.isInteger(value) ? '; original integer anchor ' + value
        : '; explicit earned half credit between original anchors '
          + Math.floor(value) + ' and ' + Math.ceil(value));
  }).join('\n');
  const start = branch.instruction.lastIndexOf(MAP_HEADING);
  assert.ok(start >= 0, 'Alpha earned-point map heading changed');
  assert.ok(branch.instruction.endsWith(RETURN_FORMAT), 'Alpha answer-format instruction changed');
  assert.equal(
    branch.instruction.slice(start + MAP_HEADING.length, -RETURN_FORMAT.length),
    expanded,
    'Alpha earned-point map changed; do not silently compact another prompt',
  );
  const concise = branch.output_labels.map((label, index) =>
    label + ': earned_points=' + values[index]).join('\n');
  return branch.instruction.slice(0, start + MAP_HEADING.length) + concise + RETURN_FORMAT;
}

export function compileHalfGrid(input) {
  const alpha = compileAlpha(input);
  const questions = alpha.questions.map((branch, index) => {
    if (alpha.request.questions[index].type !== 'score') return branch;
    const instruction = compactInstruction(branch);
    const messages = structuredClone(branch.messages);
    const selected = messages.at(-1);
    assert.equal(selected?.role, 'user', 'Alpha selected-question message changed');
    assert.ok(selected.content.endsWith(branch.instruction), 'Alpha selected-question suffix changed');
    selected.content = selected.content.slice(0, -branch.instruction.length) + instruction;
    return { ...branch, instruction, messages };
  });
  return {
    ...alpha,
    template_version: LOGICAL_ID,
    questions,
    research_contract: {
      ...alpha.research_contract,
      logical_id: LOGICAL_ID,
      base_logical_id: ALPHA_LOGICAL_ID,
      compaction: 'remove_only_repeated_per_label_anchor_annotations',
    },
    logical_prompt_sha256: sha(JSON.stringify(questions)),
  };
}

export function responseHalfGrid(plan, logits, inputTokens = 0, advanced = false, extra = {}) {
  assert.equal(plan.template_version, LOGICAL_ID, 'Unsupported compact half-grid logical plan');
  assert.equal(plan.research_contract?.logical_id, LOGICAL_ID, 'Missing compact half-grid contract');
  assert.equal(plan.research_contract.base_logical_id, ALPHA_LOGICAL_ID, 'Changed compact base contract');
  assert.equal(plan.logical_prompt_sha256, sha(JSON.stringify(plan.questions)), 'Compact logical prompt changed');
  // Reuse Alpha's exact public-core validation and original-point decoder.
  // This is a declared source adapter, never a model/runtime fallback.
  const response = responseAlpha({
    ...plan,
    template_version: ALPHA_LOGICAL_ID,
    research_contract: { ...plan.research_contract, logical_id: ALPHA_LOGICAL_ID },
  }, logits, inputTokens, advanced, extra);
  plan.request.questions.forEach(question => {
    if (question.type === 'score') response.answers[question.id].research_template = LOGICAL_ID;
  });
  response.metadata.template_version = LOGICAL_ID;
  response.metadata.logical_prompt_sha256 = plan.logical_prompt_sha256;
  response.metadata.research_contract = plan.research_contract;
  response.metadata.calibration = 'not_calibrated';
  response.metadata.approval_effect = 'none';
  return response;
}
