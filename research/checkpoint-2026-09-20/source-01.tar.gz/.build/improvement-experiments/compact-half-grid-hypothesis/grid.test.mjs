import assert from 'node:assert/strict';
import test from 'node:test';
import {
  compileHalfGrid as compileAlpha,
  responseHalfGrid as responseAlpha,
} from '../fractional-score-hypothesis/candidate-2/grid.mjs';
import { compileHalfGrid, responseHalfGrid, LOGICAL_ID, MAX_ORIGINAL_SCORE } from './grid.mjs';

// All inputs and logits below are authored CPU contract probes, not captured
// model answers, benchmark examples, or validation/test data.
const scoreQuestion = maximum => ({
  id: 'earned', type: 'score',
  instructions: {
    task: 'Count verified repairs. Each verified condition earns one point.',
    half_credit: 'Only the explicitly recorded partial repair earns 0.5. Unknown conditions earn zero.',
    maximum,
  },
  criteria: Array.from({ length: maximum + 1 }, (_, value) => ({
    earned_points: value,
    evidence: value + ' verified condition(s); no credit for proposed or quoted repairs.',
  })),
});

function request(maximum = 2, context = 'state') {
  return {
    model: 'google/gemma-3-4b-it',
    ...(context === 'state' ? {
      state: { raw_log: 'FAIL: original condition.\nQuoted example: "all fixed".', result: 'one verified; one explicitly partial' },
    } : {
      messages: [
        { role: 'system', content: 'Original context policy\nbytes preserved.' },
        { role: 'user', content: 'Original failure: FAIL.\nQuoted: "all fixed".' },
        { role: 'assistant', content: 'A repair was proposed; no result recorded.' },
        { role: 'user', content: 'Actual result: one verified and one explicitly partial.' },
      ],
    }),
    questions: [
      { id: 'route', type: 'choice', instructions: 'Choose the available operation.', criteria: [
        { id: 'inspect', description: 'Read the failure evidence.' },
        { id: 'repair', description: 'Change code after inspecting evidence.' },
      ] },
      scoreQuestion(maximum),
      { id: 'known', type: 'noul', instructions: 'The original failure has been verified repaired.', criteria: {
        true: 'Actual passing evidence establishes the repair.',
        false: 'Actual failing evidence establishes the repair did not resolve the failure.',
      } },
    ],
    options: { template_version: 'v2', raw_logits: true },
  };
}

function freeze(value) {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}

function stripRedundantAnnotations(text) {
  return text.replace(/; original integer anchor \d+/g, '')
    .replace(/; explicit earned half credit between original anchors \d+ and \d+/g, '');
}

function logitsFor(plan, peak = null) {
  return Object.fromEntries(plan.questions.map(branch => [branch.branch_id,
    Object.fromEntries(branch.output_labels.map((label, index) => [label,
      peak === null ? (index - 2) * 0.13 : index === peak ? 12 : -12])),
  ]));
}

function withoutResearchIdentity(response) {
  const copy = structuredClone(response);
  delete copy.metadata.template_version;
  delete copy.metadata.logical_prompt_sha256;
  delete copy.metadata.research_contract;
  for (const answer of Object.values(copy.answers)) delete answer.research_template;
  return copy;
}

test('only map annotations change; original state/question/rubric and choice+Noul prompts remain identical', () => {
  const input = freeze(request());
  const before = JSON.stringify(input);
  const alpha = compileAlpha(input), compact = compileHalfGrid(input);
  assert.equal(JSON.stringify(input), before);
  assert.deepEqual(compact.request, alpha.request);
  assert.equal(compact.system_prompt_prefix, alpha.system_prompt_prefix);
  assert.equal(compact.prefix_instruction, alpha.prefix_instruction);
  assert.equal(compact.suffix_instruction, alpha.suffix_instruction);
  assert.equal(compact.template_version, LOGICAL_ID);
  compact.questions.forEach((branch, index) => {
    const original = alpha.questions[index];
    if (input.questions[index].type !== 'score') return assert.deepEqual(branch, original);
    assert.equal(branch.instruction, stripRedundantAnnotations(original.instruction));
    const expected = structuredClone(original);
    expected.instruction = stripRedundantAnnotations(expected.instruction);
    const final = expected.messages.at(-1);
    final.content = final.content.slice(0, -original.instruction.length) + expected.instruction;
    assert.deepEqual(branch, expected);
    assert.ok(branch.instruction.includes('Half points are earned credit, never confidence.'));
    assert.ok(branch.instruction.includes('Otherwise select an integer total.'));
  });
});

test('score chat preserves every supplied message byte and only compacts the appended question turn', () => {
  const input = freeze(request(2, 'chat'));
  const alpha = compileAlpha(input), compact = compileHalfGrid(input);
  const a = alpha.questions[1].messages, c = compact.questions[1].messages;
  assert.equal(c.length, a.length);
  assert.deepEqual(c.slice(0, -1), a.slice(0, -1));
  assert.equal(c.at(-1).content, stripRedundantAnnotations(a.at(-1).content));
  assert.equal(c[0].content, compact.system_prompt_prefix + compact.prefix_instruction + '\n' + input.messages[0].content);
  assert.deepEqual(c.slice(1, -1), input.messages.slice(1));
  assert.deepEqual(compact.questions[0], alpha.questions[0]);
  assert.deepEqual(compact.questions[2], alpha.questions[2]);
});

test('lookalike annotations inside original question/context data are preserved verbatim', () => {
  const input = request();
  input.state = 'Literal developer evidence: ; original integer anchor 7\n'
    + 'Categorical output label to ORIGINAL earned point value:\nnot an output map.';
  input.questions[1].instructions = 'Keep quoted text "; explicit earned half credit between original anchors 4 and 5" '
    + 'as data. Actual verified repair earns one point; only an explicit partial repair earns 0.5.';
  const alpha = compileAlpha(input), compact = compileHalfGrid(input);
  const a = alpha.questions[1], c = compact.questions[1];
  const heading = '\nCategorical output label to ORIGINAL earned point value:\n';
  const mapStart = a.instruction.lastIndexOf(heading);
  assert.equal(c.instruction.slice(0, mapStart), a.instruction.slice(0, mapStart));
  assert.ok(c.instruction.includes(input.questions[1].instructions));
  assert.ok(c.messages.at(-1).content.startsWith('Actual context:\n' + input.state + '\n\n'));
  assert.deepEqual(compact.request, alpha.request);
});

test('original maximum, ordered categorical vocabulary and every earned integer/half value are unchanged', () => {
  for (const maximum of [1, 2, 10, MAX_ORIGINAL_SCORE]) {
    const input = request(maximum), alpha = compileAlpha(input), compact = compileHalfGrid(input);
    const a = alpha.questions[1], c = compact.questions[1];
    assert.deepEqual(c.answer_labels, a.answer_labels);
    assert.deepEqual(c.output_labels, a.output_labels);
    assert.deepEqual(c.research_score_values, a.research_score_values);
    assert.equal(c.answer_prefix, a.answer_prefix);
    assert.equal(c.research_score_values.length, 2 * maximum + 1);
    assert.equal(c.research_score_values.at(-1), maximum);
    assert.ok(c.instruction.includes('ORIGINAL 0..' + maximum + ' rubric'));
    const instructionBytes = Buffer.byteLength(c.instruction);
    assert.ok(instructionBytes < Buffer.byteLength(a.instruction));
    assert.equal(compact.request.questions[1].criteria.length - 1, maximum);
  }
});

test('the same supplied CPU logits yield identical score moments/raw fields and unchanged choice+Noul answers', () => {
  const input = request(), alpha = compileAlpha(input), compact = compileHalfGrid(input);
  const supplied = freeze(logitsFor(alpha));
  const before = JSON.stringify(supplied);
  const a = responseAlpha(alpha, supplied, 321, true, { device: 'cpu_contract_probe' });
  const c = responseHalfGrid(compact, supplied, 321, true, { device: 'cpu_contract_probe' });
  assert.equal(JSON.stringify(supplied), before);
  assert.deepEqual(withoutResearchIdentity(c), withoutResearchIdentity(a));
  assert.deepEqual(c.answers.route, a.answers.route);
  assert.deepEqual(c.answers.known, a.answers.known);
  assert.equal(c.answers.earned.calibrated, false);
  assert.equal(c.metadata.calibration, 'not_calibrated');
  assert.equal(c.metadata.approval_effect, 'none');
  assert.equal(c.answers.earned.research_template, LOGICAL_ID);
  assert.deepEqual(c.usage, { input_tokens: 321, output_tokens: 0 });
  assert.deepEqual(Object.keys(c.answers.earned.probabilities), Object.keys(a.answers.earned.probabilities));
  assert.deepEqual(c.answers.earned.logits, a.answers.earned.logits);
  assert.equal(Object.keys(c.answers.earned.logits).length, 5);
  assert.deepEqual(c.answers.known.rating.logits, a.answers.known.rating.logits);
  assert.equal(c.answers.known.rating.logits.length, 9);
});

test('mass on every categorical label decodes in original point units, including explicit half credit', () => {
  const alpha = compileAlpha(request()), compact = compileHalfGrid(request());
  const branch = compact.questions[1];
  branch.output_labels.forEach((label, peak) => {
    const supplied = logitsFor(alpha, peak);
    const a = responseAlpha(alpha, supplied, 0, true), c = responseHalfGrid(compact, supplied, 0, true);
    assert.deepEqual(withoutResearchIdentity(c), withoutResearchIdentity(a));
    assert.ok(Math.abs(c.answers.earned.score - peak / 2) < 1e-8);
    assert.equal(c.answers.earned.output_label_to_earned_points[label], peak / 2);
    assert.ok(c.answers.earned.score >= 0 && c.answers.earned.score <= 2);
  });
});

test('uniform logits retain the same probability expectation; fractional means are not confidence', () => {
  const alpha = compileAlpha(request(1)), compact = compileHalfGrid(request(1));
  const supplied = Object.fromEntries(alpha.questions.map(branch => [branch.branch_id,
    Object.fromEntries(branch.output_labels.map(label => [label, 0])),
  ]));
  const a = responseAlpha(alpha, supplied, 0, true), c = responseHalfGrid(compact, supplied, 0, true);
  assert.deepEqual(withoutResearchIdentity(c), withoutResearchIdentity(a));
  assert.equal(c.answers.earned.score, 0.5);
  assert.equal(c.answers.earned.confidence, 1 / 3);
  assert.equal(c.answers.earned.variance, 1 / 6);
});

test('unsupported v1/range and changed logical plan are rejected without fallback', () => {
  assert.throws(() => compileHalfGrid({ ...request(), options: { template_version: 'v1' } }), /requires original v2/);
  assert.throws(() => compileHalfGrid(request(MAX_ORIGINAL_SCORE + 1)), /Unsupported half-grid/);
  const plan = compileHalfGrid(request()), supplied = logitsFor(plan);
  const changed = structuredClone(plan);
  changed.questions[1].instruction += '\nchanged';
  assert.throws(() => responseHalfGrid(changed, supplied), /logical prompt changed/);
  assert.throws(() => responseHalfGrid({ ...plan, template_version: 'v2' }, supplied), /Unsupported compact/);
  const missingLabel = structuredClone(supplied);
  delete missingLabel['1'][plan.questions[1].output_labels[0]];
  assert.throws(() => responseHalfGrid(plan, missingLabel), /logit|label|Expected/);
});
