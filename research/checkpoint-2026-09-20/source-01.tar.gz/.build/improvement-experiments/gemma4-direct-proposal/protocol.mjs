import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

// Pure source/CPU helpers. No model, tokenizer, process, HTTP, or native entrypoint.
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export const METHODS = Object.freeze(['native', 'generative']);

function shuffled(values, seed) {
  let state = seed >>> 0;
  const random = () => {
    state += 0x6d2b79f5;
    let value = Math.imul(state ^ (state >>> 15), 1 | state);
    value ^= value + Math.imul(value ^ (value >>> 7), 61 | value);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
  const result = [...values];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export function buildSchedule(expectedIds, seed = 42) {
  assert.equal(expectedIds.length, 78, 'Use every qualified developer VAL record');
  assert.equal(new Set(expectedIds).size, 78, 'Duplicate developer VAL ID');
  return [0, 1].flatMap(repetition => {
    const recordIds = shuffled(expectedIds, (seed + repetition * 104729) >>> 0);
    const order = repetition === 0 ? METHODS : [...METHODS].reverse();
    return order.map(method => ({ repetition: repetition + 1, method, record_ids: [...recordIds] }));
  });
}

function counter(value, name, minimum = 0) {
  assert.ok(Number.isSafeInteger(value) && value >= minimum, `Missing/invalid actual ${name}`);
  return value;
}

// ResearchClassifier keeps counters per question; pairedSummary expects sums.
export function foldDirectMetrics(response, questionCount) {
  const rows = response?.metrics?.per_question_native;
  assert.equal(rows?.length, questionCount, 'Incomplete direct question accounting');
  const folded = { computed_prompt_tokens: 0, computed_output_tokens: 0, engine_forwards: 0 };
  for (const row of rows) {
    assert.equal(row.backend, 'llama.cpp');
    assert.equal(row.prefill_strategy, 'full');
    assert.equal(row.prefix_tokens, 0);
    assert.equal(row.branch_output_tokens, 0);
    assert.equal(row.scored_positions, 1);
    folded.computed_prompt_tokens += counter(row.computed_prompt_tokens, 'direct prefill tokens', 1);
    folded.engine_forwards += counter(row.engine_forwards, 'direct forwards', 1);
  }
  return folded;
}

// Provider usage alone cannot stand in for actual computed prefill tokens.
export function foldServerMetrics(posts) {
  assert.ok(posts.length > 0 && posts.length <= 3, 'Retain every production teacher POST');
  return posts.reduce((result, post) => {
    result.computed_prompt_tokens += counter(post.server_timings?.prompt_n, 'server prefill tokens', 1);
    result.computed_output_tokens += counter(post.server_timings?.predicted_n, 'server generated tokens');
    return result;
  }, { computed_prompt_tokens: 0, computed_output_tokens: 0 });
}

export function partialServerMetrics(posts) {
  const measured = key => posts.map(post => post.server_timings?.[key]).filter(value => Number.isSafeInteger(value) && value >= 0);
  const prompt = measured('prompt_n'); const generated = measured('predicted_n');
  return { known_computed_prompt_tokens: prompt.reduce((a, b) => a + b, 0), known_generated_tokens: generated.reduce((a, b) => a + b, 0),
    measured_prefill_posts: prompt.length, measured_generation_posts: generated.length, dispatched_posts: posts.length,
    computed_prompt_tokens: posts.length > 0 && prompt.length === posts.length ? prompt.reduce((a, b) => a + b, 0) : null,
    computed_output_tokens: posts.length > 0 && generated.length === posts.length ? generated.reduce((a, b) => a + b, 0) : null };
}

export function exactAttemptCoverage(attempts, schedule) {
  const expected = schedule.flatMap(block => block.record_ids.map(recordId => `${block.repetition}:${block.method}:${recordId}`));
  const actual = attempts.map(row => `${row.repetition}:${row.method}:${row.record_id}`);
  assert.equal(actual.length, 312, 'Retain all four full 78-record blocks, including failures');
  assert.equal(new Set(actual).size, 312, 'Duplicate attempt');
  assert.deepEqual([...actual].sort(), [...expected].sort(), 'Incomplete/mutated developer coverage');
  for (const row of attempts) {
    assert.ok(Number.isFinite(row.elapsed_ms) && row.elapsed_ms >= 0, 'Missing monotonic elapsed time');
  }
  return true;
}

export function measurementQualified(evidence) {
  return evidence.proof_kind === 'root_attested_actual_native' &&
    evidence.exact_frozen_artifacts === true && evidence.host_only_gold_scoring === true &&
    evidence.explicit_disabled_thinking_both_arms === true && evidence.cache_clear_proved_both_arms === true &&
    evidence.actual_native_work_complete === true && evidence.full_developer_coverage === true &&
    evidence.single_active_native_gpu_execution === true && evidence.monotonic_clock_unmodified === true;
}

// Pass in the unchanged exported pairedSummary result, computed on host-only golds.
export function improvementClaimPermitted(summary, replicateSummaries, evidence) {
  const permitted = value => value.paired?.improvement_claim_permitted === true &&
    Number.isFinite(value.paired.all_attempts_elapsed_per_accepted_judgment_generative_over_native) &&
    value.paired.all_attempts_elapsed_per_accepted_judgment_generative_over_native >= 2 &&
    Number.isFinite(value.paired.conditional_both_correct_generative_over_native_latency?.median) &&
    value.paired.conditional_both_correct_generative_over_native_latency.median >= 2;
  return measurementQualified(evidence) && permitted(summary) &&
    replicateSummaries.length === 2 && replicateSummaries.every(permitted);
}
