import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';
import { buildSchedule, exactAttemptCoverage, foldDirectMetrics, foldServerMetrics, partialServerMetrics, improvementClaimPermitted } from './protocol.mjs';

const proposal = JSON.parse(await readFile(new URL('./prospective-protocol.json', import.meta.url), 'utf8'));
const schedule = buildSchedule(proposal.dataset.expected_ids);

test('ABBA has complete paired developer coverage and balances method order', () => {
  assert.deepEqual(schedule.map(row => row.method), ['native', 'generative', 'generative', 'native']);
  assert.deepEqual(schedule[0].record_ids, schedule[1].record_ids);
  assert.deepEqual(schedule[2].record_ids, schedule[3].record_ids);
  const attempts = schedule.flatMap(block => block.record_ids.map(record_id => ({
    record_id, repetition: block.repetition, method: block.method, elapsed_ms: 0,
  })));
  assert.equal(exactAttemptCoverage(attempts, schedule), true);
  assert.throws(() => exactAttemptCoverage(attempts.slice(1), schedule));
  assert.throws(() => exactAttemptCoverage([...attempts.slice(1), attempts[1]], schedule));
  assert.throws(() => exactAttemptCoverage(attempts.map((row, i) => i === 0 ? { ...row, elapsed_ms: NaN } : row), schedule));
});

test('direct fold requires actual per-question full-prefill counters', () => {
  const metric = { backend: 'llama.cpp', prefill_strategy: 'full', prefix_tokens: 0,
    branch_output_tokens: 0, scored_positions: 1, computed_prompt_tokens: 974, engine_forwards: 4 };
  assert.deepEqual(foldDirectMetrics({ metrics: { per_question_native: [metric] } }, 1), {
    computed_prompt_tokens: 974, computed_output_tokens: 0, engine_forwards: 4,
  });
  assert.throws(() => foldDirectMetrics({ metrics: { computed_prompt_tokens: 974 } }, 1));
  assert.throws(() => foldDirectMetrics({ metrics: { per_question_native: [metric] } }, 2));
  assert.throws(() => foldDirectMetrics({ metrics: { per_question_native: [{ ...metric, prefix_tokens: 12 }] } }, 1));
  assert.throws(() => foldDirectMetrics({ metrics: { per_question_native: [{ ...metric, branch_output_tokens: 1 }] } }, 1));
});

test('server fold retains every retry and rejects provider-only or missing computed accounting', () => {
  const posts = [{ server_timings: { prompt_n: 100, predicted_n: 11 } }, { server_timings: { prompt_n: 100, predicted_n: 21 } }];
  assert.deepEqual(foldServerMetrics(posts), { computed_prompt_tokens: 200, computed_output_tokens: 32 });
  assert.throws(() => foldServerMetrics([{ provider_usage: { prompt_tokens: 100, completion_tokens: 11 } }]));
  assert.throws(() => foldServerMetrics([...posts, { error: 'transport failed' }]));
  assert.throws(() => foldServerMetrics([{ server_timings: { prompt_n: 0, predicted_n: 11 } }]));
});

test('synthetic speed or incomplete qualification cannot permit a native improvement claim', () => {
  const passed = { paired: { improvement_claim_permitted: true,
    all_attempts_elapsed_per_accepted_judgment_generative_over_native: 2,
    conditional_both_correct_generative_over_native_latency: { median: 2 } } };
  const evidence = { proof_kind: 'cpu_mock', exact_frozen_artifacts: true, host_only_gold_scoring: true,
    explicit_disabled_thinking_both_arms: true, cache_clear_proved_both_arms: true,
    actual_native_work_complete: true, full_developer_coverage: true,
    single_active_native_gpu_execution: true, monotonic_clock_unmodified: true };
  assert.equal(improvementClaimPermitted(passed, [passed, passed], evidence), false);
  const actual = { ...evidence, proof_kind: 'root_attested_actual_native' };
  assert.equal(improvementClaimPermitted(passed, [passed, passed], actual), true);
  assert.equal(improvementClaimPermitted(passed, [passed], actual), false);
  assert.equal(improvementClaimPermitted(passed, [passed, { paired: { improvement_claim_permitted: false } }], actual), false);
  assert.equal(improvementClaimPermitted({ paired: { ...passed.paired, all_attempts_elapsed_per_accepted_judgment_generative_over_native: Infinity } }, [passed, passed], actual), false);
  for (const flag of Object.keys(actual).filter(key => key !== 'proof_kind')) {
    assert.equal(improvementClaimPermitted(passed, [passed, passed], { ...actual, [flag]: false }), false);
  }
});

test('partially known failed POST work stays measured while unknown totals remain null', () => {
  assert.deepEqual(partialServerMetrics([{ server_timings: { prompt_n: 100, predicted_n: 11 } }, { error: 'response lost' }]), {
    known_computed_prompt_tokens: 100, known_generated_tokens: 11, measured_prefill_posts: 1, measured_generation_posts: 1,
    dispatched_posts: 2, computed_prompt_tokens: null, computed_output_tokens: null,
  });
});
