import assert from 'node:assert/strict';
import { spawn, execFile } from 'node:child_process';
import { createServer } from 'node:net';
import { promisify } from 'node:util';
import { createReadStream } from 'node:fs';
import { mkdir, mkdtemp, readFile, realpath, writeFile, appendFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { basename, dirname, join, resolve, relative, sep } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';
import { checkRootPermit, executeBlocks } from './harness.mjs';
import { foldDirectMetrics, foldServerMetrics, partialServerMetrics, sha256 } from './protocol.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '../../..');
const QUALIFIED = join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality/native-proof-root-1');
export const REQUIRED_SOURCES = ['scripts/developer-decision-eval.mjs', 'dist/backend.js', 'dist/core.js', 'dist/evaluation.js',
  'dist/models.js', 'dist/rfdt.js', '.build/improvement-experiments/gemma4-label-prototype/research-quality/protocol.mjs',
  '.build/improvement-experiments/gemma4-label-prototype/research-quality/quality.mjs',
  '.build/improvement-experiments/gemma4-label-prototype/research-quality/rpc.mjs',
  '.build/improvement-experiments/gemma4-direct-proposal/protocol.mjs',
  '.build/improvement-experiments/gemma4-direct-proposal/harness.mjs',
  '.build/improvement-experiments/gemma4-direct-proposal/runner.mjs'];
async function hashFile(file) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
const writeJson = (file, value) => writeFile(file, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const executeFile = promisify(execFile);

export function checkNativeLibraries(plan) {
  assert.ok(Array.isArray(plan.native_runtime_libraries) && plan.native_runtime_libraries.length > 0, 'Frozen native dylib identities required');
  for (const identity of plan.native_runtime_libraries) {
    assert.equal(dirname(identity.path), dirname(plan.generative.binary), 'Only existing adjacent server libraries');
    assert.ok(basename(identity.path).endsWith('.dylib')); assert.match(identity.sha256, /^[a-f0-9]{64}$/);
  }
  for (const prefix of ['libllama-server-impl', 'libllama', 'libggml-metal']) {
    assert.ok(plan.native_runtime_libraries.some(identity => basename(identity.path).startsWith(prefix)), `Missing pinned runtime ${prefix}`);
  }
  assert.ok(!Object.keys(process.env).some(key => /^(DYLD_|LD_PRELOAD$)/.test(key)), 'Dynamic-loader overrides must be absent for exact library attribution');
}

export function ownedCancellation() {
  const controller = new AbortController();
  const interrupted = () => controller.abort(new Error('Owned benchmark runner interrupted'));
  process.once('SIGINT', interrupted); process.once('SIGTERM', interrupted);
  return { signal: controller.signal, close: () => { process.removeListener('SIGINT', interrupted); process.removeListener('SIGTERM', interrupted); } };
}

async function availablePort(port) {
  assert.ok(Number.isSafeInteger(port) && port >= 1 && port <= 65535);
  await new Promise((resolve, reject) => {
    const server = createServer(); server.once('error', reject);
    server.listen(port, '127.0.0.1', () => server.close(error => error ? reject(error) : resolve()));
  });
}

async function ownedListener(pid, port) {
  try {
    const { stdout } = await executeFile('/usr/sbin/lsof', ['-nP', `-iTCP:${port}`, '-sTCP:LISTEN', '-Fp'], { timeout: 5000, maxBuffer: 65536 });
    const pids = stdout.split('\n').filter(line => line.startsWith('p')).map(line => Number(line.slice(1)));
    return pids.length === 1 && pids[0] === pid;
  } catch { return false; }
}

export async function boundedReply(response, limit) {
  let size = 0; const parts = [];
  for await (const part of response.body ?? []) {
    size += part.byteLength;
    if (size > limit) throw new Error('HTTP response cap exceeded');
    parts.push(Buffer.from(part));
  }
  return Buffer.concat(parts);
}

export async function startServer(plan, audit, proof) {
  const g = plan.generative; const bounds = plan.runtime_bounds;
  assert.equal(await realpath(dirname(proof)), await realpath(HERE), 'Server slot storage must stay in the fresh owned proof directory');
  const slotSavePath = await mkdtemp(join(proof, 'owned-server-slot-store-'));
  await availablePort(g.port);
  const args = ['--model', plan.artifacts.model.path, '--jinja', '--chat-template-file', plan.artifacts.template.path,
    '--alias', g.model_id, '--host', '127.0.0.1', '--port', String(g.port), '--ctx-size', String(g.context_size),
    '--parallel', '1', '--n-gpu-layers', 'all', '--verbosity', '4', '--reasoning', 'on', '--slots', '--cache-ram', '0', '--slot-save-path', slotSavePath,
    '--cors-origins', '', '--no-cors-credentials', '--no-webui', '--no-agent'];
  const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => !/^(LLAMA_|AIP_)/.test(key)));
  const child = spawn(g.binary, args, { cwd: HERE, stdio: ['ignore', 'pipe', 'pipe'], env });
  let logs = ''; let logBytes = 0; let error = null; let exited = false; let closed = false; let exitCode = null; let exitSignal = null;
  let finish; const exit = new Promise(resolve => { finish = resolve; });
  child.on('error', value => { error = String(value); });
  child.on('exit', (code, signal) => { exited = true; exitCode = code; exitSignal = signal; });
  child.on('close', () => { closed = true; finish(); });
  const log = part => {
    logBytes += part.length;
    if (logBytes > bounds.max_stderr_bytes) { error = 'Owned server log cap exceeded'; child.kill('SIGTERM'); }
    else logs += part.toString('utf8');
  };
  child.stdout.on('data', log); child.stderr.on('data', log);
  const close = async () => {
    const unexpectedExit = exited;
    if (!exited) child.kill('SIGTERM');
    const waitClose = async () => { let timer; try { await Promise.race([exit, new Promise(resolve => { timer = setTimeout(resolve, bounds.exit_timeout_ms); })]); } finally { clearTimeout(timer); } };
    await waitClose();
    if (!closed) { child.kill('SIGKILL'); await waitClose(); }
    await audit('server_process', { pid: child.pid, binary: g.binary, binary_sha256: g.binary_sha256,
      args, exited, stdio_closed: closed, exit_code: exitCode, exit_signal: exitSignal, error, logs });
    assert.equal(closed, true, 'Owned server stdio close incomplete');
    assert.equal(exited, true, 'Owned server exit incomplete');
    assert.ok(!error && !unexpectedExit, 'Owned server recorded an unexpected failure');
    assert.ok(exitCode === 0 || exitSignal === 'SIGTERM', 'Unexpected owned shutdown status');
    return { pid: child.pid, exited, stdio_closed: closed, exit_code: exitCode, exit_signal: exitSignal, owned_cleanup_complete: true };
  };
  return { child, close, ownsListener: () => ownedListener(child.pid, g.port), logs: () => logs, failure: () => error || (exited ? 'Owned server exited' : null) };
}

export async function runRootCleared({ planPath, clearancePath, proofPath, planSha256, rootFlag }) {
  const planBytes = await readFile(planPath);
  assert.equal(sha256(planBytes), planSha256, 'CLI must bind exact plan SHA');
  const clearanceBytes = await readFile(clearancePath);
  const plan = checkRootPermit(planBytes, JSON.parse(clearanceBytes), rootFlag);
  checkNativeLibraries(plan);
  assert.equal(plan.dataset.path, join(ROOT, '.build/improvement-experiments/validation-label-audit/validation-78.jsonl'));
  assert.equal(plan.artifacts.model.path, join(ROOT, 'models/gemma-4-31B_q4_0-it.gguf'));
  assert.equal(plan.artifacts.template.path, join(ROOT, 'models/gemma-4-31B-it.chat_template.jinja'));
  assert.equal(plan.artifacts.binary.path, join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/gemma4-label-prototype'));
  assert.equal(plan.generative.binary, join(ROOT, '.build/agent-server/bin/llama-server'));
  assert.equal(plan.qualified_plan.path, join(QUALIFIED, 'run-plan.json'));
  assert.equal(plan.render_reference.path, join(QUALIFIED, 'independent-render.json'));
  assert.deepEqual(plan.source_files.map(item => relative(ROOT, item.path)).sort(), [...REQUIRED_SOURCES].sort());
  // All model/artifact reads and dynamic helper imports occur after exact ROOT permit.
  for (const identity of [...plan.source_files, ...Object.values(plan.artifacts), ...plan.native_runtime_libraries,
    { path: plan.generative.binary, sha256: plan.generative.binary_sha256 }, plan.qualified_plan,
    plan.render_reference, plan.qualified_quality_report, plan.qualified_root_attestation]) {
    assert.equal(await hashFile(identity.path), identity.sha256, `Frozen identity changed: ${identity.path}`);
  }
  const inputBytes = await readFile(plan.dataset.path);
  assert.equal(sha256(inputBytes), plan.dataset.input_sha256);
  const proof = resolve(proofPath); const parent = await realpath(dirname(proof));
  assert.equal(parent, await realpath(HERE), 'Fresh proof directory must be an immediate owned proposal child');
  assert.ok(relative(HERE, proof) && !relative(HERE, proof).startsWith('..' + sep));
  await mkdir(proof, { mode: 0o700 });
  await writeJson(join(HERE, `native-reservation-${planSha256}.json`), { kind: 'once_only_ROOT_cleared_VAL_performance_reservation', plan_sha256: planSha256, proof_directory: proof });
  await writeFile(join(proof, 'run-plan.json'), planBytes, { flag: 'wx', mode: 0o600 });
  await writeFile(join(proof, 'root-clearance.json'), clearanceBytes, { flag: 'wx', mode: 0o600 });
  const snapshotPath = join(proof, 'developer-validation-78.jsonl');
  await writeFile(snapshotPath, inputBytes, { flag: 'wx', mode: 0o600 });
  let auditBytes = 0;
  const audit = async (kind, value) => {
    const bytes = JSON.stringify({ kind, ...value }) + '\n'; auditBytes += Buffer.byteLength(bytes);
    assert.ok(auditBytes <= plan.runtime_bounds.max_audit_bytes, 'Combined audit cap exceeded');
    await appendFile(join(proof, 'audit.jsonl'), bytes, { mode: 0o600 });
  };
  const [{ loadQualityRecords }, { preparePrompt }, { labelRfdt }, decision, quality, rpcModule, protocol] = await Promise.all([
    import(pathToFileURL(join(ROOT, 'dist/evaluation.js'))), import(pathToFileURL(join(ROOT, 'dist/core.js'))),
    import(pathToFileURL(join(ROOT, 'dist/rfdt.js'))), import(pathToFileURL(join(ROOT, 'scripts/developer-decision-eval.mjs'))),
    import(pathToFileURL(join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality/quality.mjs'))),
    import(pathToFileURL(join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality/rpc.mjs'))),
    import(pathToFileURL(join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality/protocol.mjs'))),
  ]);
  const records = await loadQualityRecords(snapshotPath);
  assert.ok(records.every(record => record.split === 'validation'), 'VAL-only input required');
  const logical = new Map(plan.dataset.logical_prompt_sha256);
  for (const record of records) assert.equal(sha256(JSON.stringify(preparePrompt({ ...record.request,
    options: { ...record.request.options, template_version: 'v2' } }, 'v2').questions)), logical.get(record.id));
  const qualified = JSON.parse(await readFile(plan.qualified_plan.path, 'utf8'));
  const reference = JSON.parse(await readFile(plan.render_reference.path, 'utf8'));
  const originalFetch = globalThis.fetch;
  let trialIndex = 0;
  const createAdapter = async (block, orderedRecords) => {
    if (block.method === 'native') {
      let rpc; let classifier;
      return {
        initialize: async signal => {
          signal.throwIfAborted();
          rpc = rpcModule.OwnedRpc.spawn(plan.artifacts.binary.path, [], { cwd: HERE,
            requestTimeoutMs: plan.runtime_bounds.request_timeout_ms, totalTimeoutMs: plan.runtime_bounds.total_timeout_ms,
            maxPacketBytes: 262144, maxResponseBytes: plan.runtime_bounds.max_native_response_bytes,
            maxStderrBytes: plan.runtime_bounds.max_stderr_bytes, exitTimeoutMs: plan.runtime_bounds.exit_timeout_ms });
          const audited = { snapshot: () => rpc.snapshot(), request: async (request, options) => {
            const sent = performance.now(); let response; let error;
            try { response = await rpc.request(request, options); return response; }
            catch (value) { error = String(value); throw value; }
            finally { await audit('native_rpc', { block, request, response, error, elapsed_ms: performance.now() - sent }); }
          } };
          const reply = await audited.request(qualified.rpc_init, { signal });
          assert.ok(!reply.error); protocol.validateProvenance(reply.result?.provenance, qualified);
          assert.equal(reply.result.ready, true); assert.equal(reply.result.device, 'metal'); assert.equal(reply.result.architecture, 'gemma4');
          classifier = new quality.ResearchClassifier({ rpc: audited, plan: qualified, orderedRecords,
            renderReference: reference, evidenceSink: entry => audit('native_question', entry) });
        },
        run: async (source, signal, attempt) => {
          const request = { ...source.request, model: protocol.EXPECTED.profile,
            options: { ...source.request.options, template_version: 'v2' } };
          const returned = await classifier.classify(request, signal);
          const metrics = foldDirectMetrics(returned, request.questions.length);
          attempt.native_response = { ...returned, metrics: { ...returned.metrics, ...metrics } };
          attempt.accounting_complete = true; attempt.cache_clear_proved = true;
          return returned;
        },
        close: async () => {
          if (!rpc) return { no_process_started: true, owned_cleanup_complete: true };
          const result = await rpc.close(); const snapshot = rpc.snapshot();
          await audit('native_process', snapshot);
          assert.ok(!result.cleanupError);
          for (const receipt of [result, snapshot]) {
            assert.equal(receipt.state, 'closed'); assert.equal(receipt.closedObserved, true); assert.equal(receipt.exitedObserved, true);
            assert.equal(receipt.exitCode, 0); assert.equal(receipt.signal, null); assert.equal(receipt.failureCode, null); assert.equal(receipt.pendingRequests, 0);
          }
          return { ...result, owned_cleanup_complete: true };
        },
      };
    }
    return makeGenerativeAdapter({ plan, proof, audit, labelRfdt, originalFetch, nextTrial: () => ++trialIndex });
  };
  const judge = (record, returned, method) => {
    const answers = record.request.questions.map(question => decision.scoreAnswer(question, record.targets[question.id],
      method === 'native' ? returned.answers[question.id] : returned[question.id], method));
    return { answers, correct_judgment: answers.every(answer => answer.correct_judgment),
      completed_clear_decision: answers.every(answer => answer.completed_clear_decision), abstention: answers.some(answer => answer.abstention) };
  };
  let result;
  const cancellation = ownedCancellation();
  try { result = await executeBlocks({ plan, records, createAdapter, judge, pairedSummary: decision.pairedSummary,
    evidenceSink: audit, proofKind: 'root_attested_actual_native', abortSignal: cancellation.signal }); }
  finally { globalThis.fetch = originalFetch; cancellation.close(); }
  result.plan_sha256 = planSha256; result.root_clearance_sha256 = sha256(clearanceBytes); result.audit_bytes = auditBytes;
  result.latency_boundary = 'full RFDT workflow and direct classification+host scoring; POST/cache-reset times also reported; initialization separate';
  await writeJson(join(proof, 'result.json'), result);
  return result;
}

export async function makeGenerativeAdapter({ plan, proof, audit, labelRfdt, originalFetch, nextTrial, onPost = async () => {}, startServerImpl = startServer }) {
    let server; let currentAttempt; let currentSource;
    const base = `http://127.0.0.1:${plan.generative.port}`;
    const localReply = async (path, options, signal) => {
      assert.ok(path === '/health' || path === '/v1/models' || path === '/slots/0?action=erase' || path === '/apply-template');
      assert.ok(!server.failure() && await server.ownsListener(), 'Loopback listener is not the owned child');
      const response = await originalFetch(base + path, { ...options, signal, redirect: 'error' });
      const bytes = await boundedReply(response, plan.runtime_bounds.http_response_bytes);
      assert.ok(response.ok, `Owned server ${path} failed: HTTP ${response.status}: ${bytes.toString('utf8').slice(0, 2048)}`); return bytes;
    };
    return {
      initialize: async signal => {
        signal?.throwIfAborted();
        server = await startServerImpl(plan, audit, proof);
        const started = performance.now(); let ready = false;
        while (performance.now() - started < plan.runtime_bounds.startup_timeout_ms) {
          signal?.throwIfAborted();
          if (server.failure()) throw new Error(server.failure());
          try { await localReply('/health', {}, signal ? AbortSignal.any([signal, AbortSignal.timeout(5000)]) : AbortSignal.timeout(5000)); ready = true; break; }
          catch { await new Promise(resolve => setTimeout(resolve, 250)); }
        }
        assert.ok(ready, 'Owned Gemma server startup deadline');
        assert.ok(!server.failure());
        const layers = server.logs().match(/offloaded (\d+)\/\d+ layers to GPU/);
        const device = server.logs().match(/llama_prepare_model_devices: using device (MTL\d+ \([^\n)]+\)) \(/)?.[1] ?? server.logs().match(/GPU name:\s*([^\n]+)/)?.[1];
        assert.ok(layers && Number(layers[1]) > 0 && device?.startsWith('MTL'), 'Actual positive Metal offload not proved');
        await audit('server_startup_metal', { pid: server.child.pid, offloaded_layers: Number(layers[1]), actual_device: device });
        const models = JSON.parse(await localReply('/v1/models', {}, signal ? AbortSignal.any([signal, AbortSignal.timeout(5000)]) : AbortSignal.timeout(5000)));
        assert.ok(models.data?.some(model => model.id === plan.generative.model_id));
        globalThis.fetch = async (input, init = {}) => {
          const url = String(input); assert.equal(url, base + '/v1/chat/completions');
          assert.ok(currentAttempt, 'Teacher call outside a trial'); assert.equal(init.method, 'POST');
          const body = JSON.parse(init.body); assert.equal(body.model, plan.generative.model_id);
          assert.equal(body.temperature, 0); assert.equal(body.max_tokens, 2048); assert.equal(body.response_format.type, 'json_schema');
          assert.deepEqual(JSON.parse(body.messages[1].content), { context: currentSource.request.state ?? currentSource.request.messages, questions: currentSource.request.questions });
          const headers = new Headers(init.headers); assert.ok(!headers.has('authorization') && !headers.has('cookie'));
          const post = { index: currentAttempt.transport.length + 1, dispatched: false };
          const resetStarted = performance.now();
          try {
            const erase = JSON.parse(await localReply('/slots/0?action=erase', { method: 'POST' }, init.signal));
            assert.ok(Number.isSafeInteger(erase.n_erased) && erase.n_erased >= 0, 'Slot erase proof missing');
            post.cache_reset = erase;
          } catch (error) { post.reset_error = String(error); throw error; }
          finally { post.cache_reset_elapsed_ms = performance.now() - resetStarted; await audit('teacher_attempt_reset', post); }
          body.chat_template_kwargs = { enable_thinking: false }; body.id_slot = 0;
          post.actual_request = body; await onPost(body, post, localReply, init.signal); const sent = performance.now();
          try {
            if (server.failure()) throw new Error(server.failure());
            assert.ok(await server.ownsListener(), 'Teacher listener no longer owned');
            post.dispatched = true; currentAttempt.transport.push(post);
            const response = await originalFetch(url, { ...init, body: JSON.stringify(body), redirect: 'error' });
            const bytes = await boundedReply(response, plan.runtime_bounds.http_response_bytes);
            post.ok = response.ok; post.status = response.status; post.response_text = bytes.toString('utf8');
            post.response_sha256 = sha256(bytes);
            const reply = JSON.parse(post.response_text); post.provider_usage = reply.usage; post.server_timings = reply.timings;
            assert.equal(reply.model, plan.generative.model_id);
            assert.ok(!reply.choices?.[0]?.message?.reasoning_content && !reply.choices?.[0]?.message?.reasoning, 'Unexpected baseline thinking output');
            assert.equal(reply.timings?.cache_n, 0, 'Server reused prompt cache');
            assert.equal(reply.timings?.prompt_n, reply.usage?.prompt_tokens, 'Computed/logical prefill identity mismatch');
            return new Response(bytes, { status: response.status, headers: response.headers });
          } catch (error) { post.error = String(error); throw error; }
          finally { post.elapsed_ms = performance.now() - sent; await audit('teacher_post', post); }
        };
      },
      run: async (source, signal, attempt) => {
        currentSource = source; currentAttempt = attempt;
        const directory = join(proof, `trial-${String(nextTrial()).padStart(6, '0')}`); await mkdir(directory, { mode: 0o700 });
        const input = join(directory, 'unlabeled.jsonl'); const output = join(directory, 'labeled.jsonl'); const cache = join(directory, 'fresh-label-cache');
        await writeFile(input, JSON.stringify({ ...source, targets: {} }) + '\n', { flag: 'wx', mode: 0o600 }); await mkdir(cache, { mode: 0o700 });
        try {
          const result = await labelRfdt(input, { outputPath: output, cacheDir: cache,
            teacherUrl: base + '/v1', teacherModel: plan.generative.model_id, signal });
          assert.equal(result.cache_hits, 0); attempt.label_summary = result;
          const labeled = JSON.parse((await readFile(output, 'utf8')).trim());
          assert.deepEqual(labeled.request, source.request); attempt.actual_generated_targets = labeled.targets;
          return labeled.targets;
        } finally {
          attempt.actual_work = partialServerMetrics(attempt.transport);
          try { attempt.actual_work = foldServerMetrics(attempt.transport); attempt.accounting_complete = true; }
          catch (error) { attempt.accounting_complete = false; attempt.work_accounting_error = String(error); }
          attempt.cache_clear_proved = attempt.transport.length > 0 && attempt.transport.every(post => post.server_timings?.cache_n === 0);
          currentAttempt = null; currentSource = null;
        }
      },
      close: async () => { globalThis.fetch = originalFetch; return server ? server.close() : { no_process_started: true, owned_cleanup_complete: true }; },
    };
}

async function main(argv) {
  assert.equal(argv.shift(), 'run'); assert.equal(argv.shift(), '--root-cleared', 'No implicit inference command');
  const options = {};
  while (argv.length) { const key = argv.shift(); assert.ok(['--plan', '--plan-sha256', '--root-clearance', '--proof-dir'].includes(key)); assert.ok(!options[key]); options[key] = argv.shift(); assert.ok(options[key]); }
  assert.equal(Object.keys(options).length, 4);
  const result = await runRootCleared({ planPath: options['--plan'], planSha256: options['--plan-sha256'],
    clearancePath: options['--root-clearance'], proofPath: options['--proof-dir'], rootFlag: true });
  console.log(JSON.stringify({ status: result.status, improvement_claim_permitted: result.improvement_claim_permitted, plan_sha256: result.plan_sha256 }));
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main(process.argv.slice(2)).catch(error => { console.error(String(error)); process.exitCode = 1; });
}
