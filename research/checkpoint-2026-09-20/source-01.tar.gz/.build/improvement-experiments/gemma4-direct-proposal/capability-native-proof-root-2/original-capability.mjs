import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { mkdir, realpath, readFile, writeFile, appendFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { makeGenerativeAdapter, ownedCancellation, checkNativeLibraries, REQUIRED_SOURCES } from './runner.mjs';
import { sha256 } from './protocol.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '../../..');
const executeFile = promisify(execFile);
const BOUNDARY = '<|turn>model\n<|channel>thought\n<channel|>';
const MODEL = 'google/gemma-4-31B-it-qat-q4_0';
export const SYNTHETIC_CASES = Object.freeze([
  { id: 'synthetic-choice', group_id: 'synthetic-choice', split: 'validation',
    request: { model: MODEL, state: 'The basket contains exactly two oranges.', options: { template_version: 'v2' },
      questions: [{ id: 'count', type: 'choice', instructions: 'Select the stated orange count.', criteria: [
        { id: 'two', description: 'Exactly two oranges.' }, { id: 'three', description: 'Exactly three oranges.' }] }] },
    targets: { count: { answer: 'two' } } },
  { id: 'synthetic-score', group_id: 'synthetic-score', split: 'validation',
    request: { model: MODEL, state: 'The task was started and is not complete.', options: { template_version: 'v2' },
      questions: [{ id: 'progress', type: 'score', instructions: 'Rate the stated progress.',
        criteria: ['Not started.', 'Started and not complete.', 'Complete.'] }] }, targets: { progress: { answer: 1 } } },
  { id: 'synthetic-noul', group_id: 'synthetic-noul', split: 'validation',
    request: { model: MODEL, state: 'Mia has a pet. Its species is unspecified.', options: { template_version: 'v2' },
      questions: [{ id: 'dog', type: 'noul', instructions: 'Does Mia have a dog?' }] }, targets: { dog: { answer: null } } },
]);

export function checkCapabilityPermit(planBytes, clearance, rootFlag) {
  assert.equal(rootFlag, true, 'Explicit --root-cleared flag required');
  const plan = JSON.parse(planBytes.toString('utf8'));
  assert.equal(plan.kind, 'gemma4_direct_server_capability_plan');
  assert.equal(plan.status, 'root_frozen'); assert.equal(plan.inference_ready, true);
  assert.equal(clearance.kind, 'gemma4_direct_server_capability_root_clearance');
  assert.equal(clearance.scope, 'three_synthetic_cases_one_owned_metal_server_only');
  assert.equal(clearance.stage_cleared, true); assert.equal(clearance.plan_sha256, sha256(planBytes));
  assert.equal(clearance.other_native_gpu_work_idle, true); assert.equal(clearance.production_role_approval, false);
  assert.deepEqual(plan.synthetic_cases, SYNTHETIC_CASES, 'Only these three synthetic cases may run');
  assert.equal(plan.artifacts.model.sha256, '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b');
  assert.equal(plan.artifacts.template.sha256, 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4');
  assert.equal(plan.generative.binary_sha256, 'b866bbcd1d84545b3032787295205ad5a0674fcb62fc28bb8bcef42ed36948bb');
  assert.equal(plan.generative.model_id, MODEL); assert.equal(plan.generative.host, '127.0.0.1');
  assert.equal(plan.generative.parallel, 1); assert.equal(plan.generative.cache_ram_mib, 0);
  assert.equal(plan.generative.chat_template_kwargs.enable_thinking, false);
  assert.equal(plan.generative.temperature, 0); assert.equal(plan.generative.max_tokens, 2048);
  assert.equal(plan.runtime_bounds.total_timeout_ms, 1800000);
  assert.equal(plan.runtime_bounds.request_timeout_ms, 600000);
  return plan;
}

async function hashFile(path) {
  const hash = createHash('sha256'); for await (const part of createReadStream(path)) hash.update(part); return hash.digest('hex');
}
const writeJson = (path, value) => writeFile(path, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 });

export async function runCapability({ planPath, clearancePath, proofPath, planSha256, rootFlag }) {
  const planBytes = await readFile(planPath); assert.equal(sha256(planBytes), planSha256);
  const clearanceBytes = await readFile(clearancePath);
  const plan = checkCapabilityPermit(planBytes, JSON.parse(clearanceBytes), rootFlag);
  checkNativeLibraries(plan);
  assert.equal(plan.artifacts.model.path, join(ROOT, 'models/gemma-4-31B_q4_0-it.gguf'));
  assert.equal(plan.artifacts.template.path, join(ROOT, 'models/gemma-4-31B-it.chat_template.jinja'));
  assert.equal(plan.generative.binary, join(ROOT, '.build/agent-server/bin/llama-server'));
  assert.equal(plan.renderer_script.path, join(ROOT, '.build/improvement-experiments/gemma4-label-prototype/research-quality/render-reference.py'));
  assert.ok(plan.source_files.some(file => file.path === fileURLToPath(import.meta.url)));
  assert.ok(plan.source_files.some(file => file.path === join(HERE, 'runner.mjs')));
  assert.deepEqual(plan.source_files.map(file => file.path).sort(), [...REQUIRED_SOURCES.map(file => join(ROOT, file)), fileURLToPath(import.meta.url)].sort());
  for (const identity of [...plan.source_files, ...plan.native_runtime_libraries, plan.artifacts.model, plan.artifacts.template,
    { path: plan.generative.binary, sha256: plan.generative.binary_sha256 }, plan.renderer_script,
    { path: plan.renderer.python_executable, sha256: plan.renderer.python_executable_sha256 }]) {
    assert.equal(await hashFile(identity.path), identity.sha256, `Frozen identity changed: ${identity.path}`);
  }
  const proof = resolve(proofPath); assert.equal(await realpath(dirname(proof)), await realpath(HERE));
  await mkdir(proof, { mode: 0o700 });
  await writeJson(join(HERE, `capability-reservation-${planSha256}.json`), { plan_sha256: planSha256, proof_directory: proof });
  await writeFile(join(proof, 'run-plan.json'), planBytes, { flag: 'wx', mode: 0o600 });
  await writeFile(join(proof, 'root-clearance.json'), clearanceBytes, { flag: 'wx', mode: 0o600 });
  let auditBytes = 0; let trialIndex = 0; const posts = []; const attempts = [];
  const audit = async (kind, value) => {
    const bytes = JSON.stringify({ kind, ...value }) + '\n'; auditBytes += Buffer.byteLength(bytes);
    assert.ok(auditBytes <= plan.runtime_bounds.max_audit_bytes); await appendFile(join(proof, 'audit.jsonl'), bytes, { mode: 0o600 });
  };
  const [{ labelRfdt }, decision] = await Promise.all([
    import(pathToFileURL(join(ROOT, 'dist/rfdt.js'))), import(pathToFileURL(join(ROOT, 'scripts/developer-decision-eval.mjs'))),
  ]);
  const originalFetch = globalThis.fetch;
  const adapter = await makeGenerativeAdapter({ plan, proof, audit, labelRfdt, originalFetch, nextTrial: () => ++trialIndex,
    onPost: async (body, post, localReply, signal) => {
      assert.ok(posts.length < 9, 'Three synthetic cases permit at most nine existing teacher attempts');
      const response = JSON.parse(await localReply('/apply-template', { method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ messages: body.messages, add_generation_prompt: true, chat_template_kwargs: { enable_thinking: false } }) }, signal));
      assert.equal(typeof response.prompt, 'string');
      assert.ok(response.prompt.startsWith('<bos>') && response.prompt.split('<bos>').length === 2);
      assert.ok(response.prompt.endsWith(BOUNDARY), 'Effective disabled-thinking boundary missing');
      post.apply_template_response = response; posts.push(post); await audit('apply_template', { index: posts.length, response });
    } });
  let initializationError = null; let cleanup = null; let error = null;
  const cancellation = ownedCancellation();
  const totalSignal = AbortSignal.any([cancellation.signal, AbortSignal.timeout(plan.runtime_bounds.total_timeout_ms)]);
  try {
    try { await adapter.initialize(totalSignal); } catch (value) { initializationError = String(value); }
    for (const source of plan.synthetic_cases) {
      const attempt = { record_id: source.id, transport: [], correct: false };
      try {
        if (initializationError) throw new Error(initializationError);
        const signal = AbortSignal.any([totalSignal, AbortSignal.timeout(plan.runtime_bounds.request_timeout_ms)]);
        const returned = await adapter.run({ id: source.id, group_id: source.group_id, split: source.split, request: structuredClone(source.request) }, signal, attempt);
        attempt.answers = source.request.questions.map(q => decision.scoreAnswer(q, source.targets[q.id], returned[q.id], 'generative'));
        attempt.correct = attempt.answers.every(answer => answer.correct_judgment);
      } catch (value) { attempt.error = String(value); }
      attempts.push(attempt); await audit('synthetic_attempt', attempt);
    }
  } catch (value) { error = String(value); }
  finally {
    try { cleanup = await adapter.close(); } catch (value) { error = error ?? String(value); }
    cancellation.close();
    globalThis.fetch = originalFetch;
  }
  let independent = null;
  if (posts.length > 0 && !error) {
    const renderInputs = posts.map((post, index) => ({ record_id: `synthetic-post-${index}`, branch: {
      branch_id: `synthetic-post-${index}`, messages: post.actual_request.messages, answer_prefix: '' } }));
    const input = join(proof, 'render-requests.json'); const output = join(proof, 'independent-render.json');
    await writeJson(input, renderInputs);
    try {
      await executeFile(plan.renderer.python_executable, [plan.renderer_script.path, '--requests', input, '--output', output,
        '--template', plan.artifacts.template.path, '--expected-sha256', plan.artifacts.template.sha256],
      { cwd: HERE, timeout: 60000, maxBuffer: 1048576 });
      independent = JSON.parse(await readFile(output, 'utf8'));
      assert.deepEqual(independent.runtime_identity, plan.renderer);
      assert.equal(independent.rows.length, posts.length);
      independent.rows.forEach((row, index) => assert.equal(row.rendered, posts[index].apply_template_response.prompt));
    } catch (value) { error = String(value); }
  }
  const passed = !error && !initializationError && cleanup?.owned_cleanup_complete === true && !cleanup.error &&
    posts.length >= 3 && posts.every(post => post.dispatched) && independent?.rows.length === posts.length &&
    attempts.length === 3 && attempts.every(attempt => !attempt.error && attempt.correct && attempt.accounting_complete && attempt.cache_clear_proved);
  const result = { kind: 'gemma4_direct_server_three_synthetic_capability_result', plan_sha256: planSha256,
    passed, initialization_error: initializationError, error, cleanup, attempts, posts: posts.length,
    independent_render_rows: independent?.rows.length ?? 0, full_VAL_inference: false, held_out_TEST_read: false,
    quality_or_performance_claim: false, production_role_approval: false, audit_bytes: auditBytes };
  await writeJson(join(proof, 'capability-result.json'), result); return result;
}

async function main(argv) {
  assert.equal(argv.shift(), 'run'); assert.equal(argv.shift(), '--root-cleared'); const options = {};
  while (argv.length) { const key = argv.shift(); assert.ok(['--plan','--plan-sha256','--root-clearance','--proof-dir'].includes(key)); assert.ok(!options[key]); options[key] = argv.shift(); assert.ok(options[key]); }
  assert.equal(Object.keys(options).length, 4);
  const result = await runCapability({ planPath: options['--plan'], planSha256: options['--plan-sha256'],
    clearancePath: options['--root-clearance'], proofPath: options['--proof-dir'], rootFlag: true });
  console.log(JSON.stringify({ passed: result.passed, plan_sha256: result.plan_sha256, full_VAL_inference: false }));
  if (!result.passed) process.exitCode = 1;
}
if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  main(process.argv.slice(2)).catch(error => { console.error(String(error)); process.exitCode = 1; });
}
