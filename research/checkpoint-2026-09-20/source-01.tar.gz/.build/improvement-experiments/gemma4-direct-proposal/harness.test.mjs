import assert from 'node:assert/strict';
import { readFile, mkdtemp } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import { checkRootPermit, executeBlocks } from './harness.mjs';
import { checkCapabilityPermit } from './capability.mjs';
import { makeGenerativeAdapter } from './runner.mjs';
import { sha256 } from './protocol.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const proposal = JSON.parse(await readFile(join(HERE, 'prospective-protocol.json'), 'utf8'));
const capability = JSON.parse(await readFile(join(HERE, 'prospective-capability-plan.json'), 'utf8'));
const records = proposal.dataset.expected_ids.map((id, index) => ({ id, group_id: `cpu-group-${Math.floor(index / 2)}`,
  split: 'validation', request: { model: 'google/gemma-4-31B-it-qat-q4_0', state: 'Synthetic CPU mock only.',
    questions: [{ id: 'q', type: index < 26 ? 'choice' : index < 52 ? 'score' : 'noul' }] }, targets: { q: { answer: 0 } } }));
const summary = attempts => ({ paired: { improvement_claim_permitted: attempts.every(a => !a.error),
  all_attempts_elapsed_per_accepted_judgment_generative_over_native: 2,
  conditional_both_correct_generative_over_native_latency: { median: 2 } } });

test('both future entrypoints require ROOT flag, inference-ready freeze, exact plan SHA and bounded scope', () => {
  const full = structuredClone(proposal); full.status = 'root_frozen'; full.inference_ready = true;
  full.generative.capability_source_reviewed = true;
  Object.keys(full.generative.capabilities).forEach(key => { full.generative.capabilities[key] = true; });
  const bytes = Buffer.from(JSON.stringify(full));
  const clearance = { kind: 'gemma4_direct_performance_root_clearance', stage_cleared: true,
    scope: 'full_developer_validation_78_ABBA_312_attempts_only', plan_sha256: sha256(bytes), other_native_gpu_work_idle: true, production_role_approval: false };
  assert.equal(checkRootPermit(bytes, clearance, true).inference_ready, true);
  assert.throws(() => checkRootPermit(bytes, clearance, false));
  assert.throws(() => checkRootPermit(bytes, { ...clearance, plan_sha256: '0'.repeat(64) }, true));
  assert.throws(() => checkRootPermit(Buffer.from(JSON.stringify(proposal)), clearance, true));
  const tiny = structuredClone(capability); tiny.status = 'root_frozen'; tiny.inference_ready = true;
  const tinyBytes = Buffer.from(JSON.stringify(tiny));
  const tinyClearance = { kind: 'gemma4_direct_server_capability_root_clearance', stage_cleared: true,
    scope: 'three_synthetic_cases_one_owned_metal_server_only', plan_sha256: sha256(tinyBytes), other_native_gpu_work_idle: true, production_role_approval: false };
  assert.equal(checkCapabilityPermit(tinyBytes, tinyClearance, true).synthetic_cases.length, 3);
  assert.throws(() => checkCapabilityPermit(tinyBytes, tinyClearance, false));
  assert.throws(() => checkCapabilityPermit(tinyBytes, { ...tinyClearance, plan_sha256: '0'.repeat(64) }, true));
  tiny.synthetic_cases.push(tiny.synthetic_cases[0]);
  assert.throws(() => checkCapabilityPermit(Buffer.from(JSON.stringify(tiny)), tinyClearance, true));
});

test('four sequential mock blocks retain all 312 attempts and cannot establish native speed', async () => {
  let active = 0; let maximum = 0; const order = [];
  const result = await executeBlocks({ plan: proposal, records, proofKind: 'cpu_mock', evidenceSink: async () => {}, pairedSummary: summary,
    judge: () => ({ answers: [{}], correct_judgment: true, completed_clear_decision: true, abstention: false }),
    createAdapter: async block => ({ initialize: async signal => { signal.throwIfAborted(); active++; maximum = Math.max(maximum, active); order.push(block.method); },
      run: async (source, signal, attempt) => { signal.throwIfAborted(); assert.ok(!Object.hasOwn(source, 'targets')); attempt.accounting_complete = true; attempt.cache_clear_proved = true; return {}; },
      close: async () => { active--; return { owned_cleanup_complete: true }; } }) });
  assert.deepEqual(order, ['native','generative','generative','native']); assert.equal(maximum, 1); assert.equal(active, 0);
  assert.equal(result.attempts.length, 312); assert.equal(result.status, 'completed'); assert.equal(result.improvement_claim_permitted, false);
});

test('failed initialization and failed cleanup retain frozen coverage without launching after unknown close', async () => {
  let factories = 0;
  const result = await executeBlocks({ plan: proposal, records, proofKind: 'cpu_mock', evidenceSink: async () => {}, pairedSummary: summary,
    judge: () => ({ answers: [{}], correct_judgment: true }), createAdapter: async () => {
      factories++; return { initialize: async () => { throw Error('synthetic init failure'); }, run: async () => { throw Error('must not run'); },
        close: async () => ({ error: 'synthetic missing close', owned_cleanup_complete: false }) };
    } });
  assert.equal(factories, 1); assert.equal(result.attempts.length, 312); assert.ok(result.attempts.every(a => a.error));
  assert.equal(result.status, 'incomplete'); assert.equal(result.evidence.single_active_native_gpu_execution, false); assert.equal(result.improvement_claim_permitted, false);
});

test('stage cancellation reaches initialization before any mock adapter is created', async () => {
  const aborted = new AbortController(); aborted.abort(Error('synthetic cancellation')); let factories = 0;
  const result = await executeBlocks({ plan: proposal, records, proofKind: 'cpu_mock', abortSignal: aborted.signal,
    evidenceSink: async () => {}, pairedSummary: summary, judge: () => ({}), createAdapter: async () => { factories++; throw Error('must not create'); } });
  assert.equal(factories, 0); assert.equal(result.attempts.length, 312); assert.ok(result.attempts.every(a => a.error));
});

async function mockGenerator({ beforeDispatchFailure = false } = {}) {
  const proof = await mkdtemp(join(HERE, 'cpu-mock-')); const savedFetch = globalThis.fetch; let slotErases = 0; const bodies = []; let index = 0;
  const fakeFetch = async (url, options = {}) => {
    if (url.endsWith('/health')) return new Response('{}');
    if (url.endsWith('/v1/models')) return Response.json({ data: [{ id: proposal.generative.model_id }] });
    if (url.endsWith('/slots/0?action=erase')) { slotErases++; return Response.json({ n_erased: 100 }); }
    assert.ok(url.endsWith('/v1/chat/completions')); const body = JSON.parse(options.body); bodies.push(body);
    return Response.json({ model: proposal.generative.model_id, usage: { prompt_tokens: 100, completion_tokens: 11 },
      timings: { cache_n: 0, prompt_n: 100, predicted_n: 11 }, choices: [{ message: { content: '{"invalid":true}' } }] });
  };
  const fakeLabel = async (input, options) => {
    const source = JSON.parse((await readFile(input, 'utf8')).trim());
    for (let i = 0; i < 3; i++) {
      try { await globalThis.fetch(options.teacherUrl + '/chat/completions', { method: 'POST', signal: options.signal,
        headers: { 'content-type': 'application/json' }, body: JSON.stringify({ model: proposal.generative.model_id, temperature: 0, max_tokens: 2048,
          response_format: { type: 'json_schema', json_schema: { strict: true, schema: {} } },
          messages: [{ role: 'system', content: 'Synthetic teacher contract mock only.' }, { role: 'user', content: JSON.stringify({ context: source.request.state, questions: source.request.questions }) }] }) }); }
      catch { /* simulated existing retry policy */ }
    }
    throw Error('synthetic exhausted malformed-target retries');
  };
  const adapter = await makeGenerativeAdapter({ plan: proposal, proof, audit: async () => {}, labelRfdt: fakeLabel, originalFetch: fakeFetch, nextTrial: () => ++index,
    onPost: async () => { if (beforeDispatchFailure) throw Error('synthetic apply-template failure'); },
    startServerImpl: async () => ({ child: { pid: 1 }, failure: () => null, ownsListener: async () => true,
      logs: () => 'offloaded 66/66 layers to GPU\nllama_prepare_model_devices: using device MTL0 (Apple M3 Max) (', close: async () => ({ owned_cleanup_complete: true }) }) });
  const attempt = { transport: [] };
  try {
    await adapter.initialize(AbortSignal.timeout(10000));
    const source = { id: 'synthetic-cpu-only', group_id: 'synthetic-cpu-only', split: 'validation',
      request: { model: proposal.generative.model_id, state: 'Synthetic CPU context only.', questions: [{ id: 'q', type: 'noul', instructions: 'Unknown?' }] } };
    await assert.rejects(adapter.run(source, AbortSignal.timeout(10000), attempt));
    return { attempt, slotErases, bodies };
  } finally { await adapter.close(); globalThis.fetch = savedFetch; }
}

test('malformed-target retries retain measured work and erase the owned slot before every actual POST', async () => {
  const { attempt, slotErases, bodies } = await mockGenerator();
  assert.equal(slotErases, 3); assert.equal(bodies.length, 3); assert.equal(attempt.transport.length, 3);
  assert.ok(bodies.every(body => body.chat_template_kwargs.enable_thinking === false && body.id_slot === 0));
  assert.deepEqual(attempt.actual_work, { computed_prompt_tokens: 300, computed_output_tokens: 33 }); assert.equal(attempt.accounting_complete, true);
});

test('pre-dispatch capability failure retains reset receipts without inventing actual provider POSTs', async () => {
  const { attempt, slotErases, bodies } = await mockGenerator({ beforeDispatchFailure: true });
  assert.equal(slotErases, 3); assert.equal(bodies.length, 0); assert.equal(attempt.transport.length, 0);
  assert.equal(attempt.accounting_complete, false); assert.equal(attempt.actual_work.computed_prompt_tokens, null);
});
