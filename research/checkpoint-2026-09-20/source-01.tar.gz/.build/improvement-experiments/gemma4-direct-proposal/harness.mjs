import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { buildSchedule, exactAttemptCoverage, improvementClaimPermitted, sha256 } from './protocol.mjs';

export function checkRootPermit(planBytes, clearance, rootFlag) {
  assert.equal(rootFlag, true, 'Explicit --root-cleared flag required');
  const plan = JSON.parse(planBytes.toString('utf8'));
  assert.equal(plan.kind, 'gemma4_direct_performance_prospective_protocol');
  assert.equal(plan.status, 'root_frozen');
  assert.equal(plan.inference_ready, true, 'Source proposal is not an inference plan');
  assert.equal(clearance.kind, 'gemma4_direct_performance_root_clearance');
  assert.equal(clearance.stage_cleared, true);
  assert.equal(clearance.scope, 'full_developer_validation_78_ABBA_312_attempts_only');
  assert.equal(clearance.plan_sha256, sha256(planBytes), 'ROOT must clear the exact plan bytes');
  assert.equal(clearance.other_native_gpu_work_idle, true);
  assert.equal(clearance.production_role_approval, false);
  assert.equal(plan.dataset.records, 78);
  assert.equal(plan.dataset.groups, 39);
  assert.equal(plan.dataset.input_sha256, '4ca805a0eb60be5add66db7c79f673a41141b47b1b309ced228af908ada50ef0');
  assert.equal(plan.artifacts.model.sha256, '179cfb99212709597eae5929112cfca677e1bbf566178b479ae1da0c4772874b');
  assert.equal(plan.artifacts.binary.sha256, '8d20a2b54edc87489f8e6648f81b99f81513328c39c55d14fcbad1f2f09392a8');
  assert.equal(plan.artifacts.template.sha256, 'ae53464bf3be25802b3a5b37def7fd89667067d7577049b3b2d74c4d8de4c6d4');
  assert.equal(plan.physical_profile_sha256, '9e7c39f9d4838248a768a28be9c3cacfb9a12d203556a7b60586c5b624def694');
  assert.match(plan.generative.binary_sha256 ?? '', /^[a-f0-9]{64}$/);
  assert.equal(plan.generative.binary_sha256, 'b866bbcd1d84545b3032787295205ad5a0674fcb62fc28bb8bcef42ed36948bb');
  assert.equal(plan.generative.capability_source_reviewed, true);
  assert.ok(Object.values(plan.generative.capabilities).every(value => value === true));
  assert.equal(plan.generative.chat_template_kwargs.enable_thinking, false);
  assert.equal(plan.generative.max_tokens, 2048);
  assert.equal(plan.generative.temperature, 0);
  assert.equal(plan.generative.parallel, 1);
  assert.equal(plan.generative.host, '127.0.0.1');
  assert.equal(plan.generative.cache_ram_mib, 0);
  assert.deepEqual(plan.conditions.blocks, ['native', 'generative', 'generative', 'native']);
  assert.equal(plan.conditions.total_attempts, 312);
  assert.equal(plan.runtime_bounds.request_timeout_ms, 600000);
  assert.equal(plan.runtime_bounds.total_timeout_ms, 21600000);
  return plan;
}

// CPU tests inject mocks. Only runner.mjs supplies actual, ROOT-cleared adapters.
// The adapter receives gold-free request data; judgment receives gold on the host.
export async function executeBlocks({ plan, records, createAdapter, judge, pairedSummary, evidenceSink, proofKind, abortSignal }) {
  const schedule = buildSchedule(plan.dataset.expected_ids, plan.conditions.seed);
  const byId = new Map(records.map(record => [record.id, record]));
  assert.equal(byId.size, 78);
  assert.deepEqual([...byId.keys()].sort(), [...plan.dataset.expected_ids].sort());
  const attempts = []; const blocks = []; const started = performance.now();
  const deadlineSignal = AbortSignal.timeout(plan.runtime_bounds.total_timeout_ms);
  const stageSignal = abortSignal ? AbortSignal.any([abortSignal, deadlineSignal]) : deadlineSignal;
  let cleanupError = null; let accountingComplete = true; let cacheProof = true;
  for (const block of schedule) {
    const row = { method: block.method, repetition: block.repetition, initialization_ms: null, cleanup: null };
    let adapter = null; let initializationError = null;
    const initStarted = performance.now();
    try {
      if (cleanupError) throw new Error('Remaining blocks not executed after owned cleanup failure: ' + cleanupError);
      assert.ok(performance.now() - started < plan.runtime_bounds.total_timeout_ms, 'Total deadline expired');
      stageSignal.throwIfAborted();
      adapter = await createAdapter(block, block.record_ids.map(id => byId.get(id)));
      await adapter.initialize(stageSignal);
    } catch (error) { initializationError = String(error); }
    row.initialization_ms = performance.now() - initStarted;
    row.initialization_error = initializationError;
    try {
      for (const recordId of block.record_ids) {
        const record = byId.get(recordId);
        const attempt = { method: block.method, repetition: block.repetition, record_id: recordId,
          group_id: record.group_id, regression: record.regression === true,
          pair_key: `${block.repetition}:${recordId}`, method_call_index: attempts.filter(a => a.method === block.method).length + 1,
          expected_clear_decision: record.request.questions.every(q => q.type !== 'noul' ||
            (Object.hasOwn(record.targets[q.id], 'answer') && record.targets[q.id].answer !== null)),
          answers: [], transport: [], correct_judgment: false, completed_clear_decision: false, abstention: false };
        const sent = performance.now();
        try {
          if (initializationError) throw new Error(initializationError);
          const remaining = plan.runtime_bounds.total_timeout_ms - (performance.now() - started);
          assert.ok(remaining > 0, 'Total deadline expired');
          const signal = AbortSignal.any([stageSignal, AbortSignal.timeout(Math.min(plan.runtime_bounds.request_timeout_ms, Math.floor(remaining)))]);
          signal.throwIfAborted();
          const request = JSON.parse(JSON.stringify(structuredClone(record.request)));
          const returned = await adapter.run({ id: record.id, group_id: record.group_id, split: record.split, request }, signal, attempt);
          Object.assign(attempt, judge(record, returned, block.method));
          assert.equal(attempt.accounting_complete, true, 'Actual native work accounting incomplete');
          assert.equal(attempt.cache_clear_proved, true, 'Native cache reset not proved');
        } catch (error) { attempt.error = String(error); }
        finally {
          attempt.elapsed_ms = performance.now() - sent;
          if (attempt.accounting_complete !== true) accountingComplete = false;
          if (attempt.cache_clear_proved !== true) cacheProof = false;
          attempts.push(attempt);
          await evidenceSink('attempt', attempt);
        }
      }
    } finally {
      if (adapter) {
        try {
          row.cleanup = await adapter.close();
          assert.equal(row.cleanup.owned_cleanup_complete, true, 'Missing owned close proof');
          assert.ok(!row.cleanup.error && !row.cleanup.cleanupError, 'Owned cleanup recorded failure');
        }
        catch (error) { row.cleanup_error = String(error); cleanupError = row.cleanup_error; }
      }
      blocks.push(row); await evidenceSink('block', row);
    }
    // Never start another GPU process after failure to prove owned cleanup.
    // Retain the remaining frozen attempts as failures without launching again.
  }
  let fullCoverage = false;
  try { fullCoverage = exactAttemptCoverage(attempts, schedule); } catch { /* partial result remains non-qualified */ }
  const summary = pairedSummary(attempts);
  const replicateSummaries = [1, 2].map(repetition => pairedSummary(attempts.filter(a => a.repetition === repetition)));
  const evidence = { proof_kind: proofKind, exact_frozen_artifacts: proofKind === 'root_attested_actual_native',
    host_only_gold_scoring: true, explicit_disabled_thinking_both_arms: proofKind === 'root_attested_actual_native',
    cache_clear_proved_both_arms: cacheProof, actual_native_work_complete: accountingComplete,
    full_developer_coverage: fullCoverage, single_active_native_gpu_execution: !cleanupError,
    monotonic_clock_unmodified: attempts.every(attempt => Number.isFinite(attempt.elapsed_ms) && attempt.elapsed_ms > 0) };
  return { kind: 'gemma4_direct_performance_result', status: fullCoverage && !cleanupError ? 'completed' : 'incomplete',
    attempts, blocks, summary, replicate_summaries: replicateSummaries, evidence,
    initialization_scope: plan.conditions.cold_scope, cleanup_error: cleanupError,
    improvement_claim_permitted: improvementClaimPermitted(summary, replicateSummaries, evidence) };
}
