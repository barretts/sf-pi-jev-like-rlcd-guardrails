import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { readFile, writeFile, rename, rm } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseArgs } from 'node:util';

const digest = value => createHash('sha256').update(value).digest('hex');
const representationNames = ['string_state', 'structured_state', 'messages'];
export const representation = record => typeof record.request.state === 'string' ? 'string_state' :
  record.request.state !== undefined ? 'structured_state' : 'messages';

export function coverageOf(records) {
  const groups = new Map();
  const representations = Object.fromEntries(representationNames.map(name => [name, { records: 0, groups: [] }]));
  for (const record of records) {
    const name = representation(record);
    representations[name].records += 1;
    const entries = groups.get(record.group_id) ?? [];
    entries.push(record);
    groups.set(record.group_id, entries);
  }
  for (const name of representationNames) {
    representations[name].groups = [...new Set(records.filter(record => representation(record) === name)
      .map(record => record.group_id))].sort();
  }
  return {
    records: records.length,
    groups: groups.size,
    choice_records: records.filter(record => record.request.questions.length === 1 &&
      record.request.questions[0].type === 'choice').length,
    representations,
    group_records: Object.fromEntries([...groups.entries()].sort(([a], [b]) => a.localeCompare(b))
      .map(([group, entries]) => [group, { records: entries.length, ids: entries.map(record => record.id).sort(),
        representations: Object.fromEntries(representationNames.map(name => [name,
          entries.filter(record => representation(record) === name).length])) }])),
    independent_group_count: groups.size,
    variants_are_independent_samples: false,
  };
}

export function assertExpectations(coverage, expectations = {}) {
  for (const key of ['records', 'groups', 'choice_records']) {
    if (expectations[key] !== undefined) assert.equal(coverage[key], expectations[key], `diagnosis ${key} mismatch`);
  }
  for (const name of representationNames) {
    if (expectations.representations?.[name] !== undefined)
      assert.equal(coverage.representations[name].records, expectations.representations[name], `diagnosis ${name} mismatch`);
  }
  if (expectations.variants_per_group !== undefined) assert.ok(Object.values(coverage.group_records)
    .every(group => group.records === expectations.variants_per_group), 'diagnosis variants/group mismatch');
}

export function diagnosisGates(records, report, artifact) {
  const expected = coverageOf(records);
  const byId = new Map(records.map(record => [record.id, record]));
  const results = report.results ?? [];
  const exactIds = results.length === records.length && new Set(results.map(result => result.id)).size === records.length &&
    results.every(result => byId.has(result.id) && result.group_id === byId.get(result.id).group_id && result.split === 'validation');
  const observed = coverageOf(results.filter(result => byId.has(result.id)).map(result => byId.get(result.id)));
  const coverage = {
    expected, observed,
    expected_ids: records.map(record => record.id).sort(),
    observed_ids: results.map(result => result.id).sort(),
  };
  const gates = {
    complete_expected_ids: exactIds,
    zero_errors: results.length > 0 && results.every(result => !result.error) && report.summary?.failures === 0,
    choice_accuracy: typeof report.summary?.choice?.accuracy === 'number' && Number.isFinite(report.summary.choice.accuracy) &&
      report.summary.choice.accuracy >= 0.95 && report.summary.choice.count === records.length,
    group_coverage: exactIds && observed.groups === expected.groups && expected.groups > 0,
    representation_coverage: exactIds && representationNames.every(name =>
      observed.representations[name].records === expected.representations[name].records &&
      JSON.stringify(observed.representations[name].groups) === JSON.stringify(expected.representations[name].groups)),
    each_group_representation_coverage: exactIds && representationNames.every(name =>
      expected.representations[name].records === 0 || expected.representations[name].groups.length === expected.groups),
    native_candidate_identity: results.every(result => result.error || (
      result.model === artifact.id && result.metadata?.artifact?.sha256 === artifact.sha256 &&
      result.metadata?.artifact?.size === artifact.size && result.metadata?.backend === 'llama.cpp' &&
      result.metadata?.device === 'metal' && result.metadata?.template_version === 'v2')),
  };
  return { coverage, gates: { ...gates, passed: Object.values(gates).every(Boolean) } };
}

async function productionDependencies() {
  const [backend, evaluation, models] = await Promise.all([
    import('../../../dist/backend.js'), import('../../../dist/evaluation.js'), import('../../../dist/models.js'),
  ]);
  return { ...backend, ...evaluation, ...models };
}

export async function runDiagnosis(values, injectedDependencies) {
  const dependencies = injectedDependencies ?? await productionDependencies();
  const { Classifier, configFromEnv, validateQualityRecords, evaluateRecords, writeQualityReport, verifyTrainedArtifactExport } = dependencies;
  const controller = new AbortController();
  const cancel = () => controller.abort(new DOMException('Interrupted', 'AbortError'));
  process.once('SIGINT', cancel);
  process.once('SIGTERM', cancel);
  const startedAt = new Date().toISOString();
  let completed = 0;
  let records = [];
  let artifact;
  let classifier;
  let scopedRegistry;
  let registryRemoved = false;
  let report = { results: [], summary: { records: 0, failures: 0, choice: { count: 0, correct: 0, accuracy: null } } };
  let error;
  const progress = async phase => {
    const path = resolve(values.progress);
    const part = `${path}.${process.pid}.part`;
    await writeFile(part, JSON.stringify({ pid: process.pid, phase, split: 'validation', completed_records: completed,
      total_records: records.length, started_at: startedAt, observed_at: new Date().toISOString(),
      artifact_id: artifact?.id, artifact_sha256: artifact?.sha256 }, null, 2) + '\n', { mode: 0o600 });
    await rename(part, path);
  };
  try {
    const bytes = await readFile(values.corpus);
    assert.equal(digest(bytes), values['corpus-sha256'], 'frozen diagnosis corpus changed');
    const raw = bytes.toString('utf8').split(/\r?\n/).filter(line => line.trim()).map(line => JSON.parse(line));
    assert.ok(raw.length > 0 && raw.every(record => record.split === 'validation'), 'diagnosis must contain validation rows only');
    records = validateQualityRecords(raw);
    assert.equal(coverageOf(records).choice_records, records.length, 'diagnosis requires exactly one choice question per row');
    assertExpectations(coverageOf(records), JSON.parse(values.expectations ?? '{}'));
    artifact = JSON.parse(await readFile(values.artifact, 'utf8'));
    assert.equal(artifact.template_version, 'v2');
    const descriptor = await verifyTrainedArtifactExport(artifact);
    scopedRegistry = resolve(dirname(values.output), `diagnosis-validation-candidate-${randomUUID()}-registry.json`);
    await writeFile(scopedRegistry, JSON.stringify({ version: 1, artifacts: [descriptor] }, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
    classifier = new Classifier({ ...configFromEnv(process.env), modelId: artifact.id, modelFile: artifact.file,
      artifactRegistryPath: scopedRegistry, device: 'metal', templateVersion: 'v2', advanced: true });
    await progress('evaluating');
    report = await evaluateRecords({ classify: async (request, signal) => {
      try { return await classifier.classify(request, signal); }
      finally { completed += 1; await progress('evaluating'); }
    } }, records, 'v2', { modelId: artifact.id, signal: controller.signal });
  } catch (caught) {
    error = caught;
  } finally {
    try { await classifier?.dispose(); }
    catch (caught) { error ??= caught; }
    try {
      if (scopedRegistry) { await rm(scopedRegistry, { force: true }); registryRemoved = true; }
    } catch (caught) { error ??= caught; }
    process.removeListener('SIGINT', cancel);
    process.removeListener('SIGTERM', cancel);
  }
  const { coverage, gates } = diagnosisGates(records, report, artifact ?? {});
  report.coverage = coverage;
  report.experiment_gates = { ...gates, execution_completed: !error,
    passed: gates.passed && !error, choice_accuracy_threshold: 0.95 };
  report.experiment = { corpus_raw_sha256: values['corpus-sha256'], split: 'validation',
    training_run: artifact?.training_run, artifact_id: artifact?.id, artifact_sha256: artifact?.sha256,
    artifact_size: artifact?.size, permanent_approval: false, scoped_registry_removed: registryRemoved,
    completed_records: completed, expected_records: records.length, started_at: startedAt,
    completed_at: new Date().toISOString(), outcome: error ? (controller.signal.aborted ? 'cancelled' : 'failed') :
      gates.passed ? 'completed_quality_pass' : 'completed_quality_fail' };
  if (error) report.error = { name: error.name ?? 'Error', message: String(error.message ?? error).slice(-16000) };
  await writeQualityReport(values.output, report);
  await progress(error ? (controller.signal.aborted ? 'cancelled' : 'failed') : 'complete');
  return report;
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  const { values } = parseArgs({ options: { artifact: { type: 'string' }, corpus: { type: 'string' },
    'corpus-sha256': { type: 'string' }, expectations: { type: 'string' }, output: { type: 'string' }, progress: { type: 'string' } } });
  for (const key of ['artifact', 'corpus', 'corpus-sha256', 'output', 'progress']) assert.equal(typeof values[key], 'string', `--${key} required`);
  const report = await runDiagnosis(values);
  process.stdout.write(JSON.stringify(report, null, 2) + '\n');
  if (!report.experiment_gates.passed) process.exitCode = 1;
}
