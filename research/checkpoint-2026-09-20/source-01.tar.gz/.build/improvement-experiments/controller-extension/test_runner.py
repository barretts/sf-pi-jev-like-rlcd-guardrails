"""CPU-only private controller proof. All process launches are replaced with mocks."""
import argparse
import contextlib
import importlib.util
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("private_runner", Path(__file__).resolve().parents[1] / "rfdt-runner.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class ControllerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="controller-cpu-proof-")
        self.root = Path(self.temporary.name).resolve()
        self.work = self.root / "work"
        self.work.mkdir()
        self.default = self.work / "rfdt-stage.json"
        self.custom = self.work / "custom-stage.json"
        self.stage = {"optimizer_rows": 570, "optimizer_splits": {"train": 570, "validation": 0, "test": 0}}
        self.default.write_text(json.dumps(self.stage))
        self.custom.write_text(json.dumps(self.stage))
        self.patches = [patch.object(runner, "WORK", self.work), patch.object(runner, "DEFAULT_STAGE", self.default),
                        patch.object(runner, "ROOT", self.root)]
        for item in self.patches:
            item.start()
        self.args = argparse.Namespace(stage_file=None, stage_sha256=None)

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.temporary.cleanup()

    def main(self, argv, **patches):
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch("sys.argv", ["rfdt-runner.py", *argv]))
            for key, value in patches.items():
                stack.enter_context(patch.object(runner, key, value))
            output = io.StringIO()
            stack.enter_context(contextlib.redirect_stdout(output))
            runner.main()
        return json.loads(output.getvalue())

    def test_default_stage_remains_legacy_and_has_no_extra_phase(self):
        binding, staged = runner.load_stage(self.args)
        self.assertEqual(binding, {"path": str(self.default), "sha256": runner.sha(self.default)})
        self.assertEqual(staged, self.stage)
        self.assertIsNone(runner.validation_command(staged, self.root / "run", self.work))

    def test_explicit_stage_sha_and_private_path_are_enforced(self):
        self.args.stage_file = str(self.custom)
        self.args.stage_sha256 = runner.sha(self.custom)
        binding, staged = runner.load_stage(self.args)
        self.assertTrue(runner.stage_unchanged(binding, staged))
        self.custom.write_text(json.dumps({**self.stage, "revision": 2}))
        self.assertFalse(runner.stage_unchanged(binding, staged))
        with self.assertRaisesRegex(AssertionError, "detached stage SHA"):
            runner.load_stage(self.args)
        self.args.stage_file = str(self.root / "external.json")
        with self.assertRaisesRegex(AssertionError, "private experiment"):
            runner.stage_path(self.args)

    def test_extra_corpus_sha_is_bound_and_metadata_propagates(self):
        corpus = self.work / "synthetic-validation.jsonl"
        corpus.write_text('{"split":"validation"}\n')
        diagnosis = {"path": str(corpus), "sha256": runner.sha(corpus), "records": 56, "groups": 14,
                     "choice_records": 56, "representations": {"string_state": 0, "structured_state": 28, "messages": 28},
                     "variants_per_group": 4}
        self.custom.write_text(json.dumps({**self.stage, "diagnosis_validation": diagnosis}))
        self.args.stage_file = str(self.custom)
        binding, staged = runner.load_stage(self.args)
        command = runner.validation_command(staged, self.root / "run", self.work)
        self.assertEqual(command[command.index("--corpus") + 1], str(corpus))
        self.assertEqual(json.loads(command[command.index("--expectations") + 1]), diagnosis)
        corpus.write_text('{"split":"validation","revision":2}\n')
        self.assertFalse(runner.stage_unchanged(binding, staged))
        with self.assertRaisesRegex(AssertionError, "diagnosis validation SHA"):
            runner.load_stage(self.args)

    def test_detached_worker_and_status_keep_stage_path_sha_and_512_steps(self):
        commands = []
        class Child:
            pid = 123456
        def fake_launch(command, **options):
            commands.append((command, options))
            return Child()
        with patch.object(runner.subprocess, "Popen", side_effect=fake_launch), patch.object(runner, "identity", return_value="mock-start"):
            launch = self.main(["run", "--detach", "--root-gpu-cleared", "--round", "9", "--steps", "512",
                                "--stage-file", str(self.custom), "--blocker-pid", "77"])
            command, options = commands[0]
            self.assertEqual(command[command.index("--stage-file") + 1], str(self.custom))
            self.assertEqual(command[command.index("--stage-sha256") + 1], runner.sha(self.custom))
            self.assertEqual(command[command.index("--steps") + 1], "512")
            self.assertEqual(command[command.index("--blocker-pid") + 1], "77")
            self.assertTrue(options["start_new_session"])
            status = self.main(["status", "--round", "9", "--stage-file", str(self.custom)])
            self.assertEqual(status["stage_binding"], launch["stage_binding"])
            self.assertTrue(status["stage_binding_valid"])
            with self.assertRaisesRegex(AssertionError, "does not match owned job"):
                self.main(["status", "--round", "9", "--stage-file", str(self.default)])
            self.custom.write_text(json.dumps({**self.stage, "revision": 2}))
            self.assertFalse(self.main(["status", "--round", "9"])["stage_binding_valid"])
        self.assertEqual(len(commands), 1, "only the mocked owner launch was requested")

    def test_step_protocol_is_preserved_and_512_is_an_explicit_trial(self):
        for steps in [64, 128, 256, 512]:
            result = self.main(["plan", "--steps", str(steps)])
            self.assertEqual(result["planned_steps"], [64, 128, 256])
            self.assertEqual(result["optional_trial_steps"], [512])
            self.assertEqual(result["model_calls"], 0)
        with self.assertRaises(SystemExit), contextlib.redirect_stderr(io.StringIO()):
            self.main(["plan", "--steps", "513"])

    def test_new_training_count_still_requires_zero_heldout_optimizer_rows(self):
        stage = {"optimizer_rows": 730, "optimizer_splits": {"train": 730, "validation": 0, "test": 0}}
        self.custom.write_text(json.dumps(stage))
        self.args.stage_file = str(self.custom)
        self.assertEqual(runner.load_stage(self.args)[1]["optimizer_rows"], 730)
        stage["optimizer_splits"]["validation"] = 1
        self.custom.write_text(json.dumps(stage))
        with self.assertRaisesRegex(AssertionError, "training rows only"):
            runner.load_stage(self.args)

    def mocked_worker(self, extra_validation):
        (self.root / "dist").mkdir()
        for name in ["cli.js", "rfdt.js", "models.js", "backend.js", "core.js", "evaluation.js"]:
            (self.root / "dist" / name).write_text("synthetic CPU fixture")
        (self.root / "fixtures").mkdir()
        legacy_path = self.root / "fixtures/quality.jsonl"
        legacy_path.write_text("synthetic hash-only fixture; no TEST rows")
        (self.root / "rfdt").mkdir()
        (self.root / "rfdt/worker.py").write_text("synthetic hash-only worker")
        (self.work / "evaluate-developer-candidate.mjs").write_text("synthetic hash-only helper")
        base = self.root / "synthetic-base"
        base.mkdir()
        (base / "model.safetensors").write_text("synthetic hash-only base; never loaded")
        train = self.work / "train.jsonl"
        train.write_text("synthetic hash-only training input")
        frozen = self.work / "developer.jsonl"
        frozen.write_text("synthetic hash-only frozen corpus; no TEST rows")
        staged = {"optimizer_rows": 730, "optimizer_splits": {"train": 730, "validation": 0, "test": 0},
                  "training_input": str(train), "training_input_sha256": runner.sha(train),
                  "developer_frozen": str(frozen), "developer_sha256": runner.sha(frozen), "old_evidence_hashes": {}}
        if extra_validation:
            corpus = self.work / "diagnosis.jsonl"
            corpus.write_text('{"split":"validation"}\n')
            staged["diagnosis_validation"] = {"path": str(corpus), "sha256": runner.sha(corpus)}
        self.custom.write_text(json.dumps(staged))
        args = argparse.Namespace(root_gpu_cleared=True, stage_file=str(self.custom), stage_sha256=runner.sha(self.custom),
                                  blocker_pid=[], round=10, steps=512)
        commands = []
        folder = self.work / "rfdt-round-10"
        run = folder / "run"
        class Child:
            pid = 123456
            returncode = 0
            def poll(self):
                return 0
        def fake_launch(command, **options):
            commands.append(command)
            if command[2:4] == ["rfdt", "prepare"]:
                run.mkdir()
                runner.save(run / "manifest.json", {"prepared": {"branches": staged["optimizer_splits"]}})
            elif command[2:4] == ["rfdt", "train"]:
                runner.save(run / "training-report.json", {"adapter_changed": True, "reload_verified": True,
                    "training_loss_decreased": True, "steps": int(command[command.index("--steps") + 1])})
            elif command[2:4] == ["rfdt", "export"]:
                runner.save(run / "artifact.json", {"id": "synthetic"})
            elif command[2:4] == ["rfdt", "evaluate"]:
                runner.save(run / "native-validation-report.json", {"summary": {"gates": {"passed": True},
                    "noul": {"uncertain_count": 1, "uncertainty_mae": 0.05}}})
            elif command[1].endswith("evaluate-developer-candidate.mjs"):
                runner.save(folder / "developer-validation-report.json", {"summary": {"gates": {"passed": True}},
                    "experiment_gates": {"uncertainty_mae": True}})
            elif command[1].endswith("evaluate-diagnosis-candidate.mjs"):
                runner.save(folder / "diagnosis-validation-report.json", {"summary": {"choice": {"accuracy": 1}},
                    "coverage": {"synthetic_mock": True}, "experiment_gates": {"passed": True}})
            else:
                raise AssertionError("unexpected mocked command")
            return Child()
        with patch.object(runner, "BASE", base), patch.object(runner, "BASE_SHA", runner.sha(base / "model.safetensors")), \
                patch.object(runner, "LEGACY_SHA", runner.sha(legacy_path)), \
                patch.object(runner, "CORE_SHA", runner.sha(self.root / "dist/core.js")), \
                patch.object(runner, "old_hashes", return_value={}), patch.object(runner, "identity", return_value="mock-start"), \
                patch.object(runner.signal, "signal"), patch.object(runner.subprocess, "Popen", side_effect=fake_launch), \
                patch.object(runner, "STOP", False):
            job = runner.worker(args)
        self.assertEqual(job["status"], "completed_quality_pass", job.get("error"))
        self.assertEqual(job["stage_binding"], {"path": str(self.custom), "sha256": runner.sha(self.custom)})
        self.assertEqual(job["training"]["steps"], 512)
        self.assertFalse((self.work / "rfdt-runner.lock").exists())
        self.assertEqual(job["heldout_invocations"], 0)
        self.assertEqual(job["approval_invocations"], 0)
        self.assertEqual(set(job["selection_gates"]), {"legacy_quality", "developer_quality", "legacy_uncertainty_mae",
            "developer_uncertainty_mae"} | ({"diagnosis_quality"} if extra_validation else set()))
        self.assertEqual(len(commands), 6 if extra_validation else 5)
        self.assertTrue(all("test" not in command and "approve" not in command for command in commands))

    def test_mocked_worker_binds_custom_stage_and_512_without_optional_phase(self):
        self.mocked_worker(False)

    def test_mocked_worker_adds_separate_diagnosis_gate_without_replacing_existing_gates(self):
        self.mocked_worker(True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
