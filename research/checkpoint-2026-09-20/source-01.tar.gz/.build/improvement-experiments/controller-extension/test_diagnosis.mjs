import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import test from 'node:test';
import { validateQualityRecords, evaluateRecords, writeQualityReport } from '../../../dist/evaluation.js';
import { coverageOf, assertExpectations, diagnosisGates, runDiagnosis } from './evaluate-diagnosis-candidate.mjs';

const artifact = { id: 'cpu-mock-candidate', sha256: 'a'.repeat(64), size: 123, template_version: 'v2',
  file: 'mock-does-not-exist.gguf', training_run: 'cpu-proof-only' };
const records = Array.from({ length: 56 }, (_, index) => ({ id: `synthetic-${index}`, group_id: `synthetic-group-${Math.floor(index / 4)}`,
  split: 'validation', request: { model: 'synthetic', ...(index % 4 < 2 ? { state: { synthetic: Math.floor(index / 4) } } :
    { messages: [{ role: 'user', content: `Synthetic context ${Math.floor(index / 4)}` }] }),
    questions: [{ id: 'q', type: 'choice', instructions: 'Pick the synthetic good option',
      criteria: index % 2 ? [{ id: 'bad', description: 'Bad' }, { id: 'good', description: 'Good' }] :
        [{ id: 'good', description: 'Good' }, { id: 'bad', description: 'Bad' }] }] }, targets: { q: { answer: 'good' } } }));
const expectations = { records: 56, groups: 14, choice_records: 56,
  representations: { string_state: 0, structured_state: 28, messages: 28 }, variants_per_group: 4 };

async function fixture(options = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'diagnosis-cpu-proof-'));
  const bytes = records.map(record => JSON.stringify(record)).join('\n') + '\n';
  const corpus = join(directory, 'synthetic-validation.jsonl');
  const artifactPath = join(directory, 'artifact.json');
  await writeFile(corpus, bytes);
  await writeFile(artifactPath, JSON.stringify(artifact));
  let calls = 0;
  let disposed = false;
  class MockClassifier {
    constructor(settings) { assert.equal(settings.device, 'metal'); assert.equal(settings.modelId, artifact.id); }
    async classify() {
      calls += 1;
      if (options.errorAt === calls) throw new Error('Synthetic classifier failure');
      return { model: artifact.id, answers: { q: { type: 'choice', choice: 'good' } }, metadata: {
        artifact: { sha256: options.wrongIdentity ? 'b'.repeat(64) : artifact.sha256, size: artifact.size },
        backend: 'llama.cpp', device: 'metal', template_version: 'v2' } };
    }
    async dispose() { disposed = true; if (options.disposeError) throw new Error('Synthetic disposal failure'); }
  }
  const values = { artifact: artifactPath, corpus, 'corpus-sha256': createHash('sha256').update(bytes).digest('hex'),
    expectations: JSON.stringify(expectations), output: join(directory, 'report.json'), progress: join(directory, 'progress.json') };
  const dependencies = { Classifier: MockClassifier, configFromEnv: () => ({}), validateQualityRecords, evaluateRecords, writeQualityReport,
    verifyTrainedArtifactExport: async value => value };
  return { directory, values, dependencies, calls: () => calls, disposed: () => disposed,
    cleanup: () => rm(directory, { recursive: true, force: true }) };
}

test('CPU coverage records 14 independent groups and 56 dependent variants with both representations', () => {
  const coverage = coverageOf(records);
  assertExpectations(coverage, expectations);
  assert.equal(coverage.independent_group_count, 14);
  assert.equal(coverage.variants_are_independent_samples, false);
  assert.equal(coverage.representations.structured_state.groups.length, 14);
  assert.equal(coverage.representations.messages.groups.length, 14);
  assert.throws(() => assertExpectations(coverage, { ...expectations, groups: 15 }));
});

test('strict gate accepts .95 and rejects lower accuracy, errors, duplicate IDs and missing variants', () => {
  const results = records.map(record => ({ id: record.id, group_id: record.group_id, split: 'validation', model: artifact.id,
    metadata: { artifact: { sha256: artifact.sha256, size: artifact.size }, backend: 'llama.cpp', device: 'metal', template_version: 'v2' } }));
  const report = { results, summary: { failures: 0, choice: { count: 56, accuracy: 0.95 } } };
  assert.equal(diagnosisGates(records, report, artifact).gates.passed, true);
  assert.equal(diagnosisGates(records, { ...report, summary: { failures: 0, choice: { count: 56, accuracy: 0.94999 } } }, artifact).gates.passed, false);
  assert.equal(diagnosisGates(records, { ...report, results: [{ ...results[0], error: 'synthetic' }, ...results.slice(1)] }, artifact).gates.zero_errors, false);
  assert.equal(diagnosisGates(records, { ...report, results: [results[0], ...results.slice(0, -1)] }, artifact).gates.complete_expected_ids, false);
  assert.equal(diagnosisGates(records, { ...report, results: results.slice(4) }, artifact).gates.group_coverage, false);
  assert.equal(diagnosisGates(records, { ...report, results: results.filter((_, index) => index % 4 < 2) }, artifact).gates.representation_coverage, false);
});

test('mock Classifier uses production scoring for every frozen synthetic ID and leaves a complete report', async () => {
  const data = await fixture();
  try {
    const report = await runDiagnosis(data.values, data.dependencies);
    assert.equal(report.results.length, 56);
    assert.equal(data.calls(), 56);
    assert.equal(data.disposed(), true);
    assert.equal(report.summary.choice.accuracy, 1);
    assert.equal(report.experiment_gates.passed, true);
    assert.equal(report.experiment.scoped_registry_removed, true);
    assert.equal(report.coverage.observed.groups, 14);
    assert.equal(JSON.parse(await readFile(data.values.progress, 'utf8')).phase, 'complete');
    assert.deepEqual(JSON.parse(await readFile(data.values.output, 'utf8')), JSON.parse(JSON.stringify(report)));
    assert.equal((await readdir(data.directory)).filter(name => name.includes('registry')).length, 0);
  } finally { await data.cleanup(); }
});

test('per-record native errors preserve all IDs and fail the additional gate', async () => {
  const data = await fixture({ errorAt: 3 });
  try {
    const report = await runDiagnosis(data.values, data.dependencies);
    assert.equal(report.results.length, 56);
    assert.equal(report.summary.failures, 1);
    assert.equal(report.experiment_gates.zero_errors, false);
    assert.equal(report.experiment_gates.passed, false);
    assert.equal(data.calls(), 56);
  } finally { await data.cleanup(); }
});

test('SHA failure writes a terminal error report before any classifier call', async () => {
  const data = await fixture();
  try {
    data.values['corpus-sha256'] = '0'.repeat(64);
    const report = await runDiagnosis(data.values, data.dependencies);
    assert.equal(data.calls(), 0);
    assert.equal(report.experiment_gates.passed, false);
    assert.match(report.error.message, /frozen diagnosis corpus/);
    assert.equal(JSON.parse(await readFile(data.values.progress, 'utf8')).phase, 'failed');
    assert.equal(JSON.parse(await readFile(data.values.output, 'utf8')).experiment.outcome, 'failed');
  } finally { await data.cleanup(); }
});

test('native identity mismatch and disposal failure fail safely while preserving full scored results', async () => {
  for (const options of [{ wrongIdentity: true }, { disposeError: true }]) {
    const data = await fixture(options);
    try {
      const report = await runDiagnosis(data.values, data.dependencies);
      assert.equal(report.results.length, 56);
      assert.equal(report.experiment_gates.passed, false);
      assert.equal(report.experiment.scoped_registry_removed, true);
      if (options.wrongIdentity) assert.equal(report.experiment_gates.native_candidate_identity, false);
      else assert.equal(report.experiment_gates.execution_completed, false);
    } finally { await data.cleanup(); }
  }
});
