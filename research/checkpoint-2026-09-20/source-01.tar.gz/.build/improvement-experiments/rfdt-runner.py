#!/usr/bin/env python3
"""Private one-candidate runner. plan/stage/status are weights-free; run needs root clearance."""
import argparse
import collections
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / ".build/improvement-experiments"
DEFAULT_STAGE = WORK / "rfdt-stage.json"
DIAGNOSIS_HELPER = WORK / "controller-extension/evaluate-diagnosis-candidate.mjs"
BASE = ROOT / ".build/hf-session-1_s2hbhu/home/hub/models--google--gemma-3-1b-it/snapshots/dcc83ea841ab6100d6b47a070329e1ba4cf78752"
BASE_SHA = "3d4ef8d71c14db7e448a09ebe891cfb6bf32c57a9b44499ae0d1c098e48516b6"
LEGACY_SHA = "cd3de2d07db024aeb0f8d22be394ffa9024307680efbe2967569c325bc7af3c9"
CORE_SHA = "2ee6c409a12b6a4f7b7a7d63c37d84923740e46f8732f625a65d0f39ef04bdf6"
PYTHON = ROOT / ".build/rfdt-venv/bin/python"
OLD = ROOT / ".build/rfdt-c9-64step"
STOP = False
LOG_LIMIT = 32 * 1024 * 1024


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while block := stream.read(16 * 1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def save(path, value):
    path = Path(path)
    part = path.with_name(path.name + f".{os.getpid()}.part")
    part.write_text(json.dumps(value, indent=2) + "\n")
    part.chmod(0o600)
    part.replace(path)


def read(path):
    return json.loads(Path(path).read_text())


def stage_path(args):
    path = Path(args.stage_file).resolve() if args.stage_file else DEFAULT_STAGE.resolve()
    assert path.is_relative_to(WORK.resolve()), "stage file must remain inside private experiment directory"
    return path


def load_stage(args):
    path = stage_path(args)
    raw = path.read_bytes()
    binding = {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}
    if args.stage_sha256:
        assert binding["sha256"] == args.stage_sha256, "detached stage SHA mismatch"
    staged = json.loads(raw)
    assert isinstance(staged, dict), "stage must be an object"
    optimizer_rows = staged["optimizer_rows"]
    assert isinstance(optimizer_rows, int) and not isinstance(optimizer_rows, bool) and optimizer_rows > 0
    assert staged["optimizer_splits"] == {"train": optimizer_rows, "validation": 0, "test": 0}, "optimizer input must contain training rows only"
    diagnosis = staged.get("diagnosis_validation")
    if diagnosis is not None:
        assert isinstance(diagnosis, dict), "diagnosis_validation must be an object"
        path = Path(diagnosis["path"])
        assert path.is_absolute() and str(path.resolve()) == str(path), "diagnosis path must be canonical and absolute"
        digest = diagnosis["sha256"]
        assert isinstance(digest, str) and len(digest) == 64 and all(character in "0123456789abcdef" for character in digest), "invalid diagnosis SHA"
        assert sha(path) == digest, "diagnosis validation SHA mismatch"
    return binding, staged


def stage_unchanged(binding, staged):
    try:
        if sha(binding["path"]) != binding["sha256"]:
            return False
        diagnosis = staged.get("diagnosis_validation")
        return diagnosis is None or sha(diagnosis["path"]) == diagnosis["sha256"]
    except OSError:
        return False


def validation_command(staged, run, folder):
    diagnosis = staged.get("diagnosis_validation")
    if diagnosis is None:
        return None
    return ["node", str(DIAGNOSIS_HELPER), "--artifact", str(run / "artifact.json"),
            "--corpus", diagnosis["path"], "--corpus-sha256", diagnosis["sha256"],
            "--expectations", json.dumps(diagnosis, separators=(",", ":")),
            "--output", str(folder / "diagnosis-validation-report.json"),
            "--progress", str(folder / "diagnosis-validation-progress.json")]


def latest_worker_progress(path):
    """Observe a bounded complete JSONL event without replaying the worker."""
    path = Path(path)
    if not path.exists():
        return None
    with path.open("rb") as stream:
        stream.seek(0, os.SEEK_END)
        size = stream.tell()
        stream.seek(max(0, size - 65536))
        raw = stream.read()
    if not raw.endswith(b"\n"):
        raw = raw.rsplit(b"\n", 1)[0] if b"\n" in raw else b""
    if not raw:
        return None
    line = raw.rstrip(b"\n").rsplit(b"\n", 1)[-1]
    try:
        event = json.loads(line)
    except (ValueError, UnicodeDecodeError):
        return None
    return event if isinstance(event, dict) else None


def identity(pid):
    result = subprocess.run(["ps", "-o", "lstart=", "-p", str(pid)], capture_output=True, text=True)
    return result.stdout.strip() or None


def old_hashes():
    files = [OLD / name for name in ["manifest.json", "artifact.json", "native-validation-report.json", "native-test-report.json"]]
    files.extend(OLD.glob("native-test-*.reservation.json"))
    return {str(path): sha(path) for path in files}


def context_value(row):
    request = row["request"]
    if isinstance(request.get("state"), str):
        return request["state"]
    messages = request.get("messages", [])
    if len(messages) == 1 and messages[0].get("role") == "user":
        return messages[0]["content"]
    if request.get("state") is not None:
        return {"state": request["state"]}
    return {"messages": request["messages"]} if "messages" in request else {}


def contexts(rows):
    """Use the production CPU canonical serializer, including structured state."""
    assert sha(ROOT / "dist/core.js") == CORE_SHA
    script = (
        "import {readFileSync} from 'node:fs';"
        f"import {{canonical}} from {json.dumps((ROOT / 'dist/core.js').as_uri())};"
        "const values=JSON.parse(readFileSync(0,'utf8'));"
        "process.stdout.write(JSON.stringify(values.map(canonical)));"
    )
    result = subprocess.run(["node", "--input-type=module", "-e", script],
                            input=json.dumps([context_value(row) for row in rows]),
                            capture_output=True, text=True, check=True)
    values = json.loads(result.stdout)
    assert len(values) == len(rows) and all(isinstance(value, str) for value in values)
    return values


def stage(args):
    target = stage_path(args)
    assert not target.exists(), "staged experiment already exists; do not overwrite"
    path = Path(args.developer_corpus).resolve()
    assert len(args.developer_sha256) == 64 and sha(path) == args.developer_sha256, "explicit final corpus SHA mismatch"
    developer = [json.loads(line) for line in path.read_text().splitlines() if line]
    assert len(developer) == 546
    assert collections.Counter(row["split"] for row in developer) == {"train": 390, "validation": 78, "test": 78}
    assert collections.Counter(row["request"]["questions"][0]["type"] for row in developer) == {"choice": 182, "score": 182, "noul": 182}
    assert len({row["id"] for row in developer}) == 546
    groups = {}
    for row in developer:
        assert len(row["request"]["questions"]) == 1
        assert groups.setdefault(row["group_id"], row["split"]) == row["split"], "developer group crosses splits"
    assert len({row["group_id"] for row in developer if row["split"] == "train"}) == 195
    legacy_path = ROOT / "fixtures/quality.jsonl"
    assert sha(legacy_path) == LEGACY_SHA
    legacy = [json.loads(line) for line in legacy_path.read_text().splitlines() if line]
    legacy_train = [row for row in legacy if row["split"] == "train"]
    developer_train = [row for row in developer if row["split"] == "train"]
    assert len(legacy_train) == 180
    allowed = ["id", "group_id", "split", "request", "targets", "target_provenance", "regression"]
    train = [{key: row[key] for key in allowed if key in row} for row in legacy_train + developer_train]
    assert len(train) == 570 and len({row["id"] for row in train}) == 570
    assert len({row["group_id"] for row in train}) == 285
    assert collections.Counter(row["request"]["questions"][0]["type"] for row in train) == {"choice": 190, "score": 190, "noul": 190}
    heldout = [row for row in legacy + developer if row["split"] != "train"]
    assert not ({row["group_id"] for row in train} & {row["group_id"] for row in heldout})
    contextual = contexts(train + heldout)
    assert not (set(contextual[:len(train)]) & set(contextual[len(train):])), "training context overlaps a validation/test context"
    assert sha(ROOT / "dist/core.js") == CORE_SHA
    inputs = WORK / "rfdt-inputs" if target == DEFAULT_STAGE.resolve() else target.with_name(target.stem + "-inputs")
    inputs.mkdir(mode=0o700)
    frozen = inputs / "developer-corpus.jsonl"
    frozen.write_bytes(path.read_bytes())
    frozen.chmod(0o600)
    combined = inputs / "combined-train-570.jsonl"
    combined.write_text("".join(json.dumps(row, separators=(",", ":")) + "\n" for row in train))
    combined.chmod(0o600)
    value = {"developer_source": str(path), "developer_frozen": str(frozen), "developer_sha256": args.developer_sha256, "developer_splits": {"train": 390, "validation": 78, "test": 78}, "legacy_source": str(legacy_path), "legacy_sha256": LEGACY_SHA, "training_input": str(combined), "training_input_sha256": sha(combined), "optimizer_rows": 570, "optimizer_groups": 285, "optimizer_splits": {"train": 570, "validation": 0, "test": 0}, "core_sha256": CORE_SHA, "old_evidence_hashes": old_hashes(), "staged_at": time.time(), "model_calls": 0}
    save(target, value)
    return value


def cancel_handler(signum, frame):
    global STOP
    STOP = True


def end_group(child):
    try:
        os.killpg(child.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    deadline = time.monotonic() + 5
    while child.poll() is None and time.monotonic() < deadline:
        time.sleep(0.1)
    # Kill any surviving members of this owned child group, including descendants.
    try:
        os.killpg(child.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    child.wait()


def worker(args):
    assert args.root_gpu_cleared, "explicit root GPU clearance required"
    binding, staged = load_stage(args)
    assert sha(staged["training_input"]) == staged["training_input_sha256"]
    assert sha(staged["developer_frozen"]) == staged["developer_sha256"]
    assert sha(ROOT / "fixtures/quality.jsonl") == LEGACY_SHA
    assert sha(ROOT / "dist/core.js") == CORE_SHA and old_hashes() == staged["old_evidence_hashes"]
    assert BASE.is_dir() and (BASE / "model.safetensors").is_file()
    for pid in args.blocker_pid:
        assert identity(pid) is None, f"root GPU blocker still live: {pid}"
    folder = WORK / f"rfdt-round-{args.round}"
    folder.mkdir(exist_ok=True)
    run = folder / "run"
    assert not run.exists(), "round must start fresh from the official base"
    lock_path = WORK / "rfdt-runner.lock"
    lock = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    job = {"round": args.round, "steps": args.steps, "owner_pid": os.getpid(), "owner_start": identity(os.getpid()), "status": "running", "phase": "preflight", "started_at": time.time(), "run_directory": str(run), "base_model": "google/gemma-3-1b-it", "base_revision": BASE.name, "base_model_path": str(BASE), "fresh_base": True, "old_adapter_used": False, "offline": True, "root_gpu_cleared": True, "blocker_pids": args.blocker_pid, "staged": staged, "phase_history": [], "normal_training_timeout": None, "cancel_term_grace_seconds": 5, "log_limit_bytes_per_stream": LOG_LIMIT, "heldout_invocations": 0, "approval_invocations": 0}
    job_path = folder / "job.json"
    job["stage_binding"] = binding
    critical = ["cli.js", "rfdt.js", "models.js", "backend.js", "core.js", "evaluation.js"]
    job["dist_sha256"] = {name: sha(ROOT / "dist" / name) for name in critical}
    source_files = [ROOT / "rfdt/worker.py", Path(__file__).resolve(), WORK / "evaluate-developer-candidate.mjs"]
    if staged.get("diagnosis_validation") is not None:
        source_files.append(DIAGNOSIS_HELPER)
    job["source_sha256"] = {str(path): sha(path) for path in source_files}
    signal.signal(signal.SIGTERM, cancel_handler)
    signal.signal(signal.SIGINT, cancel_handler)
    child = None
    try:
        os.write(lock, json.dumps({"owner_pid": job["owner_pid"], "owner_start": job["owner_start"], "round": args.round}).encode())
        save(job_path, job)
        job["base_weight_sha256"] = sha(BASE / "model.safetensors")
        assert job["base_weight_sha256"] == BASE_SHA
        env = dict(os.environ, HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1", HF_HUB_DISABLE_PROGRESS_BARS="1", JEV_DEVICE="metal")
        for key in ["HF_TOKEN", "HUGGING_FACE_HUB_TOKEN", "HF_TOKEN_PATH"]:
            env.pop(key, None)
        cli = ["node", str(ROOT / "dist/cli.js")]
        phases = [
            ("prepare", cli + ["rfdt", "prepare", "--input", staged["training_input"], "--output-dir", str(run), "--template", "v2", "--model", "google/gemma-3-1b-it", "--model-file", str(ROOT / "models/gemma-3-1b-it-f16.gguf"), "--device", "metal"]),
            ("train", cli + ["rfdt", "train", "--run", str(run), "--steps", str(args.steps), "--model-path", str(BASE), "--python", str(PYTHON)]),
            ("export", cli + ["rfdt", "export", "--run", str(run), "--model-path", str(BASE), "--python", str(PYTHON)]),
            ("legacy_validation", cli + ["rfdt", "evaluate", "--run", str(run), "--split", "validation"]),
            ("developer_validation", ["node", str(WORK / "evaluate-developer-candidate.mjs"), "--artifact", str(run / "artifact.json"), "--corpus", staged["developer_frozen"], "--corpus-sha256", staged["developer_sha256"], "--output", str(folder / "developer-validation-report.json"), "--progress", str(folder / "developer-validation-progress.json")]),
        ]
        diagnosis_command = validation_command(staged, run, folder)
        if diagnosis_command is not None:
            phases.append(("diagnosis_validation", diagnosis_command))
        for phase, command in phases:
            assert not STOP, "cancelled before next phase"
            assert stage_unchanged(binding, staged), "bound stage or diagnosis corpus changed during candidate"
            assert all(sha(ROOT / "dist" / name) == value for name, value in job["dist_sha256"].items()), "production dist changed during candidate"
            assert all(sha(path) == value for path, value in job["source_sha256"].items()), "executed source changed during candidate"
            assert old_hashes() == staged["old_evidence_hashes"], "old student evidence changed"
            out, err = folder / f"{phase}.stdout.json", folder / f"{phase}.stderr.log"
            assert not out.exists() and not err.exists()
            entry = {"phase": phase, "command": command, "started_at": time.time(), "stdout": str(out), "stderr": str(err)}
            job.update(phase=phase, progress=None)
            job["phase_history"].append(entry)
            with out.open("w") as stdout, err.open("w") as stderr:
                child = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True, close_fds=True)
                entry.update(child_pid=child.pid, child_start=identity(child.pid), child_pgid=child.pid)
                job.update(child_pid=child.pid, child_start=entry["child_start"], child_pgid=child.pid)
                save(job_path, job)
                while child.poll() is None:
                    if not stage_unchanged(binding, staged):
                        job["termination_reason"] = "stage_changed"
                        end_group(child)
                        raise RuntimeError(job["termination_reason"])
                    if not all(sha(path) == value for path, value in job["source_sha256"].items()) or not all(sha(ROOT / "dist" / name) == value for name, value in job["dist_sha256"].items()):
                        job["termination_reason"] = "source_changed"
                        end_group(child)
                        raise RuntimeError(job["termination_reason"])
                    if STOP or max(out.stat().st_size, err.stat().st_size) > LOG_LIMIT:
                        job["termination_reason"] = "explicit_cancel" if STOP else "output_overflow"
                        end_group(child)
                        raise RuntimeError(job["termination_reason"])
                    progress = folder / "developer-validation-progress.json"
                    if phase == "developer_validation" and progress.exists():
                        job["progress"] = read(progress)
                    if phase == "diagnosis_validation" and (folder / "diagnosis-validation-progress.json").exists():
                        job["progress"] = read(folder / "diagnosis-validation-progress.json")
                    if phase == "train":
                        job["progress"] = latest_worker_progress(run / "worker-progress.jsonl")
                    if phase == "export":
                        job["progress"] = latest_worker_progress(run / "fused/worker-progress.jsonl")
                    job["last_observed_at"] = time.time()
                    save(job_path, job)
                    time.sleep(2)
            entry.update(exit_code=child.returncode, completed_at=time.time())
            assert stage_unchanged(binding, staged), "bound stage or diagnosis corpus changed during candidate"
            if phase not in ["legacy_validation", "developer_validation", "diagnosis_validation"] and child.returncode != 0:
                raise RuntimeError(f"{phase} exited {child.returncode}: {err.read_text()[-16000:]}")
            assert child.returncode in [0, 1], f"unexpected {phase} exit"
            if phase == "prepare":
                assert read(run / "manifest.json")["prepared"]["branches"] == staged["optimizer_splits"]
            if phase == "train":
                training = read(run / "training-report.json")
                assert training["adapter_changed"] and training["reload_verified"] and training["training_loss_decreased"] and training["steps"] == args.steps
                job["training"] = training
            save(job_path, job)
            child = None
        legacy = read(run / "native-validation-report.json")
        developer = read(folder / "developer-validation-report.json")
        job["legacy_validation"] = legacy["summary"]
        job["developer_validation"] = developer["summary"]
        job["artifact"] = read(run / "artifact.json")
        legacy_uncertain = legacy["summary"]["noul"]
        job["selection_gates"] = {"legacy_quality": legacy["summary"]["gates"]["passed"], "developer_quality": developer["summary"]["gates"]["passed"], "legacy_uncertainty_mae": legacy_uncertain["uncertain_count"] > 0 and legacy_uncertain["uncertainty_mae"] is not None and legacy_uncertain["uncertainty_mae"] <= 0.1, "developer_uncertainty_mae": developer["experiment_gates"]["uncertainty_mae"]}
        if diagnosis_command is not None:
            diagnosis = read(folder / "diagnosis-validation-report.json")
            job["diagnosis_validation"] = diagnosis["summary"]
            job["diagnosis_validation_coverage"] = diagnosis["coverage"]
            job["diagnosis_validation_gates"] = diagnosis["experiment_gates"]
            job["selection_gates"]["diagnosis_quality"] = diagnosis["experiment_gates"]["passed"]
        job["status"] = "completed_quality_pass" if all(job["selection_gates"].values()) else "completed_quality_fail"
    except BaseException as error:
        if child is not None and child.poll() is None:
            end_group(child)
        job.update(status="cancelled" if STOP else "failed", error=str(error))
    finally:
        job.update(completed_at=time.time(), old_evidence_unchanged=old_hashes() == staged["old_evidence_hashes"], phase="terminal", native_test_absent=not (run / "native-test-report.json").exists(), permanent_approval_absent=not (ROOT / ".jev/artifacts.json").exists())
        save(job_path, job)
        os.close(lock)
        lock_path.unlink()
    return job


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["plan", "stage", "run", "worker", "status", "cancel"])
    parser.add_argument("--developer-corpus")
    parser.add_argument("--developer-sha256")
    parser.add_argument("--stage-file")
    parser.add_argument("--stage-sha256", help=argparse.SUPPRESS)
    parser.add_argument("--round", type=int, default=1)
    parser.add_argument("--steps", type=int, choices=[64, 128, 256, 512], default=64)
    parser.add_argument("--root-gpu-cleared", action="store_true")
    parser.add_argument("--detach", action="store_true")
    parser.add_argument("--blocker-pid", type=int, action="append", default=[])
    args = parser.parse_args()
    assert args.round >= 1
    WORK.mkdir(exist_ok=True)
    if args.action == "plan":
        result = {"planned_steps": [64, 128, 256], "optional_trial_steps": [512], "stage_file": str(stage_path(args)), "fresh_base": str(BASE), "legacy_train": 180, "developer_train": 390, "combined_train": 570, "legacy_validation": 60, "developer_validation": 78, "test_and_approval_automatically_executed": False, "gpu_clearance_required_for_run": True, "stage_available": stage_path(args).exists(), "model_calls": 0}
    elif args.action == "stage":
        assert args.developer_corpus and args.developer_sha256
        result = stage(args)
    elif args.action in ["status", "cancel"]:
        folder = WORK / f"rfdt-round-{args.round}"
        result = read(folder / "job.json") if (folder / "job.json").exists() else read(folder / "launch.json")
        binding = result.get("stage_binding")
        if binding is not None:
            if args.stage_file:
                assert str(stage_path(args)) == binding["path"], "status/cancel stage path does not match owned job"
            if args.stage_sha256:
                assert args.stage_sha256 == binding["sha256"], "status/cancel stage SHA does not match owned job"
            result["stage_binding_valid"] = stage_unchanged(binding, result.get("staged", {}))
        active = identity(result["owner_pid"]) == result["owner_start"]
        result["owner_identity_live"] = active
        if not (folder / "job.json").exists():
            result["status"] = "starting" if active else "startup_failed"
            result["owner_log_tail"] = (folder / "owner.log").read_text()[-16000:]
        if args.action == "cancel":
            assert active and result["status"] == "running", "no matching live owned job"
            os.kill(result["owner_pid"], signal.SIGTERM)
            result["cancel_requested"] = True
    elif args.action == "run" and args.detach:
        assert args.root_gpu_cleared
        binding, staged = load_stage(args)
        folder = WORK / f"rfdt-round-{args.round}"
        folder.mkdir()
        command = [str(PYTHON), str(Path(__file__).resolve()), "worker", "--round", str(args.round), "--steps", str(args.steps), "--stage-file", binding["path"], "--stage-sha256", binding["sha256"], "--root-gpu-cleared"]
        for pid in args.blocker_pid:
            command.extend(["--blocker-pid", str(pid)])
        with (folder / "owner.log").open("w") as stream:
            child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=stream, stderr=stream, start_new_session=True, close_fds=True)
        result = {"owner_pid": child.pid, "owner_start": identity(child.pid), "round": args.round, "steps": args.steps, "stage_binding": binding, "job": str(folder / "job.json"), "owner_log": str(folder / "owner.log")}
        save(folder / "launch.json", result)
    else:
        result = worker(args)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
