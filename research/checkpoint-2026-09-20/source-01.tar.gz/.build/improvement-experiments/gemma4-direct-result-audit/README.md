This isolated CPU attester is prepared for the frozen original Gemma 4 direct-classifier performance stage. It has not read the running stage's actual audit or result. ROOT must close the full stage before invoking the result entrypoint.

The input source release is runner SHA-256 `a44f4f6ca62428b56ee992f0606ae7570d8a4a2219f347087d7b67ef85108eab`, as pinned in `gemma4-direct-proposal/performance-root-frozen-plan-1.json`. The closed-stage entrypoint hashes every directly used allowed frozen source, hashes the exact safe developer VAL input, and binds plan/result/audit bytes. It does not read weights, tokenizer/template files, binaries, dynamic libraries, original mixed fixtures, TEST targets, credentials, `.jev`, trial output files, or external services. ROOT approved the production module imports; no classifier/backend constructors or model/runtime/labeling entrypoints are called.

From `/Users/bsonntag/code/simple-jev-ts`, the injected CPU checks are:

```sh
/opt/homebrew/opt/node/bin/node --test .build/improvement-experiments/gemma4-direct-result-audit/attest.test.mjs
```

After ROOT closes the complete stage, the read-only-input result check is:

```sh
/opt/homebrew/opt/node/bin/node .build/improvement-experiments/gemma4-direct-result-audit/attest.mjs --stage-closed
```

The command creates `result-attestation.json` exclusively in this directory. `--output` accepts another unused immediate-child filename in this directory; it cannot overwrite an existing file. The entrypoint rejects before reading actual audit/result files unless explicitly passed `--stage-closed`. That flag represents ROOT's clearance; it is not an independent OS observation.

The attester preserves all 312 attempts, 156 paired records, 78 distinct records, 39 groups, and the exact frozen ABBA order. It joins ordered native compile/evaluate and native-question receipts to attempts, rebuilds every usable native answer with the immutable production `responseFromSelectedLogits` wrapper and its unchanged `buildResponse`, and compares the complete stored native response. It rebuilds actual generated targets from raw POST JSON, applies the exact exported strict RFDT target normalizer, compares the complete frozen RFDT request contract, joins host targets, and calls the unchanged exported `scoreAnswer` and `pairedSummary`. It compares stored answer flags, eligibility, aggregate summaries, both replicate summaries, block receipts, completion status, and the released claim gate.

It validates full-prefill native token identities and `ceil(prompt_tokens / 256)` forwards, zero native generated output/prefix cache, slot erasure receipts, raw server `cache_n: 0`, disabled thinking, retry preservation, raw response hashes, raw provider/server accounting, and contained POST/reset/RPC elapsed. Failed attempts retain all their elapsed time and a separate ledger of known counters and unknown dispatched work. Accurate unknown judgments remain distinct from completed clear decisions. A faithful completed result with failed quality, coverage among eligible clear decisions, rate nonregression, timing thresholds, or either replicate is an attested negative; an execution failure also remains present rather than being dropped.

`released_claim_recomputed` reconstructs the released result's gate using its stored evidence declarations. It does not verify those declarations' OS or artifact truth. Without a separate ROOT receipt, `root_qualified_improvement_claim_permitted` is always false. ROOT alone verifies current weight/runtime hashes, actual ownership/single execution, monotonic-clock integrity, and final owned PID absence. To supply that verification, ROOT may write a receipt and invoke:

```sh
/opt/homebrew/opt/node/bin/node .build/improvement-experiments/gemma4-direct-result-audit/attest.mjs --stage-closed --root-receipt /absolute/path/to/root-receipt.json --output /Users/bsonntag/code/simple-jev-ts/.build/improvement-experiments/gemma4-direct-result-audit/result-attestation-root-receipt.json
```

The receipt schema is:

```json
{
  "kind": "ROOT_direct_performance_final_receipt",
  "plan_sha256": "exact closed plan SHA-256",
  "result_sha256": "exact closed result SHA-256",
  "audit_sha256": "exact closed audit SHA-256",
  "current_frozen_artifacts_verified": true,
  "current_runtime_hashes_verified": true,
  "owned_pids_absent": true,
  "single_active_native_gpu_execution_verified": true,
  "monotonic_clock_unmodified_verified": true
}
```

The CPU attester checks receipt fields and exact bindings; ROOT remains responsible for the observations they declare. All CPU tests use wholly synthetic 78-record data, selected logits, RPC responses, POST responses, and optional receipt declarations. Their proof is implementation behavior under injected evidence. They cannot prove actual model quality, speed, execution ownership, artifact identity, GPU execution, or deployment/promotion readiness.

Implementation files and their exact final hashes are in `release.json`. No results from the live stage are included in that release.
