import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { attest, strictTeacherTargets, expectedTeacherRequest, runClosedStage, sha, ROOT } from './attest.mjs';
import { canonical, preparePrompt } from '../../../dist/core.js';
import { scoreAnswer, pairedSummary } from '../../../scripts/developer-decision-eval.mjs';
import { responseFromSelectedLogits } from '../gemma4-label-prototype/research-quality/quality.mjs';
import { EXPECTED, wireBranch } from '../gemma4-label-prototype/research-quality/protocol.mjs';
import { buildSchedule, foldDirectMetrics, foldServerMetrics, partialServerMetrics,
  improvementClaimPermitted } from '../gemma4-direct-proposal/protocol.mjs';

const frozenPlan = JSON.parse(await readFile(join(ROOT, '.build/improvement-experiments/gemma4-direct-proposal/performance-root-frozen-plan-1.json'), 'utf8'));
const clone = value => JSON.parse(JSON.stringify(value));

function fixture({ actualProofFlag = false, nativeMs = 100 } = {}) {
  const plan = clone(frozenPlan);
  const records = Array.from({ length: 78 }, (_, index) => {
    const group = Math.floor(index / 2); const type = group < 13 ? 'noul' : group < 26 ? 'score' : 'choice';
    const question = { id: 'q', type, instructions: 'Decide from this synthetic CPU evidence.' };
    if (type === 'score') question.criteria = ['absent', 'partial', 'complete'];
    if (type === 'choice') question.criteria = [{ id: 'yes', description: 'yes' }, { id: 'no', description: 'no' }];
    const target = { answer: type === 'noul' ? group === 0 ? null : group % 2 === 0 : type === 'score' ? 1 : 'yes' };
    return { id: `cpu-${index}`, group_id: `cpu-group-${group}`, split: 'validation', regression: group === 13,
      request: { model: EXPECTED.profile, state: { text: `Synthetic group ${group}; this is CPU injected evidence.` }, questions: [question], options: { template_version: 'v2' } }, targets: { q: target } };
  });
  plan.dataset.expected_ids = records.map(record => record.id);
  plan.dataset.logical_prompt_sha256 = records.map(record => [record.id, sha(JSON.stringify(preparePrompt(record.request, 'v2').questions))]);
  const byId = new Map(records.map(record => [record.id, record]));
  const auditRows = []; const attempts = []; const blocks = []; const calls = { native: 0, generative: 0 };
  const provenance = { prototype_source_sha256: EXPECTED.sourceSha256,
    physical_profile: plan.physical_profile, physical_profile_sha256: plan.physical_profile_sha256,
    model_expected_sha256: EXPECTED.modelSha256,
    template_raw_identity: { sha256: EXPECTED.templateSha256, bytes: EXPECTED.templateBytes, verified: true },
    template_parser_identity: { sha256: EXPECTED.parserTemplateSha256, bytes: EXPECTED.parserTemplateBytes, verified: true },
    bos_token_id: 2, bos_piece: '<bos>', actual_mode: 'quantized_metal', vocab_only: false,
    weights_loaded: true, context_created: true, explicit_backend_init: true, device: 'metal',
    effective_limits: { max_model_len: 2048, max_batch_size: 1, max_batch_tokens: 2048 },
    gpu_layers_requested: 99, offload_kqv: true, op_offload: true, context_train_limit_checked: true };
  for (const block of buildSchedule(plan.dataset.expected_ids, plan.conditions.seed)) {
    for (let position = 0; position < block.record_ids.length; position++) {
      const record = byId.get(block.record_ids[position]); const question = record.request.questions[0];
      const prepared = preparePrompt(record.request, 'v2'); const branch = prepared.questions[0];
      const attempt = { method: block.method, repetition: block.repetition, record_id: record.id,
        group_id: record.group_id, regression: record.regression, pair_key: `${block.repetition}:${record.id}`,
        method_call_index: ++calls[block.method], expected_clear_decision: question.type !== 'noul' || record.targets.q.answer !== null,
        transport: [], elapsed_ms: block.method === 'native' ? nativeMs : 300, accounting_complete: true, cache_clear_proved: true };
      let returned;
      if (block.method === 'native') {
        const winner = question.type === 'noul' ? record.targets.q.answer === null ? 4 : record.targets.q.answer ? 8 : 0 : question.type === 'score' ? 1 : 0;
        const row = Object.fromEntries(branch.output_labels.map((label, index) => [label, index === winner ? 10 : -10]));
        const tokens = [2, ...Array(512).fill(3)]; const token_ids = Object.fromEntries(branch.output_labels.map((label, index) => [label, 10 + index]));
        const compiled = { branch_id: branch.branch_id, tokens, token_ids, provenance,
          rendered_generation_boundary: EXPECTED.generationBoundary + branch.answer_prefix,
          rendered: 'Synthetic CPU render\n' + EXPECTED.generationBoundary + branch.answer_prefix };
        const metrics = { backend: 'llama.cpp', prefill_strategy: 'full', prefix_tokens: 0, branch_output_tokens: 0,
          padded_suffix_tokens: 0, scored_positions: 1, suffix_batch_sizes: [1], computed_prompt_tokens: tokens.length,
          branch_prompt_tokens: tokens.length, logical_prefill_tokens: tokens.length, engine_forwards: Math.ceil(tokens.length / 256), provenance };
        const prefix = `r${String(position).padStart(3, '0')}q0`;
        auditRows.push({ kind: 'native_rpc', block, request: { v: 1, id: prefix + '-compile', op: 'compile', branches: [wireBranch(branch)] },
          response: { result: [compiled] }, elapsed_ms: 1 });
        auditRows.push({ kind: 'native_rpc', block, request: { v: 1, id: prefix + '-evaluate', op: 'evaluate', full: true,
          branches: [{ branch_id: branch.branch_id, tokens, token_ids }] }, response: { result: { logits: { [branch.branch_id]: row }, input_tokens: tokens.length, metrics } }, elapsed_ms: 1 });
        auditRows.push({ kind: 'native_question', record_id: record.id, logical_prompt_sha256: sha(JSON.stringify(prepared.questions)),
          elapsed_ms: 2, actual_mode: 'quantized_metal', questions: [{ question_id: question.id, branch_id: branch.branch_id,
            raw_selected_label_logits: row, native_metrics: metrics, compiled_token_sha256: sha(JSON.stringify(tokens)),
            rendered_sha256: sha(compiled.rendered), actual_prompt_tokens: tokens.length, generation_tokens: 0,
            labels: branch.output_labels, answer_labels: branch.answer_labels, selected_label_token_ids: token_ids }] });
        returned = responseFromSelectedLogits(prepared, { [branch.branch_id]: row }, tokens.length, { per_question_native: [metrics] }, {
          actual_mode: 'quantized_metal', physical_profile_sha256: plan.physical_profile_sha256,
          prototype_source_sha256: plan.prototype_source.sha256, binary_sha256: plan.artifacts.binary.sha256,
          raw_model_sha256: plan.artifacts.model.sha256, raw_model_bytes: plan.artifacts.model.bytes,
          raw_template_sha256: EXPECTED.templateSha256, parser_template_sha256: EXPECTED.parserTemplateSha256,
          independent_render_match: true, actual_question_count: 1 });
        attempt.native_response = { ...returned, metrics: { ...returned.metrics, ...foldDirectMetrics(returned, 1) } };
      } else {
        const body = expectedTeacherRequest(record, plan);
        const reply = { model: plan.generative.model_id, choices: [{ message: { content: JSON.stringify(record.targets) } }],
          usage: { prompt_tokens: 700, completion_tokens: 20, total_tokens: 720 }, timings: { prompt_n: 700, predicted_n: 20, cache_n: 0 } };
        const post = { index: 1, dispatched: true, cache_reset: { n_erased: 0 }, cache_reset_elapsed_ms: 1,
          actual_request: body, ok: true, status: 200, response_text: JSON.stringify(reply), response_sha256: sha(JSON.stringify(reply)),
          provider_usage: reply.usage, server_timings: reply.timings, elapsed_ms: 200 };
        auditRows.push({ kind: 'teacher_attempt_reset', index: 1, dispatched: false, cache_reset: post.cache_reset, cache_reset_elapsed_ms: 1 });
        auditRows.push({ kind: 'teacher_post', ...clone(post) });
        attempt.transport = [post]; attempt.actual_generated_targets = clone(record.targets);
        attempt.actual_work = foldServerMetrics(attempt.transport); returned = record.targets;
      }
      attempt.answers = [scoreAnswer(question, record.targets.q, block.method === 'native' ? returned.answers.q : returned.q, block.method)];
      attempt.correct_judgment = attempt.answers.every(answer => answer.correct_judgment);
      attempt.completed_clear_decision = attempt.answers.every(answer => answer.completed_clear_decision);
      attempt.abstention = attempt.answers.some(answer => answer.abstention);
      attempts.push(clone(attempt)); auditRows.push({ kind: 'attempt', ...clone(attempt) });
    }
    const row = { method: block.method, repetition: block.repetition, initialization_ms: 1000, initialization_error: null,
      cleanup: { owned_cleanup_complete: true }, cleanup_error: undefined };
    blocks.push(clone(row)); auditRows.push({ kind: 'block', ...clone(row) });
  }
  const result = { kind: 'gemma4_direct_performance_result', status: 'completed', attempts, blocks,
    evidence: { proof_kind: actualProofFlag ? 'root_attested_actual_native' : 'cpu_mock',
      exact_frozen_artifacts: actualProofFlag, host_only_gold_scoring: true, explicit_disabled_thinking_both_arms: actualProofFlag,
      cache_clear_proved_both_arms: true, actual_native_work_complete: true, full_developer_coverage: true,
      single_active_native_gpu_execution: true, monotonic_clock_unmodified: true }, cleanup_error: null };
  refresh({ result, auditRows });
  return { plan, records, result, auditRows };
}

function refresh(f) {
  f.result.summary = pairedSummary(f.result.attempts);
  f.result.replicate_summaries = [1, 2].map(repetition => pairedSummary(f.result.attempts.filter(a => a.repetition === repetition)));
  f.result.evidence.actual_native_work_complete = f.result.attempts.every(a => a.accounting_complete === true);
  f.result.evidence.cache_clear_proved_both_arms = f.result.attempts.every(a => a.cache_clear_proved === true);
  f.result.improvement_claim_permitted = improvementClaimPermitted(f.result.summary, f.result.replicate_summaries, f.result.evidence);
  const audited = f.auditRows.filter(row => row.kind === 'attempt');
  f.result.attempts.forEach((attempt, index) => { for (const key of Object.keys(audited[index])) delete audited[index][key]; Object.assign(audited[index], { kind: 'attempt', ...clone(attempt) }); });
}

test('CPU injected full 312/156/39 reconstruction accepts faithful complete data and never qualifies CPU gain', () => {
  const f = fixture(); const report = attest(f);
  assert.equal(report.integrity_attested, true); assert.equal(report.exact_coverage.paired_records, 156);
  assert.equal(report.actual_token_and_cache_accounting_complete, true);
  assert.equal(report.summary.paired.improvement_claim_permitted, true);
  assert.equal(report.released_claim_recomputed, false); assert.equal(report.root_qualified_improvement_claim_permitted, false);
  assert.equal(report.work_ledger.filter(row => row.method === 'native').reduce((sum, row) => sum + row.known_engine_forwards, 0), 468);
});

test('hypothetical released positive still requires separately supplied ROOT receipt', () => {
  const f = fixture({ actualProofFlag: true }); const report = attest(f);
  assert.equal(report.released_claim_recomputed, true); assert.equal(report.root_receipt_bound, false);
  assert.equal(report.root_qualified_improvement_claim_permitted, false);
});

test('ROOT external receipts qualify only with exact artifact bindings and every ROOT-only verification', () => {
  const f = fixture({ actualProofFlag: true });
  const identities = { plan_sha256: 'a'.repeat(64), result_sha256: 'b'.repeat(64), audit_sha256: 'c'.repeat(64) };
  const rootReceipt = { kind: 'ROOT_direct_performance_final_receipt', ...identities,
    current_frozen_artifacts_verified: true, current_runtime_hashes_verified: true, owned_pids_absent: true,
    single_active_native_gpu_execution_verified: true, monotonic_clock_unmodified_verified: true };
  // These are injected declarations, not evidence about an OS, model, or GPU.
  const conditional = attest({ ...f, identities, rootReceipt });
  assert.equal(conditional.root_receipt_bound, true); assert.equal(conditional.root_qualified_improvement_claim_permitted, true);
  for (const field of ['result_sha256', 'owned_pids_absent', 'current_runtime_hashes_verified']) {
    const bad = { ...rootReceipt, [field]: field.endsWith('sha256') ? 'd'.repeat(64) : false };
    assert.equal(attest({ ...f, identities, rootReceipt: bad }).root_qualified_improvement_claim_permitted, false);
  }
});

test('faithful completed negative with <2 gain is attested rather than discarded', () => {
  const report = attest(fixture({ actualProofFlag: true, nativeMs: 200 }));
  assert.equal(report.result_status, 'completed'); assert.equal(report.honest_negative_attested, true);
  assert.equal(report.summary.paired.all_attempts_elapsed_per_accepted_judgment_generative_over_native, 1.5);
});

test('failed transport preserves all-attempt elapsed plus known/unknown accounting', () => {
  const f = fixture(); const attempt = f.result.attempts.find(a => a.method === 'generative');
  const post = attempt.transport[0]; const postAudit = f.auditRows.find(row => row.kind === 'teacher_post');
  for (const key of ['response_text', 'response_sha256', 'provider_usage', 'server_timings', 'status', 'ok']) delete post[key];
  post.error = 'injected timeout before response';
  for (const key of Object.keys(postAudit)) delete postAudit[key]; Object.assign(postAudit, { kind: 'teacher_post', ...clone(post) });
  delete attempt.actual_generated_targets; attempt.actual_work = partialServerMetrics(attempt.transport);
  attempt.accounting_complete = false; attempt.cache_clear_proved = false; attempt.error = post.error;
  attempt.answers = []; attempt.correct_judgment = false; attempt.completed_clear_decision = false; attempt.abstention = false;
  refresh(f); const report = attest(f); const ledger = report.work_ledger.find(row => row.method === attempt.method && row.record_id === attempt.record_id && row.repetition === attempt.repetition);
  assert.equal(report.execution_failures, 1); assert.equal(report.actual_token_and_cache_accounting_complete, false);
  assert.equal(ledger.unknown_prefill_posts, 1); assert.equal(ledger.known_computed_prompt_tokens, 0);
  assert.equal(report.summary.methods.generative.elapsed_all_attempts_ms, 46800);
  assert.equal(report.summary.methods.generative.elapsed_all_attempts_per_accepted_judgment_ms, 46800 / 155);
});

test('native failed evaluate retains an unknown dispatched evaluation', () => {
  const f = fixture(); const attempt = f.result.attempts[0];
  const rpc = f.auditRows.find(row => row.kind === 'native_rpc' && row.request.op === 'evaluate');
  delete rpc.response; rpc.error = 'injected native lost reply';
  const receipt = f.auditRows.find(row => row.kind === 'native_question'); receipt.questions = []; receipt.error = rpc.error;
  delete attempt.native_response; delete attempt.accounting_complete; delete attempt.cache_clear_proved;
  attempt.answers = []; attempt.correct_judgment = false; attempt.completed_clear_decision = false; attempt.abstention = false; attempt.error = rpc.error;
  refresh(f); const report = attest(f);
  assert.equal(report.work_ledger[0].unknown_evaluations, 1); assert.equal(report.work_ledger[0].known_computed_prompt_tokens, 0);
  assert.equal(report.execution_failures, 1); assert.equal(report.integrity_attested, true);
});

test('native typed answer tampering is rejected even with matching altered audit and summaries', () => {
  const f = fixture(); const attempt = f.result.attempts.find(a => a.method === 'native' && a.answers[0].type === 'score');
  attempt.native_response.answers.q.score = 0; refresh(f);
  assert.throws(() => attest(f), /production buildResponse reconstruction/);
});

test('native ceil256 accounting violation cannot pass through complete flags', () => {
  const f = fixture(); const rpc = f.auditRows.find(row => row.kind === 'native_rpc' && row.request.op === 'evaluate');
  rpc.response.result.metrics.engine_forwards++;
  assert.throws(() => attest(f), /lacks complete raw proof/);
});

test('generative target tampering is rejected independently from stored scores', () => {
  const f = fixture(); const attempt = f.result.attempts.find(a => a.method === 'generative' && a.answers[0].type === 'choice');
  attempt.actual_generated_targets.q.answer = 'no'; refresh(f);
  assert.throws(() => attest(f), /actual teacher JSON/);
});

test('raw transport hash, thinking flag, cache reuse, and complete RFDT request mutations are rejected', () => {
  for (const mutate of [post => { post.response_sha256 = '0'.repeat(64); }, post => { post.actual_request.chat_template_kwargs.enable_thinking = true; },
    post => { post.actual_request.messages[0].content += '\nChanged workflow'; }, post => { post.actual_request.response_format.json_schema.schema.properties.q.anyOf = []; },
    post => { const reply = JSON.parse(post.response_text); reply.timings.cache_n = 1; post.response_text = JSON.stringify(reply); post.response_sha256 = sha(post.response_text); post.server_timings = reply.timings; }]) {
    const f = fixture(); const attempt = f.result.attempts.find(a => a.method === 'generative'); mutate(attempt.transport[0]);
    const auditPost = f.auditRows.find(row => row.kind === 'teacher_post'); Object.assign(auditPost, clone(attempt.transport[0])); refresh(f);
    assert.throws(() => attest(f));
  }
});

test('all-attempt latency cannot exclude its contained teacher POST and reset work', () => {
  const f = fixture(); const attempt = f.result.attempts.find(a => a.method === 'generative'); attempt.elapsed_ms = 100; refresh(f);
  assert.throws(() => attest(f), /excludes contained/);
});

test('duplicate/missing attempts, wrong groups, eligibility, score flags, and summary mutations are rejected', () => {
  for (const mutate of [f => f.result.attempts.pop(), f => { f.result.attempts[1] = clone(f.result.attempts[0]); },
    f => { f.result.attempts[0].group_id = 'wrong'; }, f => { f.result.attempts[0].expected_clear_decision = !f.result.attempts[0].expected_clear_decision; },
    f => { f.result.attempts[0].correct_judgment = false; }, f => { f.result.summary.methods.native.accepted_correct_judgments--; }]) {
    const f = fixture(); mutate(f); assert.throws(() => attest(f));
  }
});

test('aggregate passing cannot hide a replicate failing its twofold threshold', () => {
  const f = fixture({ actualProofFlag: true });
  f.result.attempts.filter(a => a.method === 'native').forEach(a => { a.elapsed_ms = a.repetition === 1 ? 200 : 50; });
  refresh(f); const report = attest(f);
  assert.equal(report.summary.paired.improvement_claim_permitted, true);
  assert.equal(report.replicate_summaries[0].paired.improvement_claim_permitted, false);
  assert.equal(report.released_claim_recomputed, false);
});

test('strict teacher normalization rejects extra fields, missing labels, NaN and malformed targets', () => {
  const questions = [{ id: 'q', type: 'choice', criteria: [{ id: 'yes' }, { id: 'no' }] }];
  assert.deepEqual(strictTeacherTargets('```json\n{"q":{"answer":"yes"}}\n```', questions), { q: { answer: 'yes' } });
  for (const text of ['{"q":{"answer":"yes","type":"choice"}}', '{"q":{"probabilities":{"yes":1}}}',
    '{"q":{"answer":"unknown"}}', '{"q":{"answer":"yes"},"extra":{"answer":0}}', '{"q":{"probabilities":{"yes":1e999,"no":0}}}']) assert.throws(() => strictTeacherTargets(text, questions));
});

test('stage-open entry rejects before any live result reads', async () => {
  await assert.rejects(runClosedStage({ stageClosed: false }), /close the full stage/);
});
