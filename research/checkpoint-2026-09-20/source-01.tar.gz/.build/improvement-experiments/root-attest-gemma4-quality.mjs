import { readFile, writeFile } from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { join } from 'node:path';
import { preparePrompt } from '../../dist/core.js';
import { qualityDatasetDigest } from '../../dist/evaluation.js';
import { HERE, EXPECTED, sha, jsonBytes, insist, readInputSets,
  verifyFrozenIdentities, validateProvenance, wireBranch } from './gemma4-label-prototype/research-quality/protocol.mjs';
import { responseFromSelectedLogits, verifyCompiledBranch, evaluateValidation } from './gemma4-label-prototype/research-quality/quality.mjs';
import { nativeContractsPassed, checkRootClearance } from './gemma4-label-prototype/research-quality/runner.mjs';

const execute = promisify(execFile);
const canonical = value => {
  const sort = item => Array.isArray(item) ? item.map(sort) : item && typeof item === 'object'
    ? Object.fromEntries(Object.keys(item).sort().map(key => [key, sort(item[key])])) : item;
  return JSON.stringify(sort(JSON.parse(JSON.stringify(value))));
};
const same = (a, b, label) => insist(canonical(a) === canonical(b), label);
const json = async path => JSON.parse(await readFile(path, 'utf8'));
const jsonl = async path => (await readFile(path, 'utf8')).trim().split('\n').map(line => JSON.parse(line));

const directory = join(HERE, process.argv[2] ?? 'native-proof-root-1');
insist(directory.startsWith(HERE + '/native-proof-root-') && !directory.includes('..'), 'Literal owned ROOT proof directory required');
const planBytes = await readFile(join(directory, 'run-plan.json'));
const plan = JSON.parse(planBytes);
const clearanceBytes = await readFile(join(directory, 'root-clearance.json'));
const clearance = JSON.parse(clearanceBytes);
checkRootClearance(clearance, planBytes);
await verifyFrozenIdentities(plan);
const stage = await json(join(directory, 'stage-proof.json'));
const report = await json(join(directory, 'quality-report.json'));
const reference = await json(join(directory, 'independent-render.json'));
const evidence = await jsonl(join(directory, 'question-evidence.jsonl'));
const rpc = await jsonl(join(directory, 'native-rpc.jsonl'));
const sets = await readInputSets();
const records = sets.flatMap(set => set.records);
const modelSets = sets.map(set => ({ ...set, records: set.records.map(record => ({
  ...record, request: { ...record.request, model: EXPECTED.profile },
})) }));
same(sets.map(({ records: rows, ...set }) => ({ ...set, records: rows.length })), plan.inputs, 'Exact current frozen validation manifests');
same(records.map(record => record.id), plan.execution_order, 'Exact frozen 194 record order');
insist(records.length === 194 && report.results.length === 194 && evidence.length === 194, 'Complete actual record/evidence census');
insist(stage.run_plan_sha256 === sha(planBytes) && stage.root_clearance_sha256 === sha(clearanceBytes), 'Actual stage plan/clearance attribution');
insist(stage.native_contracts_passed === nativeContractsPassed(stage, stage.audit_failure), 'Actual native acceptance recomputation');
insist(stage.native_contracts_passed === true, 'This attestation requires successful full native execution and cleanup');
insist(stage.production_registry_or_role_mutated === false && stage.rfdt_gates_mutated === false, 'Research scope preserved');
insist(stage.independent_render_sha256 === sha(await readFile(join(directory, 'independent-render.json'))), 'Independent render artifact attribution');
insist(reference.rows.length === 194 && reference.native_or_model_execution === false, 'All original-template independent renders');
const renders = new Map(reference.rows.map(row => [row.record_id + ':' + row.branch_id, row]));
insist(renders.size === 194, 'Distinct independent render keys');
insist(rpc.length === 389 && new Set(rpc.map(attempt => attempt.id)).size === 389, 'One init and exactly 194 compile/evaluate pairs');
insist(rpc.every(attempt => !attempt.error && !attempt.response?.error && attempt.response?.id === attempt.id), 'Actual RPC envelopes and errors');
same(rpc[0].request, plan.rpc_init, 'Actual initialization request');
validateProvenance(rpc[0].response.result.provenance, plan);
let computedTokens = 0;
let nativeForwards = 0;
let cursor = 0;
const reconstructed = await evaluateValidation({ classify: async request => {
  const index = cursor++;
  const record = records[index];
  const actual = report.results[index];
  const questionEvidence = evidence[index];
  const prompt = preparePrompt(request, 'v2');
  insist(prompt.questions.length === 1 && actual.id === record.id && questionEvidence.record_id === record.id, 'Ordered actual single-question source identity');
  insist(!actual.error && !questionEvidence.error, 'All actual native records completed');
  const branch = prompt.questions[0];
  const compile = rpc[1 + 2 * index];
  const evaluate = rpc[2 + 2 * index];
  const prefix = 'r' + String(index).padStart(3, '0') + 'q0';
  same(compile.request, { v: 1, id: prefix + '-compile', op: 'compile', branches: [wireBranch(branch)] }, 'Native received exact gold-free logical question');
  const compiled = compile.response.result[0];
  const parity = verifyCompiledBranch(branch, compiled, renders.get(record.id + ':' + branch.branch_id), plan);
  same(evaluate.request, { v: 1, id: prefix + '-evaluate', op: 'evaluate', full: true,
    branches: [{ branch_id: compiled.branch_id, tokens: compiled.tokens, token_ids: compiled.token_ids }] }, 'Actual selected-logit full evaluation payload');
  const result = evaluate.response.result;
  const metrics = result.metrics;
  validateProvenance(metrics.provenance, plan);
  insist(metrics.backend === 'llama.cpp' && metrics.prefill_strategy === 'full' && metrics.prefix_tokens === 0 &&
    metrics.branch_output_tokens === 0 && metrics.scored_positions === 1 && metrics.padded_suffix_tokens === 0,
    'Actual full-prefill zero-generation contract');
  same(metrics.suffix_batch_sizes, [1], 'Actual single-branch native evaluation');
  insist(metrics.computed_prompt_tokens === compiled.tokens.length && metrics.branch_prompt_tokens === compiled.tokens.length &&
    metrics.logical_prefill_tokens === compiled.tokens.length && result.input_tokens === compiled.tokens.length &&
    metrics.engine_forwards === Math.ceil(compiled.tokens.length / 256), 'Actual token and forward counters');
  const q = questionEvidence.questions[0];
  insist(questionEvidence.questions.length === 1 && q.compiled_token_sha256 === sha(JSON.stringify(compiled.tokens)), 'Actual compiled token evidence');
  same(q.native_metrics, metrics, 'Native metric evidence');
  same(q.raw_selected_label_logits, result.logits[branch.branch_id], 'Actual selected label logit evidence');
  same(q.selected_label_token_ids, parity.selected_label_token_ids, 'Actual label token evidence');
  const logicalSha = sha(JSON.stringify(prompt.questions));
  insist(questionEvidence.logical_prompt_sha256 === logicalSha && actual.logical_prompt_sha256 === logicalSha, 'Actual production logical prompt digest');
  insist(actual.metadata.prototype_source_sha256 === EXPECTED.sourceSha256 &&
    actual.metadata.binary_sha256 === EXPECTED.binarySha256 && actual.metadata.raw_model_sha256 === EXPECTED.modelSha256 &&
    actual.metadata.physical_profile_sha256 === plan.physical_profile_sha256 && actual.metadata.independent_render_match === true &&
    actual.metadata.production_role_approval === false && actual.metadata.actual_mode === 'quantized_metal', 'Every actual answer source/model/device scope');
  const response = responseFromSelectedLogits(prompt, result.logits, compiled.tokens.length,
    { per_question_native: [metrics] }, { independent_render_match: true });
  same(actual.usage, response.usage, 'Actual response usage derived from native computation');
  computedTokens += metrics.computed_prompt_tokens;
  nativeForwards += metrics.engine_forwards;
  return response;
} }, modelSets);
insist(cursor === 194, 'Full ROOT recomputation');
same(report.results.map(row => row.answers), reconstructed.results.map(row => row.answers), 'All actual targets/predictions independently rejoined and production-scored');
same(report.summary, reconstructed.summary, 'Complete production metric recomputation');
same(report.coverage, reconstructed.coverage, 'Independent per-set coverage and summaries');
same(report.unknown_noul, reconstructed.unknown_noul, 'Unknown scoring recomputation');
same(report.diagnosis, reconstructed.diagnosis, 'Diagnosis representations and metric recomputation');
same(report.gates, { ...reconstructed.gates, native_contracts: true }, 'Every unchanged quality gate recomputation');
insist(report.dataset_sha256 === qualityDatasetDigest(modelSets.flatMap(set => set.records)), 'Actual model-scoped dataset digest');
try {
  await execute('/bin/ps', ['-p', String(stage.native_pid), '-o', 'comm='], { timeout: 1000, maxBuffer: 4096 });
  throw new Error('Owned native PID remains present; no GPU release attestation');
} catch (error) { insist(error.code === 1, 'Owned native PID absence must be observed'); }
const protectedStage = await json('.build/improvement-experiments/evidence-supervision-comparison/supplemented-stage.json');
for (const [path, digest] of Object.entries(protectedStage.old_evidence_hashes)) insist(sha(await readFile(path)) === digest, 'Earlier held-out artifact evidence preserved');
const artifacts = {};
for (const name of ['run-plan.json', 'root-clearance.json', 'stage-proof.json', 'quality-report.json',
  'independent-render.json', 'native-rpc.jsonl', 'question-evidence.jsonl', 'native-stderr.log']) artifacts[name] = sha(await readFile(join(directory, name)));
const proof = { kind: 'jev_root_full_gemma4_validation_attestation', observed_at: new Date().toISOString(),
  actual_records: 194, actual_groups: 83, actual_compile_evaluate_pairs: 194,
  all_actual_predictions_and_targets_production_recomputed: true, per_set_original_quality_and_unknown_gates_recomputed: true,
  all_actual_original_template_render_matches: true, actual_computed_prompt_tokens: computedTokens,
  actual_native_engine_forwards: nativeForwards, actual_generated_output_tokens: 0,
  raw_model_sha256_current_verified: EXPECTED.modelSha256, physical_profile_sha256: plan.physical_profile_sha256,
  native_process_exit_and_close_observed: true, owned_native_pid_absent: stage.native_pid,
  frozen_sources_and_input_identities_unchanged: true, earlier_held_out_evidence_unchanged: true,
  quality_passed: report.gates.passed, quality_gates: report.gates,
  actual_stage_elapsed_ms: stage.elapsed_ms, actual_native_init_ms: stage.init_ms,
  sampled_peak_native_rss_kib: stage.native_resource_samples.observed_peak_rss_kib,
  developer_speed_or_cost_gain_proven: false, production_role_approved: false,
  artifacts, helper_sha256: sha(await readFile(new URL(import.meta.url))),
  limitation: 'Actual validation-quality result and native contract attribution only; sampled RSS is not true peak or Metal allocation. No protected TEST, permanent role promotion, calibration or developer workflow improvement is established.' };
await writeFile(join(directory, 'root-result-attestation.json'), jsonBytes(proof), { flag: 'wx', mode: 0o600 });
console.log(JSON.stringify({ attested_records: 194, quality_passed: proof.quality_passed,
  computed_prompt_tokens: computedTokens, native_pid_absent: stage.native_pid, production_role_approved: false }));
