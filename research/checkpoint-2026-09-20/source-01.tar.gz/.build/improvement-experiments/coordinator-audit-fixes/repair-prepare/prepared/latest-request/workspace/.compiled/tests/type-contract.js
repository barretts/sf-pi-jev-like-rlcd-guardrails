import { LatestRequest } from "../src/latest.js";
const request = new LatestRequest(async (_key) => "value");
void request;
