import { RefreshLoader } from "../src/refresh.js";
const loader = new RefreshLoader(async (_signal) => "value");
const value = loader.load(new AbortController().signal);
void value;
