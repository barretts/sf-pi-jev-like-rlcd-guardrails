export class LatestRequest {
    fetchValue;
    state = {
        status: "idle",
        data: undefined,
        error: undefined,
    };
    constructor(fetchValue) {
        this.fetchValue = fetchValue;
    }
    read() {
        return { ...this.state };
    }
    async refresh(key) {
        this.state = { status: "loading", data: this.state.data, error: undefined };
        try {
            const data = await this.fetchValue(key);
            this.state = { status: "ready", data, error: undefined };
        }
        catch (reason) {
            this.state = {
                status: "error",
                data: this.state.data,
                error: reason instanceof Error ? reason.message : String(reason),
            };
        }
    }
}
