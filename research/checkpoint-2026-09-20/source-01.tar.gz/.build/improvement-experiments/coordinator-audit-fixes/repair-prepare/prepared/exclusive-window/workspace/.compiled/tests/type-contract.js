import { pageWindow } from "../src/window.js";
const rows = Object.freeze(["one", "two"]);
const window = pageWindow(rows, 0, 1);
void window;
