export class RefreshLoader {
    fetchValue;
    inFlight;
    constructor(fetchValue) {
        this.fetchValue = fetchValue;
    }
    load(signal) {
        if (this.inFlight)
            return this.inFlight;
        this.inFlight = this.fetchValue(signal).then((value) => {
            this.inFlight = undefined;
            return value;
        });
        return this.inFlight;
    }
}
