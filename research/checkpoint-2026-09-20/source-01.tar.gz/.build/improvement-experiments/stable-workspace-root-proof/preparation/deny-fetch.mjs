import {writeFileSync} from 'node:fs';
let attempts=0;
globalThis.fetch=async()=>{attempts++;throw new Error('ROOT preparation forbids network fetch');};
process.on('exit',()=>writeFileSync(new URL('./fetch-guard-result.json',import.meta.url),JSON.stringify({guard:'globalThis.fetch denied before SDK import',attempts,scope:'Actual configured-provider SDK preparation'},null,2)+'\n',{mode:0o600}));
