"""Metadata-only approved GGUF inspection. Never access tensor payload arrays."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path('/Users/bsonntag/code/simple-jev-ts')
sys.path.insert(0, str(ROOT / '.vendor/llama.cpp/gguf-py'))
from gguf.gguf_reader import GGUFReader

MODEL = ROOT / 'models/gemma-3-4b-it-f16.gguf'
reader = GGUFReader(MODEL, mode='r')
selected = {}
arrays = {}
for name, field in reader.fields.items():
    if name.startswith('GGUF.') or name.startswith('general.') or name.startswith('gemma3.'):
        selected[name] = field.contents()
    elif name.startswith('tokenizer.'):
        if len(field.types) > 1 and field.types[0].name == 'ARRAY':
            arrays[name] = {'types': [value.name for value in field.types], 'entries': len(field.data)}
        elif name != 'tokenizer.chat_template':
            selected[name] = field.contents()
        else:
            template = field.contents()
            selected[name] = {'utf8_bytes': len(template.encode('utf-8')), 'sha256': sha256(template.encode('utf-8')).hexdigest()}

tensors = [{'name': tensor.name, 'ggml_shape': tensor.shape.tolist(),
            'numpy_shape': list(reversed(tensor.shape.tolist())), 'ggml_dtype': tensor.tensor_type.name,
            'elements_from_shape': tensor.n_elements, 'bytes_from_shape_dtype': tensor.n_bytes}
           for tensor in reader.tensors]
with MODEL.open('rb') as stream:
    header_bytes = stream.read(reader.data_offset)

result = {'research_schema': 'jev.gemma3.offline-feasibility.header-metadata.v1',
          'scope': 'approved_exact_file_header_tensor_names_shapes_dtypes_only_no_payload_access',
          'model_path': str(MODEL), 'file_size_from_stat': MODEL.stat().st_size,
          'header_bytes_including_alignment': reader.data_offset,
          'header_sha256': sha256(header_bytes).hexdigest(),
          'full_model_sha256': None, 'full_model_sha256_not_computed_reason': 'Would read tensor payload; outside this task authorization.',
          'fields': selected, 'tokenizer_array_metadata': arrays,
          'tensor_count': len(tensors), 'dtype_counts': dict(Counter(tensor['ggml_dtype'] for tensor in tensors)),
          'tensors': tensors,
          'claims': {'tensor_payload_read': False, 'tokenizer_executed': False, 'model_instantiated': False,
                     'native_or_gpu_execution': False, 'quality_or_gain_established': False}}
output = Path(__file__).parent / 'gguf-header-metadata.json'
with output.open('x', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: result[key] for key in ['tensor_count', 'dtype_counts', 'file_size_from_stat', 'header_bytes_including_alignment', 'header_sha256']}, indent=2))
