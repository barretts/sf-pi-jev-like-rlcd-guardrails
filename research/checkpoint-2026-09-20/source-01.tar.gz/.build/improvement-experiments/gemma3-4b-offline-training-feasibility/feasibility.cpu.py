"""Synthetic scalar + metadata checks only; not a model converter or execution test."""
import json
from pathlib import Path
import struct
import unittest

HERE = Path(__file__).parent
METADATA = json.loads((HERE / 'gguf-header-metadata.json').read_text())


class SourceMetadataFeasibility(unittest.TestCase):
    def test_all_text_tensor_names_shapes_and_dtypes_close_against_architecture(self):
        expected = {'token_embd.weight': ([262144, 2560], 'F16'), 'output_norm.weight': ([2560], 'F32')}
        families = {
            'attn_q': ([2048, 2560], 'F16'), 'attn_k': ([1024, 2560], 'F16'), 'attn_v': ([1024, 2560], 'F16'),
            'attn_output': ([2560, 2048], 'F16'), 'ffn_gate': ([10240, 2560], 'F16'),
            'ffn_up': ([10240, 2560], 'F16'), 'ffn_down': ([2560, 10240], 'F16'),
            'attn_norm': ([2560], 'F32'), 'post_attention_norm': ([2560], 'F32'),
            'ffn_norm': ([2560], 'F32'), 'post_ffw_norm': ([2560], 'F32'),
            'attn_q_norm': ([256], 'F32'), 'attn_k_norm': ([256], 'F32'),
        }
        for layer in range(34):
            for family, descriptor in families.items():
                expected[f'blk.{layer}.{family}.weight'] = descriptor
        actual = {tensor['name']: (tensor['numpy_shape'], tensor['ggml_dtype']) for tensor in METADATA['tensors']}
        self.assertEqual(len(actual), 444)
        self.assertEqual(actual, expected)

    def test_header_and_embedding_metadata_agree_on_text_config(self):
        fields = METADATA['fields']
        self.assertEqual(fields['general.architecture'], 'gemma3')
        for key, expected in {'embedding_length': 2560, 'block_count': 34, 'feed_forward_length': 10240,
                              'attention.head_count': 8, 'attention.head_count_kv': 4,
                              'attention.key_length': 256, 'attention.value_length': 256,
                              'context_length': 131072, 'attention.sliding_window': 1024,
                              'rope.freq_base': 1000000.0, 'rope.scaling.factor': 8.0}.items():
            self.assertEqual(fields['gemma3.' + key], expected)
        self.assertEqual(METADATA['tokenizer_array_metadata']['tokenizer.ggml.tokens']['entries'], 262144)
        self.assertEqual(METADATA['dtype_counts'], {'F16': 239, 'F32': 205})
        self.assertFalse(any(tensor['name'] == 'output.weight' or 'vision' in tensor['name'] for tensor in METADATA['tensors']))
        self.assertEqual(sum(tensor['bytes_from_shape_dtype'] for tensor in METADATA['tensors']),
                         METADATA['file_size_from_stat'] - METADATA['header_bytes_including_alignment'])

    def test_synthetic_offset_norm_f32_rounding_can_destroy_exact_original(self):
        # 2^-25 is BF16-representable. This demonstrates potential loss only;
        # no claim is made that any actual model parameter has this value.
        original = 2 ** -25
        stored = struct.unpack('<f', struct.pack('<f', 1.0 + original))[0]
        recovered = stored - 1.0
        self.assertEqual(stored, 1.0)
        self.assertEqual(recovered, 0.0)
        self.assertNotEqual(recovered, original)

    def test_synthetic_f16_cast_can_destroy_exact_bf16_representable_original(self):
        original = 2 ** -25
        stored = struct.unpack('<e', struct.pack('<e', original))[0]
        self.assertEqual(stored, 0.0)
        self.assertNotEqual(stored, original)


if __name__ == '__main__':
    unittest.main(verbosity=2)
