import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, '../../..');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const insist = (condition, message) => { if (!condition) throw new Error(message); };
const reviewed = [
  '.vendor/llama.cpp/convert_hf_to_gguf.py', '.vendor/llama.cpp/conversion/gemma.py', '.vendor/llama.cpp/conversion/base.py',
  '.vendor/llama.cpp/gguf-py/gguf/tensor_mapping.py', '.vendor/llama.cpp/gguf-py/gguf/gguf_reader.py',
  'scripts/build-rfdt.sh', 'rfdt/worker.py', 'rfdt/requirements.txt', 'rfdt/requirements.lock',
  'src/models.ts', 'models/registry.json', 'src/rfdt.ts',
  '.build/rfdt-venv/lib/python3.13/site-packages/transformers/models/gemma3/configuration_gemma3.py',
  '.build/rfdt-venv/lib/python3.13/site-packages/transformers/models/gemma3/modeling_gemma3.py',
  '.build/rfdt-venv/lib/python3.13/site-packages/mlx_lm/models/gemma3.py',
  '.build/rfdt-venv/lib/python3.13/site-packages/mlx_lm/models/gemma3_text.py',
];
const files = [
  ...['FEASIBILITY.md', 'inspect-header.py', 'feasibility.cpu.py', 'gguf-header-metadata.json', 'freeze-source.mjs'].map(name => ({ name, path: join(here, name), category: 'owned_source_or_metadata' })),
  ...reviewed.map(name => ({ name, path: join(root, name), category: 'reviewed_plain_source_or_catalog' })),
];
const sources = await Promise.all(files.map(async file => {
  const bytes = await readFile(file.path);
  return { ...file, bytes: bytes.length, sha256: sha(bytes) };
}));
const checked = await promisify(execFile)(join(root, '.build/rfdt-venv/bin/python'), [join(here, 'feasibility.cpu.py')],
  { cwd: here, timeout: 30000, maxBuffer: 1024 * 1024, encoding: 'utf8' });
insist(/Ran 4 tests/m.test(checked.stderr) && /^OK$/m.test(checked.stderr), 'Complete four-check CPU receipt required');
for (const file of sources) insist(sha(await readFile(file.path)) === file.sha256, 'Source changed during CPU checks: ' + file.name);
const header = JSON.parse(await readFile(join(here, 'gguf-header-metadata.json'), 'utf8'));
const receipt = { research_schema: 'jev.gemma3.offline-feasibility.cpu-receipt.v1', frozen_at: new Date().toISOString(),
  scope: 'approved_header_metadata_and_synthetic_scalar_cpu_only',
  execution: { command: '.build/rfdt-venv/bin/python feasibility.cpu.py', exit_code: 0, stdout: checked.stdout, stderr: checked.stderr },
  checks: 4, passed: 4, failed: 0,
  claims: { model_instantiated: false, tensor_payload_read: false, weights_recovered: false, tokenizer_executed: false,
    native_or_gpu_execution: false, official_checkpoint_parity: false, training: false, quality_or_speed_gain: false }, approval_effect: 'none' };
const receiptBytes = jsonBytes(receipt);
await writeFile(join(here, 'cpu-receipt.json'), receiptBytes, { flag: 'wx', mode: 0o600 });
const freeze = { research_schema: 'jev.gemma3.offline-feasibility.source-freeze.v1', frozen_at: receipt.frozen_at,
  scope: 'source_plan_and_approved_header_metadata_only_no_recovery_or_model_execution', sources,
  header_identity: { exact_path: header.model_path, header_bytes: header.header_bytes_including_alignment,
    header_sha256: header.header_sha256, file_size_from_stat: header.file_size_from_stat,
    full_model_sha256_verified: false, catalog_expected_sha256: '29f4b518b636635613894282bda2a01bad964c8d474c4147343057b7ac442d50' },
  cpu_receipt: { name: 'cpu-receipt.json', bytes: receiptBytes.length, sha256: sha(receiptBytes) },
  tokenizer_reuse: 'unproved; no original plain cached HF metadata identified within permitted source-referenced paths',
  conclusion: 'Plausible future GGUF-derived text research base; exact official HF recovery is unproved and forward export is generally lossy.',
  stop_state: 'ready_source_feasibility_plan_only', approval_effect: 'none' };
const freezeBytes = jsonBytes(freeze);
await writeFile(join(here, 'source-freeze.json'), freezeBytes, { flag: 'wx', mode: 0o600 });
process.stdout.write(JSON.stringify({ note_sha256: sources.find(source => source.name === 'FEASIBILITY.md').sha256,
  header_metadata_sha256: sources.find(source => source.name === 'gguf-header-metadata.json').sha256,
  cpu_receipt_sha256: sha(receiptBytes), source_freeze_sha256: sha(freezeBytes), checks: 4, passed: 4,
  stop_state: freeze.stop_state }, null, 2) + '\n');
