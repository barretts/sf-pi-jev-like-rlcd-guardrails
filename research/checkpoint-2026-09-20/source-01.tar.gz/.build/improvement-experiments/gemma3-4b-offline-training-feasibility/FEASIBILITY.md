# Local Gemma 3 4B offline text-training feasibility

An offline **GGUF-derived text-only research base appears structurally possible**, using the local `models/gemma-3-4b-it-f16.gguf` and installed Gemma 3 text implementations. **Exact recovery of the original official HF checkpoint is not established and cannot generally be guaranteed from this export.** The current forward export includes embedding row removal, floating-point casts, and the Gemma norm offset, while the GGUF contains no vision weights. An official HF-equivalent base requires the original HF checkpoint and configuration, or independent equivalence evidence that this bounded task cannot provide.

This is a fallback hypothesis for a larger existing Google base and future authorized RFDT work using already available training supervision. It is not a model recommendation, a training run, an inference result, a speed measurement, a quality result, or a gain claim. Existing frozen grader/core/grid/runtime files were not changed. No converter, weight recovery, checkpoint write, tokenizer execution, model instantiation, forward pass, GPU/native process, training, download, network/auth access, process inspection, or validation/test/result read occurred.

## Approved metadata evidence

The exact local F16 file was opened read-only through the vendored `GGUFReader`. The reader source constructs memory-mapped ndarray views without evaluating tensor payload elements; the inspection script accessed tensor names, shapes, dtypes, derived sizes, and the header region only. It never accesses `tensor.data`. The full model digest was deliberately not computed, because that would read weights outside this task's authorization.

| Observation | Evidence |
|---|---|
| Local file size | 7,767,474,336 bytes, matching the catalog's expected size |
| Catalog expected full SHA | `29f4b518b636635613894282bda2a01bad964c8d474c4147343057b7ac442d50`; catalog assertion only, not verified here |
| Read header including alignment | 6,539,424 bytes |
| Header SHA | `6d1c5325eaca56b12a6c591110833db2a0ba3f64771930a830f5b47babf980f6` |
| Header architecture | `gemma3`, instruction-tuned 4B, Gemma license |
| Text tensor inventory | 444 distinct tensors: 239 F16 and 205 F32 |
| Tensor structure | 34 × 13 per-layer tensors, one embedding matrix, one final norm |
| Elements described by shapes | 3,880,099,328 |
| Tensor sizes described by metadata | Exactly file size minus the header region |
| Vision/projector tensors | None in the tensor inventory |
| Independent output head tensor | None; use a tied embedding head for the prospective text base |

`gguf-header-metadata.json` contains the full approved tensor-name/shape/dtype inventory. This proves structural metadata closure; it does not establish weight validity, whole-file identity, original exporter provenance, numerical parity, or model behavior.

## Prospective text architecture and configuration

The following values are supported directly by the approved header and shapes. The prospective base should be explicitly configured as text-only `model_type: "gemma3_text"` / `Gemma3ForCausalLM`, rather than loading the multimodal `gemma3` wrapper with its larger default vocabulary.

| HF/MLX text parameter | Value | Basis |
|---|---:|---|
| `vocab_size` | 262144 | Token array length and embedding shape |
| `hidden_size` | 2560 | Header and all hidden-width matrices/norms |
| `num_hidden_layers` | 34 | Header and every layer's complete tensor inventory |
| `intermediate_size` | 10240 | Header and MLP matrices |
| `num_attention_heads` | 8 | Header; Q/O matrix width 2048 = 8 × 256 |
| `num_key_value_heads` | 4 | Header; K/V matrix width 1024 = 4 × 256 |
| `head_dim` | 256 | Header and per-head Q/K norm width |
| `rms_norm_eps` | 1e-6 | Header stores the nearest F32 representation |
| `max_position_embeddings` | 131072 | Header |
| `sliding_window` | 1024 | Header |
| Global `rope_theta` | 1000000 | Header |
| Global RoPE scaling | linear, factor 8 | Header |
| BOS/EOS/UNK/PAD IDs | 2 / 1 / 3 / 0 | Header |
| Add BOS / add EOS / add space prefix | true / false / false | Header |
| `tie_word_embeddings` | true, prospective | Missing output tensor plus installed text model's tied-head support; original config still needed for official equivalence |
| `attention_bias` | false, prospective | No bias tensors and installed source's supported bias-free text path |

Fields not recovered directly from this header remain **source-default hypotheses**, rather than original checkpoint facts: `hidden_activation = "gelu_pytorch_tanh"`, `query_pre_attn_scalar = 256`, local RoPE base 10000, sliding-window pattern 6 (global layers 5, 11, 17, 23, 29 at zero-based indices), causal attention, zero dropout, and absent softcapping. Installed HF configuration source and MLX text source provide these defaults; a separately obtained original 4B config or future parity evidence must resolve them before treating a reconstructed base as equivalent. The header does not uniquely recover the original complete HF config, exact layer-type list, dtype policy, or training provenance.

The installed HF class's defaults (`hidden_size = 2304`, layers 26, vocabulary 262208, sliding window 4096) and the installed MLX text class's defaults (`hidden_size = 1152`, layers 26, vocabulary 262144, sliding window 512) are **not** this file's configuration. Copying either default config or the 1B config wholesale would create the wrong architecture. The installed multimodal MLX wrapper also defaults its vocabulary to 262208; a direct explicit `gemma3_text` base avoids inventing rows that are absent from the GGUF.

## Forward contract and inverse mapping

The reviewed **current** vendored Gemma 3 converter inherits `TextModel`. Its `modify_tensors` performs exactly two Gemma-specific value changes: truncate embedding rows to the exported vocabulary and add 1.0 to names ending in `norm.weight`. The base route maps names, optionally concatenates Q/K/V when fusion is requested, and otherwise returns values unchanged. This file has separate Q, K, and V tensors, so it has no fused-QKV split to undo.

The reviewed Gemma 3 path contains **no Q/K rotary weight permutation, no Q/K-norm permutation, and no embedding scale multiplication/division**. A generic Llama inverse-permutation would therefore be an unsupported change. Shapes in the GGUF use reversed ggml dimension order: interpreting payloads with the reader's reversed NumPy shape already restores the HF matrix shape; that is not a numeric matrix transpose. This source contract is not uniquely linked to the historical catalog GGUF exporter, so future recovery must freeze exporter provenance or independently prove round-trip parity.

The prospective mapping below describes a future converter; no such weight conversion was written or executed here. `i` ranges over every layer 0–33. All matrix shapes use ordinary HF/NumPy order.

| GGUF tensor | HF/MLX text key | Shape | Required future treatment under reviewed contract |
|---|---|---|---|
| `token_embd.weight` | `model.embed_tokens.weight` | `[262144, 2560]` | Preserve available F16 values; do not divide by sqrt(hidden_size); omitted source rows cannot be recovered |
| `output_norm.weight` | `model.norm.weight` | `[2560]` | Subtract 1.0 in F32 |
| `blk.i.attn_norm.weight` | `model.layers.i.input_layernorm.weight` | `[2560]` | Subtract 1.0 in F32 |
| `blk.i.post_attention_norm.weight` | `model.layers.i.post_attention_layernorm.weight` | `[2560]` | Subtract 1.0 in F32 |
| `blk.i.ffn_norm.weight` | `model.layers.i.pre_feedforward_layernorm.weight` | `[2560]` | Subtract 1.0 in F32 |
| `blk.i.post_ffw_norm.weight` | `model.layers.i.post_feedforward_layernorm.weight` | `[2560]` | Subtract 1.0 in F32 |
| `blk.i.attn_q_norm.weight` | `model.layers.i.self_attn.q_norm.weight` | `[256]` | Subtract 1.0 in F32; no source-supported permutation |
| `blk.i.attn_k_norm.weight` | `model.layers.i.self_attn.k_norm.weight` | `[256]` | Subtract 1.0 in F32; no source-supported permutation |
| `blk.i.attn_q.weight` | `model.layers.i.self_attn.q_proj.weight` | `[2048, 2560]` | Rename; no source-supported permutation |
| `blk.i.attn_k.weight` | `model.layers.i.self_attn.k_proj.weight` | `[1024, 2560]` | Rename; no source-supported permutation |
| `blk.i.attn_v.weight` | `model.layers.i.self_attn.v_proj.weight` | `[1024, 2560]` | Rename |
| `blk.i.attn_output.weight` | `model.layers.i.self_attn.o_proj.weight` | `[2560, 2048]` | Rename |
| `blk.i.ffn_gate.weight` | `model.layers.i.mlp.gate_proj.weight` | `[10240, 2560]` | Rename |
| `blk.i.ffn_up.weight` | `model.layers.i.mlp.up_proj.weight` | `[10240, 2560]` | Rename |
| `blk.i.ffn_down.weight` | `model.layers.i.mlp.down_proj.weight` | `[2560, 10240]` | Rename |
| No output tensor | tied `lm_head.weight` / embedding projection | Same embedding matrix | Tie to available embedding; never invent a separately learned head |

For an original multimodal HF key, the current converter strips the `language_model.` prefix and filters vision/projector tensors. A prospective text-only recovery should use direct text keys, not fabricate a multimodal container or its missing weights. Installed MLX `gemma3_text.Model.sanitize` removes its separate head when no `lm_head.weight` exists and uses embedding projection.

## Why exact official recovery is uncertain or impossible

1. **Embedding removal is lossy.** Current Gemma 3 export truncates source embedding rows to its exported vocabulary. This file has 262144 rows, whereas the installed full Gemma 3 configuration defaults to 262208. The actual original source row count is not recorded in this header, so a loss of exactly 64 original rows is not asserted here. If any rows were omitted, the GGUF cannot restore their original values.
2. **The norm offset is not generally invertible after rounding.** The base exporter converts BF16 and other unsupported input dtypes to F32 before the Gemma-specific `+1`; all this file's 205 norm tensors are F32. Subtracting 1 recovers a compatible offset convention but does not guarantee the original HF bits. A synthetic BF16-representable `2^-25` norm rounds to exactly 1.0 after F32 addition and then recovers as 0.0. This is a loss counterexample, not an observation about actual weights.
3. **F16 casts can lose original values.** All embedding/linear tensors are F16. BF16 values inside normal representable F16 ranges can often be represented exactly, but original F32 precision or BF16 underflow/overflow ranges cannot generally be recovered. The synthetic BF16-representable `2^-25` casts to F16 zero. No actual parameter was read to determine whether any such loss occurred.
4. **Vision/projector weights are absent.** Exact reconstruction of the official multimodal 4B HF model is impossible from this text GGUF alone. A text-only derivative should explicitly preserve that scope.
5. **The original full config/tokenizer/exporter are not recoverable uniquely from flat GGUF fields.** Token strings/scores/types and flags do not reproduce every original tokenizer normalizer/pre-tokenizer/decoder/SentencePiece serialization setting or a unique HF file identity.
6. **Numerical behavior differs across implementations/dtypes.** Installed HF multiplies embeddings by sqrt(hidden_size) cast to embedding weight dtype. Installed MLX explicitly creates that scale in BF16 before casting to hidden-state dtype. MLX's F16 residual path also computes/clips a sum in F32, whereas inspected HF decoder source adds residuals directly. Norm precision, GELU, rotary scaling/local-global patterns, attention masks, tied-head behavior, and backend kernels require independent future parity evidence. Header metadata and scalar algebra cannot establish it.

## Existing tokenizer/config reuse

No original official 1B HF plain config/tokenizer metadata was found at the bounded paths examined. Conventional repository/home HF cache paths were absent. Safe filename-only inventory under `.build` found derivative fused-run config/tokenizer files, which were **not read** because derivative artifacts/results are outside this task. The permitted `src/rfdt.ts` frontend passes an optional `modelPath` or the model ID; it contains no literal original checkpoint cache directory. The Python worker delegates cache resolution to HF snapshot handling. No environment, credential, token, auth, or cache-state files were inspected, and no HF resolver was executed.

Therefore **exact reusable local HF tokenizer assets remain unproved**. The GGUF header's 262144-entry vocabulary, special IDs, flags, and 1532-byte chat-template digest (`7de1c58e208eda46e9c7f86397df37ec49883aeece39fb961e0a6b24088dd3c4`) provide metadata constraints for a future authorized comparison, not tokenizer parity. If ROOT later supplies an original plain 1B HF snapshot path, compare its complete token-ID map and in-range added-token declarations against the approved 4B GGUF vocabulary; separately compare normalizer/pre-tokenizer/decoder, special token, BOS/EOS, and chat-template metadata. Only then identify what can be reused. Actual prompt/label tokenization parity would still be a later authorized execution check.

The existing worker's source `project_text_tokenizer` is a useful **reference**: it requires original tokenizer JSON/config, exact contiguous embedding ID coverage, and unchanged in-range vocabulary, and removes only an out-of-range `<image_soft_token>` placeholder. It was not executed. Its 1B tokenizer policy is not automatically a proof for the 4B tokenizer, its potentially padded rows, or all 4B modalities.

An original 1B HF config, if later identified, cannot be reused as the 4B architecture. At most, independently checked shared text-tokenizer metadata and individually justified semantic defaults could be reused. A new explicit 4B text config must derive structural values from this header and resolve the still-unproved fields above.

## Existing RFDT integration boundary and ready source plan

The current worker is intentionally fixed to `google/gemma-3-1b-it` at revision `dcc83ea841ab6100d6b47a070329e1ba4cf78752`. It rejects other lineage, requires 26 layers / hidden 1152 / MLP 6912 / 4 Q heads / 1 KV head, and hardcodes 26-layer Q/V LoRA construction, 104 trainable leaves, 52 fused modules, adapter metadata, and 1B output identity. Current package artifact approval likewise restricts local RFDT derivatives to the pinned 1B lineage. These checks should not be bypassed or relabelled for a GGUF-derived 4B research base. No worker adaptation or source promotion occurred.

The source plan is ready for a separately authorized future slice:

1. Decide whether the requirement is an official HF checkpoint or an explicitly GGUF-derived text research base. Official equivalence needs original checkpoint/config/tokenizer assets or independently proven equivalence; this source note cannot manufacture it.
2. Freeze the complete source/model/profile identities and obtain separate permission for actual weight reads and writes. The approved header SHA is insufficient for a full payload identity; ROOT can verify the catalog's complete SHA when that scope is authorized.
3. Identify original plain tokenizer/config assets, resolve every non-header config field, and perform metadata comparison before selecting reuse. Preserve exact token IDs, original prompts/rubrics/targets, and train-only supervision boundaries.
4. Implement an isolated, streaming prospective inverse converter only after authorization: complete 444-tensor mapping, original dimension interpretation, F32 norm subtraction, unchanged available matrices, tied head, and explicit lost-row/dtype provenance. It must produce a new research identity and reject missing/extra tensors; it must not claim the pinned official HF 4B revision.
5. Under separate future CPU/model execution authorization, verify structural load, source GGUF round-trip values at stored precision, and HF/MLX versus native render/token/selected-logit parity on synthetic contracts. Report actual differences and rounding/loss limits. No parity step has happened here.
6. Propose a separate 4B research worker/provenance boundary. For the existing all-layer Q/V policy, 34 layers imply 136 LoRA parameter leaves and 68 fused Q/V modules; verify these from actual trainable structure later rather than changing 1B checks blindly. Do not call the current worker, because train/fuse paths call resolution with `fetch=True` and reject the 4B lineage.
7. Only after those slices are authorized and closed should ROOT consider a bounded training experiment and fresh validation/performance acceptance. No validation/test reuse, performance prediction, role approval, or gain is implied by structural feasibility.

## Exact reviewed source pointers and CPU limits

- `scripts/build-rfdt.sh:20-26`: existing environment and worker entrypoint; source read only.
- `.vendor/llama.cpp/convert_hf_to_gguf.py:12-29`: imports Torch and conversion registry; not imported or executed here.
- `.vendor/llama.cpp/conversion/gemma.py:124-179`: Gemma 3 registration, vocabulary route, config defaults, embedding trim, norm shift.
- `.vendor/llama.cpp/conversion/base.py:587-597`: language-model prefix stripping.
- `.vendor/llama.cpp/conversion/base.py:670-729`: name/fusion route; no Gemma Q/K value permutation.
- `.vendor/llama.cpp/conversion/base.py:989-1019,1075-1110`: dtype conversion, F32 norm policy, explicit output dtype, ggml shape order.
- `.vendor/llama.cpp/conversion/base.py:1269-1328,1390-1439`: text-config flattening, vision filtering, rotary metadata.
- `.vendor/llama.cpp/gguf-py/gguf/tensor_mapping.py:10-16,97-106,193,257-278,326,371,428-440,502,573,637,698-720`: text tensor mappings.
- `.vendor/llama.cpp/gguf-py/gguf/gguf_reader.py:132-197,207-218,334-405`: read-only mmap, header parsing, metadata shape reversal, lazy tensor views.
- `.build/rfdt-venv/lib/python3.13/site-packages/transformers/models/gemma3/configuration_gemma3.py:89-174`: current text config, defaults, local/global layer types and RoPE.
- `.build/rfdt-venv/lib/python3.13/site-packages/transformers/models/gemma3/modeling_gemma3.py:98-142,307-396,405-435,499-505,587-596`: embedding scaling, norm offset, attention/MLP dimensions, residuals, tied head.
- `.build/rfdt-venv/lib/python3.13/site-packages/mlx_lm/models/gemma3_text.py:15-67,114-180,183-218,247-275`: explicit text args, split rotary layout, norm/embedding conventions, F16 residual clipping, tied-head sanitation.
- `.build/rfdt-venv/lib/python3.13/site-packages/mlx_lm/models/gemma3.py:14-50`: multimodal wrapper vocabulary override and vision sanitation.
- `rfdt/worker.py:25-35,159-204,294-352,430-452,565-619,727-761`: current 1B lineage/config/LoRA checks, final selected logits, tokenizer projection, F32 fusion.
- `src/rfdt.ts:922-936,1300-1375`: optional base path; pinned forward converter and 1B export route.
- `src/models.ts:106-122,783-796` and `models/registry.json`: current pinned catalog/1B derivative approval source.

The local RFDT requirements pin Python 3.13, MLX 0.32.2, MLX-LM source revision `9d1e356e7cc6549e7d1697adabe2ea01ff8e062c`, Transformers 5.11.0, and a separate Torch 2.11.0 forward exporter. Requirements/source identity were read; training readiness and backend availability were not queried.

`feasibility.cpu.py` verifies all metadata tensor names/shapes/dtypes and header/byte-size closure, then demonstrates two synthetic floating-point loss counterexamples. Its four passing checks establish only those claims. They do not load or sample actual weights, execute a tokenizer/model, validate checkpoint recovery, or measure training/inference quality or speed. `source-freeze.json` binds this note, scripts, captured metadata, CPU receipt, and every reviewed source identity. This is the stopping point: **ready source feasibility plan and metadata evidence; no recovery or model execution authorized or performed.**
