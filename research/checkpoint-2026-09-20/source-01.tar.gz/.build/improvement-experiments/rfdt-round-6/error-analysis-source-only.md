R6 remains completed_quality_fail. Its diagnosis gain is large but incomplete, and developer retention worsens. This analysis used only the allowlisted R5/R6 VAL reports/proofs and ROOT-filtered VAL labels. No native/model/GPU/network/auth/build/Git execution occurred, and no training, source, fixture, gate, protocol, runtime or critical file was changed.

| Validation measure | R5 | R6 |
|---|---:|---:|
| Legacy choice | 17/20 | 18/20 |
| Legacy clear truth | 16/16 | 16/16 |
| Legacy Brier | .004134 | .004826 |
| Legacy unknown MAE | .004468 | .002522 |
| Legacy score normalized MAE | .008217 | .041819 |
| Developer choice | 24/26 | 23/26 |
| Developer clear truth | 12/20 | 10/20 |
| Developer Brier | .358564 | .438559 |
| Developer unknown MAE | .197511 | .259144 |
| Developer score normalized MAE | .120077 | .186561 |
| Diagnosis choice | 16/56 | 44/56 |

R6 passes legacy quality and legacy uncertainty, but fails developer quality, developer uncertainty and diagnosis quality. Both proofs record zero approval, final TEST unused for these candidates, 23/23 actual file checks true, owned-process cleanup complete and lock absent. These are ROOT attestations; this analysis independently hashes only its permitted inputs and verifies report/candidate/label bindings.

Diagnosis has 32 repairs and 4 regressions. Category counts are type-contract 0→8/8, async-lifecycle 2→8/8, iteration-boundary 2→4/8, configuration 0→6/8, test-expectation 4→8/8, insufficient-evidence 8→4/8 and multiple-causes 0→6/8. Fully solved groups rise 3→10/14. The 56 rows contain 28 logical prompts in 14 synthetic groups: each state/chat pair has the same logical hash and complete prediction. Order 1 wins rise 8→20/28 rows; order 2 rises 8→24/28. These are correlated variants, not 56 independent successes.

The sole diagnosis regression is cropped-assertion-gap: both orders switch from insufficient-evidence to test-expectation even though the decisive assertion/specification facts are absent. Uncalibrated label probabilities are .983831 and .997205. Transpose stays wrong in both orders; runtime-feature-flag and independent-version-and-wrap remain wrong only in order 1. Diagnosis needs five additional logical-prompt repairs (10 paired rows) to reach its unchanged .95 gate. All execution/coverage/identity gates pass; accuracy still fails.

Developer route repairs herdr chat but loses mixed SOQL/browser chat and inactive Apex fallback state. Clear truth loses only the sanitizer payload pair; four other logical clear-truth failures persist. R6 still has six high-extremity wrong clear-truth rows representing three logical prompts. Unknown mail delivery moves .149448→.083716 and ESM import .411428→.158255, while unavailable GPU telemetry improves .346591→.480597. Score error increases in 11/13 developer groups. Log correlation, masking policy and worker frames account for the largest mean-error contributions; legacy conditional-plan scoring alone contributes .029163 of the .033602 mean-error increase.

The bounded next hypothesis is insufficient training discrimination between evidence that establishes a bad test expectation and evidence that merely reports a failed assertion, together with weak retention of evidence judgment and rubric coverage. Test independently authored training-only contrasts and balanced criterion orders, then use every unchanged VAL gate. Recipe counts/composition and train/VAL independence were not verified: only changed training-dataset digests and equal 512-step counts are available. The paired runs do not establish an optimal mix, step count, causal mechanism or Gemma4 behavior.

The JSON companion includes every recorded summary/experiment/selection gate, exact changed discrete errors, all numerical error deltas, group/category/order coverage, confidence diagnostics and SHA-256 provenance.
