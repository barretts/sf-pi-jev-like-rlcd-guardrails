#!/usr/bin/env python3
"""Owned R7 export-only continuation. Never calls prepare/train/evaluate/approve."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/bsonntag/code/simple-jev-ts')
WORK = ROOT / '.build/improvement-experiments'
HERE = Path(__file__).resolve().parent
RUN = WORK / 'rfdt-round-7/run'
OLD_JOB = WORK / 'rfdt-round-7/job.json'
PROTOCOL = WORK / 'evidence-supervision-comparison/protocol.json'
REVIEW = WORK / 'evidence-supervision-comparison/root-current-dependency-review-1.json'
BASE_PROOF = WORK / 'evidence-supervision-comparison/root-offline-base-full-files-preflight-1.json'
PYTHON = ROOT / '.build/rfdt-venv/bin/python'
NODE = Path('/Users/bsonntag/.local/bin/node')
EXPECTED_RUN = 'rfdt-20260920150051-6adca0d2'
EXPECTED_ADAPTER = '393be73af7a4f0db018ac4c43c092af7c4059d513a2e54a1a0b4be444182194e'
EXPECTED_PROTOCOL = '287da1f64c43524ac5aaa255c7647e831553c0fd2d7d795374c147379eb6fbbf'
EXPECTED_STAGE = '384470ef8c186512c2076f210c741452ebeb4c88a8fe86719d9a6960fe344953'
EXPECTED_CONVERTER = 'f072b103714dfa1eee531f80b24512faf38e3dd2'
STOP = False
CHILD = None
LOG_LIMIT = 32 * 1024 * 1024

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while True:
            block = stream.read(4 * 1024 * 1024)
            if not block:
                break
            h.update(block)
    return h.hexdigest()

def identity(path):
    path = Path(path)
    return {'path': str(path), 'resolved_path': str(path.resolve()),
            'bytes': path.stat().st_size, 'sha256': digest(path)}

def read(path):
    return json.loads(Path(path).read_text())

def save(path, value):
    path = Path(path)
    part = path.with_name(path.name + '.part')
    with part.open('w') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    part.chmod(0o600)
    part.replace(path)

def capture(command, env=None):
    result = subprocess.run(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                            capture_output=True, text=True, check=True)
    return result.stdout.strip()

def process_rows():
    raw = capture(['/bin/ps', '-ax', '-o', 'pid=,ppid=,pgid=,lstart=,comm='])
    rows = []
    for line in raw.splitlines():
        cells = line.split(None, 8)
        if len(cells) == 9:
            rows.append({'pid': int(cells[0]), 'ppid': int(cells[1]),
                         'pgid': int(cells[2]), 'start': ' '.join(cells[3:8]),
                         'command': cells[8]})
    return rows

def stop_handler(_number, _frame):
    global STOP
    STOP = True

def terminate_group():
    if CHILD is None:
        return
    for sig, grace in [(signal.SIGTERM, 5), (signal.SIGKILL, 3)]:
        members = [row for row in process_rows() if row['pgid'] == CHILD.pid]
        if not members:
            return
        os.killpg(CHILD.pid, sig)
        deadline = time.monotonic() + grace
        while time.monotonic() < deadline:
            CHILD.poll()
            if not any(row['pgid'] == CHILD.pid for row in process_rows()):
                return
            time.sleep(0.2)
    raise RuntimeError('Owned recovery process group failed bounded termination')

def main():
    global CHILD
    journal_path = HERE / 'journal.json'
    assert not journal_path.exists(), 'Recovery journal already exists; do not replay'
    journal = {'kind': 'ROOT_R7_export_only_recovery_1', 'started_at': utc(),
               'owner_pid': os.getpid(), 'status': 'preflight',
               'run_directory': str(RUN), 'training_replayed': False,
               'native_evaluation_invocations': 0, 'heldout_invocations': 0,
               'approval_invocations': 0, 'network_or_credentials_authorized': False}
    save(journal_path, journal)
    lock_path = HERE / 'owner.lock'
    lock = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    immutable = {}
    output_refs = {}
    try:
        manifest = read(RUN / 'manifest.json')
        job = read(OLD_JOB)
        protocol = read(PROTOCOL)
        review = read(REVIEW)
        base_proof = read(BASE_PROOF)
        assert manifest['id'] == EXPECTED_RUN and manifest['status'] == 'trained'
        assert manifest['template_version'] == 'v2'
        assert manifest['prepared']['branches'] == {'train': 970, 'validation': 0, 'test': 0}
        training = manifest['training']
        assert training['steps'] == 512 and training['adapter_sha256'] == EXPECTED_ADAPTER
        assert all(training[key] is True for key in ['adapter_changed', 'reload_verified', 'training_loss_decreased'])
        assert digest(PROTOCOL) == EXPECTED_PROTOCOL
        assert job['stage_binding']['sha256'] == EXPECTED_STAGE
        assert digest(job['stage_binding']['path']) == EXPECTED_STAGE
        assert job['staged']['training_input_sha256'] == manifest['source']['sha256']
        assert digest(job['staged']['training_input']) == manifest['source']['sha256']
        assert digest(manifest['prepared']['dataset_file']) == manifest['prepared']['dataset_sha256']
        frozen = hashlib.sha256()
        for split in ['train', 'validation', 'test']:
            path = Path(manifest['prepared']['files'][split])
            assert path.parent == RUN
            if split != 'train':
                assert path.stat().st_size == 0, 'Expected empty prepared nontraining splits'
            frozen.update((split + '\n').encode())
            frozen.update(path.read_bytes())
        assert frozen.hexdigest() == manifest['prepared']['sha256']
        assert digest(manifest['prepared']['files']['train']) == training['training_data_sha256']
        adapter_dir = Path(training['adapter_dir'])
        assert adapter_dir == RUN / 'adapter'
        adapter_manifest = read(adapter_dir / 'rfdt-manifest.json')
        assert adapter_manifest['adapter_sha256'] == EXPECTED_ADAPTER
        assert digest(adapter_dir / 'adapters.safetensors') == EXPECTED_ADAPTER
        assert adapter_manifest['training_data_sha256'] == training['training_data_sha256']
        assert adapter_manifest['template_version'] == 'v2'
        assert not (RUN / 'fused').exists(), 'Fresh fused output required; do not delete/reuse an existing output'
        assert not (RUN / 'artifact.json').exists() and not manifest.get('exports')
        assert not list(RUN.glob('*.gguf'))
        assert not (RUN / 'native-test-report.json').exists()
        assert not list(RUN.glob('native-test-*.reservation.json'))
        assert not (RUN / 'native-evaluation.lock').exists()
        assert not (ROOT / '.jev/artifacts.json').exists()
        original_rows = process_rows()
        original_pids = {job['owner_pid'], job['child_pid']}
        original_groups = {entry['child_pgid'] for entry in job['phase_history']}
        assert not [row for row in original_rows if row['pid'] in original_pids or row['pgid'] in original_groups], 'Original R7 owner/child/group still exists'
        for name, expected in job['dist_sha256'].items():
            path = ROOT / 'dist' / name
            actual = digest(path)
            assert actual == expected, 'R7 executed dist identity mismatch: ' + name
            if actual != protocol['dist_sha256'][name]:
                drift = review['sole_dependency_drift']
                assert name == 'evaluation.js' and actual == drift['current'] and protocol['dist_sha256'][name] == drift['old']
                assert review['training_semantics_unchanged'] is True
        for path, expected in job['source_sha256'].items():
            assert digest(path) == expected, 'R7 source identity mismatch: ' + path
        assert digest(ROOT / 'rfdt/worker.py') == protocol['worker_sha256']
        for ref in base_proof['full_files']:
            assert identity(ref['path']) == ref, 'Offline base file identity mismatch: ' + ref['path']
        assert identity(PYTHON) == base_proof['python_executable']
        base = Path(job['base_model_path'])
        assert str(base) == base_proof['base_snapshot']
        assert base.name == protocol['base_revision']
        assert digest(base / 'model.safetensors') == protocol['base_weight_sha256']
        env = {key: os.environ[key] for key in ['PATH', 'HOME', 'TMPDIR', 'USER', 'LOGNAME', 'LANG', 'LC_ALL'] if key in os.environ}
        env.update({'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1',
                    'HF_HUB_DISABLE_PROGRESS_BARS': '1', 'HF_HUB_DISABLE_IMPLICIT_TOKEN': '1',
                    'HF_HOME': str(HERE / 'offline-hf-home'), 'HF_TOKEN_PATH': str(HERE / 'absent-token'),
                    'JEV_DEVICE': 'metal', 'PYTHONUNBUFFERED': '1'})
        metadata_code = "import json,platform,importlib.metadata as m; names=['mlx','mlx-lm','transformers','huggingface-hub','torch']; print(json.dumps({'python':platform.python_version(),**{n:m.version(n) for n in names},'mlx_lm_direct_url':json.loads(m.distribution('mlx-lm').read_text('direct_url.json'))}))"
        runtime = json.loads(capture([str(PYTHON), '-I', '-c', metadata_code], env))
        assert {key: runtime[key] for key in base_proof['runtime_package_metadata']} == base_proof['runtime_package_metadata']
        assert runtime['mlx_lm_direct_url']['vcs_info']['commit_id'] == training['provenance']['dependencies']['mlx_lm_revision']
        vendor = ROOT / '.vendor/llama.cpp'
        assert capture(['/usr/bin/git', '-C', str(vendor), 'rev-parse', 'HEAD'], env) == EXPECTED_CONVERTER
        converter = vendor / 'convert_hf_to_gguf.py'
        converter_source = subprocess.run(['/usr/bin/git', '-C', str(vendor), 'show', EXPECTED_CONVERTER + ':convert_hf_to_gguf.py'], cwd=ROOT, env=env, stdin=subprocess.DEVNULL, capture_output=True, check=True).stdout
        assert digest(converter) == hashlib.sha256(converter_source).hexdigest()
        capture(['/usr/bin/git', '-C', str(vendor), 'diff', '--quiet', '--', 'conversion', 'gguf-py'], env)
        protected = {Path(path): expected for path, expected in job['staged']['old_evidence_hashes'].items()}
        for path, expected in protected.items():
            assert digest(path) == expected, 'Protected evidence mismatch: ' + str(path)
        for source, name in [(RUN / 'manifest.json', 'original-trained-manifest.json'), (OLD_JOB, 'original-stale-job.json')]:
            target = HERE / name
            with target.open('xb') as stream:
                stream.write(source.read_bytes())
            target.chmod(0o600)
        paths = [PROTOCOL, REVIEW, BASE_PROOF, OLD_JOB, Path(job['stage_binding']['path']),
                 Path(job['staged']['training_input']), Path(job['staged']['developer_frozen']),
                 Path(job['staged']['diagnosis_validation']['path']),
                 RUN / 'dataset.jsonl', RUN / 'train.jsonl', RUN / 'validation.jsonl', RUN / 'test.jsonl',
                 RUN / 'training-report.json', converter, PYTHON, NODE, Path(__file__), ROOT / 'rfdt/requirements.txt']
        paths += [ROOT / 'dist' / name for name in job['dist_sha256']]
        paths += [Path(path) for path in job['source_sha256']]
        paths += [ROOT / 'src' / name for name in ['cli.ts', 'rfdt.ts', 'models.ts', 'backend.ts', 'core.ts', 'evaluation.ts']]
        paths += [Path(ref['path']) for ref in base_proof['full_files']]
        paths += list(adapter_dir.glob('*'))
        paths += list(protected)
        original_lock = WORK / 'rfdt-runner.lock'
        if original_lock.exists():
            paths.append(original_lock)
        site = ROOT / '.build/rfdt-venv/lib/python3.13/site-packages'
        for glob in ['mlx-*.dist-info', 'mlx_metal-*.dist-info', 'mlx_lm-*.dist-info', 'transformers-*.dist-info', 'huggingface_hub-*.dist-info', 'torch-*.dist-info']:
            for info in site.glob(glob):
                paths += [file for file in info.iterdir() if file.is_file() and file.name in ['METADATA', 'RECORD', 'direct_url.json', 'WHEEL']]
        immutable = {str(path): identity(path) for path in dict.fromkeys(paths) if path.is_file()}
        preflight = {'observed_at': utc(), 'identities': list(immutable.values()), 'runtime_metadata': runtime,
                     'node_version': capture([str(NODE), '--version'], env), 'original_processes_absent': True,
                     'original_runner_lock_preserved': original_lock.exists(), 'fresh_fused_output': True,
                     'protocol_verified': EXPECTED_PROTOCOL, 'stage_verified': EXPECTED_STAGE,
                     'adapter_verified': EXPECTED_ADAPTER, 'only_documented_original_evaluation_export_drift': True,
                     'credential_environment_inherited': False, 'offline_local_base_only': True,
                     'prepared_test_empty': True, 'protected_evidence_hashed_only': True}
        save(HERE / 'preflight.json', preflight)
        command = [str(NODE), str(ROOT / 'dist/cli.js'), 'rfdt', 'export', '--run', str(RUN),
                   '--model-path', str(base), '--python', str(PYTHON)]
        journal.update(status='export_running', command=command, preflight=identity(HERE / 'preflight.json'),
                       original_trained_manifest=identity(HERE / 'original-trained-manifest.json'),
                       original_stale_job=identity(HERE / 'original-stale-job.json'), runtime_lane='owned export only')
        save(journal_path, journal)
        print(json.dumps({'status': 'preflight_passed_export_starting', 'journal': str(journal_path), 'adapter_sha256': EXPECTED_ADAPTER}), flush=True)
        signal.signal(signal.SIGINT, stop_handler)
        signal.signal(signal.SIGTERM, stop_handler)
        with (HERE / 'export.stdout.json').open('xb') as stdout, (HERE / 'export.stderr.log').open('xb') as stderr, (HERE / 'owned-process-observations.jsonl').open('x') as observations:
            CHILD = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, start_new_session=True, close_fds=True)
            journal.update(child_pid=CHILD.pid, child_pgid=CHILD.pid, export_started_at=utc())
            save(journal_path, journal)
            while CHILD.poll() is None:
                members = [row for row in process_rows() if row['pgid'] == CHILD.pid]
                observations.write(json.dumps({'observed_at': utc(), 'members': members}) + '\n')
                observations.flush()
                if STOP or max((HERE / 'export.stdout.json').stat().st_size, (HERE / 'export.stderr.log').stat().st_size) > LOG_LIMIT:
                    terminate_group()
                    raise RuntimeError('Recovery explicitly cancelled' if STOP else 'Recovery stream exceeded bounded log size')
                for path in [str(OLD_JOB), str(ROOT / 'dist/cli.js'), str(ROOT / 'dist/rfdt.js'), str(ROOT / 'rfdt/worker.py'), job['stage_binding']['path']]:
                    assert digest(path) == immutable[path]['sha256'], 'Bound export input changed during execution: ' + path
                time.sleep(1)
            exit_code = CHILD.wait()
            journal.update(export_exit_code=exit_code, child_wait_completed_at=utc())
        journal['stdout_stderr_handles_closed'] = True
        assert not [row for row in process_rows() if row['pgid'] == CHILD.pid], 'Owned process group retained after CLI exit'
        journal['owned_process_group_absent'] = True
        assert exit_code == 0, 'Export CLI failed; retained original output/logs'
        for path, before in immutable.items():
            assert identity(path) == before, 'Frozen input changed after export: ' + path
        exported = read(RUN / 'manifest.json')
        artifact = read(RUN / 'artifact.json')
        assert exported['status'] == 'exported' and exported['id'] == EXPECTED_RUN
        assert exported['training']['adapter_sha256'] == EXPECTED_ADAPTER
        assert artifact['training_run'] == EXPECTED_RUN and artifact['template_version'] == 'v2'
        assert Path(artifact['run_manifest']) == RUN / 'manifest.json'
        assert exported['exports']['sha256'] == artifact['sha256']
        artifact_file = Path(artifact['file'])
        assert artifact_file.parent == RUN and digest(artifact_file) == artifact['sha256']
        assert artifact_file.stat().st_size == artifact['size']
        with artifact_file.open('rb') as stream:
            assert stream.read(4) == b'GGUF'
        assert not exported.get('evaluation')
        assert not (RUN / 'native-test-report.json').exists() and not list(RUN.glob('native-test-*.reservation.json'))
        assert not (ROOT / '.jev/artifacts.json').exists()
        output_refs = {name: identity(path) for name, path in [('exported_manifest', RUN / 'manifest.json'),
                       ('artifact_manifest', RUN / 'artifact.json'), ('gguf', artifact_file),
                       ('fused_manifest', RUN / 'fused/rfdt-fused-manifest.json'),
                       ('stdout', HERE / 'export.stdout.json'), ('stderr', HERE / 'export.stderr.log')]}
        journal.update(status='exported', artifact=artifact, output_refs=output_refs,
                       original_job_unchanged=True, all_frozen_inputs_unchanged=True,
                       native_test_and_approval_absent=True, quality_validation_completed=False)
    except BaseException as error:
        if CHILD is not None:
            try:
                terminate_group()
                CHILD.wait(timeout=2)
                journal['owned_process_group_absent'] = not any(row['pgid'] == CHILD.pid for row in process_rows())
                journal['export_exit_code'] = CHILD.returncode
            except BaseException as cleanup_error:
                journal['cleanup_error'] = str(cleanup_error)
        journal.update(status='cancelled' if STOP else 'failed', error={'type': type(error).__name__, 'message': str(error)})
    finally:
        journal['completed_at'] = utc()
        journal['export_stdout_stderr_closed_at_finish'] = CHILD is None or CHILD.poll() is not None
        save(journal_path, journal)
        os.close(lock)
        lock_path.unlink()
        print(json.dumps({'status': journal['status'], 'journal': str(journal_path),
                          'artifact': journal.get('artifact'), 'error': journal.get('error')}), flush=True)
    return 0 if journal['status'] == 'exported' else 1

if __name__ == '__main__':
    sys.exit(main())
