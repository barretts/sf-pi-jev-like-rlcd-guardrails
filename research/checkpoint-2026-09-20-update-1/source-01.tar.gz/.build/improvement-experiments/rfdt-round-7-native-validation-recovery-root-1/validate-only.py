#!/usr/bin/env python3
"""Prepared R7 native validation continuation; explicit execution flag required."""
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/Users/bsonntag/code/simple-jev-ts')
WORK = ROOT / '.build/improvement-experiments'
HERE = Path(__file__).resolve().parent
EXPORT = WORK / 'rfdt-round-7-export-recovery-root-1'
RUN = WORK / 'rfdt-round-7/run'
ROUND = WORK / 'rfdt-round-7'
EXPECTED_GGUF = 'd350a4dc0ecf2384b02bb6ab323c27fc12ff6738b5e6279d118f2069bba0040e'
spec = importlib.util.spec_from_file_location('owned_export_helpers', EXPORT / 'recover-export.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)

def phases(job):
    cli = [str(helpers.NODE), str(ROOT / 'dist/cli.js')]
    stage = job['staged']
    diagnosis = stage['diagnosis_validation']
    return [
        ('legacy_validation', cli + ['rfdt', 'evaluate', '--run', str(RUN), '--split', 'validation']),
        ('developer_validation', ['node', str(WORK / 'evaluate-developer-candidate.mjs'),
         '--artifact', str(RUN / 'artifact.json'), '--corpus', stage['developer_frozen'],
         '--corpus-sha256', stage['developer_sha256'],
         '--output', str(ROUND / 'developer-validation-report.json'),
         '--progress', str(ROUND / 'developer-validation-progress.json')]),
        ('diagnosis_validation', ['node', str(WORK / 'controller-extension/evaluate-diagnosis-candidate.mjs'),
         '--artifact', str(RUN / 'artifact.json'), '--corpus', diagnosis['path'],
         '--corpus-sha256', diagnosis['sha256'],
         '--expectations', json.dumps(diagnosis, separators=(',', ':')),
         '--output', str(ROUND / 'diagnosis-validation-report.json'),
         '--progress', str(ROUND / 'diagnosis-validation-progress.json')]),
    ]

def no_protected_mutation():
    assert not (RUN / 'native-test-report.json').exists()
    assert not list(RUN.glob('native-test-*.reservation.json'))
    assert not (ROOT / '.jev/artifacts.json').exists()

def main():
    assert sys.argv[1:] == ['--execute-frozen-validation'], 'Prepared only: ROOT authorization and explicit execution flag required'
    prepared = helpers.read(HERE / 'prepared-source.json')
    for ref in prepared['source_and_input_identities']:
        assert helpers.identity(ref['path']) == ref, 'Prepared source/input identity changed: ' + ref['path']
    journal_path = HERE / 'journal.json'
    assert not journal_path.exists(), 'Do not replay an existing native validation recovery'
    journal = {'kind': 'ROOT_R7_native_validation_only_recovery_1', 'started_at': helpers.utc(),
               'owner_pid': os.getpid(), 'status': 'preflight', 'phase_history': [],
               'training_replayed': False, 'export_replayed': False, 'heldout_invocations': 0,
               'approval_invocations': 0, 'independent_prospective_attestation': 'separate and pending'}
    helpers.save(journal_path, journal)
    lock_path = HERE / 'owner.lock'
    lock = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    immutable = {}
    try:
        export_journal = helpers.read(EXPORT / 'journal.json')
        assert export_journal['status'] == 'exported' and export_journal['export_exit_code'] == 0
        assert export_journal['owned_process_group_absent'] is True
        assert export_journal['all_frozen_inputs_unchanged'] is True
        manifest = helpers.read(RUN / 'manifest.json')
        job = helpers.read(helpers.OLD_JOB)
        assert manifest['id'] == helpers.EXPECTED_RUN and manifest['status'] == 'exported'
        assert manifest['training']['adapter_sha256'] == helpers.EXPECTED_ADAPTER
        assert manifest['training']['steps'] == 512 and not manifest.get('evaluation')
        artifact = helpers.read(RUN / 'artifact.json')
        assert artifact['sha256'] == EXPECTED_GGUF and artifact['training_run'] == helpers.EXPECTED_RUN
        assert artifact['template_version'] == 'v2'
        assert helpers.identity(artifact['file']) == export_journal['output_refs']['gguf']
        no_protected_mutation()
        assert not (RUN / 'native-evaluation.lock').exists()
        assert not any(row['pgid'] == export_journal['child_pgid'] for row in helpers.process_rows())
        for ref in helpers.read(EXPORT / 'preflight.json')['identities']:
            assert helpers.identity(ref['path']) == ref, 'Original frozen R7 identity changed: ' + ref['path']
            immutable[ref['path']] = ref
        for path in [RUN / 'artifact.json', Path(artifact['file']), HERE / 'validate-only.py', HERE / 'prepared-source.json']:
            immutable[str(path)] = helpers.identity(path)
        outputs = [RUN / 'native-validation-report.json', ROUND / 'developer-validation-report.json',
                   ROUND / 'diagnosis-validation-report.json', ROUND / 'developer-validation-progress.json',
                   ROUND / 'diagnosis-validation-progress.json']
        assert not any(path.exists() for path in outputs), 'Native recovery outputs must start fresh'
        snapshot = HERE / 'original-exported-manifest.json'
        with snapshot.open('xb') as stream:
            stream.write((RUN / 'manifest.json').read_bytes())
        snapshot.chmod(0o600)
        commands = phases(job)
        assert commands == [(entry['phase'], entry['command']) for entry in prepared['frozen_remaining_phases']]
        env = {key: os.environ[key] for key in ['PATH', 'HOME', 'TMPDIR', 'USER', 'LOGNAME', 'LANG', 'LC_ALL'] if key in os.environ}
        env.update({'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'HF_DATASETS_OFFLINE': '1',
                    'HF_HUB_DISABLE_PROGRESS_BARS': '1', 'HF_HUB_DISABLE_IMPLICIT_TOKEN': '1',
                    'HF_HOME': str(HERE / 'offline-hf-home'), 'HF_TOKEN_PATH': str(HERE / 'absent-token'),
                    'JEV_DEVICE': 'metal', 'PYTHONUNBUFFERED': '1'})
        helpers.STOP = False
        signal.signal(signal.SIGINT, helpers.stop_handler)
        signal.signal(signal.SIGTERM, helpers.stop_handler)
        journal.update(original_exported_manifest=helpers.identity(snapshot),
                       preflight_passed=True, artifact=artifact, expected_validation_records=194,
                       expected_independent_groups=83, source_and_input_identities=list(immutable.values()))
        helpers.save(journal_path, journal)
        for phase, command in commands:
            helpers.CHILD = None
            assert not helpers.STOP, 'Cancelled before the next frozen phase'
            no_protected_mutation()
            for path, ref in immutable.items():
                assert helpers.identity(path) == ref, 'Bound input changed before phase: ' + path
            stdout_path, stderr_path = HERE / (phase + '.stdout.json'), HERE / (phase + '.stderr.log')
            entry = {'phase': phase, 'command': command, 'started_at': helpers.utc(),
                     'stdout': str(stdout_path), 'stderr': str(stderr_path)}
            journal['phase_history'].append(entry)
            journal.update(status='running', phase=phase)
            with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr, (HERE / (phase + '.processes.jsonl')).open('x') as observations:
                helpers.CHILD = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                     stdout=stdout, stderr=stderr, start_new_session=True, close_fds=True)
                entry.update(child_pid=helpers.CHILD.pid, child_pgid=helpers.CHILD.pid)
                helpers.save(journal_path, journal)
                print(json.dumps({'phase': phase, 'child_pid': helpers.CHILD.pid, 'status': 'running'}), flush=True)
                while helpers.CHILD.poll() is None:
                    members = [row for row in helpers.process_rows() if row['pgid'] == helpers.CHILD.pid]
                    observations.write(json.dumps({'observed_at': helpers.utc(), 'members': members}) + '\n')
                    observations.flush()
                    if helpers.STOP or max(stdout_path.stat().st_size, stderr_path.stat().st_size) > helpers.LOG_LIMIT:
                        helpers.terminate_group()
                        raise RuntimeError('Validation cancelled' if helpers.STOP else 'Validation log size exceeded bound')
                    for path in [str(helpers.OLD_JOB), str(ROOT / 'dist/cli.js'), str(ROOT / 'dist/rfdt.js'),
                                 str(ROOT / 'dist/models.js'), str(ROOT / 'dist/backend.js'), str(ROOT / 'dist/core.js'),
                                 str(ROOT / 'dist/evaluation.js'), job['stage_binding']['path']]:
                        assert helpers.digest(path) == immutable[path]['sha256'], 'Source or stage changed during phase: ' + path
                    time.sleep(1)
                entry.update(exit_code=helpers.CHILD.wait(), wait_completed_at=helpers.utc())
            entry['stdout_stderr_handles_closed'] = True
            entry['owned_process_group_absent'] = not any(row['pgid'] == helpers.CHILD.pid for row in helpers.process_rows())
            assert entry['owned_process_group_absent'], 'Owned validation process group remains'
            assert entry['exit_code'] in [0, 1], 'Unexpected frozen phase exit; preserve failure and stop'
            entry.update(stdout_identity=helpers.identity(stdout_path), stderr_identity=helpers.identity(stderr_path))
            helpers.save(journal_path, journal)
        no_protected_mutation()
        for path, ref in immutable.items():
            assert helpers.identity(path) == ref, 'Bound input changed after validation: ' + path
        journal.update(status='completed_frozen_validation', phase='terminal',
                       native_report_identities=[helpers.identity(path) for path in outputs[:3]],
                       native_test_and_approval_absent=True, original_job_and_sources_unchanged=True,
                       independent_selection_attester_pending=True, quality_approval_effect='none')
    except BaseException as error:
        if helpers.CHILD is not None:
            try:
                helpers.terminate_group()
                helpers.CHILD.wait(timeout=2)
            except BaseException as cleanup_error:
                journal['cleanup_error'] = str(cleanup_error)
        journal.update(status='cancelled' if helpers.STOP else 'failed',
                       error={'type': type(error).__name__, 'message': str(error)})
    finally:
        journal['completed_at'] = helpers.utc()
        helpers.save(journal_path, journal)
        os.close(lock)
        lock_path.unlink()
        print(json.dumps({'status': journal['status'], 'journal': str(journal_path), 'error': journal.get('error')}), flush=True)
    return 0 if journal['status'] == 'completed_frozen_validation' else 1

if __name__ == '__main__':
    sys.exit(main())
