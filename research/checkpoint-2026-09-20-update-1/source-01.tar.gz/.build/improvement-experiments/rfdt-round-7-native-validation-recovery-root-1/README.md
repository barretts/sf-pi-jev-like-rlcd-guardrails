Prepared source only. ROOT authorization is required before running this wrapper.

The wrapper continues the three unchanged remaining R7 commands: legacy native VALIDATION60, developer VALIDATION78, and diagnosis VALIDATION56. It performs no training, re-export, TEST inference, approval, gate tuning, prompt edits, corpus edits, or model selection. The original stale job and archived runner stay unchanged. The original exported manifest is snapshotted before authorized evaluation updates it.

The wrapper compares the original R7 export preflight identities, verified exported GGUF, frozen stage and current executable source bytes. Every phase owns a new process group and retains its actual exit, closed streams, process observations, and original report. Original quality failures (exit 1) are retained while the remaining original validation suites complete. Unexpected exits or identity changes stop the recovery.

After all owned native processes and streams close, ROOT separately applies the corrected prospective independent host attester to the complete original validation bytes and native reports. This wrapper does not declare selection success or production approval. The additional individual-score gate and every original gate remain unchanged.

Authorized execution, once ROOT explicitly clears it:

```sh
/usr/bin/python3 .build/improvement-experiments/rfdt-round-7-native-validation-recovery-root-1/validate-only.py --execute-frozen-validation
```
