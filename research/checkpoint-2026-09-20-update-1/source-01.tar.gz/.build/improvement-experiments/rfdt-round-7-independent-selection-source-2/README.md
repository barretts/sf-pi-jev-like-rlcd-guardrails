This is a pure host attester for finished R7 validation report bytes. It grades original predictions through the actual exported production `scorePrediction`, recomputes summaries through `summarizeQuality`, and reuses the original diagnosis evaluator's exported `coverageOf`, `assertExpectations` and `diagnosisGates`. It has no CLI, filesystem defaults, model/native launch, tokenizer, rendering, network or process observation. Importing the diagnosis helper does not call its runDiagnosis function or lazy production backend imports.

```js
import { attestR7ValidationSelection } from './attest.mjs';
const hostReport = attestR7ValidationSelection({
  stageClosed: true,
  suiteInputBytes: { legacy, developer, diagnosis }, // original safe validation JSONL BYTE values
  nativeReportBytes: { legacy, developer, diagnosis }, // unchanged complete/partial native report BYTE values
  frozenInputRefs: {
    legacy: { bytes, sha256 }, developer: { bytes, sha256 }, diagnosis: { bytes, sha256 },
  }, // ROOT independently frozen original input refs, never derived from predictions
  candidateBinding: { id, sha256, size, training_run, template_version: 'v2' },
  legacyRfdtBinding: {
    training_run, artifact_id, artifact_sha256, artifact_size, template_version: 'v2',
    prepared_sha256, dataset_sha256, quality_suite_sha256,
  }, // ROOT independently verifies the original RFDT run/artifact binding
});
```

ROOT alone injects bytes after owned processes exit and stdio closes. ROOT supplies original60/78/56 validation subsets with30/39/14 independent groups, exact original IDs, requests, targets, criteria order and regression flags. The input refs are an explicit trusted ROOT boundary: this module checks supplied bytes against them but cannot establish that arbitrary caller-supplied refs are the real frozen corpus. It never reads a full mixed corpus or TEST. ROOT must verify those original input refs and source identities independently; report-derived selection of records/targets is forbidden.

Each result must match its original ID/group/split/regression, original v2 prepared prompt, candidate model, artifact SHA/size, native backend/device and template metadata. Predictions are rescored against original questions and targets; stored grades and summary must equal the actual exported scoring results. The metadata is retained unchanged in raw_native_reports and is not relabeled. RFDT legacy prepared/dataset/quality-suite binding is compared to the separate trusted input. Developer/diagnosis experiment attribution and their original gates are checked against source. ROOT separately verifies the complete source/runtime/model/export/training attribution and experimental full-corpus raw hashes.

All original legacy/developer full-suite and uncertainty MAE<=.1 gates remain. The additional explicit-null gate counts only target.answer===null, requires every expected null target to have a successful graded result, and requires MAE<=.1. Probability-map NOUL retains the original scorer's uncertain behavior and original summary gate, but cannot dilute this null-only gate. The individual developer gate requires24 of all26 score questions correct under unchanged production scorePrediction.correct and normalized-error tolerance .1. Three misses fail even when the original mean-error gate passes.

The original diagnosis helper retains its .95 accuracy, zero-error, exact-ID/group/representation and native-identity gates. Input coverage additionally requires all14 groups to retain four rows: zero string states, two structured states and two message rows (two candidate orders across state/chat). The exact frozen input byte ref, compiled prompt hashes and result IDs retain both original message/order cells; no invented order permutation rule or independent-sample count is introduced.

Duplicate/foreign IDs, target/grade/prompt or metadata contradictions reject the host report. Missing/unrun results retain a metadata-free failure grading view in the full expected denominator; raw native reports are preserved exactly as parsed. Native error rows retain their errors and grades and cannot count as individual-score successes. The original observed summary is compared before adding missing failure views, so honest partial/cancelled outputs can be assessed without forging a full native report. ROOT retains any report that rejects as an honest invalid/negative result. No missing predictions or elapsed work are imputed as success.

The planning identity pins original R7 protocol SHA `287da1f64c43524ac5aaa255c7647e831553c0fd2d7d795374c147379eb6fbbf`, stage SHA `384470ef8c186512c2076f210c741452ebeb4c88a8fe86719d9a6960fe344953`, 970 TRAIN rows and 512 optimizer steps. It also pins prospective selection contract SHA `24f447ec984aac297022b8a7d4306e11f1ed18a6ccc3ab9c5fcbcdd3353a3eff`. These are planning/source identities; ROOT must establish actual training with exact executed-source and output bindings. The original protocol's historical evaluation.js SHA predates exporting the unchanged scorer. The current production export bytes are recorded in this source inventory; ROOT's current dependency review must bind the actual executed bytes and unchanged semantics.

The output research_schema is rfdt-round7-independent-host-selection-1. host_quality_gates_passed is a host reconstruction result. actual_native_execution_or_training_proven_by_host_attester remains false. ROOT must combine it with independently observed full streamed artifact/source/runtime hashes, actual inference parity, all owned exits/stdio/PID absence and unchanged protected-history hashes. Only old protected TEST hashes are needed; this host attester never reads TEST predictions or runs new TEST inference. Classifier selection does not establish speed, normal developer workflow/true DX, role approval or promotion; all approval effects remain none.

The tiny CPU suite is wholly invented. It checks complete194 host reconstruction,23/26 individual misses despite acceptable MAE, missing-score denominators, forged grades/metadata, a missing diagnosis cell, probability-map dilution of explicit-null MAE, and rejection of wrong aggregate or per-group diagnosis inventories. It does not prove actual R7 training, model quality, native runtime, parity, cleanup, resource use or gain.

```bash
node --test --test-reporter=tap \
  .build/improvement-experiments/rfdt-round-7-independent-selection-source-2/attest.cpu.test.mjs
```

source-freeze.json and cpu-proof.json identify the source-only release and invented CPU proof. ROOT independently verifies their bytes and reruns these focused tests before using the module. No actual R7/older output, dataset, proof, model/tokenizer/native/library payload, authentication or process state was read during this preparation.
