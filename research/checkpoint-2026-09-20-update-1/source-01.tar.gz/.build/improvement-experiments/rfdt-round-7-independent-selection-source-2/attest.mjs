import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { canonical, preparePrompt } from '../../../dist/core.js';
import { validateQualityRecords, qualityDatasetDigest, scorePrediction, summarizeQuality } from '../../../dist/evaluation.js';
import { coverageOf, assertExpectations, diagnosisGates } from '../controller-extension/evaluate-diagnosis-candidate.mjs';

// Pure host regrading only: no files, CLI/default inputs, classifier creation,
// native/model execution, rendering, tokenization or external observations.
export const PLANNING = Object.freeze({
  round: 7, training_rows: 970, optimizer_steps: 512, template_version: 'v2',
  base_model: 'google/gemma-3-1b-it', base_revision: 'dcc83ea841ab6100d6b47a070329e1ba4cf78752',
  base_weight_sha256: '3d4ef8d71c14db7e448a09ebe891cfb6bf32c57a9b44499ae0d1c098e48516b6',
  protocol_sha256: '287da1f64c43524ac5aaa255c7647e831553c0fd2d7d795374c147379eb6fbbf',
  stage_sha256: '384470ef8c186512c2076f210c741452ebeb4c88a8fe86719d9a6960fe344953',
  prospective_contract_bytes: 1547,
  prospective_contract_sha256: '24f447ec984aac297022b8a7d4306e11f1ed18a6ccc3ab9c5fcbcdd3353a3eff',
  developer_expected_scores: 26, developer_correct_scores_min: 24, developer_score_accuracy_min: 0.9,
});
export const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export const jsonBytes = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
function finiteOwnJson(value) {
  const active = new Set(); let nodes = 0;
  function visit(item, depth) {
    assert.ok(++nodes <= 4000000 && depth <= 80, 'Host evidence structural bound');
    if (item === null || typeof item === 'string' || typeof item === 'boolean') return;
    if (typeof item === 'number') { assert.ok(Number.isFinite(item), 'Finite JSON numbers required'); return; }
    assert.ok(item && typeof item === 'object' && !active.has(item), 'Plain acyclic JSON required');
    assert.ok(Array.isArray(item) ? Object.getPrototypeOf(item) === Array.prototype : [Object.prototype, null].includes(Object.getPrototypeOf(item)), 'Own plain JSON required');
    assert.equal(Object.getOwnPropertySymbols(item).length, 0); active.add(item);
    const entries = Object.entries(Object.getOwnPropertyDescriptors(item));
    if (Array.isArray(item)) assert.equal(entries.length, item.length + 1, 'Dense arrays required');
    for (const [key, descriptor] of entries) {
      if (Array.isArray(item) && key === 'length') continue;
      assert.ok(Object.hasOwn(descriptor, 'value') && descriptor.enumerable, 'Own data properties required'); visit(descriptor.value, depth + 1);
    }
    active.delete(item);
  }
  visit(value, 0); return value;
}
const parse = bytes => finiteOwnJson(JSON.parse(Buffer.from(bytes).toString('utf8')));
const same = (a, b, reason) => { finiteOwnJson(a); finiteOwnJson(b); assert.equal(canonical(a), canonical(b), reason); };
const descriptor = bytes => ({ bytes: bytes.length, sha256: sha(bytes) });
const types = records => Object.fromEntries(['choice', 'score', 'noul'].map(type => [type, records.filter(row => row.request.questions[0].type === type).length]));
const digestPattern = /^[a-f0-9]{64}$/;

function recordsFor(name, bytes, expected) {
  same(descriptor(bytes), expected, 'ROOT-frozen original input byte binding: ' + name);
  const records = validateQualityRecords(bytes.toString('utf8').trim().split(/\r?\n/).filter(line => line.trim()).map(line => parse(Buffer.from(line))));
  const counts = { legacy: [60, 30], developer: [78, 39], diagnosis: [56, 14] }[name];
  assert.equal(records.length, counts[0]); assert.equal(new Set(records.map(row => row.group_id)).size, counts[1]);
  assert.ok(records.every(row => row.split === 'validation' && row.request.questions.length === 1), 'Only complete original validation suites');
  if (name === 'developer') same(types(records), { choice: 26, score: 26, noul: 26 }, 'All original developer type denominators');
  if (name === 'diagnosis') {
    const coverage = coverageOf(records);
    assertExpectations(coverage, { records: 56, groups: 14, choice_records: 56, variants_per_group: 4,
      representations: { string_state: 0, structured_state: 28, messages: 28 } });
    for (const group of Object.values(coverage.group_records)) same(group.representations, { string_state: 0, structured_state: 2, messages: 2 }, 'All four frozen diagnosis state/chat/order rows per group');
  }
  return records;
}

function gradeSuite(name, records, report, candidate) {
  assert.equal(report.schema_version, 1); assert.equal(report.template_version, 'v2');
  assert.ok(typeof report.created_at === 'string' && Number.isFinite(Date.parse(report.created_at)), 'Native quality report creation timestamp');
  assert.equal(report.dataset_sha256, qualityDatasetDigest(records)); same(report.splits, ['validation']);
  assert.ok(Array.isArray(report.results)); const byId = new Map(records.map(row => [row.id, row])); const seen = new Set(); const observed = [];
  for (const row of report.results) {
    assert.ok(byId.has(row.id) && !seen.has(row.id), 'No duplicate or foreign native result IDs'); seen.add(row.id);
    const record = byId.get(row.id); assert.equal(row.group_id, record.group_id); assert.equal(row.split, 'validation');
    assert.equal(row.regression, record.regression === true); assert.ok(Number.isFinite(row.elapsed_ms) && row.elapsed_ms >= 0, 'Retained finite elapsed time');
    const request = { ...record.request, model: candidate.id, options: { ...record.request.options, template_version: 'v2' } };
    const prompt = sha(JSON.stringify(preparePrompt(request, 'v2').questions));
    if (!row.error || row.logical_prompt_sha256 != null) assert.equal(row.logical_prompt_sha256, prompt, 'Original v2 compiled request/order binding');
    if (row.error) assert.ok(typeof row.error === 'string' && row.error.length > 0, 'Retain every inference error');
    else {
      assert.equal(row.model, candidate.id); assert.equal(row.metadata?.artifact?.sha256, candidate.sha256); assert.equal(row.metadata?.artifact?.size, candidate.size);
      assert.equal(row.metadata?.backend, 'llama.cpp'); assert.equal(row.metadata?.device, 'metal'); assert.equal(row.metadata?.template_version, 'v2');
    }
    assert.ok(Array.isArray(row.answers)); const answers = []; const questionIds = new Set();
    for (const answer of row.answers) {
      const question = record.request.questions.find(q => q.id === answer.question_id);
      assert.ok(question && !questionIds.has(question.id), 'Exact original question IDs, no duplicates'); questionIds.add(question.id);
      const reproduced = scorePrediction(question, record.targets[question.id], answer.prediction);
      same(answer, reproduced, 'Original target/prediction/production grade equality'); answers.push(reproduced);
    }
    if (!row.error) assert.equal(answers.length, record.request.questions.length, 'Successful inference covers all original questions');
    observed.push({ id: row.id, group_id: row.group_id, split: row.split, regression: row.regression, answers, ...(row.error ? { error: row.error } : {}) });
  }
  const observedSummary = summarizeQuality(observed); same(report.summary, observedSummary, 'Production summary independently recomputed');
  assert.equal(report.prompt_manifest_sha256, sha(JSON.stringify(report.results.map(row => [row.id, row.logical_prompt_sha256 ?? null]))));
  const observedById = new Map(observed.map(row => [row.id, row]));
  const gradingViews = records.map(record => observedById.get(record.id) ?? { id: record.id, group_id: record.group_id, split: record.split,
    regression: record.regression === true, answers: [], error: 'Unrun or missing native result; original denominator retained' });
  const summary = summarizeQuality(gradingViews); const fullCoverage = seen.size === records.length;
  const explicitNulls = records.flatMap(record => record.request.questions.filter(q => q.type === 'noul' && Object.hasOwn(record.targets[q.id], 'answer') && record.targets[q.id].answer === null)
    .map(q => ({ record, q })));
  const unknownGrades = explicitNulls.map(({ record, q }) => { const row = observedById.get(record.id); return !row?.error ? row?.answers.find(answer => answer.question_id === q.id) : undefined; }).filter(Boolean);
  const unknownMae = unknownGrades.length ? unknownGrades.reduce((sum, grade) => sum + grade.normalized_absolute_error, 0) / unknownGrades.length : null;
  const unknown = { expected: explicitNulls.length, observed: unknownGrades.length, normalized_mae: unknownMae,
    passed: explicitNulls.length > 0 && unknownGrades.length === explicitNulls.length && Number.isFinite(unknownMae) && unknownMae <= 0.1 };
  let originalGates;
  if (name === 'diagnosis') {
    const reconstructed = diagnosisGates(records, { ...report, summary: observedSummary }, candidate);
    same(report.coverage, reconstructed.coverage, 'Original diagnosis coverage helper');
    const expectedGates = { ...reconstructed.gates, execution_completed: !report.error, passed: reconstructed.gates.passed && !report.error, choice_accuracy_threshold: 0.95 };
    same(report.experiment_gates, expectedGates, 'Original diagnosis .95/coverage/native gates');
    originalGates = { diagnosis: expectedGates.passed };
  } else {
    const uncertain = observedSummary.noul;
    const originalUncertainty = uncertain.uncertain_count > 0 && Number.isFinite(uncertain.uncertainty_mae) && uncertain.uncertainty_mae <= 0.1;
    if (name === 'developer') same(report.experiment_gates, { uncertainty_mae: originalUncertainty, passed: observedSummary.gates.passed && originalUncertainty }, 'Original developer uncertainty gates');
    originalGates = { full_original_suite: summary.gates.passed, original_uncertainty_mae: originalUncertainty, explicit_null_coverage_and_mae: unknown.passed };
  }
  if (name !== 'legacy') {
    for (const [key, value] of Object.entries({ training_run: candidate.training_run, artifact_id: candidate.id, artifact_sha256: candidate.sha256,
      artifact_size: candidate.size, split: 'validation', permanent_approval: false, scoped_registry_removed: true })) assert.equal(report.experiment?.[key], value, 'Original candidate experiment binding ' + key);
  }
  return { expected_records: records.length, observed_records: seen.size, missing_records: records.length - seen.size,
    full_coverage: fullCoverage, grading_views: gradingViews, summary, original_gates: originalGates, explicit_null_unknown: unknown,
    passed: fullCoverage && !report.error && Object.values(originalGates).every(value => value === true) };
}

export function attestR7ValidationSelection(input) {
  assert.equal(input.stageClosed, true, 'ROOT closes owned processes before byte injection');
  finiteOwnJson(input.frozenInputRefs); finiteOwnJson(input.candidateBinding); finiteOwnJson(input.legacyRfdtBinding);
  const candidate = input.candidateBinding;
  assert.equal(candidate.template_version, 'v2'); assert.ok(typeof candidate.id === 'string' && candidate.id.length > 0);
  assert.match(candidate.sha256, digestPattern); assert.ok(Number.isSafeInteger(candidate.size) && candidate.size > 0);
  assert.ok(typeof candidate.training_run === 'string' && candidate.training_run.length > 0);
  same(Object.keys(input.suiteInputBytes).sort(), ['developer', 'diagnosis', 'legacy']); same(Object.keys(input.nativeReportBytes).sort(), ['developer', 'diagnosis', 'legacy']);
  const records = {}, reports = {}, suites = {}, inputRefs = {}, reportRefs = {};
  for (const name of ['legacy', 'developer', 'diagnosis']) {
    const bytes = Buffer.from(input.suiteInputBytes[name]), reportBytes = Buffer.from(input.nativeReportBytes[name]);
    records[name] = recordsFor(name, bytes, input.frozenInputRefs[name]); reports[name] = parse(reportBytes);
    inputRefs[name] = descriptor(bytes); reportRefs[name] = descriptor(reportBytes);
    suites[name] = gradeSuite(name, records[name], reports[name], candidate);
  }
  const allRecords = Object.values(records).flat();
  assert.equal(allRecords.length, 194); assert.equal(new Set(allRecords.map(row => row.id)).size, 194, 'Unique original IDs across all suites');
  assert.equal(new Set(allRecords.map(row => row.group_id)).size, 83, 'All83 independent original groups across suites');
  const rfdt = input.legacyRfdtBinding;
  for (const [key, value] of Object.entries({ training_run: candidate.training_run, artifact_id: candidate.id, artifact_sha256: candidate.sha256, artifact_size: candidate.size, template_version: 'v2' })) assert.equal(rfdt[key], value);
  for (const key of ['prepared_sha256', 'dataset_sha256', 'quality_suite_sha256']) assert.match(rfdt[key], digestPattern);
  same(reports.legacy.rfdt, rfdt, 'ROOT-frozen original RFDT prepared/dataset/model binding');
  const scores = records.developer.flatMap(record => record.request.questions.filter(q => q.type === 'score').map(q => ({ record, q })));
  const views = new Map(suites.developer.grading_views.map(row => [row.id, row]));
  const correct = scores.filter(({ record, q }) => { const row = views.get(record.id); return !row.error && row.answers.find(answer => answer.question_id === q.id)?.correct === true; }).length;
  assert.equal(scores.length, 26); const individual = { expected: scores.length, correct, accuracy: correct / scores.length,
    tolerance_source: 'unchanged exported production scorePrediction.correct, normalized error <= .1', passed: correct >= 24 && correct / scores.length >= 0.9 };
  const hostPassed = Object.values(suites).every(suite => suite.passed) && individual.passed;
  const output = { research_schema: 'rfdt-round7-independent-host-selection-1', planning: PLANNING, candidate_binding: candidate,
    expected_population: { records: 194, independent_groups: 83, suites: { legacy: 60, developer: 78, diagnosis: 56 } },
    input_byte_refs: inputRefs, native_report_byte_refs: reportRefs, suites, developer_individual_score_correctness: individual,
    host_quality_gates_passed: hostPassed, honest_host_negative: !hostPassed, raw_native_reports: reports,
    actual_native_execution_or_training_proven_by_host_attester: false,
    ROOT_independent_current_identity_raw_parity_protected_history_and_cleanup_observations_required: true,
    held_out_TEST_read_by_host_attester: false, speed_or_true_DX_gain_established: false, production_role_approval: false, approval_effect: 'none' };
  finiteOwnJson(output); return output;
}
