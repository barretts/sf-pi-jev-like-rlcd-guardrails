import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { PLANNING, sha, jsonBytes } from './attest.mjs';

// Pure SOURCE release packaging: reads only new invented CPU evidence and the
// exact authorized source/planning metadata. No referenced artifact is opened.
const here = new URL('./', import.meta.url), root = new URL('../../../', here);
const own = ['attest.mjs', 'attest.cpu.test.mjs', 'README.md', 'freeze-source.mjs'];
const dependencies = ['dist/evaluation.js', 'dist/core.js', 'dist/rfdt.js',
  '.build/improvement-experiments/evaluate-developer-candidate.mjs',
  '.build/improvement-experiments/controller-extension/evaluate-diagnosis-candidate.mjs',
  '.build/improvement-experiments/rfdt-runner.py',
  '.build/improvement-experiments/evidence-supervision-comparison/protocol.json',
  '.build/improvement-experiments/evidence-supervision-comparison/root-prospective-individual-score-selection-contract-1.json'];
async function identity(url) { const bytes = await readFile(url); return { path: fileURLToPath(url), bytes: bytes.length, sha256: sha(bytes) }; }
export async function freezeSource({ observedCpuExitCode, observedCpuSessionClosed }) {
  assert.equal(observedCpuExitCode, 0); assert.equal(observedCpuSessionClosed, true);
  const tap = await readFile(new URL('cpu-tap.txt', here), 'utf8');
  for (const [key, value] of Object.entries({ tests: 7, pass: 7, fail: 0, cancelled: 0, skipped: 0, todo: 0 })) assert.match(tap, new RegExp('^# ' + key + ' ' + value + '$', 'm'));
  const proof = { kind: 'R7_independent_host_selection_invented_CPU_proof_ONLY', observed_at: new Date().toISOString(),
    command: 'node --test --test-reporter=tap .build/improvement-experiments/rfdt-round-7-independent-selection-source-2/attest.cpu.test.mjs',
    tests: 7, passed: 7, failed: 0, observed_exit_code: 0, observed_session_closed: true,
    raw_CPU_output: await identity(new URL('cpu-tap.txt', here)), wholly_invented_records_targets_reports_and_identities: true,
    actual_dataset_or_run_output_read: false, native_model_tokenizer_GPU_training_network_auth_execution: false, process_state_inspected: false,
    actual_R7_training_or_classifier_quality_or_gain_proven: false, approval_effect: 'none' };
  await writeFile(new URL('cpu-proof.json', here), jsonBytes(proof), { flag: 'wx', mode: 0o600 });
  const refs = await Promise.all([...own.map(name => new URL(name, here)), ...dependencies.map(name => new URL(name, root))].map(identity));
  const bySuffix = suffix => refs.find(ref => ref.path.endsWith(suffix));
  assert.equal(bySuffix('/evidence-supervision-comparison/protocol.json').sha256, PLANNING.protocol_sha256);
  assert.equal(bySuffix('/root-prospective-individual-score-selection-contract-1.json').sha256, PLANNING.prospective_contract_sha256);
  assert.equal(bySuffix('/root-prospective-individual-score-selection-contract-1.json').bytes, PLANNING.prospective_contract_bytes);
  assert.equal(refs.length, 12);
  const release = { kind: 'R7_independent_host_selection_source_release', release_revision: 2,
    released_at: new Date().toISOString(), source_and_invented_CPU_only: true,
    research_schema: 'rfdt-round7-independent-host-selection-1', planning: PLANNING,
    source_identities: refs.sort((a, b) => a.path.localeCompare(b.path)), cpu_proof: await identity(new URL('cpu-proof.json', here)),
    actual_datasets_reports_proofs_artifacts_process_state_read: false,
    actual_training_inference_quality_speed_DX_or_cleanup_proven: false,
    existing_production_helpers_protocol_training_or_selection_sources_edited: false,
    ROOT_closed_stage_full_current_hash_identity_raw_parity_and_protected_history_checks_required: true,
    TEST_read_or_inference: false, native_execution_authorized: false, production_role_approval: false,
    approval_effect: 'none', source_ownership_released_to_ROOT: true };
  await writeFile(new URL('source-freeze.json', here), jsonBytes(release), { flag: 'wx', mode: 0o600 });
  return { release: await identity(new URL('source-freeze.json', here)), cpu_proof: release.cpu_proof,
    attester: refs.find(ref => ref.path === fileURLToPath(new URL('attest.mjs', here))), sources: refs.length };
}
