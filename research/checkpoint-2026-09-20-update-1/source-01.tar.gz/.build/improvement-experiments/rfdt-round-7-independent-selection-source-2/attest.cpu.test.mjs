import test from 'node:test';
import assert from 'node:assert/strict';
import { preparePrompt } from '../../../dist/core.js';
import { validateQualityRecords, scorePrediction, summarizeQuality, qualityDatasetDigest } from '../../../dist/evaluation.js';
import { coverageOf, diagnosisGates } from '../controller-extension/evaluate-diagnosis-candidate.mjs';
import { attestR7ValidationSelection, sha, jsonBytes } from './attest.mjs';

// Every row, target, prediction, identity and report here is invented CPU data.
const candidate = { id: 'invented-r7-candidate', sha256: '1'.repeat(64), size: 100, training_run: 'invented-r7-run', template_version: 'v2' };
const rfdt = { training_run: candidate.training_run, artifact_id: candidate.id, artifact_sha256: candidate.sha256, artifact_size: candidate.size,
  template_version: 'v2', prepared_sha256: '2'.repeat(64), dataset_sha256: '3'.repeat(64), quality_suite_sha256: '4'.repeat(64) };
const question = type => ({ id: 'q', type, instructions: 'Invented CPU contract question',
  ...(type === 'choice' ? { criteria: [{ id: 'a', description: 'A' }, { id: 'b', description: 'B' }] }
    : type === 'score' ? { criteria: ['zero', 'one', 'two', 'three'] } : {}) });
const experiment = { training_run: candidate.training_run, artifact_id: candidate.id, artifact_sha256: candidate.sha256,
  artifact_size: candidate.size, split: 'validation', permanent_approval: false, scoped_registry_removed: true };

function records(name) {
  return validateQualityRecords(Array.from({ length: { legacy: 60, developer: 78, diagnosis: 56 }[name] }, (_, i) => {
    const type = name === 'diagnosis' ? 'choice' : name === 'developer' ? ['choice', 'score', 'noul'][Math.floor(i / 26)] : ['choice', 'score', 'noul'][i % 3];
    const q = question(type); const target = type === 'choice' ? { answer: 'a' } : type === 'score' ? { answer: 1.5 } : { answer: [true, false, null][name === 'legacy' ? Math.floor(i / 3) % 3 : i % 3] };
    let context = { state: 'Invented context ' + i };
    if (name === 'diagnosis') {
      const cell = i % 4;
      context = cell % 2 === 0 ? { state: { scenario: 'invented-' + Math.floor(i / 4) } }
        : { messages: [{ role: 'user', content: 'Invented scenario ' + Math.floor(i / 4) }] };
      if (cell >= 2) q.criteria.reverse();
    }
    return { id: name + '-' + i, group_id: name + '-group-' + Math.floor(i / (name === 'diagnosis' ? 4 : 2)), split: 'validation',
      request: { model: 'google/gemma-3-1b-it', ...context, questions: [q] }, targets: { q: target } };
  }));
}
function finish(name, source, report) {
  report.summary = summarizeQuality(report.results);
  report.prompt_manifest_sha256 = sha(JSON.stringify(report.results.map(row => [row.id, row.logical_prompt_sha256 ?? null])));
  if (name === 'developer') { const u = report.summary.noul; const pass = u.uncertain_count > 0 && Number.isFinite(u.uncertainty_mae) && u.uncertainty_mae <= 0.1;
    report.experiment_gates = { uncertainty_mae: pass, passed: report.summary.gates.passed && pass }; }
  if (name === 'diagnosis') { const gates = diagnosisGates(source, report, candidate); report.coverage = gates.coverage;
    report.experiment_gates = { ...gates.gates, execution_completed: true, passed: gates.gates.passed, choice_accuracy_threshold: 0.95 }; }
}
function fixture({ scoreMisses = 0 } = {}) {
  const all = {}, reports = {}, suiteInputBytes = {}, nativeReportBytes = {}, frozenInputRefs = {};
  for (const name of ['legacy', 'developer', 'diagnosis']) {
    const source = all[name] = records(name); let misses = scoreMisses;
    const results = source.map(record => { const q = record.request.questions[0], target = record.targets.q;
      const prediction = q.type === 'choice' ? { type: 'choice', choice: 'a' } : q.type === 'score' ? { type: 'score', score: name === 'developer' && misses-- > 0 ? 2 : 1.5 }
        : { type: 'noul', noul: target.answer === null ? 0.5 : target.answer ? 1 : 0 };
      const plan = preparePrompt({ ...record.request, model: candidate.id, options: { template_version: 'v2' } }, 'v2');
      return { id: record.id, group_id: record.group_id, split: 'validation', regression: false, elapsed_ms: 1,
        logical_prompt_sha256: sha(JSON.stringify(plan.questions)), answers: [scorePrediction(q, target, prediction)], model: candidate.id,
        metadata: { artifact: { sha256: candidate.sha256, size: candidate.size }, backend: 'llama.cpp', device: 'metal', template_version: 'v2' } };
    });
    const report = reports[name] = { schema_version: 1, template_version: 'v2', created_at: '2026-09-20T15:00:00.000Z', dataset_sha256: qualityDatasetDigest(source), splits: ['validation'], results,
      ...(name === 'legacy' ? { rfdt } : { experiment }) }; finish(name, source, report);
    suiteInputBytes[name] = Buffer.from(source.map(row => JSON.stringify(row)).join('\n') + '\n');
    frozenInputRefs[name] = { bytes: suiteInputBytes[name].length, sha256: sha(suiteInputBytes[name]) };
    nativeReportBytes[name] = jsonBytes(report);
  }
  const input = { stageClosed: true, suiteInputBytes, nativeReportBytes, frozenInputRefs, candidateBinding: candidate, legacyRfdtBinding: rfdt };
  return { input, all, reports, refresh() { for (const name of ['legacy', 'developer', 'diagnosis']) { finish(name, all[name], reports[name]); input.nativeReportBytes[name] = jsonBytes(reports[name]); } return input; } };
}

test('invented complete194 host grades pass without native training quality speed TEST or approval claims', () => {
  const f = fixture(); const report = attestR7ValidationSelection(f.input);
  assert.equal(report.host_quality_gates_passed, true); assert.equal(report.developer_individual_score_correctness.correct, 26);
  assert.equal(report.suites.diagnosis.observed_records, 56); assert.equal(report.suites.legacy.observed_records, 60);
  assert.equal(report.actual_native_execution_or_training_proven_by_host_attester, false);
  assert.equal(report.speed_or_true_DX_gain_established, false); assert.equal(report.production_role_approval, false);
  assert.equal(report.held_out_TEST_read_by_host_attester, false); assert.equal(report.approval_effect, 'none');
  assert.equal(report.planning.training_rows, 970); assert.equal(report.planning.optimizer_steps, 512);
});

test('three original developer individual score misses fail24of26 despite acceptable original mean error', () => {
  const f = fixture({ scoreMisses: 3 }); const report = attestR7ValidationSelection(f.input);
  assert.ok(report.suites.developer.summary.score.normalized_mae <= 0.1);
  assert.equal(report.suites.developer.original_gates.full_original_suite, true);
  assert.equal(report.developer_individual_score_correctness.correct, 23); assert.equal(report.developer_individual_score_correctness.expected, 26);
  assert.equal(report.developer_individual_score_correctness.passed, false); assert.equal(report.host_quality_gates_passed, false);
});

test('four missing or unrun developer score rows retain the26-score and78-record denominators', () => {
  const f = fixture(); f.reports.developer.results.splice(26, 4); const report = attestR7ValidationSelection(f.refresh());
  assert.equal(report.suites.developer.observed_records, 74); assert.equal(report.suites.developer.grading_views.length, 78);
  assert.equal(report.suites.developer.summary.failures, 4); assert.equal(report.developer_individual_score_correctness.correct, 22);
  assert.equal(report.developer_individual_score_correctness.expected, 26); assert.equal(report.host_quality_gates_passed, false);
  assert.equal(report.raw_native_reports.developer.results.length, 74, 'Raw report is not rewritten with invented success rows');
});

test('forged original score correctness and wrong native metadata cannot survive host regrading', () => {
  const f = fixture({ scoreMisses: 3 }); f.reports.developer.results[26].answers[0].correct = true;
  assert.throws(() => attestR7ValidationSelection(f.refresh()), /production grade equality/);
  const g = fixture(); g.reports.developer.results[0].metadata.artifact.sha256 = '9'.repeat(64);
  assert.throws(() => attestR7ValidationSelection(g.refresh()), /Expected/);
});

test('one missing diagnosis state chat order cell stays honest negative through the original helper', () => {
  const f = fixture(); f.reports.diagnosis.results.pop(); const report = attestR7ValidationSelection(f.refresh());
  assert.equal(report.suites.diagnosis.missing_records, 1); assert.equal(report.suites.diagnosis.grading_views.length, 56);
  assert.equal(report.suites.diagnosis.original_gates.diagnosis, false); assert.equal(report.host_quality_gates_passed, false);
});

test('probability-map uncertainty cannot dilute the additional full-coverage explicit-null unknown gate', () => {
  const f = fixture(); let changed = 0;
  for (const record of f.all.developer.filter(row => row.request.questions[0].type === 'noul')) {
    const q = record.request.questions[0], row = f.reports.developer.results.find(row => row.id === record.id);
    let prediction = row.answers[0].prediction;
    if (record.targets.q.answer === null) prediction = { type: 'noul', noul: 0.7 };
    else if (changed++ < 13) {
      const truth = record.targets.q.answer;
      record.targets.q = { probabilities: { [truth ? '9' : '1']: 1 } };
      prediction = { type: 'noul', noul: truth ? 0.99 : 0.01 };
    }
    row.answers = [scorePrediction(q, record.targets.q, prediction)];
  }
  const bytes = Buffer.from(f.all.developer.map(row => JSON.stringify(row)).join('\n') + '\n');
  f.input.suiteInputBytes.developer = bytes; f.input.frozenInputRefs.developer = { bytes: bytes.length, sha256: sha(bytes) };
  f.reports.developer.dataset_sha256 = qualityDatasetDigest(f.all.developer);
  const report = attestR7ValidationSelection(f.refresh());
  assert.equal(report.suites.developer.original_gates.full_original_suite, true);
  assert.equal(report.suites.developer.original_gates.original_uncertainty_mae, true);
  assert.equal(report.suites.developer.explicit_null_unknown.expected, 9);
  assert.equal(report.suites.developer.explicit_null_unknown.observed, 9);
  assert.ok(report.suites.developer.explicit_null_unknown.normalized_mae > 0.1);
  assert.equal(report.suites.developer.explicit_null_unknown.passed, false); assert.equal(report.host_quality_gates_passed, false);
});


test('frozen diagnosis inventory rejects old string counts and uneven group layouts despite correct global totals', () => {
  const bindInventedDiagnosis = f => {
    const bytes = Buffer.from(f.all.diagnosis.map(row => JSON.stringify(row)).join('\n') + '\n');
    f.input.suiteInputBytes.diagnosis = bytes;
    f.input.frozenInputRefs.diagnosis = { bytes: bytes.length, sha256: sha(bytes) };
    return f.input;
  };
  const counts = source => Object.fromEntries(Object.entries(coverageOf(source).representations).map(([name, value]) => [name, value.records]));
  const complete = fixture();
  assert.deepEqual(counts(complete.all.diagnosis), { string_state: 0, structured_state: 28, messages: 28 });
  assert.ok(Object.values(coverageOf(complete.all.diagnosis).group_records).every(group =>
    group.records === 4 && group.representations.string_state === 0 && group.representations.structured_state === 2 && group.representations.messages === 2));
  assert.deepEqual(complete.all.diagnosis.slice(0, 4).map(row => row.request.questions[0].criteria.map(criterion => criterion.id)),
    [['a', 'b'], ['a', 'b'], ['b', 'a'], ['b', 'a']]);

  const oldCounts = fixture();
  oldCounts.all.diagnosis.forEach((row, i) => { if (i % 4 === 0) row.request.state = 'Invented string state ' + Math.floor(i / 4); });
  assert.deepEqual(counts(oldCounts.all.diagnosis), { string_state: 14, structured_state: 14, messages: 28 });
  assert.throws(() => attestR7ValidationSelection(bindInventedDiagnosis(oldCounts)), /diagnosis string_state mismatch/);

  const uneven = fixture();
  delete uneven.all.diagnosis[0].request.state;
  uneven.all.diagnosis[0].request.messages = [{ role: 'user', content: 'Invented scenario 0' }];
  delete uneven.all.diagnosis[5].request.messages;
  uneven.all.diagnosis[5].request.state = { scenario: 'invented-1' };
  assert.deepEqual(counts(uneven.all.diagnosis), { string_state: 0, structured_state: 28, messages: 28 });
  assert.throws(() => attestR7ValidationSelection(bindInventedDiagnosis(uneven)), /All four frozen diagnosis state\/chat\/order rows per group/);
});
