import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { createReadStream } from "node:fs";
import { spawnSync } from "node:child_process";
import { attestR7ValidationSelection, PLANNING } from "../rfdt-round-7-independent-selection-source-2/attest.mjs";
import { qualityDatasetDigest, validateQualityRecords } from "../../../dist/evaluation.js";

const sha = bytes => createHash("sha256").update(bytes).digest("hex");
const root = new URL("../../../", import.meta.url);
const file = path => new URL(path, root);
const work = ".build/improvement-experiments/";
const reportPath = file(work + "rfdt-round-7-selection-root-1/host-selection.json");
const receiptPath = file(work + "rfdt-round-7-selection-root-1/root-receipt.json");
const readJson = async path => JSON.parse(await readFile(file(path), "utf8"));
const checkpoint = await readJson("research/checkpoint-2026-09-20/manifest.json");
const historicalRefs = new Map(checkpoint.archives.flatMap(archive => archive.files).map(ref => [ref.path, ref]));
async function frozenInput(path) {
  const bytes = await readFile(file(path));
  const expected = historicalRefs.get(path);
  assert.ok(expected, "Input must have been preserved before native validation");
  assert.equal(bytes.length, expected.bytes);
  assert.equal(sha(bytes), expected.sha256);
  const rows = validateQualityRecords(bytes.toString("utf8").trim().split(/\r?\n/).map(JSON.parse));
  assert.ok(rows.every(row => row.split === "validation"), "No TRAIN or TEST rows injected");
  return {bytes, refs: {bytes: expected.bytes, sha256: expected.sha256}, rows};
}
const oldJobBytes = await readFile(file(work + "rfdt-round-7/job.json"));
assert.equal(sha(oldJobBytes), "350a3f6ab806ba7f70645cc45f005efdb4cfc8c9b8a00af1e027ba79c2258590");
const job = JSON.parse(oldJobBytes);
assert.equal(sha(await readFile(job.stage_binding.path)), PLANNING.stage_sha256);
assert.equal(sha(await readFile(file(work + "evidence-supervision-comparison/protocol.json"))), PLANNING.protocol_sha256);
for (const [name, expected] of Object.entries(job.dist_sha256)) assert.equal(sha(await readFile(file("dist/" + name))), expected);
for (const [path, expected] of Object.entries(job.source_sha256)) assert.equal(sha(await readFile(path)), expected);
for (const [path, expected] of Object.entries(job.staged.old_evidence_hashes)) assert.equal(sha(await readFile(path)), expected);
const sourceBytes = await readFile(file(work + "rfdt-round-7-independent-selection-source-2/attest.mjs"));
assert.equal(sha(sourceBytes), "0fb380832782f4bee1eadd843999a09cf7d576fb7b30baebf6974e9e60e922b0");
const freezeBytes = await readFile(file(work + "rfdt-round-7-independent-selection-source-2/source-freeze.json"));
assert.equal(sha(freezeBytes), "11f2949da8e53fae3f5400f5a2bcd1b87bda7c48a9610a3fe66c7a9501ed3faa");
for (const ref of JSON.parse(freezeBytes).source_identities) {
  const bytes = await readFile(ref.path);
  assert.equal(bytes.length, ref.bytes); assert.equal(sha(bytes), ref.sha256);
}
const journalBytes = await readFile(file(work + "rfdt-round-7-native-validation-recovery-root-1/journal.json"));
assert.equal(sha(journalBytes), "bdfd2dddcd86e5416e5655f14f466d76e2946260be86927f9956c744d370320e");
const journal = JSON.parse(journalBytes);
assert.equal(journal.status, "completed_frozen_validation");
assert.equal(journal.phase_history.length, 3);
assert.ok(journal.phase_history.every(phase => phase.exit_code === 1 && phase.stdout_stderr_handles_closed && phase.owned_process_group_absent));
const observedProcesses = spawnSync("/bin/ps", ["-axo", "pid=,pgid=,state=,comm="], {encoding: "utf8"});
assert.equal(observedProcesses.status, 0);
const processes = observedProcesses.stdout.trim().split("\n").map(line => line.trim().split(/\s+/));
for (const phase of journal.phase_history) assert.ok(!processes.some(row => Number(row[1]) === phase.child_pgid), "Owned native group remains");
const manifest = await readJson(work + "rfdt-round-7/run/manifest.json");
const artifact = await readJson(work + "rfdt-round-7/run/artifact.json");
assert.equal(manifest.id, "rfdt-20260920150051-6adca0d2");
assert.equal(manifest.training.adapter_sha256, "393be73af7a4f0db018ac4c43c092af7c4059d513a2e54a1a0b4be444182194e");
assert.equal(manifest.training.steps, 512);
assert.equal(manifest.training.reload_max_probability_delta, 0);
assert.equal(artifact.sha256, "d350a4dc0ecf2384b02bb6ab323c27fc12ff6738b5e6279d118f2069bba0040e");
const modelHash = createHash("sha256");
let modelBytes = 0;
for await (const chunk of createReadStream(artifact.file)) {modelHash.update(chunk); modelBytes += chunk.length;}
assert.equal(modelHash.digest("hex"), artifact.sha256);
assert.equal(modelBytes, artifact.size);
const candidateBinding = {id: artifact.id, sha256: artifact.sha256, size: artifact.size, training_run: manifest.id, template_version: "v2"};
const legacyRfdtBinding = {training_run: manifest.id, artifact_id: artifact.id, artifact_sha256: artifact.sha256, artifact_size: artifact.size,
  template_version: "v2", prepared_sha256: manifest.prepared.sha256, dataset_sha256: manifest.prepared.dataset_sha256, quality_suite_sha256: job.staged.legacy_sha256};
const inputPaths = {legacy: work + "validation-label-audit/legacy-validation-60.jsonl", developer: work + "validation-label-audit/validation-78.jsonl", diagnosis: work + "conditional-supervision-comparison/diagnosis-validation-56.jsonl"};
const nativePaths = {legacy: work + "rfdt-round-7/run/native-validation-report.json", developer: work + "rfdt-round-7/developer-validation-report.json", diagnosis: work + "rfdt-round-7/diagnosis-validation-report.json"};
const expectedReports = {legacy: "77fc416ff5dc026143dfa477fcbdfab48df2975e2e6e46e4e7f949d36e0d8b0f", developer: "5d691a3dcbafdf47506da3f44636cfbf4e43e1f9d737958305aa2a10f7452b4f", diagnosis: "8e711add9a841f1989222ed16604f5ed0e0fdbaa7607c3c00a7b0a39bfe88435"};
const input = {stageClosed: true, suiteInputBytes: {}, nativeReportBytes: {}, frozenInputRefs: {}, candidateBinding, legacyRfdtBinding};
for (const name of ["legacy", "developer", "diagnosis"]) {
  const original = await frozenInput(inputPaths[name]);
  const reportBytes = await readFile(file(nativePaths[name]));
  assert.equal(sha(reportBytes), expectedReports[name]);
  assert.equal(qualityDatasetDigest(original.rows), JSON.parse(reportBytes).dataset_sha256);
  input.suiteInputBytes[name] = original.bytes;
  input.frozenInputRefs[name] = original.refs;
  input.nativeReportBytes[name] = reportBytes;
}
const report = attestR7ValidationSelection(input);
assert.equal(report.expected_population.records, 194);
assert.equal(report.host_quality_gates_passed, false);
assert.equal(report.developer_individual_score_correctness.correct, 13);
assert.ok(Object.values(report.suites).every(suite => suite.full_coverage && suite.summary.failures === 0));
const output = JSON.stringify(report, null, 2) + "\n";
await writeFile(reportPath, output, {flag: "wx", mode: 0o600});
const receipt = {schema_version: 1, created_at: new Date().toISOString(), host_selection_sha256: sha(output), attester_sha256: sha(sourceBytes),
  prospective_freeze_sha256: sha(freezeBytes), validation_journal_sha256: sha(journalBytes), root_script_sha256: sha(await readFile(new URL(import.meta.url))),
  candidate: candidateBinding, original_inputs_preserved_before_native_validation: true, all194_report_rows_regraded: true,
  native_subprocesses_exit1_and_streams_closed: true, ROOT_observed_native_groups_absent: true, historical_protected_evidence_unchanged: true,
  model_full_byte_hash_verified: true, host_quality_gates_passed: false, production_role_approval: false, new_TEST_inference: false,
  native_binary_pinned_before_validation_by_recovery_wrapper: false,
  limitations: ["The host grader verifies production predictions/targets and summaries; raw RPC logits were not retained by these evaluators.",
    "Native binary fingerprint in recovery was collected after execution; no positive speed or complete independent native parity claim.",
    "Wrapper owners are defunct under external tool infrastructure; wrapper tool terminal exits are unavailable, native subprocess waits/exits are recorded.",
    "Training loss is TRAIN fit; repeated VALIDATION selection is not unseen TEST or a developer workflow improvement."]};
await writeFile(receiptPath, JSON.stringify(receipt, null, 2) + "\n", {flag: "wx", mode: 0o600});
console.log(JSON.stringify({status: "completed_honest_negative", report_sha256: receipt.host_selection_sha256, developer_scores: report.developer_individual_score_correctness,
  suites: Object.fromEntries(Object.entries(report.suites).map(([name, suite]) => [name, {records: suite.observed_records, gates: suite.original_gates}])), limitations: receipt.limitations}));
